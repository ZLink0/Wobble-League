import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AdventureSave,
  Athlete,
  RECRUITS,
  STADIUMS,
  recruitFound,
  resolveLineup,
  trophyCount,
} from '../game/adventure';
import { NpcDef, Poi, TILE, WORLD_H, WORLD_W, buildWorld, isSolidTile } from '../game/openWorldMap';
import { DrawEntity, Dir, WorldView, collectBuildings, collectDeco, drawAnimal, drawGround, drawPoiProp, renderMinimapCanvas } from '../game/worldRender';
import {
  MenuAction,
  RecruitPanel,
  SavePanel,
  SettingsPanel,
  ShopPanel,
  StadiumPanel,
  StatsPanel,
  StoryMenu,
  TeamPanel,
  TrainingPanel,
  TrophyPanel,
  WorldMapPanel,
} from './AdventureMenus';

type Overlay = null | 'menu' | 'map' | 'trophies' | 'team' | 'recruit' | 'stats' | 'save' | 'settings' | 'stadium' | 'shop' | 'training';
type HallId = 'hall_start' | 'hall_mid' | 'hall_neon';

interface DialogState {
  name: string;
  lines: string[];
  idx: number;
  after?: () => void;
}

interface NpcRuntime {
  def: NpcDef;
  x: number;
  y: number;
  tx: number;
  ty: number;
  wait: number;
  dir: Dir;
  walk: number;
}

interface Props {
  save: AdventureSave;
  onSaveChange: (next: AdventureSave) => void;
  onManualSave: (next: AdventureSave) => void;
  onPlayMatch: (stadium: number, match: number, posSave: AdventureSave) => void;
  onReset: () => void;
  onExit: () => void;
}

const NPC_HALL: Record<string, HallId> = { npc_hall1: 'hall_start', npc_hall2: 'hall_mid', npc_hall3: 'hall_neon' };
const WALK = 3.8;
const RUN = 6.4;

export function OpenWorldScreen({ save, onSaveChange, onManualSave, onPlayMatch, onReset, onExit }: Props) {
  const world = useMemo(() => buildWorld(), []);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);

  const saveRef = useRef(save);
  saveRef.current = save;

  const [overlay, setOverlay] = useState<Overlay>(null);
  const returnTo = useRef<Overlay>(null);
  const [stadiumIdx, setStadiumIdx] = useState(0);
  const [hallId, setHallId] = useState<HallId | null>(null);
  const [atCenter, setAtCenter] = useState(false);
  const [dialog, setDialog] = useState<DialogState | null>(null);
  const [toast, setToast] = useState('');
  const [prompt, setPrompt] = useState('');
  const [, force] = useState(0);

  const overlayRef = useRef<Overlay>(null);
  overlayRef.current = overlay;
  const dialogRef = useRef<DialogState | null>(null);
  dialogRef.current = dialog;

  const startPos = save.pos.x >= 0 ? save.pos : world.spawn;
  const st = useRef({
    px: startPos.x + 0.5,
    py: startPos.y + 0.5,
    dir: 'down' as Dir,
    walk: 0,
    moving: false,
    keys: new Set<string>(),
    joy: { x: 0, y: 0 },
    run: false,
    time: 0,
    nearest: null as null | { type: 'npc'; npc: NpcRuntime } | { type: 'poi'; poi: Poi },
    npcs: world.npcs.map<NpcRuntime>((n) => ({ def: n, x: n.x + 0.5, y: n.y + 0.5, tx: n.x + 0.5, ty: n.y + 0.5, wait: Math.random() * 3, dir: 'down', walk: 0 })),
    saveTimer: 0,
    lastSavedPos: { x: -1, y: -1 },
    promptText: '',
  });

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((t) => (t === msg ? '' : t)), 2600);
  }, []);

  const commit = useCallback(
    (next: AdventureSave) => {
      onSaveChange({ ...next, pos: { x: Math.floor(st.current.px), y: Math.floor(st.current.py) } });
    },
    [onSaveChange]
  );

  const openOverlay = (o: Overlay, fromMenu = false) => {
    returnTo.current = fromMenu ? 'menu' : null;
    setOverlay(o);
  };
  const closeOverlay = useCallback(() => {
    const back = returnTo.current;
    returnTo.current = null;
    setOverlay(back);
  }, []);

  /* ------------------------------ dialog ------------------------------ */
  const say = useCallback((name: string, lines: string[], after?: () => void) => {
    setDialog({ name, lines, idx: 0, after });
  }, []);
  const advanceDialog = useCallback(() => {
    setDialog((d) => {
      if (!d) return d;
      if (d.idx + 1 < d.lines.length) return { ...d, idx: d.idx + 1 };
      const cb = d.after;
      if (cb) window.setTimeout(cb, 0);
      return null;
    });
  }, []);

  /* ------------------------------ interaksi ------------------------------ */
  const interact = useCallback(() => {
    const near = st.current.nearest;
    if (!near) return;
    const s = saveRef.current;
    if (near.type === 'npc') {
      const d = near.npc.def;
      const line = d.lines[Math.floor(Math.random() * d.lines.length)];
      const lines = d.kind === 'villager' || d.kind === 'athlete' ? d.lines : [line];
      say(d.name, lines, () => {
        if (d.kind === 'shop') openOverlay('shop');
        else if (d.kind === 'recruiter') {
          setHallId(NPC_HALL[d.id] ?? 'hall_start');
          openOverlay('recruit');
        } else if (d.kind === 'coach') openOverlay('training');
        else if (d.kind === 'guard') {
          setAtCenter(true);
          openOverlay('save');
        }
      });
      return;
    }
    const p = near.poi;
    if (p.kind === 'stadium' && p.stadium !== undefined) {
      setStadiumIdx(p.stadium);
      if (!s.discovered[p.stadium]) {
        const d = [...s.discovered];
        d[p.stadium] = true;
        commit({ ...s, discovered: d });
      }
      openOverlay('stadium');
    } else if (p.kind === 'save') {
      setAtCenter(true);
      openOverlay('save');
    } else if (p.kind === 'shop') openOverlay('shop');
    else if (p.kind === 'hall') {
      setHallId(p.hall ?? 'hall_start');
      openOverlay('recruit');
    } else if (p.kind === 'train') openOverlay('training');
    else if (p.kind === 'rest') say('Area Istirahat', [p.text ?? 'Beristirahat sejenak.']);
    else if (p.kind === 'sign') say('Papan Petunjuk', [p.text ?? '...']);
    else if (p.kind === 'chest') {
      if (s.openedChests.includes(p.id)) say('Peti Harta', ['Peti ini sudah kosong.']);
      else {
        const coins = p.coins ?? 100;
        commit({ ...s, coins: s.coins + coins, openedChests: [...s.openedChests, p.id] });
        say('Peti Harta', [`Kamu menemukan 🪙 ${coins} koin!`]);
      }
    } else if (p.kind === 'found' && p.spot) {
      const r = recruitFound(s, p.spot);
      if (r.athlete) {
        commit(r.save);
        say(r.athlete.name, [`Aku ${r.athlete.name}, ${r.athlete.skill} adalah keahlianku!`, r.msg]);
      } else say('Atlet Misterius', [r.msg]);
    }
  }, [commit, say]);

  const interactRef = useRef(interact);
  interactRef.current = interact;

  /* ------------------------------ intro cerita ------------------------------ */
  useEffect(() => {
    if (!save.started) {
      say('Wali Kota Hop', [
        'Selamat datang di dunia Wobble League! Kamu adalah atlet pemula yang bermimpi jadi juara dunia.',
        'Ada 10 stadion tersebar di dunia ini. Berjalanlah ke setiap stadion dan menangkan turnamen 10 pertandingannya untuk mendapatkan 1 trofi.',
        'Kumpulkan 10 trofi untuk membuka World Championship! Jangan lupa rekrut atlet, beli perlengkapan, dan simpan progres di Player Save Center.',
        'Gunakan joystick untuk berjalan, tombol A untuk berbicara/masuk, dan MENU untuk peta, tim, dan lainnya. Semoga sukses!',
      ], () => commit({ ...saveRef.current, started: true }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ------------------------------ keyboard ------------------------------ */
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (overlayRef.current) return;
      if (dialogRef.current) {
        if (['Space', 'Enter', 'KeyZ', 'KeyE'].includes(e.code)) {
          e.preventDefault();
          advanceDialog();
        }
        return;
      }
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      if (['Space', 'Enter', 'KeyZ', 'KeyE'].includes(e.code)) {
        if (!e.repeat) interactRef.current();
        return;
      }
      if (e.code === 'Escape' || e.code === 'KeyM') {
        setOverlay('menu');
        return;
      }
      st.current.keys.add(e.code);
    };
    const up = (e: KeyboardEvent) => st.current.keys.delete(e.code);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, [advanceDialog]);

  // simpan posisi saat game ditutup / disembunyikan
  useEffect(() => {
    const flush = () => {
      if (saveRef.current.settings.autosave) {
        onSaveChange({ ...saveRef.current, pos: { x: Math.floor(st.current.px), y: Math.floor(st.current.py) } });
      }
    };
    document.addEventListener('visibilitychange', () => document.hidden && flush());
    window.addEventListener('pagehide', flush);
    return () => window.removeEventListener('pagehide', flush);
  }, [onSaveChange]);

  /* ------------------------------ loop utama ------------------------------ */
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext('2d')!;
    let raf = 0;
    let last = performance.now();
    let vw = 800;
    let vh = 400;
    let dpr = 1;
    const resize = () => {
      const r = wrap.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      vw = r.width;
      vh = r.height;
      canvas.width = Math.floor(vw * dpr);
      canvas.height = Math.floor(vh * dpr);
      canvas.style.width = `${vw}px`;
      canvas.style.height = `${vh}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const blockedAt = (x: number, y: number, ignore?: NpcRuntime) => {
      const r = 0.27;
      const pts = [
        [x - r, y - r * 0.2],
        [x + r, y - r * 0.2],
        [x - r, y + r],
        [x + r, y + r],
      ];
      for (const [cx, cy] of pts) if (isSolidTile(world, Math.floor(cx), Math.floor(cy))) return true;
      void ignore;
      return false;
    };
    const npcBlock = (x: number, y: number) => {
      for (const n of st.current.npcs) if (Math.hypot(n.x - x, n.y - y) < 0.55) return true;
      return false;
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = st.current;
      s.time += dt;
      const frozen = Boolean(overlayRef.current) || Boolean(dialogRef.current);

      // --- input ---
      let ix = s.joy.x;
      let iy = s.joy.y;
      if (!frozen) {
        const k = s.keys;
        if (k.has('ArrowLeft') || k.has('KeyA')) ix -= 1;
        if (k.has('ArrowRight') || k.has('KeyD')) ix += 1;
        if (k.has('ArrowUp') || k.has('KeyW')) iy -= 1;
        if (k.has('ArrowDown') || k.has('KeyS')) iy += 1;
      } else {
        ix = 0;
        iy = 0;
      }
      const mag = Math.hypot(ix, iy);
      s.moving = mag > 0.15;
      if (s.moving) {
        const running = s.run || s.keys.has('ShiftLeft') || s.keys.has('KeyX') || mag > 0.95;
        const sp = (running ? RUN : WALK) * Math.min(1, mag > 1 ? 1 : mag < 0.5 ? 0.6 : 1);
        const nx = ix / Math.max(1, mag);
        const ny = iy / Math.max(1, mag);
        const stepX = nx * sp * dt;
        const stepY = ny * sp * dt;
        if (!blockedAt(s.px + stepX, s.py) && !npcBlock(s.px + stepX, s.py)) s.px += stepX;
        if (!blockedAt(s.px, s.py + stepY) && !npcBlock(s.px, s.py + stepY)) s.py += stepY;
        s.dir = Math.abs(nx) > Math.abs(ny) ? (nx > 0 ? 'right' : 'left') : ny > 0 ? 'down' : 'up';
        s.walk += dt * (running ? 14 : 9);
      }

      // --- NPC ---
      for (const n of s.npcs) {
        if (n.def.wander <= 0) continue;
        n.wait -= dt;
        const d = Math.hypot(n.tx - n.x, n.ty - n.y);
        if (d > 0.05 && !frozen) {
          const nx = (n.tx - n.x) / d;
          const ny = (n.ty - n.y) / d;
          const nxp = n.x + nx * 1.0 * dt;
          const nyp = n.y + ny * 1.0 * dt;
          if (!isSolidTile(world, Math.floor(nxp), Math.floor(nyp)) && Math.hypot(nxp - s.px, nyp - s.py) > 0.8) {
            n.x = nxp;
            n.y = nyp;
            n.walk += dt * 7;
            n.dir = Math.abs(nx) > Math.abs(ny) ? (nx > 0 ? 'right' : 'left') : ny > 0 ? 'down' : 'up';
          } else n.tx = n.x;
        } else if (n.wait <= 0) {
          n.wait = 2 + Math.random() * 4;
          const ax = n.def.x + 0.5 + (Math.random() * 2 - 1) * n.def.wander;
          const ay = n.def.y + 0.5 + (Math.random() * 2 - 1) * n.def.wander;
          if (!isSolidTile(world, Math.floor(ax), Math.floor(ay))) {
            n.tx = ax;
            n.ty = ay;
          }
        }
      }

      // --- stadion ditemukan ---
      const sv = saveRef.current;
      for (let i = 0; i < world.stadiums.length; i++) {
        if (!sv.discovered[i]) {
          const door = world.stadiums[i].door;
          if (Math.hypot(door.x - s.px, door.y - s.py) < 9) {
            const d = [...sv.discovered];
            d[i] = true;
            onSaveChange({ ...sv, discovered: d, pos: { x: Math.floor(s.px), y: Math.floor(s.py) } });
            showToast(`🏟️ Stadion ditemukan: ${STADIUMS[i].name}!`);
            break;
          }
        }
      }

      // --- interaksi terdekat ---
      let best: typeof s.nearest = null;
      let bd = 1.7;
      for (const n of s.npcs) {
        const d = Math.hypot(n.x - s.px, n.y - s.py);
        if (d < bd) {
          bd = d;
          best = { type: 'npc', npc: n };
        }
      }
      for (const p of world.pois) {
        if (p.kind === 'found' && p.spot && sv.foundRecruits.includes(RECRUITS.find((r) => r.method.type === 'found' && r.method.spot === p.spot)?.athlete.id ?? '')) continue;
        const d = Math.hypot(p.x + 0.5 - s.px, p.y + 0.5 - s.py);
        if (d < bd) {
          bd = d;
          best = { type: 'poi', poi: p };
        }
      }
      s.nearest = best;
      const text = frozen ? '' : best ? (best.type === 'npc' ? `Bicara: ${best.npc.def.name}` : best.poi.label) : '';
      if (text !== s.promptText) {
        s.promptText = text;
        setPrompt(text);
      }

      // --- simpan posisi berkala ---
      s.saveTimer += dt;
      if (s.saveTimer > 5) {
        s.saveTimer = 0;
        const fx = Math.floor(s.px);
        const fy = Math.floor(s.py);
        if ((fx !== s.lastSavedPos.x || fy !== s.lastSavedPos.y) && saveRef.current.settings.autosave && saveRef.current.started) {
          s.lastSavedPos = { x: fx, y: fy };
          onSaveChange({ ...saveRef.current, pos: { x: fx, y: fy } });
        }
      }

      // --- render ---
      const ts = Math.max(26, Math.min(56, Math.round(vh / 11)));
      const view: WorldView = { camX: s.px, camY: s.py - 0.4, ts, vw, vh, time: s.time };
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawGround(ctx, world, view);
      const ents: DrawEntity[] = [];
      collectDeco(world, view, ents);
      collectBuildings(world, view, sv.discovered, sv.trophies, ents);
      const scr = (tx: number, ty: number) => ({ x: (tx - view.camX) * ts + vw / 2, y: (ty - view.camY) * ts + vh / 2 });
      for (const p of world.pois) {
        const q = scr(p.x, p.y);
        if (q.x < -ts || q.y < -ts || q.x > vw + ts || q.y > vh + ts) continue;
        if (p.kind === 'chest' || p.kind === 'sign' || p.kind === 'rest') {
          const opened = sv.openedChests.includes(p.id);
          ents.push({ y: p.y + 0.8, draw: (g) => drawPoiProp(g, p, q.x, q.y, ts, opened) });
        } else if (p.kind === 'found') {
          const def = RECRUITS.find((r) => r.method.type === 'found' && r.method.spot === p.spot);
          if (def && !sv.foundRecruits.includes(def.athlete.id)) {
            ents.push({ y: p.y + 0.95, draw: (g) => drawAnimal(g, def.athlete.animal, q.x + ts / 2, q.y + ts * 0.95, ts * 1.1, 'down', s.time * 3, { headband: '#facc15' }) });
          }
        }
      }
      for (const n of s.npcs) {
        const q = scr(n.x, n.y);
        if (q.x < -ts * 2 || q.y < -ts * 2 || q.x > vw + ts * 2 || q.y > vh + ts * 2) continue;
        ents.push({
          y: n.y + 0.2,
          draw: (g) => {
            drawAnimal(g, n.def.animal, q.x, q.y + ts * 0.35, ts * 1.1, n.dir, n.walk, {});
            if (n.def.kind !== 'villager') {
              const mark = n.def.kind === 'shop' ? '🛍️' : n.def.kind === 'recruiter' ? '🤝' : n.def.kind === 'coach' ? '🏋️' : n.def.kind === 'guard' ? '💾' : '⚽';
              g.font = `${Math.round(ts * 0.4)}px system-ui`;
              g.textAlign = 'center';
              g.fillText(mark, q.x, q.y - ts * 0.95);
            }
          },
        });
      }
      const captain = resolveLineup(sv, 1)[0];
      const pq = scr(s.px, s.py);
      ents.push({
        y: s.py + 0.2,
        draw: (g) => drawAnimal(g, captain.animal, pq.x, pq.y + ts * 0.35, ts * 1.2, s.dir, s.moving ? s.walk : 0, { headband: '#ef4444' }),
      });
      ents.sort((a, b) => a.y - b.y);
      for (const e of ents) e.draw(ctx);
      // penanda interaksi
      if (best && !frozen) {
        const tx = best.type === 'npc' ? best.npc.x : best.poi.x + 0.5;
        const ty = best.type === 'npc' ? best.npc.y : best.poi.y + 0.5;
        const q = scr(tx, ty);
        ctx.fillStyle = '#fde047';
        ctx.strokeStyle = '#7c2d12';
        ctx.lineWidth = 2;
        const bob = Math.sin(s.time * 6) * 3;
        ctx.beginPath();
        ctx.moveTo(q.x, q.y - ts * 1.25 + bob + 10);
        ctx.lineTo(q.x - 8, q.y - ts * 1.25 + bob);
        ctx.lineTo(q.x + 8, q.y - ts * 1.25 + bob);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      // mini-map
      if (sv.settings.minimap) {
        const mw = Math.min(150, vw * 0.22);
        const mh = (mw * WORLD_H) / WORLD_W;
        const mx = vw - mw - 8;
        const my = 44;
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = '#0b1530';
        ctx.fillRect(mx - 3, my - 3, mw + 6, mh + 6);
        ctx.drawImage(renderMinimapCanvas(world, 4), mx, my, mw, mh);
        ctx.globalAlpha = 1;
        world.stadiums.forEach((sd, i) => {
          ctx.fillStyle = sv.trophies[i] ? '#facc15' : sv.discovered[i] ? '#ffffff' : '#475569';
          ctx.beginPath();
          ctx.arc(mx + (sd.cx / WORLD_W) * mw, my + (sd.cy / WORLD_H) * mh, 2.6, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.fillStyle = '#ef4444';
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(mx + (s.px / WORLD_W) * mw, my + (s.py / WORLD_H) * mh, 3.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 2;
        ctx.strokeRect(mx - 3, my - 3, mw + 6, mh + 6);
      }
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [world, onSaveChange, showToast]);

  /* ------------------------------ joystick sentuh ------------------------------ */
  const joyRef = useRef<HTMLDivElement | null>(null);
  const joyActive = useRef<number | null>(null);
  const updateJoy = (clientX: number, clientY: number) => {
    const el = joyRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const max = r.width / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const d = Math.hypot(dx, dy);
    if (d > max) {
      dx = (dx / d) * max;
      dy = (dy / d) * max;
    }
    st.current.joy = { x: dx / max, y: dy / max };
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
  };
  const endJoy = () => {
    joyActive.current = null;
    st.current.joy = { x: 0, y: 0 };
    if (knobRef.current) knobRef.current.style.transform = 'translate(0px, 0px)';
  };

  /* ------------------------------ aksi menu ------------------------------ */
  const onMenuPick = (a: MenuAction) => {
    if (a === 'continue') return setOverlay(null);
    if (a === 'exit') {
      commit(saveRef.current);
      return onExit();
    }
    if (a === 'save') setAtCenter(false);
    if (a === 'recruit') setHallId(null);
    const map: Record<string, Overlay> = { map: 'map', trophies: 'trophies', team: 'team', recruit: 'recruit', stats: 'stats', save: 'save', settings: 'settings' };
    openOverlay(map[a], true);
  };

  const sv = save;
  void force;
  void TILE;
  void WORLD_W;
  return (
    <div className="fixed inset-0 z-40 bg-black select-none touch-none" data-testid="open-world-screen">
      <div ref={wrapRef} className="absolute inset-0">
        <canvas ref={canvasRef} className="absolute inset-0" />
      </div>

      {/* HUD atas */}
      <div className="absolute top-1.5 left-2 flex items-center gap-1.5 pointer-events-none">
        <span className="px-2 py-0.5 rounded-lg bg-slate-950/70 border-2 border-amber-300 text-amber-200 text-xs font-extrabold">🪙 {sv.coins}</span>
        <span className="px-2 py-0.5 rounded-lg bg-slate-950/70 border-2 border-yellow-300 text-yellow-200 text-xs font-extrabold">🏆 {trophyCount(sv)}/10</span>
      </div>
      <button
        type="button"
        data-testid="open-world-menu"
        onClick={() => setOverlay('menu')}
        className="absolute top-1.5 right-2 px-3 py-1 rounded-xl bg-gradient-to-b from-[#2f7bff] to-[#1546b8] border-2 border-sky-200 text-white text-xs font-extrabold cursor-pointer"
        style={{ right: 8 }}
      >
        ☰ MENU
      </button>

      {/* prompt */}
      {prompt && !dialog && !overlay && (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-24 sm:bottom-6 px-3 py-1 rounded-full bg-slate-950/80 border-2 border-amber-300 text-xs font-extrabold text-white pointer-events-none">
          <span className="inline-block w-5 h-5 rounded-full bg-amber-300 text-slate-900 text-center mr-1.5">A</span>
          {prompt}
        </div>
      )}
      {toast && <div className="absolute top-12 left-1/2 -translate-x-1/2 px-3 py-1 rounded-lg bg-emerald-600/90 border-2 border-emerald-200 text-xs font-extrabold text-white pointer-events-none">{toast}</div>}

      {/* kontrol sentuh */}
      {!overlay && !dialog && (
        <>
          <div
            ref={joyRef}
            data-testid="open-world-joystick"
            className="absolute left-4 bottom-4 w-28 h-28 rounded-full bg-white/15 border-2 border-white/50 touch-none"
            onPointerDown={(e) => {
              (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
              joyActive.current = e.pointerId;
              updateJoy(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => joyActive.current === e.pointerId && updateJoy(e.clientX, e.clientY)}
            onPointerUp={endJoy}
            onPointerCancel={endJoy}
          >
            <div ref={knobRef} className="absolute left-1/2 top-1/2 -ml-6 -mt-6 w-12 h-12 rounded-full bg-white/60 border-2 border-white pointer-events-none" />
          </div>
          <button
            type="button"
            data-testid="open-world-a"
            className="absolute right-6 bottom-8 w-16 h-16 rounded-full bg-gradient-to-b from-amber-300 to-amber-500 border-4 border-amber-100 text-slate-900 text-xl font-extrabold cursor-pointer touch-none"
            onPointerDown={(e) => {
              e.preventDefault();
              interact();
            }}
          >
            A
          </button>
          <button
            type="button"
            data-testid="open-world-run"
            className="absolute right-24 bottom-4 w-12 h-12 rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 border-4 border-emerald-100 text-white text-[10px] font-extrabold cursor-pointer touch-none"
            onPointerDown={(e) => {
              e.preventDefault();
              st.current.run = true;
            }}
            onPointerUp={() => (st.current.run = false)}
            onPointerLeave={() => (st.current.run = false)}
            onPointerCancel={() => (st.current.run = false)}
          >
            RUN
          </button>
        </>
      )}

      {/* dialog */}
      {dialog && (
        <div className="absolute inset-x-0 bottom-0 p-2 z-50" onPointerDown={advanceDialog} data-testid="open-world-dialog">
          <div className="max-w-2xl mx-auto rounded-2xl border-[3px] border-amber-300 bg-gradient-to-b from-blue-900 to-slate-950 p-3 text-white cursor-pointer">
            <div className="text-xs font-extrabold text-amber-300">{dialog.name}</div>
            <div className="text-sm mt-0.5 min-h-[2.5rem]">{dialog.lines[dialog.idx]}</div>
            <div className="text-[10px] text-right text-sky-300">{dialog.idx + 1 < dialog.lines.length ? 'Ketuk untuk lanjut ▶' : 'Ketuk untuk menutup ✓'}</div>
          </div>
        </div>
      )}

      {/* panel */}
      {overlay === 'menu' && <StoryMenu save={sv} onPick={onMenuPick} />}
      {overlay === 'map' && <WorldMapPanel save={sv} world={world} playerPos={{ x: st.current.px, y: st.current.py }} onClose={closeOverlay} />}
      {overlay === 'trophies' && <TrophyPanel save={sv} onClose={closeOverlay} />}
      {overlay === 'team' && <TeamPanel save={sv} onChange={commit} onClose={closeOverlay} />}
      {overlay === 'recruit' && <RecruitPanel save={sv} hall={hallId} onChange={commit} onClose={closeOverlay} />}
      {overlay === 'stats' && <StatsPanel save={sv} onClose={closeOverlay} />}
      {overlay === 'save' && (
        <SavePanel
          save={sv}
          atCenter={atCenter}
          onSave={() => onManualSave({ ...sv, pos: { x: Math.floor(st.current.px), y: Math.floor(st.current.py) }, manualSaves: sv.manualSaves + 1 })}
          onClose={closeOverlay}
        />
      )}
      {overlay === 'settings' && <SettingsPanel save={sv} onChange={commit} onReset={onReset} onClose={closeOverlay} />}
      {overlay === 'stadium' && (
        <StadiumPanel
          save={sv}
          stadium={stadiumIdx}
          onClose={closeOverlay}
          onPlay={(s, m) => onPlayMatch(s, m, { ...sv, pos: { x: Math.floor(st.current.px), y: Math.floor(st.current.py) } })}
        />
      )}
      {overlay === 'shop' && <ShopPanel save={sv} onChange={commit} onClose={closeOverlay} />}
      {overlay === 'training' && <TrainingPanel save={sv} onChange={commit} onClose={closeOverlay} />}
    </div>
  );
}

export type { Athlete };
