import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Check,
  ChevronLeft,
  ChevronRight,
  Dices,
  Footprints,
  Glasses,
  Palette,
  RotateCcw,
  Shield,
  Shirt,
  User,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  ANIMALS,
  CAPES,
  CLOTHES_STYLES,
  FUR_COLOR_PALETTE,
  HATS,
  MASKS,
  randomNpcCustomization,
  SHOE_STYLES,
  TRIM_COLOR_PALETTE,
} from '../game/catalog';
import { ClothesStyleId, PlayerCustomization, TeamId } from '../game/types';
import { useMenuController } from '../hooks/useMenuController';
import { CharacterPreview3D } from './CharacterPreview3D';
import { AccessoryIcon, AnimalIcon } from './MenuIcons';

export type CustomCategory =
  | 'athlete'
  | 'headwear'
  | 'clothes'
  | 'glasses'
  | 'shoes'
  | 'colors'
  | 'accessories';

const CATEGORIES: Array<{ id: CustomCategory; label: string }> = [
  { id: 'athlete', label: 'Athlete' },
  { id: 'headwear', label: 'Hats' },
  { id: 'clothes', label: 'Jersey' },
  { id: 'glasses', label: 'Glasses' },
  { id: 'shoes', label: 'Shoes' },
  { id: 'colors', label: 'Colors' },
  { id: 'accessories', label: 'Capes' },
];

interface CharacterCustomizationScreenProps {
  active: boolean;
  standalone?: boolean;
  team: TeamId;
  custom: PlayerCustomization;
  onChangeTeam: (team: TeamId) => void;
  onChangeCustom: (next: PlayerCustomization) => void;
  onBack: () => void;
  onReady: () => void;
}

function JerseyThumbSvg({
  styleId,
  team,
  trimColor,
}: {
  styleId: ClothesStyleId;
  team: TeamId;
  trimColor: string;
}) {
  const base = team === 'red' ? '#dc2626' : '#2563eb';
  const dark = team === 'red' ? '#991b1b' : '#1e3a8a';
  const hi = team === 'red' ? '#f87171' : '#60a5fa';
  const stripe = '#ffffff';
  const trim = trimColor || '#ffffff';

  return (
    <svg viewBox="0 0 80 76" className="w-16 h-16 drop-shadow-[0_3px_4px_rgba(0,0,0,0.45)]" aria-hidden="true">
      <defs>
        <clipPath id={`shirt-${styleId}-${team}`}>
          <path d="M24 10 L10 18 L4 34 L16 39 L21 29 L21 68 L59 68 L59 29 L64 39 L76 34 L70 18 L56 10 L48 14 C44 18 36 18 32 14 Z" />
        </clipPath>
      </defs>
      <g clipPath={`url(#shirt-${styleId}-${team})`}>
        <rect x="0" y="0" width="80" height="76" fill={base} />
        <rect x="0" y="0" width="80" height="22" fill={hi} opacity="0.28" />
        <rect x="0" y="54" width="80" height="22" fill={dark} opacity="0.45" />

        {styleId === 'stripe_vertical' && (
          <>
            <rect x="27" y="10" width="8" height="60" fill={stripe} />
            <rect x="45" y="10" width="8" height="60" fill={stripe} />
          </>
        )}
        {styleId === 'stripe_horizontal' && (
          <>
            <rect x="18" y="29" width="44" height="8" fill={stripe} />
            <rect x="18" y="45" width="44" height="8" fill={stripe} />
          </>
        )}
        {styleId === 'classic_sash' && (
          <polygon points="16,58 58,10 64,22 22,68" fill={stripe} />
        )}
        {styleId === 'split_hoop' && (
          <>
            <rect x="18" y="31" width="44" height="16" fill={stripe} />
            <rect x="18" y="28" width="44" height="3" fill={trim} />
            <rect x="18" y="47" width="44" height="3" fill={trim} />
          </>
        )}
        {styleId === 'pro_vneck' && (
          <>
            <polygon points="21,22 40,39 59,22 59,30 40,47 21,30" fill={stripe} />
            <polygon points="21,36 40,52 59,36 59,41 40,57 21,41" fill={trim} />
          </>
        )}

        {/* Sleeves shade */}
        <rect x="2" y="14" width="16" height="26" fill={dark} opacity="0.32" />
        <rect x="62" y="14" width="16" height="26" fill={dark} opacity="0.32" />
      </g>
      <path
        d="M24 10 L10 18 L4 34 L16 39 L21 29 L21 68 L59 68 L59 29 L64 39 L76 34 L70 18 L56 10 L48 14 C44 18 36 18 32 14 Z"
        fill="none"
        stroke="#0f172a"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
      <path
        d="M31 12 C35 19 45 19 49 12"
        fill="none"
        stroke={styleId === 'solid' ? dark : stripe}
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  );
}

function ShoeThumbSvg({ primaryColor, accentColor }: { primaryColor: string; accentColor: string }) {
  return (
    <svg viewBox="0 0 76 56" className="w-14 h-12 drop-shadow-[0_2px_4px_rgba(0,0,0,0.45)]" aria-hidden="true">
      <path
        d="M14 16 L34 16 L40 28 L62 32 C67 33 69 40 65 43 L12 43 L12 22 Z"
        fill={primaryColor}
        stroke="#0f172a"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
      <path d="M12 41 L66 41 L64 46 L12 46 Z" fill={accentColor} stroke="#0f172a" strokeWidth="1.8" />
      <rect x="16" y="46" width="5" height="4" rx="1" fill="#0f172a" />
      <rect x="30" y="46" width="5" height="4" rx="1" fill="#0f172a" />
      <rect x="44" y="46" width="5" height="4" rx="1" fill="#0f172a" />
      <rect x="56" y="46" width="5" height="4" rx="1" fill="#0f172a" />
      <path d="M27 24 L37 35" stroke={accentColor} strokeWidth="3.5" strokeLinecap="round" />
      <path d="M35 24 L44 35" stroke={accentColor} strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  );
}

function TeamCrestBadge({ team }: { team: TeamId }) {
  const isRed = team === 'red';
  return (
    <div className="flex flex-col items-center select-none">
      <svg viewBox="0 0 72 82" className="w-14 h-16 md:w-16 md:h-[72px] drop-shadow-[0_4px_10px_rgba(0,0,0,0.5)]" aria-hidden="true">
        <path
          d="M8 10 L36 4 L64 10 L62 46 C60 62 48 72 36 78 C24 72 12 62 10 46 Z"
          fill={isRed ? '#dc2626' : '#2563eb'}
          stroke="#facc15"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        <path
          d="M15 16 L36 11 L57 16 L55 44 C53 56 44 65 36 70 C28 65 19 56 17 44 Z"
          fill={isRed ? '#991b1b' : '#1e3a8a'}
        />
        <rect x="17" y="31" width="38" height="14" fill="#facc15" />
        <text
          x="36"
          y="41.5"
          textAnchor="middle"
          fill="#0f172a"
          fontSize="10.5"
          fontWeight="900"
          fontFamily="sans-serif"
        >
          {isRed ? 'RED' : 'BLU'}
        </text>
        <circle cx="36" cy="57" r="7.5" fill="#ffffff" stroke="#0f172a" strokeWidth="1.8" />
        <polygon points="36,52 40,55 38.5,60 33.5,60 32,55" fill="#0f172a" />
      </svg>
      <span className="mt-1 font-display font-extrabold text-sm md:text-base tracking-wider text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
        {isRed ? 'RED FC' : 'BLUE FC'}
      </span>
    </div>
  );
}

function renderTabIcon(id: CustomCategory) {
  switch (id) {
    case 'athlete':
      return <User className="w-5 h-5" />;
    case 'headwear':
      return (
        <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 14a7 7 0 0 1 14 0v2H5v-2Z" />
          <path d="M3 16h18l-1.5 2.5H5" />
        </svg>
      );
    case 'clothes':
      return <Shirt className="w-5 h-5" />;
    case 'glasses':
      return <Glasses className="w-5 h-5" />;
    case 'shoes':
      return <Footprints className="w-5 h-5" />;
    case 'colors':
      return <Palette className="w-5 h-5" />;
    case 'accessories':
      return <Shield className="w-5 h-5" />;
  }
}

export function CharacterCustomizationScreen({
  active,
  standalone = false,
  team,
  custom,
  onChangeTeam,
  onChangeCustom,
  onBack,
  onReady,
}: CharacterCustomizationScreenProps) {
  const [category, setCategory] = useState<CustomCategory>('clothes');
  const [facingYaw, setFacingYaw] = useState(0.38);
  const [zoomLevel, setZoomLevel] = useState(1.0);

  const selectedAnimalIdx = Math.max(0, ANIMALS.findIndex((a) => a.id === custom.animal));
  const selectedAnimal = ANIMALS[selectedAnimalIdx] ?? ANIMALS[0];
  const currentClothes: ClothesStyleId = custom.clothes ?? 'solid';
  const currentShoes = custom.shoes ?? 'classic_cleats';
  const currentTrim = custom.trimColor ?? '#ffffff';
  const shoeSpec = SHOE_STYLES.find((s) => s.id === currentShoes) ?? SHOE_STYLES[0];

  const patch = (p: Partial<PlayerCustomization>) => onChangeCustom({ ...custom, ...p });

  const cycleCategory = (dir: -1 | 1) => {
    const idx = CATEGORIES.findIndex((c) => c.id === category);
    setCategory(CATEGORIES[(idx + dir + CATEGORIES.length) % CATEGORIES.length].id);
  };

  const cycleCurrentCategoryItem = (dir: -1 | 1) => {
    if (category === 'athlete') {
      const next = ANIMALS[(selectedAnimalIdx + dir + ANIMALS.length) % ANIMALS.length];
      patch({ animal: next.id });
    } else if (category === 'clothes') {
      const idx = Math.max(0, CLOTHES_STYLES.findIndex((c) => c.id === currentClothes));
      patch({ clothes: CLOTHES_STYLES[(idx + dir + CLOTHES_STYLES.length) % CLOTHES_STYLES.length].id });
    } else if (category === 'headwear') {
      const idx = Math.max(0, HATS.findIndex((h) => h.id === custom.hat));
      patch({ hat: HATS[(idx + dir + HATS.length) % HATS.length].id });
    } else if (category === 'glasses') {
      const idx = Math.max(0, MASKS.findIndex((m) => m.id === custom.mask));
      patch({ mask: MASKS[(idx + dir + MASKS.length) % MASKS.length].id });
    } else if (category === 'shoes') {
      const idx = Math.max(0, SHOE_STYLES.findIndex((s) => s.id === currentShoes));
      patch({ shoes: SHOE_STYLES[(idx + dir + SHOE_STYLES.length) % SHOE_STYLES.length].id });
    } else if (category === 'colors') {
      const idx = Math.max(0, FUR_COLOR_PALETTE.findIndex((f) => f.hex === (custom.furColor ?? '')));
      patch({ furColor: FUR_COLOR_PALETTE[(idx + dir + FUR_COLOR_PALETTE.length) % FUR_COLOR_PALETTE.length].hex });
    } else {
      const idx = Math.max(0, CAPES.findIndex((c) => c.id === custom.cape));
      patch({ cape: CAPES[(idx + dir + CAPES.length) % CAPES.length].id });
    }
  };

  // Auto-scroll daftar pilihan ke item terpilih saat navigasi D-Pad / kontrol eksternal
  useEffect(() => {
    try {
      const root = document.querySelector('[data-testid="character-customization-screen"]');
      const el = root?.querySelector('[class*="ring-amber-300/70"]');
      el?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    } catch {
      // auto-scroll hanya pelengkap; abaikan jika gagal
    }
  }, [category, custom]);

  useMenuController({
    active,
    onRotateStick: (dx) => setFacingYaw((y) => y + dx),
    onAction: (action) => {
      if (action === 'lb') cycleCategory(-1);
      else if (action === 'rb') cycleCategory(1);
      else if (action === 'up') cycleCategory(-1);
      else if (action === 'down') cycleCategory(1);
      else if (action === 'left') cycleCurrentCategoryItem(-1);
      else if (action === 'right') cycleCurrentCategoryItem(1);
      else if (action === 'lt') setZoomLevel((z) => Math.max(0.75, +(z - 0.1).toFixed(2)));
      else if (action === 'rt') setZoomLevel((z) => Math.min(1.4, +(z + 0.1).toFixed(2)));
      else if (action === 'back') onBack();
      else if (action === 'start' || action === 'confirm') onReady();
    },
  });

  // Real attribute metrics based on selected athlete & footwear
  const speedStat = Math.round(
    selectedAnimal.speedBonus * 1450 + (currentShoes === 'speed_stripes' ? 180 : 40)
  );
  const powerStat = Math.round(
    selectedAnimal.kickPowerBonus * 1650 +
      (currentShoes === 'heavy_stompers' ? 240 : currentShoes === 'gold_boots' ? 150 : 40)
  );
  const controlStat = Math.round(
    1120 + (shoeSpec.bulkScale <= 1.0 ? 180 : 70) + (custom.hat !== 'none' ? 95 : 0)
  );

  const statRows = [
    { label: 'SPEED', val: speedStat, pct: Math.min(98, Math.round((speedStat / 2100) * 100)), icon: 'speed' as const },
    { label: 'POWER', val: powerStat, pct: Math.min(98, Math.round((powerStat / 2450) * 100)), icon: 'power' as const },
    { label: 'SKILL', val: controlStat, pct: Math.min(98, Math.round((controlStat / 1800) * 100)), icon: 'skill' as const },
  ];

  return (
    <div
      data-testid="character-customization-screen"
      className="fixed inset-0 z-30 flex flex-col overflow-hidden pointer-events-auto select-none"
    >
      {/* Sunlit Open-Air Stadium Sky & Pitch Backdrop (matching reference composition) */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute inset-x-0 top-0 h-[62%]"
          style={{
            background: 'linear-gradient(180deg, #2b82c9 0%, #6fc3ef 58%, #cbeafe 100%)',
          }}
        />
        {/* Soft distant stadium stand & cloud silhouettes */}
        <div
          className="absolute inset-x-0 top-[44%] h-[20%] opacity-40"
          style={{
            background: 'linear-gradient(180deg, rgba(15,23,42,0.12) 0%, rgba(15,23,42,0.55) 100%)',
          }}
        />
        <div
          className="absolute inset-x-0 bottom-0 h-[42%]"
          style={{
            background:
              'repeating-linear-gradient(90deg, #3ba448 0px, #3ba448 110px, #33913f 110px, #33913f 220px)',
            boxShadow: 'inset 0 18px 34px rgba(0,0,0,0.22)',
          }}
        />
        {/* Crisp white pitch touchline */}
        <div className="absolute inset-x-0 top-[58%] h-1.5 bg-white/65" />
      </div>

      {/* Top Header Bar: Circular Back + Bold Title (Left) | Team Toggle & Randomize (Right) */}
      <header className="relative z-10 flex flex-wrap items-center justify-between gap-2 px-3 sm:px-6 pt-2 sm:pt-3 pb-1">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            data-testid="custom-back-btn"
            aria-label="Back"
            onClick={onBack}
            className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-slate-900/75 hover:bg-slate-800 border-2 border-white text-white flex items-center justify-center shadow-lg cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
          <h2 className="font-display font-extrabold text-xl sm:text-2xl md:text-3xl text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.65)] tracking-wide">
            Customize
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center p-1 rounded-xl bg-slate-950/65 backdrop-blur-sm border border-white/25">
            <button
              type="button"
              data-testid="custom-team-red"
              onClick={() => onChangeTeam('red')}
              className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer whitespace-nowrap ${
                team === 'red' ? 'bg-red-600 text-white shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              Red Team
            </button>
            <button
              type="button"
              data-testid="custom-team-blue"
              onClick={() => onChangeTeam('blue')}
              className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer whitespace-nowrap ${
                team === 'blue' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              Blue Team
            </button>
          </div>

          <button
            type="button"
            onClick={() => onChangeCustom(randomNpcCustomization(Math.floor(Math.random() * 10000)))}
            className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 border-2 border-white/80 text-slate-950 text-xs font-extrabold flex items-center gap-1.5 shadow-md cursor-pointer whitespace-nowrap"
          >
            <Dices className="w-4 h-4" /> Random
          </button>
        </div>
      </header>

      {/* Main Split Stage: Side-by-side on horizontal sm+ screens and desktop */}
      <div className="relative z-10 flex-1 min-h-0 px-3 sm:px-6 pb-2 sm:pb-4 grid grid-cols-1 sm:grid-cols-12 gap-3 sm:gap-4 items-center">
        {/* Left/Center: Team Crest + Bottom-Left Stat Bars + Open-Air Standing 3D Character */}
        <div className="sm:col-span-5 lg:col-span-6 relative h-[220px] sm:h-full flex items-center justify-center">
          {/* Top-Left Team Crest Badge */}
          <div className="absolute top-1 sm:top-3 left-1 sm:left-3 z-20 scale-90 sm:scale-100 origin-top-left">
            <TeamCrestBadge team={team} />
          </div>

          {/* Bottom-Left 3 Attribute Stat Bars (raised on compact landscape so touch D-pad doesn't cover them) */}
          <div className="absolute top-[74px] sm:top-[82px] lg:top-auto lg:bottom-3 left-1 sm:left-3 z-20 flex flex-col gap-1 lg:gap-2.5 w-28 sm:w-36 lg:w-44">
            {statRows.map((st) => (
              <div key={st.label} className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-gradient-to-b from-sky-400 to-blue-700 border-2 border-white shadow-md flex items-center justify-center shrink-0 text-white">
                  {st.icon === 'speed' ? (
                    <Footprints className="w-4 h-4" />
                  ) : st.icon === 'power' ? (
                    <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor">
                      <path d="M13 2L4 14h7l-1 8 10-12h-7l0-8z" />
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.2">
                      <circle cx="12" cy="12" r="9" />
                      <polygon points="12,7 16,10 14.5,15 9.5,15 8,10" fill="currentColor" />
                    </svg>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between text-[11px] font-extrabold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] mb-0.5">
                    <span>{st.label}</span>
                    <span className="font-mono-num tabular-nums">{st.val}</span>
                  </div>
                  <div className="h-3 rounded-full bg-slate-950/80 border border-white/60 overflow-hidden p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-amber-300 to-yellow-400"
                      style={{ width: `${st.pct}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Standing Open-Pitch 3D Character */}
          <div className="w-full h-full relative">
            <CharacterPreview3D
              team={team}
              custom={custom}
              facingYaw={facingYaw}
              spinEnabled={false}
              openPitch={true}
              zoomLevel={zoomLevel}
              dragRotate={true}
              onYawChange={setFacingYaw}
            />

            {/* Compact Rotate/Zoom Pill Controls Bottom-Right of Character Stage */}
            <div className="absolute bottom-3 right-3 flex items-center gap-1 bg-slate-950/65 backdrop-blur-sm border border-white/25 rounded-xl p-1">
              <button
                type="button"
                aria-label="Rotate Left"
                onClick={() => setFacingYaw((y) => y - 0.5)}
                className="p-1.5 rounded-lg hover:bg-white/15 text-white cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                aria-label="Reset Angle"
                onClick={() => {
                  setFacingYaw(0.38);
                  setZoomLevel(1.0);
                }}
                className="p-1.5 rounded-lg hover:bg-white/15 text-amber-300 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                aria-label="Rotate Right"
                onClick={() => setFacingYaw((y) => y + 0.5)}
                className="p-1.5 rounded-lg hover:bg-white/15 text-white cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <div className="w-px h-4 bg-white/20 mx-0.5" />
              <button
                type="button"
                aria-label="Zoom Out"
                onClick={() => setZoomLevel((z) => Math.max(0.75, +(z - 0.15).toFixed(2)))}
                className="p-1.5 rounded-lg hover:bg-white/15 text-white cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                type="button"
                aria-label="Zoom In"
                onClick={() => setZoomLevel((z) => Math.min(1.4, +(z + 0.15).toFixed(2)))}
                className="p-1.5 rounded-lg hover:bg-white/15 text-white cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Horizontal Tactile Category Icon Tabs + Framed Blue 3-Column Card Grid */}
        <div className="sm:col-span-7 lg:col-span-6 flex flex-col gap-2 max-w-[560px] w-full mx-auto">
          {/* Category Icon Strip */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2 px-1">
            {CATEGORIES.map((cat) => {
              const isAct = category === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  data-testid={`custom-cat-${cat.id}`}
                  aria-label={cat.label}
                  title={cat.label}
                  onClick={() => setCategory(cat.id)}
                  className={`h-9 sm:h-11 lg:h-12 rounded-xl border-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-transform ${
                    isAct
                      ? 'bg-gradient-to-b from-sky-300 via-sky-500 to-blue-700 border-white text-white shadow-[0_4px_14px_rgba(14,165,233,0.65)] -translate-y-0.5'
                      : 'bg-gradient-to-b from-amber-300 via-amber-400 to-orange-500 border-amber-100 text-white shadow-[0_3px_0_#b45309] hover:brightness-105'
                  }`}
                >
                  {renderTabIcon(cat.id)}
                  <span className="text-[8px] lg:text-[9px] font-extrabold leading-none tracking-tight hidden sm:block">
                    {cat.label}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Blue Framed 3-Column Visual Card Grid */}
          <div className="rounded-2xl border-[3px] border-sky-400 bg-gradient-to-b from-blue-950/80 via-slate-900/85 to-blue-950/90 backdrop-blur-md shadow-[0_14px_38px_rgba(2,132,199,0.4)] p-2 sm:p-3">
            <div className="flex items-center justify-between px-1 pb-1.5 border-b border-white/15 mb-2">
              <span className="font-display font-extrabold text-xs sm:text-sm text-sky-200 uppercase tracking-wider">
                {CATEGORIES.find((c) => c.id === category)?.label} · {selectedAnimal.name}
              </span>
              <span className="text-[10px] sm:text-[11px] font-bold text-amber-300">
                LB / RB : Tab
              </span>
            </div>

            <div className="h-[155px] lg:h-[360px] overflow-y-auto custom-scroll pr-1">
              {category === 'clothes' && (
                <div className="space-y-2.5">
                  <div className="grid grid-cols-3 gap-2">
                    {CLOTHES_STYLES.map((st) => {
                      const isSel = currentClothes === st.id;
                      return (
                        <button
                          key={st.id}
                          type="button"
                          data-testid={`clothes-opt-${st.id}`}
                          onClick={() => patch({ clothes: st.id })}
                          className={`relative rounded-xl border-2 p-1.5 flex flex-col items-center justify-between h-[126px] cursor-pointer ${
                            isSel
                              ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                              : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                          }`}
                        >
                          {isSel && (
                            <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </span>
                          )}
                          <div className="flex-1 flex items-center justify-center">
                            <JerseyThumbSvg styleId={st.id} team={team} trimColor={currentTrim} />
                          </div>
                          <div
                            className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                              isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                            }`}
                          >
                            {st.name}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {currentClothes !== 'solid' && (
                    <div className="rounded-xl p-2.5 bg-slate-950/60 border border-white/15">
                      <div className="text-[10px] font-extrabold uppercase tracking-wider text-sky-200 mb-2">
                        Pattern Accent Trim
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        {TRIM_COLOR_PALETTE.map((tc) => {
                          const isSel = currentTrim === tc.hex;
                          return (
                            <button
                              key={tc.id}
                              type="button"
                              onClick={() => patch({ trimColor: tc.hex })}
                              className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 text-[10px] font-bold cursor-pointer ${
                                isSel
                                  ? 'border-amber-300 bg-sky-500/30 text-white'
                                  : 'border-white/15 bg-slate-900/70 text-slate-200 hover:border-white/40'
                              }`}
                            >
                              <span
                                className="w-3.5 h-3.5 rounded-full border border-white/50"
                                style={{ backgroundColor: tc.hex }}
                              />
                              <span>{tc.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {category === 'athlete' && (
                <div className="grid grid-cols-3 gap-2.5">
                  {ANIMALS.map((a) => {
                    const isSel = a.id === custom.animal;
                    return (
                      <button
                        key={a.id}
                        type="button"
                        data-testid={`animal-opt-${a.id}`}
                        onClick={() => patch({ animal: a.id })}
                        className={`relative rounded-xl border-2 p-2 flex flex-col items-center justify-between aspect-[1/1.05] cursor-pointer ${
                          isSel
                            ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                            : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                        }`}
                      >
                        {isSel && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                        )}
                        <div className="flex-1 flex items-center justify-center">
                          <AnimalIcon animal={a} className="w-14 h-14" />
                        </div>
                        <div
                          className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                            isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                          }`}
                        >
                          {a.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {category === 'headwear' && (
                <div className="grid grid-cols-3 gap-2.5">
                  {HATS.map((h) => {
                    const isSel = custom.hat === h.id;
                    return (
                      <button
                        key={h.id}
                        type="button"
                        data-testid={`hat-opt-${h.id}`}
                        onClick={() => patch({ hat: h.id })}
                        className={`relative rounded-xl border-2 p-2 flex flex-col items-center justify-between aspect-[1/1.05] cursor-pointer ${
                          isSel
                            ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                            : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                        }`}
                      >
                        {isSel && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                        )}
                        <div className="flex-1 flex items-center justify-center">
                          <AccessoryIcon item={h} className="w-14 h-14" />
                        </div>
                        <div
                          className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                            isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                          }`}
                        >
                          {h.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {category === 'glasses' && (
                <div className="grid grid-cols-3 gap-2.5">
                  {MASKS.map((m) => {
                    const isSel = custom.mask === m.id;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        data-testid={`mask-opt-${m.id}`}
                        onClick={() => patch({ mask: m.id })}
                        className={`relative rounded-xl border-2 p-2 flex flex-col items-center justify-between aspect-[1/1.05] cursor-pointer ${
                          isSel
                            ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                            : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                        }`}
                      >
                        {isSel && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                        )}
                        <div className="flex-1 flex items-center justify-center">
                          <AccessoryIcon item={m} className="w-14 h-14" />
                        </div>
                        <div
                          className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                            isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                          }`}
                        >
                          {m.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {category === 'shoes' && (
                <div className="grid grid-cols-3 gap-2.5">
                  {SHOE_STYLES.map((sh) => {
                    const isSel = currentShoes === sh.id;
                    return (
                      <button
                        key={sh.id}
                        type="button"
                        data-testid={`shoes-opt-${sh.id}`}
                        onClick={() => patch({ shoes: sh.id })}
                        className={`relative rounded-xl border-2 p-2 flex flex-col items-center justify-between aspect-[1/1.05] cursor-pointer ${
                          isSel
                            ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                            : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                        }`}
                      >
                        {isSel && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                        )}
                        <div className="flex-1 flex items-center justify-center">
                          <ShoeThumbSvg primaryColor={sh.primaryColor} accentColor={sh.accentColor} />
                        </div>
                        <div
                          className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                            isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                          }`}
                        >
                          {sh.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {category === 'colors' && (
                <div className="space-y-3">
                  <div className="text-[11px] font-extrabold uppercase tracking-wider text-sky-200">
                    Fur &amp; Coat Color
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {FUR_COLOR_PALETTE.map((fc) => {
                      const isSel = (custom.furColor ?? '') === fc.hex;
                      return (
                        <button
                          key={fc.name}
                          type="button"
                          data-testid={`fur-opt-${fc.name}`}
                          onClick={() => patch({ furColor: fc.hex })}
                          className={`relative rounded-xl border-2 p-2 flex flex-col items-center justify-between aspect-[1/1.02] cursor-pointer ${
                            isSel
                              ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                              : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                          }`}
                        >
                          {isSel && (
                            <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </span>
                          )}
                          <div className="flex-1 flex items-center justify-center">
                            <span
                              className="w-11 h-11 rounded-full border-2 border-white/80 shadow-inner"
                              style={{ backgroundColor: fc.hex || selectedAnimal.bodyColor }}
                            />
                          </div>
                          <div
                            className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                              isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                            }`}
                          >
                            {fc.name}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {category === 'accessories' && (
                <div className="grid grid-cols-3 gap-2.5">
                  {CAPES.map((c) => {
                    const isSel = custom.cape === c.id;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        data-testid={`cape-opt-${c.id}`}
                        onClick={() => patch({ cape: c.id })}
                        className={`relative rounded-xl border-2 p-2 flex flex-col items-center justify-between aspect-[1/1.05] cursor-pointer ${
                          isSel
                            ? 'border-amber-300 ring-2 ring-amber-300/70 bg-gradient-to-b from-sky-400/45 via-blue-700/75 to-blue-950'
                            : 'border-sky-300/35 bg-gradient-to-b from-sky-200/20 via-blue-800/60 to-slate-950/85 hover:border-sky-300/80'
                        }`}
                      >
                        {isSel && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center shadow">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                        )}
                        <div className="flex-1 flex items-center justify-center">
                          <AccessoryIcon item={c} className="w-14 h-14" />
                        </div>
                        <div
                          className={`w-full rounded-md px-1.5 py-1 text-[10px] font-extrabold text-center truncate ${
                            isSel ? 'bg-emerald-400 text-slate-950' : 'bg-slate-950/85 text-white'
                          }`}
                        >
                          {c.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Bottom-Right Confirm / Ready CTA */}
          <div className="flex items-center justify-between gap-2 pt-0.5 lg:pt-1">
            <span className="text-[10px] lg:text-[11px] font-bold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]">
              Drag character to spin · B : Back
            </span>
            <button
              type="button"
              data-testid="custom-ready-btn"
              data-start="true"
              onClick={onReady}
              className="px-5 py-1.5 lg:px-7 lg:py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 border-2 border-white text-slate-950 font-display font-extrabold text-xs lg:text-sm tracking-wide shadow-lg cursor-pointer whitespace-nowrap"
            >
              {standalone ? 'SAVE & CLOSE (START)' : 'START : READY'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
