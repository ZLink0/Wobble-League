import { ControllerStatus } from './ControllerStatus';
import { useEffect, useState } from 'react';
import { DEFAULT_CONTROL_MAPPING } from '../game/catalog';
import { gamepadManager, PadAction, PadButtonMap } from '../game/gamepadManager';
import { ControlMapping, KeyBindingConfig } from '../game/types';

interface ControlMappingPanelProps {
  mapping: ControlMapping;
  onChange: (next: ControlMapping) => void;
}

interface ControlMappingModalProps extends ControlMappingPanelProps {
  onClose: () => void;
}

const LABELS: Array<{ key: keyof KeyBindingConfig; label: string }> = [
  { key: 'up', label: 'Move Up' },
  { key: 'down', label: 'Move Down' },
  { key: 'left', label: 'Move Left' },
  { key: 'right', label: 'Move Right' },
  { key: 'run', label: 'Run (Hold)' },
  { key: 'kick', label: 'A · Tap: 180° Kick Left / Hold: Super Kick / Jump+A: Fire Backflip / Throw' },
  { key: 'kickRightSpin', label: 'X · Tap: 180° Kick Right / Hold Long: Mega Punch / Jump+X: Lob Backflip' },
  { key: 'grabProp', label: 'Y · Grab / Drop Arena Prop' },
  { key: 'jump', label: 'B · Jump' },
  { key: 'headSpinLeft', label: 'L · 360° Long Neck Head' },
  { key: 'dash', label: 'R · Dash Forward (1s Cooldown)' },
];

export function ControlMappingPanel({ mapping, onChange }: ControlMappingPanelProps) {
  const [slot, setSlot] = useState<'p1' | 'p2' | 'p3' | 'p4'>('p1');
  const [listeningKey, setListeningKey] = useState<keyof KeyBindingConfig | null>(null);
  const [devices, setDevices] = useState(() => gamepadManager.getDevices());
  const [deviceKey, setDeviceKey] = useState('');
  const [listeningPadAction, setListeningPadAction] = useState<PadAction | null>(null);
  const pad = devices.find(d => d.key === deviceKey);
  const padMap: PadButtonMap = deviceKey ? gamepadManager.getButtonMap(deviceKey) : { kick:0, jump:1, kick2:2, grab:3, head:4, dash:5, start:9 };

  const activeMap: KeyBindingConfig =
    mapping[slot] ?? DEFAULT_CONTROL_MAPPING[slot] ?? DEFAULT_CONTROL_MAPPING.p1;

  useEffect(() => {
    if (!listeningKey) return;
    document.body.dataset.capturingKey = '1';
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      if (e.code === 'Escape') {
        setListeningKey(null);
        return;
      }
      onChange({
        ...mapping,
        [slot]: {
          ...activeMap,
          [listeningKey]: e.code,
        },
      });
      setListeningKey(null);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      delete document.body.dataset.capturingKey;
    };
  }, [listeningKey, mapping, activeMap, onChange, slot]);

  useEffect(() => {
    const refresh = () => { const next = gamepadManager.getDevices(); setDevices(next); if (!deviceKey && next.length) setDeviceKey(next[0].key); };
    refresh(); const id = window.setInterval(refresh, 300); return () => window.clearInterval(id);
  }, [deviceKey]);

  useEffect(() => {
    if (!listeningPadAction || !pad) return;
    let previous = new Set<number>();
    const id = window.setInterval(() => {
      const gp = navigator.getGamepads?.()[pad.index]; if (!gp) return;
      const pressed = new Set<number>();
      gp.buttons.forEach((b, i) => { if (b.pressed || b.value > 0.65) pressed.add(i); });
      const newly = [...pressed].find(i => !previous.has(i));
      previous = pressed;
      if (newly !== undefined) {
        gamepadManager.setButtonMap(pad.key, { ...gamepadManager.getButtonMap(pad.key), [listeningPadAction]: newly });
        setListeningPadAction(null);
      }
    }, 30);
    return () => window.clearInterval(id);
  }, [listeningPadAction, pad]);

  return (
    <div className="space-y-2.5">
      <section className="rounded-xl border border-emerald-300/40 bg-emerald-950/30 p-3 space-y-2">
        <div className="text-xs font-extrabold text-emerald-100">Universal Bluetooth / USB Gamepad Mapping</div>
        <p className="text-[10px] text-emerald-200">Pilih perangkat, lalu tekan fungsi dan tombol fisik pada controller. Joy-Con hanya dapat dipilih dan di-mapping manual; tidak otomatis masuk ke slot pemain.</p>
        <select aria-label="Pilih controller" value={deviceKey} onChange={e => setDeviceKey(e.target.value)} className="w-full rounded-lg bg-slate-900 text-white border border-emerald-300/40 p-2 text-xs">
          <option value="">Pilih controller...</option>
          {devices.map(d => <option key={d.key} value={d.key}>{d.name} · {d.kind} · #{d.index}{d.slot ? ` · P${d.slot}` : ' · Belum ditugaskan'}</option>)}
        </select>
        {pad && <div className="grid grid-cols-2 gap-2">{([['kick','A / Kick 1'],['jump','B / Jump'],['kick2','X / Kick 2'],['grab','Y / Grab'],['head','L / Long Head'],['dash','R / Dash'],['start','Start / Menu']] as [PadAction,string][]).map(([action,label]) => <button key={action} type="button" onClick={() => setListeningPadAction(action)} className={`rounded-lg px-2 py-2 text-xs font-bold border ${listeningPadAction === action ? 'bg-amber-400 text-slate-950 border-amber-200' : 'bg-slate-900 text-white border-emerald-300/40'}`}>{label}: {listeningPadAction === action ? 'Tekan tombol...' : `Button ${padMap[action]}`}</button>)}</div>}
        {!pad && <p className="text-[10px] text-amber-200">Sambungkan controller, tekan tombol, lalu pilih perangkat di sini.</p>}
      </section>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-sky-100">
          Click any action and press a key. Up to 4 Local Players supported (Gamepads 1–4 + 4 Keyboards).
        </p>
        <div className="flex items-center gap-1.5 shrink-0">
          {(['p1', 'p2', 'p3', 'p4'] as const).map((pKey, idx) => (
            <button
              key={pKey}
              type="button"
              onClick={() => setSlot(pKey)}
              className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer border ${
                slot === pKey
                  ? 'bg-amber-400 text-slate-950 border-amber-200'
                  : 'bg-blue-900/80 text-white border-sky-300/40'
              }`}
            >
              P{idx + 1}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {LABELS.map((item) => {
          const isListening = listeningKey === item.key;
          return (
            <div
              key={item.key}
              className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-blue-950/60 border border-sky-300/35"
            >
              <span className="text-xs text-white font-semibold leading-snug">{item.label}</span>
              <button
                type="button"
                onClick={() => setListeningKey(item.key)}
                className={`px-3 py-1 rounded-lg font-mono-num text-xs font-extrabold cursor-pointer shrink-0 ${
                  isListening
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-blue-800 hover:bg-blue-700 text-amber-300 border border-sky-300/40'
                }`}
              >
                {isListening ? 'Key...' : activeMap[item.key]}
              </button>
            </div>
          );
        })}
      </div>

      <div className="pt-1 flex justify-end">
        <button
          type="button"
          onClick={() => onChange(DEFAULT_CONTROL_MAPPING)}
          className="px-4 py-1.5 rounded-xl bg-blue-900/80 hover:bg-blue-800 border border-sky-300/40 text-white text-xs font-bold cursor-pointer"
        >
          Reset Key Defaults
        </button>
      </div>
    </div>
  );
}

export function ControlMappingModal({ mapping, onChange, onClose }: ControlMappingModalProps) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 bg-gradient-to-b from-sky-500/75 via-sky-300/45 to-emerald-500/45 backdrop-blur-sm pointer-events-auto">
      <div className="w-full max-w-2xl rounded-2xl border-[3px] border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-[0_16px_42px_rgba(2,132,199,0.5)] overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-sky-300/35 bg-blue-900/45">
          <h2 className="font-display font-extrabold text-lg text-white">Button Mapping &amp; Gamepad</h2>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-extrabold cursor-pointer"
          >
            Done
          </button>
        </div>
        <div className="p-4 sm:p-5 max-h-[75vh] overflow-y-auto custom-scroll">
          <div className="mb-3">
            <ControllerStatus />
            <p className="text-[10px] text-sky-200 mt-1">
              Layout tombol controller (sama untuk Xbox, PlayStation, dan Nintendo — mengikuti POSISI FISIK): tombol bawah = Kick 1, kanan = Jump, kiri = Kick 2, atas = Grab, L/LB = Long Head, R/RB = Dash, Start/Options/+ = Start/Menu, analog kiri = gerak.
            </p>
          </div>
          <ControlMappingPanel mapping={mapping} onChange={onChange} />
        </div>
      </div>
    </div>
  );
}
