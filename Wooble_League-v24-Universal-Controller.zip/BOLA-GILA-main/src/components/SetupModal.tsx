import { useRef, useState } from 'react';
import { useDomFocusNav } from '../hooks/useDomFocusNav';
import { Dices, Shuffle, Users, Wifi } from 'lucide-react';
import {
  ANIMALS,
  ARENAS,
  BALLS,
  CAPES,
  CENTER_ITEMS,
  createTrainingConfig,
  HATS,
  MASKS,
  randomNpcCustomization,
} from '../game/catalog';
import { CenterItemType, GameMode, MatchConfig, PlayerCustomization, TeamId } from '../game/types';
import { CharacterPreview3D } from './CharacterPreview3D';
import {
  AccessoryIcon,
  AnimalIcon,
  ArenaPreviewIcon,
  BallPreviewIcon,
  ItemSpawnIcon,
} from './MenuIcons';

interface SetupModalProps {
  config: MatchConfig;
  highestStoryStage: number;
  lanRoomCode: string | null;
  lanRole: 'host' | 'guest' | null;
  backLabel?: string;
  onChangeConfig: (next: MatchConfig) => void;
  onSetLan: (roomCode: string | null, role: 'host' | 'guest' | null) => void;
  onOpenStoryMap?: () => void;
  onStartMatch: () => void;
  onBack: () => void;
}

export function SetupModal({
  config,
  highestStoryStage,
  lanRoomCode,
  lanRole,
  backLabel = 'Back',
  onChangeConfig,
  onSetLan,
  onOpenStoryMap,
  onStartMatch,
  onBack,
}: SetupModalProps) {
  const [editingSlot, setEditingSlot] = useState<1 | 2>(1);
  const [customTab, setCustomTab] = useState<'animal' | 'hat' | 'mask' | 'cape'>('animal');
  const [lanInput, setLanInput] = useState(lanRoomCode ?? 'PITCH-101');

  const activeCustom: PlayerCustomization = editingSlot === 1 ? config.p1Custom : config.p2Custom;
  const activeTeam: TeamId = editingSlot === 1 ? config.p1Team : config.p2Team;

  const updateCustom = (patch: Partial<PlayerCustomization>) => {
    if (editingSlot === 1) {
      onChangeConfig({ ...config, p1Custom: { ...config.p1Custom, ...patch } });
    } else {
      onChangeConfig({ ...config, p2Custom: { ...config.p2Custom, ...patch } });
    }
  };

  const randomizeOutfit = () => {
    updateCustom(randomNpcCustomization(Math.floor(Math.random() * 10000)));
  };

  const applyPresetSize = (n: 1 | 2 | 3) => {
    onChangeConfig({ ...config, redCount: n, blueCount: n });
  };

  const toggleItem = (id: CenterItemType) => {
    const exists = config.enabledItems.includes(id);
    const next = exists ? config.enabledItems.filter((i) => i !== id) : [...config.enabledItems, id];
    onChangeConfig({ ...config, itemSpawnMode: 'custom', enabledItems: next });
  };

  const navRootRef = useRef<HTMLDivElement | null>(null);
  useDomFocusNav({ rootRef: navRootRef, onBack, onStart: onStartMatch });

  const selectedAnimal = ANIMALS.find((a) => a.id === activeCustom.animal) ?? ANIMALS[0];
  const selectedHat = HATS.find((h) => h.id === activeCustom.hat) ?? HATS[0];
  const selectedMask = MASKS.find((m) => m.id === activeCustom.mask) ?? MASKS[0];
  const selectedCape = CAPES.find((c) => c.id === activeCustom.cape) ?? CAPES[0];

  return (
    <div
      ref={navRootRef}
      className="fixed inset-0 z-30 flex items-center justify-center p-3 md:p-5 pointer-events-auto"
      style={{ backgroundColor: 'rgba(6, 14, 22, 0.8)' }}
    >
      <div
        className="w-full max-w-6xl max-h-[94vh] rounded-2xl border border-white/15 shadow-2xl flex flex-col overflow-hidden"
        style={{ backgroundColor: '#0e1d28' }}
      >
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-white/10">
          <h2 className="font-display font-extrabold text-lg md:text-2xl text-white">
            {config.mode === 'story'
              ? 'Story Cup & Character Locker'
              : config.mode === 'training'
                ? 'Training (1v1 Keeper) & Character Locker'
                : config.mode === 'coop'
                  ? 'Local Co-op Setup'
                  : config.mode === 'lan'
                    ? 'WiFi LAN Match Setup'
                    : 'Quick Match & Character Locker'}
          </h2>

          <div className="flex flex-wrap items-center gap-1.5">
            {(['quick', 'story', 'training', 'coop', 'lan'] as GameMode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() =>
                  onChangeConfig(m === 'training' ? createTrainingConfig(config) : { ...config, mode: m })
                }
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  config.mode === m ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {m === 'quick'
                  ? 'Quick Match'
                  : m === 'story'
                    ? 'Story Mode'
                    : m === 'training'
                      ? 'Training'
                      : m === 'coop'
                        ? 'Local Co-op'
                        : 'WiFi LAN'}
              </button>
            ))}
            <button
              type="button"
              onClick={onBack}
              className="ml-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
            >
              {backLabel}
            </button>
          </div>
        </div>

        {/* Main 2-Column Body */}
        <div className="flex-1 overflow-y-auto custom-scroll p-4 md:p-5 grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Column: 3D Character Preview & Illustrated Locker */}
          <div className="lg:col-span-6 flex flex-col gap-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                {(config.mode === 'coop' || config.mode === 'lan') && (
                  <>
                    <button
                      type="button"
                      onClick={() => setEditingSlot(1)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                        editingSlot === 1 ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      P1
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingSlot(2)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                        editingSlot === 2 ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      P2
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() =>
                    editingSlot === 1
                      ? onChangeConfig({ ...config, p1Team: 'red' })
                      : onChangeConfig({ ...config, p2Team: 'red' })
                  }
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer border ${
                    activeTeam === 'red'
                      ? 'bg-red-600 text-white border-red-300'
                      : 'bg-slate-800 text-slate-300 border-transparent'
                  }`}
                >
                  Red Jersey
                </button>
                <button
                  type="button"
                  onClick={() =>
                    editingSlot === 1
                      ? onChangeConfig({ ...config, p1Team: 'blue' })
                      : onChangeConfig({ ...config, p2Team: 'blue' })
                  }
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer border ${
                    activeTeam === 'blue'
                      ? 'bg-blue-600 text-white border-blue-300'
                      : 'bg-slate-800 text-slate-300 border-transparent'
                  }`}
                >
                  Blue Jersey
                </button>
              </div>

              <button
                type="button"
                onClick={randomizeOutfit}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Dices className="w-3.5 h-3.5" />
                Randomize
              </button>
            </div>

            {/* 3D Preview + Visual Loadout Card */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5 items-stretch">
              <div className="sm:col-span-6 h-[210px]">
                <CharacterPreview3D team={activeTeam} custom={activeCustom} />
              </div>
              <div className="sm:col-span-6 rounded-xl p-3.5 bg-slate-900/80 border border-white/10 flex flex-col justify-between">
                <div className="flex items-center gap-3">
                  <AnimalIcon animal={selectedAnimal} className="w-12 h-12 shrink-0" />
                  <div className="min-w-0">
                    <div className="text-[11px] uppercase tracking-wider text-slate-400">Athlete</div>
                    <div className="font-display font-extrabold text-lg text-white truncate">{selectedAnimal.name}</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-1.5 pt-3 mt-3 border-t border-white/10">
                  <div className="flex flex-col items-center p-1.5 rounded-lg bg-slate-950/70">
                    <AccessoryIcon item={selectedHat} className="w-8 h-8" />
                    <span className="text-[10px] text-slate-300 truncate max-w-full mt-1">{selectedHat.name}</span>
                  </div>
                  <div className="flex flex-col items-center p-1.5 rounded-lg bg-slate-950/70">
                    <AccessoryIcon item={selectedMask} className="w-8 h-8" />
                    <span className="text-[10px] text-slate-300 truncate max-w-full mt-1">{selectedMask.name}</span>
                  </div>
                  <div className="flex flex-col items-center p-1.5 rounded-lg bg-slate-950/70">
                    <AccessoryIcon item={selectedCape} className="w-8 h-8" />
                    <span className="text-[10px] text-slate-300 truncate max-w-full mt-1">{selectedCape.name}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Customization Tabs */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/90 border border-white/10">
              {([
                { id: 'animal', label: `Animals (${ANIMALS.length})` },
                { id: 'hat', label: `Hats (${HATS.length - 1})` },
                { id: 'mask', label: `Masks (${MASKS.length - 1})` },
                { id: 'cape', label: `Capes (${CAPES.length - 1})` },
              ] as const).map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setCustomTab(t.id)}
                  className={`flex-1 py-2 px-2 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors ${
                    customTab === t.id ? 'bg-amber-400 text-slate-950' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Illustrated Visual Selection Grid */}
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[296px] overflow-y-auto custom-scroll pr-1">
              {customTab === 'animal' &&
                ANIMALS.map((a) => {
                  const active = activeCustom.animal === a.id;
                  return (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => updateCustom({ animal: a.id })}
                      className={`p-2 rounded-xl flex flex-col items-center gap-1.5 border transition-colors cursor-pointer ${
                        active
                          ? 'bg-amber-400/20 border-amber-400 text-white shadow-sm'
                          : 'bg-slate-900/75 border-white/10 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <AnimalIcon animal={a} className="w-11 h-11" />
                      <span className="text-[11px] font-bold text-center leading-tight line-clamp-1">{a.name}</span>
                    </button>
                  );
                })}

              {customTab === 'hat' &&
                HATS.map((h) => {
                  const active = activeCustom.hat === h.id;
                  return (
                    <button
                      key={h.id}
                      type="button"
                      onClick={() => updateCustom({ hat: h.id })}
                      className={`p-2 rounded-xl flex flex-col items-center gap-1.5 border transition-colors cursor-pointer ${
                        active
                          ? 'bg-amber-400/20 border-amber-400 text-white shadow-sm'
                          : 'bg-slate-900/75 border-white/10 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <AccessoryIcon item={h} className="w-10 h-10" />
                      <span className="text-[11px] font-semibold text-center leading-tight line-clamp-1">{h.name}</span>
                    </button>
                  );
                })}

              {customTab === 'mask' &&
                MASKS.map((m) => {
                  const active = activeCustom.mask === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => updateCustom({ mask: m.id })}
                      className={`p-2 rounded-xl flex flex-col items-center gap-1.5 border transition-colors cursor-pointer ${
                        active
                          ? 'bg-amber-400/20 border-amber-400 text-white shadow-sm'
                          : 'bg-slate-900/75 border-white/10 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <AccessoryIcon item={m} className="w-10 h-10" />
                      <span className="text-[11px] font-semibold text-center leading-tight line-clamp-1">{m.name}</span>
                    </button>
                  );
                })}

              {customTab === 'cape' &&
                CAPES.map((c) => {
                  const active = activeCustom.cape === c.id;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => updateCustom({ cape: c.id })}
                      className={`p-2 rounded-xl flex flex-col items-center gap-1.5 border transition-colors cursor-pointer ${
                        active
                          ? 'bg-amber-400/20 border-amber-400 text-white shadow-sm'
                          : 'bg-slate-900/75 border-white/10 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <AccessoryIcon item={c} className="w-10 h-10" />
                      <span className="text-[11px] font-semibold text-center leading-tight line-clamp-1">{c.name}</span>
                    </button>
                  );
                })}
            </div>
          </div>

          {/* Right Column: Visual Arena, Ball, Item Spawn & Match Rules */}
          <div className="lg:col-span-6 flex flex-col gap-3.5">
            {config.mode === 'story' ? (
              <div className="rounded-xl p-5 bg-slate-900/75 border border-amber-400/30 space-y-4">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-amber-300">
                    World Tour Challenge · {Math.min(10, Math.floor(highestStoryStage / 5) + 1)}/10 Worlds Open
                  </div>
                  <div className="text-lg font-display font-extrabold text-white mt-0.5">
                    10 Worlds · 50 Challengers &amp; Bosses
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    Customize your Hero outfit on the left, then open the interactive World Tour Adventure Map to battle through Green Valley up to the Grand Royal Championship!
                  </p>
                </div>
                {onOpenStoryMap && (
                  <button
                    type="button"
                    onClick={onOpenStoryMap}
                    className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-display font-extrabold text-sm cursor-pointer"
                  >
                    Open 10-World Adventure Map
                  </button>
                )}
              </div>
            ) : (
              <>
                {config.mode === 'training' && (
                  <div className="rounded-xl p-4 bg-emerald-950/50 border border-emerald-400/35 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-sm font-bold text-emerald-300">
                        Training Rules: 1 Player vs 1 NPC Goalkeeper
                      </span>
                      <button
                        type="button"
                        onClick={() => onChangeConfig(createTrainingConfig(config))}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold cursor-pointer"
                      >
                        <Shuffle className="w-3.5 h-3.5" /> Roll Random Arena
                      </button>
                    </div>
                    <p className="text-xs text-slate-300">
                      Classic Soccer ball locked, random stadium pitch selected, and 1 NPC goalkeeper defending the net for shooting &amp; kick timing drills.
                    </p>
                  </div>
                )}

                {config.mode === 'lan' && (
                  <div className="rounded-xl p-3.5 bg-slate-900/75 border border-white/10 space-y-2.5">
                    <div className="flex items-center gap-2 text-sm font-bold text-white">
                      <Wifi className="w-4 h-4 text-sky-400" />
                      WiFi LAN / Multi-Window Room Sync
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        aria-label="LAN Room Code"
                        value={lanInput}
                        onChange={(e) => setLanInput(e.target.value.toUpperCase())}
                        className="px-3 py-1.5 rounded-lg bg-slate-950 border border-white/15 text-sm text-white font-mono-num w-36"
                      />
                      <button
                        type="button"
                        onClick={() => onSetLan(lanInput || 'PITCH-101', 'host')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                          lanRole === 'host' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-200'
                        }`}
                      >
                        Host Room
                      </button>
                      <button
                        type="button"
                        onClick={() => onSetLan(lanInput || 'PITCH-101', 'guest')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                          lanRole === 'guest' ? 'bg-sky-400 text-slate-950' : 'bg-slate-800 text-slate-200'
                        }`}
                      >
                        Join Room
                      </button>
                    </div>
                  </div>
                )}

                {/* Team Size + Duration Row */}
                <div className="rounded-xl p-3.5 bg-slate-900/75 border border-white/10 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5" /> Format ({config.redCount}v{config.blueCount})
                    </span>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {([2, 5, 10, 15] as const).map((min) => (
                        <button
                          key={min}
                          type="button"
                          data-testid={`duration-${min}m`}
                          onClick={() => onChangeConfig({ ...config, durationMinutes: min })}
                          className={`px-2.5 py-1 rounded-md text-xs font-bold font-mono-num cursor-pointer ${
                            config.durationMinutes === min
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                          }`}
                        >
                          {min}m
                        </button>
                      ))}
                      <span className="text-slate-600 mx-0.5">|</span>
                      {([1, 2] as const).map((h) => (
                        <button
                          key={h}
                          type="button"
                          data-testid={`halves-${h}`}
                          onClick={() => onChangeConfig({ ...config, halves: h })}
                          className={`px-2 py-1 rounded-md text-[11px] font-bold cursor-pointer ${
                            (config.halves ?? 2) === h
                              ? 'bg-sky-400 text-slate-950'
                              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                          }`}
                        >
                          {h === 1 ? '1 Half' : '2 Halves'}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {[1, 2, 3].map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => applyPresetSize(n as 1 | 2 | 3)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                          config.redCount === n && config.blueCount === n
                            ? 'bg-amber-400 text-slate-950'
                            : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                        }`}
                      >
                        {n}v{n}
                      </button>
                    ))}
                    <div className="flex items-center gap-2 ml-auto text-xs">
                      <label className="text-red-400 font-semibold">
                        Red:
                        <select
                          aria-label="Custom Red Team Count"
                          value={config.redCount}
                          onChange={(e) => onChangeConfig({ ...config, redCount: Number(e.target.value) })}
                          className="ml-1 bg-slate-950 border border-white/15 rounded px-1.5 py-1 text-white"
                        >
                          {[1, 2, 3, 4].map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label className="text-blue-400 font-semibold">
                        Blue:
                        <select
                          aria-label="Custom Blue Team Count"
                          value={config.blueCount}
                          onChange={(e) => onChangeConfig({ ...config, blueCount: Number(e.target.value) })}
                          className="ml-1 bg-slate-950 border border-white/15 rounded px-1.5 py-1 text-white"
                        >
                          {[1, 2, 3, 4].map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Illustrated 10 Ball Shapes Selector */}
                <div className="rounded-xl p-3.5 bg-slate-900/75 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      3D Ball Shape ({BALLS.length})
                    </span>
                    <span className="text-xs font-semibold text-amber-300">
                      {BALLS.find((b) => b.id === config.ballType)?.name}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-7 gap-1.5 max-h-[210px] overflow-y-auto custom-scroll pr-1">
                    {BALLS.map((b) => {
                      const active = config.ballType === b.id;
                      return (
                        <button
                          key={b.id}
                          type="button"
                          data-testid={`ball-opt-${b.id}`}
                          onClick={() => onChangeConfig({ ...config, ballType: b.id })}
                          className={`p-1.5 rounded-xl flex flex-col items-center gap-1 border transition-colors cursor-pointer ${
                            active
                              ? 'bg-amber-400/20 border-amber-400 text-white'
                              : 'bg-slate-950/60 border-white/10 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <BallPreviewIcon ball={b} className="w-9 h-9" />
                          <span className="text-[10px] font-semibold text-center leading-tight line-clamp-1">
                            {b.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Illustrated 10 Arena Pitch Selector */}
                <div className="rounded-xl p-3.5 bg-slate-900/75 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      3D Arena Pitch ({ARENAS.length})
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const randA = ARENAS[Math.floor(Math.random() * ARENAS.length)].id;
                        const randB = BALLS[Math.floor(Math.random() * BALLS.length)].id;
                        onChangeConfig({ ...config, arena: randA, ballType: randB });
                      }}
                      className="flex items-center gap-1 text-[11px] text-amber-300 hover:text-amber-200 cursor-pointer font-semibold"
                    >
                      <Shuffle className="w-3 h-3" /> Randomize Arena &amp; Ball
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-[118px] overflow-y-auto custom-scroll pr-1">
                    {ARENAS.map((ar) => {
                      const active = config.arena === ar.id;
                      return (
                        <button
                          key={ar.id}
                          type="button"
                          onClick={() => onChangeConfig({ ...config, arena: ar.id })}
                          className={`p-1.5 rounded-xl text-left border transition-colors cursor-pointer ${
                            active
                              ? 'bg-amber-400/20 border-amber-400 text-white'
                              : 'bg-slate-950/60 border-white/10 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <ArenaPreviewIcon arena={ar} className="w-full h-9 rounded-md mb-1" />
                          <div className="text-[10px] font-bold truncate px-0.5">{ar.name}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Illustrated Center Item Spawn (60s) */}
                <div className="rounded-xl p-3 bg-slate-900/75 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Center Item Spawns (60s)
                    </span>
                    <div className="flex items-center gap-1.5">
                      {(['on', 'off', 'custom'] as const).map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() =>
                            onChangeConfig({
                              ...config,
                              itemSpawnMode: m,
                              enabledItems: m === 'on' ? CENTER_ITEMS.map((c) => c.id) : config.enabledItems,
                            })
                          }
                          className={`px-2.5 py-1 rounded-md text-xs font-bold uppercase cursor-pointer ${
                            config.itemSpawnMode === m
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  </div>

                  {config.itemSpawnMode !== 'off' && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {CENTER_ITEMS.map((it) => {
                        const checked = config.enabledItems.includes(it.id);
                        return (
                          <button
                            key={it.id}
                            type="button"
                            onClick={() => toggleItem(it.id)}
                            className={`p-1.5 rounded-lg text-left text-[11px] border transition-colors cursor-pointer flex items-center gap-1.5 ${
                              checked
                                ? 'bg-slate-800 border-amber-400/70 text-white'
                                : 'bg-slate-950/60 border-white/5 text-slate-500 opacity-60'
                            }`}
                          >
                            <ItemSpawnIcon item={it} className="w-6 h-6 shrink-0" />
                            <span className="truncate font-semibold">{it.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Footer Action Bar */}
        <div className="px-5 py-3.5 border-t border-white/10 flex items-center justify-end gap-4 bg-slate-950/60">
          <button
            type="button"
            data-start="true"
            onClick={onStartMatch}
            className="px-7 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-base tracking-tight whitespace-nowrap shrink-0 cursor-pointer"
          >
            Start Match
          </button>
        </div>
      </div>
    </div>
  );
}
