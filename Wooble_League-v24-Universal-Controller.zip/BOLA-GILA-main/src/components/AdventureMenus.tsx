import { ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import {
  AdventureResult,
  AdventureSave,
  Athlete,
  GEARS,
  LINEUP_LIMIT,
  POSITION_LABEL,
  RECRUITS,
  ROSTER_LIMIT,
  STADIUMS,
  STAT_CAP,
  STAT_KEYS,
  STAT_LABELS,
  StatKey,
  buyGear,
  championshipUnlocked,
  describeMatch,
  effectiveStats,
  equipGear,
  gearById,
  recruitWithCoins,
  releaseAthlete,
  resolveLineup,
  setLineup,
  stadiumLockReason,
  totalStat,
  trainStat,
  trophyCount,
} from '../game/adventure';
import { ANIMALS } from '../game/catalog';
import { WORLD_H, WORLD_W, WorldData } from '../game/openWorldMap';
import { renderMinimapCanvas } from '../game/worldRender';

/* ------------------------------ UI dasar ------------------------------ */
export function Panel({
  title,
  icon,
  onClose,
  children,
  right,
  width = 'max-w-4xl',
}: {
  title: string;
  icon?: string;
  onClose: () => void;
  children: ReactNode;
  right?: ReactNode;
  width?: string;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[60] bg-slate-950/80 flex items-center justify-center p-2" data-testid="adventure-panel">
      <div className={`w-full ${width} max-h-[96vh] flex flex-col rounded-2xl border-[3px] border-amber-300 bg-gradient-to-b from-sky-600 to-blue-900 shadow-[0_0_30px_rgba(0,0,0,0.6)]`}>
        <div className="flex items-center justify-between gap-2 px-3 py-1.5 border-b-2 border-amber-300/70 bg-blue-950/60 rounded-t-xl">
          <h2 className="font-display font-extrabold italic text-sm sm:text-lg text-white flex items-center gap-1.5">
            {icon && <span>{icon}</span>}
            {title}
          </h2>
          <div className="flex items-center gap-2">
            {right}
            <button
              type="button"
              onClick={onClose}
              data-testid="adventure-panel-close"
              className="px-3 py-1 rounded-lg bg-gradient-to-b from-rose-500 to-rose-700 border-2 border-rose-200 text-white text-xs font-extrabold cursor-pointer"
            >
              ✕ Tutup
            </button>
          </div>
        </div>
        <div className="flex-1 min-h-0 overflow-y-auto custom-scroll p-2 pr-11 text-white">{children}</div>
      </div>
    </div>
  );
}

export function Btn({
  children,
  onClick,
  disabled,
  tone = 'blue',
  small,
  testid,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  tone?: 'blue' | 'amber' | 'green' | 'red' | 'slate';
  small?: boolean;
  testid?: string;
}) {
  const tones: Record<string, string> = {
    blue: 'from-[#2f7bff] to-[#1546b8] border-sky-200 text-white',
    amber: 'from-amber-300 to-amber-500 border-amber-100 text-slate-950',
    green: 'from-emerald-400 to-emerald-600 border-emerald-100 text-white',
    red: 'from-rose-500 to-rose-700 border-rose-200 text-white',
    slate: 'from-slate-500 to-slate-700 border-slate-300 text-white',
  };
  return (
    <button
      type="button"
      data-testid={testid}
      disabled={disabled}
      onClick={onClick}
      className={`rounded-lg border-2 bg-gradient-to-b font-extrabold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${tones[tone]} ${small ? 'px-2 py-0.5 text-[10px]' : 'px-3 py-1.5 text-xs'}`}
    >
      {children}
    </button>
  );
}

function StatBar({ label, value, bonus = 0, compare }: { label: string; value: number; bonus?: number; compare?: number }) {
  const pct = Math.min(100, value);
  return (
    <div className="flex items-center gap-1.5 text-[10px]">
      <span className="w-20 shrink-0 font-bold text-sky-100">{label}</span>
      <div className="flex-1 h-2.5 rounded-full bg-slate-900/70 overflow-hidden relative">
        <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-lime-300" style={{ width: `${pct}%` }} />
        {bonus > 0 && <div className="absolute top-0 h-full bg-amber-300/90" style={{ left: `${Math.min(100, value - bonus)}%`, width: `${bonus}%` }} />}
      </div>
      <span className="w-12 text-right font-mono-num font-extrabold">
        {value}
        {compare !== undefined && compare !== value && (
          <span className={compare > value ? 'text-rose-300' : 'text-emerald-300'}> {value - compare > 0 ? '+' : ''}{value - compare}</span>
        )}
      </span>
    </div>
  );
}

const animalName = (id: string) => ANIMALS.find((a) => a.id === id)?.name ?? id;
const animalDot = (id: string) => ANIMALS.find((a) => a.id === id)?.bodyColor ?? '#999';

function AthleteChip({ a, extra }: { a: Athlete; extra?: ReactNode }) {
  return (
    <div className="flex items-center gap-2 min-w-0">
      <span className="w-7 h-7 rounded-full border-2 border-white/70 shrink-0" style={{ background: animalDot(a.animal) }} />
      <div className="min-w-0">
        <div className="font-extrabold text-xs truncate">{a.name}</div>
        <div className="text-[10px] text-sky-200 truncate">
          {animalName(a.animal)} · {POSITION_LABEL[a.position]} {extra}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- WORLD MAP ------------------------------- */
export function WorldMapPanel({
  save,
  world,
  playerPos,
  onClose,
}: {
  save: AdventureSave;
  world: WorldData;
  playerPos: { x: number; y: number };
  onClose: () => void;
}) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const src = renderMinimapCanvas(world, 4);
    c.width = src.width;
    c.height = src.height;
    c.getContext('2d')!.drawImage(src, 0, 0);
  }, [world]);
  const pct = (x: number, y: number) => ({ left: `${(x / WORLD_W) * 100}%`, top: `${(y / WORLD_H) * 100}%` });
  return (
    <Panel title="World Map" icon="🗺️" onClose={onClose}>
      <p className="text-[10px] text-sky-100 mb-1">
        Kamu bisa melihat lokasi stadion, tetapi tidak bisa teleport — berjalanlah mengikuti jalan! Trofi: {trophyCount(save)}/10
      </p>
      <div className="relative w-full rounded-lg overflow-hidden border-2 border-amber-200/70" style={{ aspectRatio: `${WORLD_W}/${WORLD_H}` }}>
        <canvas ref={ref} className="absolute inset-0 w-full h-full" style={{ imageRendering: 'pixelated' }} />
        {world.towns.map((t) => (
          <div key={t.name} className="absolute -translate-x-1/2 -translate-y-1/2 text-[9px] font-extrabold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] pointer-events-none" style={pct(t.x, t.y - 8)}>
            🏘️ {t.name}
          </div>
        ))}
        {world.stadiums.map((s, i) => {
          const found = save.discovered[i];
          const cleared = save.trophies[i];
          const locked = Boolean(stadiumLockReason(save, i));
          return (
            <div
              key={i}
              title={STADIUMS[i].name}
              className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none`}
              style={pct(s.cx, s.cy)}
            >
              <span
                className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full border-2 flex items-center justify-center text-sm sm:text-lg shadow-lg ${
                  cleared ? 'bg-yellow-300 border-yellow-100 ring-2 ring-yellow-200' : found ? 'bg-white border-slate-800' : 'bg-slate-600 border-slate-900 opacity-80'
                }`}
              >
                {cleared ? '🏆' : found ? STADIUMS[i].icon : '❓'}
              </span>
              <span className="text-[8px] sm:text-[9px] font-extrabold text-white bg-slate-900/80 px-1 rounded mt-0.5 whitespace-nowrap">
                {i + 1}. {found ? STADIUMS[i].name.replace(' Stadium', '') : '???'}
                {locked && found ? ' 🔒' : ''}
              </span>
            </div>
          );
        })}
        <div className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none" style={pct(playerPos.x, playerPos.y)}>
          <span className="block w-3.5 h-3.5 rounded-full bg-rose-500 border-2 border-white animate-ping absolute" />
          <span className="block w-3.5 h-3.5 rounded-full bg-rose-500 border-2 border-white relative" />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 mt-2">
        {STADIUMS.map((s, i) => {
          const lock = stadiumLockReason(save, i);
          const status = save.trophies[i] ? 'Turnamen selesai 🏆' : save.discovered[i] ? (lock ? 'Terkunci 🔒' : `Ditemukan · ${save.wins[i]}/10 menang`) : 'Belum ditemukan';
          return (
            <div key={i} className="flex items-center gap-2 rounded-lg bg-blue-950/50 border border-sky-300/30 px-2 py-1 text-[10px]">
              <span className="text-base">{save.discovered[i] ? s.icon : '❓'}</span>
              <div className="min-w-0">
                <div className="font-extrabold truncate">{save.discovered[i] ? s.name : `Stadion ${i + 1}`}</div>
                <div className="text-sky-200 truncate">{status}</div>
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

/* ------------------------------ TROPHY COLLECTION ------------------------------ */
export function TrophyPanel({ save, onClose }: { save: AdventureSave; onClose: () => void }) {
  const count = trophyCount(save);
  return (
    <Panel title={`Trophy Collection  ${count}/10`} icon="🏆" onClose={onClose}>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {STADIUMS.map((s, i) => {
          const got = save.trophies[i];
          return (
            <div key={i} data-testid={`trophy-slot-${i}`} className={`rounded-xl border-2 p-2 text-center ${got ? 'bg-gradient-to-b from-yellow-300/30 to-amber-600/30 border-yellow-300' : 'bg-slate-900/50 border-slate-500'}`}>
              <div className="text-4xl sm:text-5xl leading-none" style={{ filter: got ? `drop-shadow(0 0 8px ${s.color})` : 'grayscale(1) brightness(0.45)' }}>
                🏆
              </div>
              <div className="font-extrabold text-[11px] mt-1">{got ? s.trophyName : '???'}</div>
              <div className="text-[9px] text-sky-200 truncate">{s.name}</div>
              <div className={`mt-1 inline-block px-2 rounded-full text-[9px] font-extrabold ${got ? 'bg-emerald-400 text-slate-900' : 'bg-slate-600'}`}>{got ? 'Obtained' : 'Locked'}</div>
              <div className="text-[9px] mt-0.5">Turnamen: {save.wins[i]}/10 menang</div>
            </div>
          );
        })}
      </div>
      <div className="mt-2 rounded-xl border-2 border-amber-300/70 bg-blue-950/50 p-2 text-xs">
        {save.championshipCleared ? (
          <b className="text-yellow-300">👑 World Champion! Kamu menamatkan Story Mode.</b>
        ) : count >= 10 ? (
          <b className="text-yellow-300">🌟 Semua trofi terkumpul! World Championship terbuka di World Final Stadium.</b>
        ) : (
          <span>Kumpulkan 10 trofi untuk membuka World Championship ({count}/10).</span>
        )}
      </div>
    </Panel>
  );
}

/* ------------------------------ TEAM MANAGEMENT ------------------------------ */
export function TeamPanel({
  save,
  onChange,
  onClose,
}: {
  save: AdventureSave;
  onChange: (s: AdventureSave) => void;
  onClose: () => void;
}) {
  const [selId, setSelId] = useState(save.roster[0]?.id ?? '');
  const [cmpId, setCmpId] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const sel = save.roster.find((r) => r.id === selId) ?? save.roster[0];
  const cmp = cmpId ? save.roster.find((r) => r.id === cmpId) ?? null : null;
  const lineupIdx = (id: string) => save.lineup.indexOf(id);
  const inv = useMemo(() => {
    const c: Record<string, number> = {};
    for (const g of save.inventory) c[g] = (c[g] ?? 0) + 1;
    return c;
  }, [save.inventory]);

  const toggleLineup = (id: string) => {
    const idx = lineupIdx(id);
    if (idx >= 0) {
      if (save.lineup.length <= 1) return setMsg('Susunan minimal 1 atlet');
      onChange(setLineup(save, save.lineup.filter((l) => l !== id)));
    } else {
      if (save.lineup.length >= LINEUP_LIMIT) return setMsg(`Pemain utama maksimal ${LINEUP_LIMIT}. Keluarkan satu dulu.`);
      onChange(setLineup(save, [...save.lineup, id]));
    }
    setMsg('');
  };
  const makeCaptain = (id: string) => {
    const rest = save.lineup.filter((l) => l !== id);
    onChange(setLineup(save, [id, ...rest]));
    setMsg('Kapten dipilih — kapten adalah atlet yang kamu kendalikan.');
  };
  const doRelease = (id: string) => {
    const r = releaseAthlete(save, id);
    if (typeof r === 'string') return setMsg(r);
    onChange(r);
    setSelId(r.roster[0]?.id ?? '');
    setMsg('Atlet dikeluarkan dari roster.');
  };
  const doEquip = (gid: string | null) => {
    if (!sel) return;
    const r = equipGear(save, sel.id, gid);
    if (typeof r === 'string') return setMsg(r);
    onChange(r);
  };

  return (
    <Panel title={`Team Management  (${save.roster.length}/${ROSTER_LIMIT})`} icon="🧩" onClose={onClose} width="max-w-5xl">
      <p className="text-[10px] text-sky-100 mb-1">
        Susunan pemain utama (maks {LINEUP_LIMIT}): kapten = atlet yang kamu kendalikan, lainnya dikendalikan AI. Pertandingan awal 1v1, lalu 2v2 dan 3v3.
      </p>
      {msg && <div className="mb-1 text-[10px] font-bold text-amber-200">{msg}</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <div className="flex flex-col gap-1">
          {save.roster.map((a) => {
            const li = lineupIdx(a.id);
            return (
              <div
                key={a.id}
                data-testid={`roster-${a.id}`}
                onClick={() => setSelId(a.id)}
                className={`flex items-center justify-between gap-2 rounded-lg border-2 px-2 py-1 cursor-pointer ${a.id === sel?.id ? 'bg-amber-300/25 border-amber-300' : 'bg-blue-950/50 border-sky-300/30'}`}
              >
                <AthleteChip a={a} extra={`· ${totalStat(a)}`} />
                <div className="flex items-center gap-1 shrink-0">
                  {li >= 0 && <span className="px-1.5 rounded-full bg-emerald-400 text-slate-900 text-[10px] font-extrabold">{li === 0 ? 'C' : li + 1}</span>}
                  {a.gear && <span title={gearById(a.gear)?.name}>🎒</span>}
                </div>
              </div>
            );
          })}
        </div>
        {sel && (
          <div className="rounded-xl border-2 border-sky-300/40 bg-blue-950/50 p-2">
            <div className="flex items-center justify-between gap-2">
              <AthleteChip a={sel} />
              <div className="text-[10px] text-right">
                <div>Menang: {sel.wins}</div>
                <div>TP: {sel.tp}</div>
              </div>
            </div>
            <div className="text-[10px] mt-1 text-amber-200 font-bold">
              ★ {sel.skill} <span className="text-sky-100 font-normal">— {sel.skillDesc}</span>
            </div>
            <div className="mt-1.5 flex flex-col gap-0.5">
              {STAT_KEYS.map((k) => {
                const eff = effectiveStats(sel)[k];
                return <StatBar key={k} label={STAT_LABELS[k].name} value={eff} bonus={eff - sel.stats[k]} compare={cmp ? effectiveStats(cmp)[k] : undefined} />;
              })}
            </div>
            {cmp && <div className="text-[10px] mt-1 text-sky-100">Membandingkan dengan <b>{cmp.name}</b> (angka merah/hijau = selisih)</div>}
            <div className="flex flex-wrap gap-1 mt-2">
              <Btn small tone={lineupIdx(sel.id) >= 0 ? 'slate' : 'green'} onClick={() => toggleLineup(sel.id)} testid="toggle-lineup">
                {lineupIdx(sel.id) >= 0 ? 'Jadikan Cadangan' : 'Jadikan Pemain Utama'}
              </Btn>
              <Btn small tone="amber" disabled={lineupIdx(sel.id) < 0 || lineupIdx(sel.id) === 0} onClick={() => makeCaptain(sel.id)}>
                Jadikan Kapten
              </Btn>
              <Btn small tone="red" disabled={sel.id === 'hero'} onClick={() => doRelease(sel.id)}>
                Keluarkan
              </Btn>
            </div>
            <div className="mt-2 text-[10px] font-extrabold">Bandingkan dengan:</div>
            <div className="flex flex-wrap gap-1 mt-0.5">
              <Btn small tone={cmpId === null ? 'amber' : 'slate'} onClick={() => setCmpId(null)}>
                —
              </Btn>
              {save.roster
                .filter((r) => r.id !== sel.id)
                .map((r) => (
                  <Btn key={r.id} small tone={cmpId === r.id ? 'amber' : 'slate'} onClick={() => setCmpId(r.id)}>
                    {r.name}
                  </Btn>
                ))}
            </div>
            <div className="mt-2 text-[10px] font-extrabold">Perlengkapan: {gearById(sel.gear)?.name ?? '—'}</div>
            <div className="flex flex-wrap gap-1 mt-0.5">
              <Btn small tone="slate" disabled={!sel.gear} onClick={() => doEquip(null)}>
                Lepas
              </Btn>
              {Object.entries(inv).map(([gid, n]) => (
                <Btn key={gid} small tone="blue" onClick={() => doEquip(gid)}>
                  {gearById(gid)?.name} ×{n}
                </Btn>
              ))}
              {Object.keys(inv).length === 0 && <span className="text-[10px] text-sky-200">Tidak ada perlengkapan cadangan — beli di Toko.</span>}
            </div>
          </div>
        )}
      </div>
      <div className="mt-2 rounded-lg bg-blue-950/50 border border-sky-300/30 p-2 text-[10px]">
        <b>Susunan saat ini:</b>{' '}
        {resolveLineup(save, LINEUP_LIMIT)
          .map((a, i) => `${i === 0 ? '(C) ' : ''}${a.name}`)
          .join('  •  ')}
      </div>
    </Panel>
  );
}

/* ------------------------------ RECRUITMENT ------------------------------ */
export function RecruitPanel({
  save,
  hall,
  onChange,
  onClose,
}: {
  save: AdventureSave;
  hall: 'hall_start' | 'hall_mid' | 'hall_neon' | null;
  onChange: (s: AdventureSave) => void;
  onClose: () => void;
}) {
  const [msg, setMsg] = useState('');
  const hallName = { hall_start: 'Wobble Town', hall_mid: 'Harbor Town', hall_neon: 'Neon City' };
  const buy = (id: string) => {
    const r = recruitWithCoins(save, id);
    if (typeof r === 'string') return setMsg(r);
    onChange(r);
    setMsg('Atlet baru bergabung! 🎉');
  };
  return (
    <Panel
      title={`Recruitment  (${save.roster.length}/${ROSTER_LIMIT})`}
      icon="🤝"
      onClose={onClose}
      right={<span className="text-xs font-extrabold text-amber-200">🪙 {save.coins}</span>}
      width="max-w-5xl"
    >
      <p className="text-[10px] text-sky-100 mb-1">
        {hall ? `Aula Rekrut ${hallName[hall]} — atlet berlabel koin bisa dibeli di sini.` : 'Mode lihat — kunjungi Aula Rekrut (Recruit Hall) di kota untuk membeli atlet.'} Atlet lain didapat dari penemuan di perjalanan, tantangan, atau mengalahkan tim tertentu.
      </p>
      {msg && <div className="mb-1 text-[10px] font-bold text-amber-200">{msg}</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
        {RECRUITS.map((d) => {
          const a = d.athlete;
          const joined = save.foundRecruits.includes(a.id);
          const m = d.method;
          const here = m.type === 'coin' && hall === m.hall;
          return (
            <div key={a.id} data-testid={`recruit-${a.id}`} className={`rounded-lg border-2 p-1.5 ${joined ? 'bg-emerald-900/40 border-emerald-300/60' : 'bg-blue-950/50 border-sky-300/30'}`}>
              <div className="flex items-center justify-between gap-2">
                <AthleteChip a={a} />
                <div className="text-right text-[10px] shrink-0">
                  {joined ? <b className="text-emerald-300">Bergabung ✓</b> : m.type === 'coin' ? <b className="text-amber-200">🪙 {m.price}</b> : null}
                </div>
              </div>
              <div className="text-[10px] text-amber-200 font-bold mt-0.5">
                ★ {a.skill} <span className="text-sky-100 font-normal">— {a.skillDesc}</span>
              </div>
              <div className="grid grid-cols-2 gap-x-2 mt-0.5">
                {(['speed', 'strength', 'jump', 'balance', 'stamina', 'power'] as StatKey[]).map((k) => (
                  <StatBar key={k} label={STAT_LABELS[k].name} value={a.stats[k]} />
                ))}
              </div>
              <div className="flex items-center justify-between gap-2 mt-1">
                <span className="text-[10px] text-sky-200">
                  {m.type === 'coin' && `Dijual di Aula ${hallName[m.hall]}`}
                  {m.type === 'found' && `Ditemukan: ${m.hint}`}
                  {m.type === 'challenge' && `Tantangan: ${m.text}`}
                  {m.type === 'defeat' && `Kalahkan: ${m.text}`}
                </span>
                {m.type === 'coin' && !joined && (
                  <Btn small tone="amber" disabled={!here || save.coins < m.price || save.roster.length >= ROSTER_LIMIT} onClick={() => buy(a.id)} testid={`buy-${a.id}`}>
                    Rekrut
                  </Btn>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

/* ------------------------------ PLAYER STATISTICS ------------------------------ */
export function StatsPanel({ save, onClose }: { save: AdventureSave; onClose: () => void }) {
  const [sortKey, setSortKey] = useState<StatKey | 'total'>('total');
  const rows = [...save.roster].sort((a, b) =>
    sortKey === 'total' ? totalStat(b) - totalStat(a) : effectiveStats(b)[sortKey] - effectiveStats(a)[sortKey]
  );
  return (
    <Panel title="Player Statistics" icon="📊" onClose={onClose} width="max-w-5xl">
      <div className="overflow-x-auto">
        <table className="w-full text-[10px] border-separate border-spacing-y-0.5">
          <thead>
            <tr className="text-sky-200">
              <th className="text-left px-1">Atlet</th>
              {STAT_KEYS.map((k) => (
                <th key={k} className="px-1 cursor-pointer" onClick={() => setSortKey(k)} title={STAT_LABELS[k].desc}>
                  {STAT_LABELS[k].name.slice(0, 5)}
                  {sortKey === k && '▼'}
                </th>
              ))}
              <th className="px-1 cursor-pointer" onClick={() => setSortKey('total')}>
                Total{sortKey === 'total' && '▼'}
              </th>
              <th className="px-1">TP</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((a) => {
              const eff = effectiveStats(a);
              return (
                <tr key={a.id} className="bg-blue-950/50">
                  <td className="px-1 py-0.5 font-extrabold whitespace-nowrap">
                    {a.name} <span className="text-sky-300 font-normal">{POSITION_LABEL[a.position]}</span>
                  </td>
                  {STAT_KEYS.map((k) => (
                    <td key={k} className={`px-1 text-center font-mono-num ${eff[k] > a.stats[k] ? 'text-amber-300 font-extrabold' : eff[k] >= 70 ? 'text-emerald-300 font-extrabold' : ''}`}>
                      {eff[k]}
                    </td>
                  ))}
                  <td className="px-1 text-center font-extrabold">{totalStat(a)}</td>
                  <td className="px-1 text-center">{a.tp}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-1">
        {STAT_KEYS.map((k) => (
          <div key={k} className="text-[10px] rounded bg-blue-950/40 px-2 py-0.5">
            <b>{STAT_LABELS[k].name}</b> — {STAT_LABELS[k].desc}
          </div>
        ))}
      </div>
      <p className="text-[10px] text-sky-200 mt-1">Angka kuning = bonus perlengkapan. Statistik memengaruhi gameplay langsung di lapangan. Tidak ada sistem level — tingkatkan statistik lewat TP di Area Latihan.</p>
    </Panel>
  );
}

/* ------------------------------ SAVE CENTER ------------------------------ */
export function SavePanel({
  save,
  atCenter,
  onSave,
  onClose,
}: {
  save: AdventureSave;
  atCenter: boolean;
  onSave: () => void;
  onClose: () => void;
}) {
  const [saved, setSaved] = useState(false);
  const when = save.savedAt ? new Date(save.savedAt).toLocaleString() : '—';
  return (
    <Panel title="Player Save Center" icon="💾" onClose={onClose} width="max-w-xl">
      <div className="rounded-xl bg-blue-950/50 border-2 border-sky-300/40 p-2 text-xs grid grid-cols-2 gap-x-3 gap-y-0.5">
        <span>Trofi</span><b>{trophyCount(save)}/10</b>
        <span>Koin</span><b>🪙 {save.coins}</b>
        <span>Roster</span><b>{save.roster.length}/{ROSTER_LIMIT}</b>
        <span>Stadion ditemukan</span><b>{save.discovered.filter(Boolean).length}/10</b>
        <span>Pertandingan dimenangkan</span><b>{save.wins.reduce((a, b) => a + b, 0)}/100</b>
        <span>Terakhir disimpan</span><b>{when}</b>
      </div>
      <p className="text-[10px] text-sky-100 mt-1.5">
        Progres juga tersimpan otomatis setiap menang pertandingan{save.settings.autosave ? '' : ' (autosave sedang dimatikan di Story Settings)'}. Save manual menyimpan lokasi terakhirmu.
      </p>
      <div className="mt-2 flex items-center gap-2">
        <Btn
          tone="green"
          disabled={!atCenter}
          testid="manual-save"
          onClick={() => {
            onSave();
            setSaved(true);
          }}
        >
          💾 Simpan Progres
        </Btn>
        {!atCenter && <span className="text-[10px] text-amber-200">Kunjungi Player Save Center di depan stadion untuk menyimpan manual.</span>}
        {saved && <span className="text-[11px] font-extrabold text-emerald-300">Tersimpan! ✓</span>}
      </div>
    </Panel>
  );
}

/* ------------------------------ STORY SETTINGS ------------------------------ */
export function SettingsPanel({
  save,
  onChange,
  onReset,
  onClose,
}: {
  save: AdventureSave;
  onChange: (s: AdventureSave) => void;
  onReset: () => void;
  onClose: () => void;
}) {
  const [confirm, setConfirm] = useState(false);
  const Toggle = ({ label, value, onToggle, id }: { label: string; value: boolean; onToggle: () => void; id: string }) => (
    <button type="button" data-testid={id} onClick={onToggle} className={`w-full flex items-center justify-between rounded-lg border-2 px-3 py-1.5 text-xs font-extrabold cursor-pointer ${value ? 'bg-emerald-500/30 border-emerald-300' : 'bg-slate-800/60 border-slate-500'}`}>
      <span>{label}</span>
      <span>{value ? 'ON' : 'OFF'}</span>
    </button>
  );
  return (
    <Panel title="Story Settings" icon="⚙️" onClose={onClose} width="max-w-md">
      <div className="flex flex-col gap-1.5">
        <Toggle id="set-autosave" label="Autosave setelah menang pertandingan" value={save.settings.autosave} onToggle={() => onChange({ ...save, settings: { ...save.settings, autosave: !save.settings.autosave } })} />
        <Toggle id="set-minimap" label="Tampilkan mini-map" value={save.settings.minimap} onToggle={() => onChange({ ...save, settings: { ...save.settings, minimap: !save.settings.minimap } })} />
        <div className="mt-2 rounded-lg border-2 border-rose-400/70 bg-rose-950/40 p-2">
          <div className="text-xs font-extrabold text-rose-200">Mulai Story Baru</div>
          <p className="text-[10px] text-rose-100">Menghapus seluruh progres Story Mode (trofi, roster, koin). Tidak bisa dibatalkan.</p>
          {!confirm ? (
            <Btn small tone="red" onClick={() => setConfirm(true)}>
              Reset Story…
            </Btn>
          ) : (
            <div className="flex gap-1 mt-1">
              <Btn small tone="red" onClick={onReset} testid="confirm-reset">
                Ya, hapus semua
              </Btn>
              <Btn small tone="slate" onClick={() => setConfirm(false)}>
                Batal
              </Btn>
            </div>
          )}
        </div>
      </div>
    </Panel>
  );
}

/* ------------------------------ STADIUM / TURNAMEN ------------------------------ */
export function StadiumPanel({
  save,
  stadium,
  onPlay,
  onClose,
}: {
  save: AdventureSave;
  stadium: number;
  onPlay: (stadium: number, match: number) => void;
  onClose: () => void;
}) {
  const st = STADIUMS[stadium];
  const lock = stadiumLockReason(save, stadium);
  const next = save.wins[stadium];
  const champ = stadium === 9 && championshipUnlocked(save);
  const lineup = resolveLineup(save, 3);
  return (
    <Panel title={st.name} icon={st.icon} onClose={onClose} width="max-w-3xl">
      <div className="text-[11px] text-sky-100">{st.subtitle}</div>
      <div className="text-[11px] mt-0.5">
        Turnamen: <b>{save.wins[stadium]}/10</b> menang {save.trophies[stadium] && <b className="text-yellow-300">· 🏆 {st.trophyName} diraih</b>}
      </div>
      <div className="text-[10px] text-sky-200">Tim kamu: {lineup.map((a) => a.name).join(', ')}</div>
      {lock && <div className="mt-1 rounded bg-rose-900/60 border border-rose-300 px-2 py-1 text-[11px] font-bold">🔒 {lock}</div>}
      <div className="mt-1.5 grid grid-cols-1 sm:grid-cols-2 gap-1">
        {Array.from({ length: 10 }, (_, m) => {
          const info = describeMatch(stadium, m);
          const done = m < next;
          const isNext = m === next && !lock;
          return (
            <div key={m} data-testid={`match-row-${m}`} className={`rounded-lg border-2 px-2 py-1 flex items-center justify-between gap-2 ${done ? 'bg-emerald-900/40 border-emerald-300/50' : isNext ? 'bg-amber-300/20 border-amber-300' : 'bg-slate-900/40 border-slate-600 opacity-70'}`}>
              <div className="min-w-0">
                <div className="text-[11px] font-extrabold truncate">
                  {m + 1}. {info.opponentName} {info.isFinal && '👑'}
                </div>
                <div className="text-[9px] text-sky-200">
                  {info.teamSize}v{info.teamSize} · AI {Math.round(info.difficulty * 100)}% · stat ≈{info.avgOpponentStat} · {info.durationMinutes} mnt
                </div>
              </div>
              {done ? <span className="text-emerald-300 text-xs font-extrabold">✓</span> : isNext ? <Btn small tone="amber" onClick={() => onPlay(stadium, m)} testid="play-match">Main</Btn> : <span>🔒</span>}
            </div>
          );
        })}
      </div>
      {champ && (
        <div className="mt-2 rounded-xl border-2 border-yellow-300 bg-gradient-to-b from-yellow-500/20 to-rose-600/20 p-2">
          <div className="text-sm font-extrabold text-yellow-200">👑 WORLD CHAMPIONSHIP</div>
          <p className="text-[10px] text-sky-100">Semua 10 trofi terkumpul! Kalahkan 3 tim juara dunia untuk menamatkan Story Mode.</p>
          <div className="grid grid-cols-1 gap-1 mt-1">
            {[0, 1, 2].map((m) => {
              const info = describeMatch(10, m);
              const done = m < save.championshipWins;
              const isNext = m === save.championshipWins;
              return (
                <div key={m} className="flex items-center justify-between rounded-lg bg-blue-950/60 border border-yellow-300/50 px-2 py-1">
                  <span className="text-[11px] font-extrabold">{info.opponentName}</span>
                  {done ? <span className="text-emerald-300 font-extrabold">✓</span> : isNext ? <Btn small tone="amber" onClick={() => onPlay(10, m)} testid="play-championship">Main</Btn> : <span>🔒</span>}
                </div>
              );
            })}
          </div>
        </div>
      )}
      {save.championshipCleared && stadium === 9 && <div className="mt-2 text-center text-yellow-300 font-extrabold text-sm">👑 Kamu adalah World Champion!</div>}
    </Panel>
  );
}

/* ------------------------------ TOKO ------------------------------ */
export function ShopPanel({ save, onChange, onClose }: { save: AdventureSave; onChange: (s: AdventureSave) => void; onClose: () => void }) {
  const [msg, setMsg] = useState('');
  return (
    <Panel title="Toko Perlengkapan" icon="🛍️" onClose={onClose} right={<span className="text-xs font-extrabold text-amber-200">🪙 {save.coins}</span>} width="max-w-3xl">
      {msg && <div className="mb-1 text-[10px] font-bold text-amber-200">{msg}</div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
        {GEARS.map((g) => {
          const owned = save.inventory.filter((i) => i === g.id).length + save.roster.filter((r) => r.gear === g.id).length;
          return (
            <div key={g.id} className="rounded-lg border-2 border-sky-300/30 bg-blue-950/50 p-2 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-xs font-extrabold">🎒 {g.name}</div>
                <div className="text-[10px] text-sky-200">{g.desc}</div>
                <div className="text-[9px] text-sky-300">Dimiliki: {owned}</div>
              </div>
              <Btn
                small
                tone="amber"
                disabled={save.coins < g.price}
                testid={`buy-gear-${g.id}`}
                onClick={() => {
                  const r = buyGear(save, g.id);
                  if (typeof r === 'string') return setMsg(r);
                  onChange(r);
                  setMsg(`${g.name} dibeli! Pasang di Team Management.`);
                }}
              >
                🪙 {g.price}
              </Btn>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

/* ------------------------------ AREA LATIHAN ------------------------------ */
export function TrainingPanel({ save, onChange, onClose }: { save: AdventureSave; onChange: (s: AdventureSave) => void; onClose: () => void }) {
  const [selId, setSelId] = useState(save.roster[0]?.id ?? '');
  const [msg, setMsg] = useState('');
  const sel = save.roster.find((r) => r.id === selId) ?? save.roster[0];
  return (
    <Panel title="Area Latihan" icon="🏋️" onClose={onClose} width="max-w-3xl">
      <p className="text-[10px] text-sky-100">Ubah pengalaman bertanding (TP) menjadi statistik. 1 TP = +1 statistik. Atlet mendapat TP dari setiap pertandingan yang dimainkan.</p>
      {msg && <div className="text-[10px] font-bold text-amber-200">{msg}</div>}
      <div className="flex flex-wrap gap-1 my-1.5">
        {save.roster.map((a) => (
          <Btn key={a.id} small tone={a.id === sel?.id ? 'amber' : 'slate'} onClick={() => setSelId(a.id)}>
            {a.name} · {a.tp} TP
          </Btn>
        ))}
      </div>
      {sel && (
        <div className="flex flex-col gap-1">
          <div className="text-xs font-extrabold">
            {sel.name} — TP tersedia: <span className="text-amber-300">{sel.tp}</span>
          </div>
          {STAT_KEYS.map((k) => (
            <div key={k} className="flex items-center gap-2">
              <div className="flex-1">
                <StatBar label={STAT_LABELS[k].name} value={sel.stats[k]} />
              </div>
              <Btn
                small
                tone="green"
                disabled={sel.tp < 1 || sel.stats[k] >= STAT_CAP}
                testid={`train-${k}`}
                onClick={() => {
                  const r = trainStat(save, sel.id, k);
                  if (typeof r === 'string') return setMsg(r);
                  onChange(r);
                  setMsg('');
                }}
              >
                +1
              </Btn>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}

/* ------------------------------ MENU UTAMA STORY ------------------------------ */
export type MenuAction = 'continue' | 'map' | 'trophies' | 'team' | 'recruit' | 'stats' | 'save' | 'settings' | 'exit';
export function StoryMenu({ save, onPick }: { save: AdventureSave; onPick: (a: MenuAction) => void }) {
  const items: Array<[MenuAction, string, string]> = [
    ['continue', '▶', 'Continue Story'],
    ['map', '🗺️', 'World Map'],
    ['trophies', '🏆', 'Trophy Collection'],
    ['team', '🧩', 'Team Management'],
    ['recruit', '🤝', 'Recruitment'],
    ['stats', '📊', 'Player Statistics'],
    ['save', '💾', 'Save Center'],
    ['settings', '⚙️', 'Story Settings'],
    ['exit', '⏏', 'Keluar ke Menu Utama'],
  ];
  return (
    <Panel title="Story Mode" icon="🌍" onClose={() => onPick('continue')} width="max-w-md" right={<span className="text-xs font-extrabold text-amber-200">🪙 {save.coins} · 🏆 {trophyCount(save)}/10</span>}>
      <div className="grid grid-cols-1 gap-1.5">
        {items.map(([k, icon, label]) => (
          <button
            key={k}
            type="button"
            data-testid={`story-menu-${k}`}
            onClick={() => onPick(k)}
            className={`flex items-center gap-2 rounded-xl border-2 px-3 py-2 text-sm font-extrabold cursor-pointer text-left ${k === 'continue' ? 'bg-gradient-to-b from-amber-300 to-amber-500 border-amber-100 text-slate-950' : k === 'exit' ? 'bg-slate-800/70 border-slate-500' : 'bg-gradient-to-b from-[#2f7bff] to-[#1546b8] border-sky-200'}`}
          >
            <span className="text-lg w-7 text-center">{icon}</span>
            {label}
          </button>
        ))}
      </div>
    </Panel>
  );
}

/* ------------------------------ HASIL PERTANDINGAN ------------------------------ */
export function ResultModal({ result, onContinue }: { result: AdventureResult; onContinue: () => void }) {
  const st = result.stadium === 10 ? null : STADIUMS[result.stadium];
  return (
    <div className="fixed inset-0 z-[70] bg-slate-950/85 flex items-center justify-center p-3" data-testid="adventure-result">
      <style>{`
        @keyframes trophyPop { 0% { transform: scale(0.2) rotate(-20deg); opacity: 0 } 60% { transform: scale(1.3) rotate(8deg); opacity: 1 } 100% { transform: scale(1) rotate(0) } }
        @keyframes trophyGlow { 0%,100% { filter: drop-shadow(0 0 10px #facc15) } 50% { filter: drop-shadow(0 0 28px #fde047) } }
        @keyframes confettiFall { from { transform: translateY(-20vh) rotate(0) } to { transform: translateY(110vh) rotate(720deg) } }
      `}</style>
      {(result.trophyEarned || result.championshipCleared) &&
        Array.from({ length: 28 }, (_, i) => (
          <span key={i} className="fixed top-0 text-xl pointer-events-none" style={{ left: `${(i * 37) % 100}%`, animation: `confettiFall ${2.5 + (i % 5) * 0.5}s linear ${(i % 7) * 0.2}s infinite` }}>
            {['🎉', '⭐', '✨', '🏆'][i % 4]}
          </span>
        ))}
      <div className="w-full max-w-md rounded-2xl border-[3px] border-amber-300 bg-gradient-to-b from-sky-600 to-blue-900 p-3 text-white text-center shadow-2xl">
        <div className={`font-display font-extrabold italic text-2xl ${result.won ? 'text-emerald-300' : 'text-rose-300'}`}>{result.won ? 'MENANG!' : 'KALAH'}</div>
        <div className="text-3xl font-mono-num font-extrabold my-1">
          {result.redScore} <span className="text-sky-300">-</span> {result.blueScore}
        </div>
        <div className="text-[11px] text-sky-100">{result.info.title}</div>
        {(result.trophyEarned || result.championshipCleared) && (
          <div className="my-2">
            <div className="text-7xl leading-none inline-block" style={{ animation: 'trophyPop 0.9s ease-out both, trophyGlow 1.6s ease-in-out infinite 0.9s' }}>
              {result.championshipCleared ? '👑' : '🏆'}
            </div>
            <div className="font-extrabold text-yellow-300 text-sm mt-1">
              {result.championshipCleared ? 'WORLD CHAMPION! Story Mode tamat!' : `${st?.trophyName} diraih! Trofi masuk koleksi.`}
            </div>
          </div>
        )}
        <div className="text-xs mt-1">
          🪙 +{result.coins} koin · ⭐ +{result.tp} TP untuk atlet yang bermain
        </div>
        {result.recruits.map((r) => (
          <div key={r.id} className="mt-1 rounded-lg bg-emerald-900/50 border border-emerald-300 px-2 py-1 text-xs font-extrabold">
            🤝 {r.name} ({animalName(r.animal)}) bergabung ke timmu!
          </div>
        ))}
        {result.allTrophies && !result.championshipCleared && (
          <div className="mt-1 text-xs font-extrabold text-yellow-200">🌟 10 trofi terkumpul! Pergi ke World Final Stadium untuk World Championship.</div>
        )}
        <div className="mt-2">
          <Btn tone="amber" onClick={onContinue} testid="result-continue">
            Kembali ke Dunia
          </Btn>
        </div>
      </div>
    </div>
  );
}
