import { PAD_KIND_LABEL, SlotId, gamepadManager } from '../game/gamepadManager';
import { useGamepadStatus } from '../hooks/useGamepadStatus';

const KIND_ICON = { xbox: '🟢', playstation: '🔵', nintendo: '🔴', joycon: '🔴', generic: '🎮' } as const;

/**
 * Status External Controller: 1 controller = 1 player.
 * Penugasan otomatis berurutan (controller 1 -> P1, dst) dan bisa ditukar dengan tombol ⇅.
 */
export function ControllerStatus({ compact = false }: { compact?: boolean }) {
  const { slots, spare } = useGamepadStatus();
  const connected = slots.filter((s) => s.pad).length;
  return (
    <div data-testid="controller-status" className={`rounded-xl border border-sky-300/40 bg-blue-950/55 ${compact ? 'px-2 py-1' : 'p-2.5'}`}>
      <div className={`font-extrabold text-sky-100 ${compact ? 'text-[10px]' : 'text-xs'} mb-1`}>
        🎮 External Controller — {connected === 0 ? 'tidak ada yang tersambung (colok USB / pairing Bluetooth lalu tekan tombol apa saja)' : `${connected} tersambung`}
      </div>
      <div className={`grid ${compact ? 'grid-cols-2 sm:grid-cols-4 gap-1' : 'grid-cols-1 sm:grid-cols-2 gap-1.5'}`}>
        {slots.map(({ slot, pad, reconnecting }) => (
          <div
            key={slot}
            data-testid={`controller-slot-${slot}`}
            className={`flex items-center justify-between gap-1 rounded-lg border px-1.5 py-1 ${pad ? 'border-emerald-300/70 bg-emerald-900/30' : reconnecting ? 'border-amber-300/70 bg-amber-900/25' : 'border-slate-500/50 bg-slate-900/40'}`}
          >
            <div className="min-w-0">
              <div className={`font-extrabold ${compact ? 'text-[10px]' : 'text-xs'} text-white`}>
                P{slot}{' '}
                <span className={pad ? 'text-emerald-300' : reconnecting ? 'text-amber-300' : 'text-slate-400'}>
                  {pad ? 'Connected' : reconnecting ? 'Reconnecting…' : '—'}
                </span>
              </div>
              {pad && (
                <div className="text-[9px] text-sky-200 truncate">
                  {KIND_ICON[pad.kind]} {PAD_KIND_LABEL[pad.kind]} · {pad.name} · #{pad.index}
                </div>
              )}
            </div>
            {!compact && slot < 4 && (
              <button
                type="button"
                title={`Tukar P${slot} dengan P${slot + 1}`}
                onClick={() => gamepadManager.swapSlots(slot, (slot + 1) as SlotId)}
                className="shrink-0 px-1.5 py-0.5 rounded bg-blue-600 border border-sky-200 text-[10px] font-extrabold text-white cursor-pointer"
              >
                ⇅
              </button>
            )}
          </div>
        ))}
      </div>
      {spare.length > 0 && <div className="mt-2 space-y-2">
        <div className="text-[10px] font-bold text-amber-200">Perangkat tersedia — pilih slot secara manual</div>
        {spare.map(p => <div key={p.key} className="flex flex-wrap items-center gap-2 rounded-lg bg-slate-900/50 p-2">
          <span className="text-[10px] text-white flex-1 min-w-0 truncate">{KIND_ICON[p.kind]} {p.name} · {p.kind}</span>
          {([1,2,3,4] as SlotId[]).map(target => <button key={target} type="button" onClick={() => gamepadManager.assignSlot(p.index, target)} className="rounded bg-emerald-700 px-2 py-1 text-[10px] font-bold text-white border border-emerald-300/40">P{target}</button>)}
        </div>)}
      </div>}
    </div>
  );
}
