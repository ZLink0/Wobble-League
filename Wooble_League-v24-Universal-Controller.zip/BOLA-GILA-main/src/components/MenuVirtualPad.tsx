import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp } from 'lucide-react';
import { dispatchMenuVirtualAction, MenuNavAction } from '../hooks/useMenuController';

interface MenuVirtualPadProps {
  visible: boolean;
  showBumpers?: boolean;
  startLabel?: string;
}

export function MenuVirtualPad({
  visible,
  showBumpers = false,
  startLabel = 'START',
}: MenuVirtualPadProps) {
  if (!visible) return null;

  const fire = (action: MenuNavAction) => (e: React.PointerEvent | React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dispatchMenuVirtualAction(action);
  };

  return (
    <div
      data-testid="menu-virtual-pad"
      className="fixed inset-x-0 bottom-2 z-40 px-3 flex items-end justify-between pointer-events-none select-none"
    >
      {/* Bottom-Left Compact D-Pad */}
      <div className="pointer-events-auto grid grid-cols-3 gap-1 p-1.5 rounded-2xl border-2 border-sky-300 bg-blue-700/85 backdrop-blur-sm shadow-xl">
        <div />
        <button
          type="button"
          aria-label="Menu Up"
          onPointerDown={fire('up')}
          className="w-9 h-9 rounded-lg bg-blue-900/90 active:bg-amber-400 active:text-slate-950 text-white border border-sky-300/40 flex items-center justify-center cursor-pointer"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
        <div />
        <button
          type="button"
          aria-label="Menu Left"
          onPointerDown={fire('left')}
          className="w-9 h-9 rounded-lg bg-blue-900/90 active:bg-amber-400 active:text-slate-950 text-white border border-sky-300/40 flex items-center justify-center cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button
          type="button"
          aria-label="Menu Down"
          onPointerDown={fire('down')}
          className="w-9 h-9 rounded-lg bg-blue-900/90 active:bg-amber-400 active:text-slate-950 text-white border border-sky-300/40 flex items-center justify-center cursor-pointer"
        >
          <ArrowDown className="w-4 h-4" />
        </button>
        <button
          type="button"
          aria-label="Menu Right"
          onPointerDown={fire('right')}
          className="w-9 h-9 rounded-lg bg-blue-900/90 active:bg-amber-400 active:text-slate-950 text-white border border-sky-300/40 flex items-center justify-center cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom-Right Compact Action Cluster */}
      <div className="pointer-events-auto flex flex-col items-end gap-1.5 p-2 rounded-2xl border-2 border-sky-300 bg-blue-700/85 backdrop-blur-sm shadow-xl">
        {showBumpers && (
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onPointerDown={fire('lb')}
              className="px-2.5 py-1 rounded-md bg-blue-900/90 active:bg-sky-300 active:text-slate-950 text-white border border-sky-300/40 text-[10px] font-bold cursor-pointer"
            >
              LB
            </button>
            <button
              type="button"
              onPointerDown={fire('rb')}
              className="px-2.5 py-1 rounded-md bg-blue-900/90 active:bg-sky-300 active:text-slate-950 text-white border border-sky-300/40 text-[10px] font-bold cursor-pointer"
            >
              RB
            </button>
          </div>
        )}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onPointerDown={fire('back')}
            className="w-10 h-10 rounded-full bg-rose-500 active:bg-rose-400 text-white font-display font-extrabold text-xs border-2 border-rose-200 cursor-pointer"
          >
            B
          </button>
          <button
            type="button"
            onPointerDown={fire('confirm')}
            className="w-10 h-10 rounded-full bg-amber-400 active:bg-amber-300 text-slate-950 font-display font-extrabold text-xs border-2 border-amber-100 cursor-pointer"
          >
            A
          </button>
          <button
            type="button"
            onPointerDown={fire('start')}
            className="px-3 h-10 rounded-xl bg-emerald-400 active:bg-emerald-300 text-slate-950 font-display font-extrabold text-[11px] tracking-wide border-2 border-emerald-100 cursor-pointer"
          >
            {startLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
