import { useEffect, useState } from 'react';
import { Award, ChevronRight, Coins, Crown, FastForward, Play, Sparkles } from 'lucide-react';
import { ANIMALS } from '../game/catalog';
import { gameAudio } from '../game/audio';
import {
  DialogueChoice,
  DialogueEmotion,
  DialogueLine,
  StoryCompletionOutcome,
  StoryMatchSpec,
  StoryWorldSpec,
  WORLD_10_CELEBRATION_CAST,
  WORLD_10_ENDING_DIALOGUE,
} from '../game/story';
import { PlayerCustomization } from '../game/types';
import { CharacterPreview3D } from './CharacterPreview3D';
import { AnimalIcon } from './MenuIcons';

export type CutsceneKind = 'pre_match' | 'post_win' | 'post_lose' | 'world10_ending';

interface StoryDialogueCutsceneProps {
  kind: CutsceneKind;
  world: StoryWorldSpec;
  match: StoryMatchSpec;
  heroCustom: PlayerCustomization;
  winOutcome?: StoryCompletionOutcome | null;
  onFinish: () => void;
  onRematch?: () => void;
}

const EMOTION_BADGE: Record<DialogueEmotion, { label: string; bg: string }> = {
  neutral: { label: 'Ready', bg: 'bg-slate-700 text-slate-100' },
  happy: { label: 'Hyped!', bg: 'bg-emerald-500 text-slate-950' },
  angry: { label: 'Fierce!', bg: 'bg-rose-500 text-white' },
  surprised: { label: 'Shocked!', bg: 'bg-amber-400 text-slate-950' },
  confident: { label: 'Confident', bg: 'bg-sky-400 text-slate-950' },
};

export function StoryDialogueCutscene({
  kind,
  world,
  match,
  heroCustom,
  winOutcome,
  onFinish,
  onRematch,
}: StoryDialogueCutsceneProps) {
  const initialLines: DialogueLine[] =
    kind === 'pre_match'
      ? match.preMatchDialogue
      : kind === 'post_win'
        ? match.postWinDialogue
        : kind === 'world10_ending'
          ? WORLD_10_ENDING_DIALOGUE
          : [
              {
                speaker: 'opponent',
                speakerName: match.opponentName,
                emotion: 'confident',
                text: match.postLoseLine,
              },
            ];

  const [lines, setLines] = useState<DialogueLine[]>(initialLines);
  const [lineIdx, setLineIdx] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [autoAdvance, setAutoAdvance] = useState(false);
  const [choiceUsed, setChoiceUsed] = useState<Record<number, boolean>>({});
  const [showEndingCredits, setShowEndingCredits] = useState(false);

  const currentLine = lines[lineIdx] ?? lines[lines.length - 1];
  const fullText = currentLine?.text ?? '';
  const isTyping = charCount < fullText.length;
  const waitingForChoice =
    Boolean(currentLine?.choices && currentLine.choices.length > 0 && !choiceUsed[lineIdx]) && !isTyping;

  // Typewriter reveal + expressive RPG voice chirp
  useEffect(() => {
    setCharCount(0);
  }, [lineIdx, fullText]);

  useEffect(() => {
    if (showEndingCredits || !currentLine) return;
    if (charCount >= fullText.length) return;
    const t = window.setTimeout(() => {
      setCharCount((c) => c + 1);
      if (charCount % 3 === 0) {
        const pitch =
          currentLine.speaker === 'hero' ? 420 : currentLine.speaker === 'narrator' ? 300 : 340;
        gameAudio.playVoiceChirp(pitch, currentLine.emotion);
      }
    }, 20);
    return () => window.clearTimeout(t);
  }, [charCount, fullText, currentLine, showEndingCredits]);

  // Auto-play progression when enabled and no choice is pending
  useEffect(() => {
    if (!autoAdvance || isTyping || waitingForChoice || showEndingCredits) return;
    const t = window.setTimeout(() => {
      handleNext();
    }, 1500);
    return () => window.clearTimeout(t);
  });

  const handleNext = () => {
    if (showEndingCredits) {
      onFinish();
      return;
    }
    if (isTyping) {
      setCharCount(fullText.length);
      return;
    }
    if (waitingForChoice) return;
    if (lineIdx + 1 < lines.length) {
      setLineIdx((i) => i + 1);
    } else if (kind === 'world10_ending') {
      setShowEndingCredits(true);
    } else {
      onFinish();
    }
  };

  const handleSkip = () => {
    if (kind === 'world10_ending' && !showEndingCredits) {
      setShowEndingCredits(true);
      return;
    }
    onFinish();
  };

  const handlePickChoice = (choice: DialogueChoice) => {
    if (choiceUsed[lineIdx]) return;
    setChoiceUsed((prev) => ({ ...prev, [lineIdx]: true }));
    const reply: DialogueLine = {
      speaker: 'opponent',
      speakerName: match.opponentName,
      emotion: choice.replyEmotion,
      text: choice.replyLine,
    };
    const nextLines = [...lines.slice(0, lineIdx + 1), reply, ...lines.slice(lineIdx + 1)];
    setLines(nextLines);
    setLineIdx(lineIdx + 1);
    gameAudio.playVoiceChirp(370, choice.replyEmotion);
  };

  // Keyboard Space/Enter shortcut to advance dialogue
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        if (waitingForChoice) return;
        e.preventDefault();
        handleNext();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (showEndingCredits) {
    return (
      <div
        data-testid="world10-ending-celebration"
        className="fixed inset-0 z-40 flex items-center justify-center p-2.5 sm:p-4 pointer-events-auto"
        style={{ backgroundColor: 'rgba(12, 32, 68, 0.78)', backdropFilter: 'blur(4px)' }}
      >
        <div className="w-full max-w-4xl max-h-[94vh] rounded-2xl border-2 border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-2xl overflow-y-auto custom-scroll p-4 sm:p-6 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400 text-slate-950 font-display font-extrabold text-xs sm:text-sm tracking-wide">
            <Crown className="w-4 h-4 sm:w-5 sm:h-5" />
            WORLD CHAMPION CROWNED
          </div>

          <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
            Grand World Tour Complete!
          </h2>
          <p className="text-xs sm:text-sm text-amber-200 max-w-2xl mx-auto">
            All 10 Worlds conquered! Every Boss Champion and rival from Green Valley to the Grand Royal Stadium joins the trophy parade.
          </p>

          {/* All-Rivals Celebration Roster */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-left">
            {WORLD_10_CELEBRATION_CAST.map((c) => {
              const anim = ANIMALS.find((a) => a.id === c.custom.animal) ?? ANIMALS[0];
              return (
                <div
                  key={c.bossName}
                  className="p-2 rounded-xl bg-blue-900/75 border border-amber-300/40 flex flex-col items-center text-center gap-1"
                >
                  <AnimalIcon animal={anim} className="w-10 h-10" />
                  <div className="text-xs font-extrabold text-white truncate max-w-full">{c.bossName}</div>
                  <div className="text-[10px] text-amber-300 font-bold truncate max-w-full">{c.worldName}</div>
                  <div className="text-[10px] text-sky-100 leading-snug">{c.cheerLine}</div>
                </div>
              );
            })}
          </div>

          {/* Short Credits */}
          <div className="rounded-xl p-3 bg-blue-950/65 border border-sky-300/40 text-xs text-sky-100 space-y-1">
            <div className="text-amber-300 font-extrabold uppercase tracking-widest">
              WOBBLE LEAGUE football — World Tour Credits
            </div>
            <div>Grand Champion Athlete: You ({ANIMALS.find((a) => a.id === heroCustom.animal)?.name ?? 'Allstar'})</div>
            <div>Title Unlocked: WORLD CHAMPION · All 10 Arena Cups Completed</div>
          </div>

          <button
            type="button"
            data-testid="ending-continue-btn"
            onClick={onFinish}
            className="px-8 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 border-2 border-emerald-100 text-slate-950 font-display font-extrabold text-sm sm:text-base cursor-pointer"
          >
            Return to Adventure Map
          </button>
        </div>
      </div>
    );
  }

  const activeSpeaker = currentLine?.speaker ?? 'opponent';
  const heroSpeaking = activeSpeaker === 'hero';
  const oppSpeaking = activeSpeaker === 'opponent';
  const emo = EMOTION_BADGE[currentLine?.emotion ?? 'neutral'];

  return (
    <div
      data-testid="story-dialogue-cutscene"
      className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(12, 32, 68, 0.72)', backdropFilter: 'blur(4px)' }}
    >
      <div className="w-full max-w-4xl max-h-[95vh] rounded-2xl border-2 border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-2xl overflow-y-auto custom-scroll flex flex-col">
        {/* Cutscene Top Banner */}
        <div className="px-4 sm:px-5 py-2.5 border-b border-sky-300/40 bg-blue-950/55 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {match.isBoss && <Crown className="w-4 h-4 text-amber-300" />}
            <span className="text-[11px] sm:text-xs font-extrabold uppercase tracking-wider text-amber-300">
              World {world.worldNumber}: {world.name} ·{' '}
              {kind === 'pre_match'
                ? match.isBoss
                  ? 'Boss Champion Intro'
                  : `Stage ${match.matchIndex + 1} Challenger`
                : kind === 'post_win'
                  ? 'Victory Celebration'
                  : kind === 'world10_ending'
                    ? 'Grand Championship Ceremony'
                    : 'Keep Pushing!'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {match.bossStyleLabel && kind === 'pre_match' && (
              <span className="px-2.5 py-0.5 rounded-md bg-rose-500/35 border border-rose-300/60 text-white text-[11px] font-bold">
                Specialty: {match.bossStyleLabel}
              </span>
            )}
            <button
              type="button"
              data-testid="dialogue-auto-btn"
              onClick={() => setAutoAdvance((v) => !v)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer border ${
                autoAdvance
                  ? 'bg-emerald-400 text-slate-950 border-emerald-100'
                  : 'bg-sky-500/35 text-white border-sky-300/45'
              }`}
            >
              Auto: {autoAdvance ? 'ON' : 'OFF'}
            </button>
            <button
              type="button"
              data-testid="dialogue-skip-btn"
              onClick={handleSkip}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/35 hover:bg-sky-400/45 text-white text-[11px] font-bold cursor-pointer border border-sky-300/45"
            >
              <FastForward className="w-3.5 h-3.5" />
              Skip
            </button>
          </div>
        </div>

        {/* Facing Character Portraits with Active-Speaker Camera Zoom */}
        <div className="grid grid-cols-2 gap-3 sm:gap-5 px-4 sm:px-6 pt-3 pb-1.5">
          {/* Left: Hero */}
          <div
            className={`relative rounded-xl p-1.5 sm:p-2 border transition-all duration-300 ${
              heroSpeaking
                ? 'border-amber-300 bg-blue-900/75 scale-[1.02] shadow-lg'
                : 'border-sky-300/30 bg-blue-950/45 scale-95 opacity-85'
            }`}
          >
            <div className="h-[115px] sm:h-[180px]">
              <CharacterPreview3D
                team="red"
                custom={heroCustom}
                facingYaw={0.62}
                spinEnabled={false}
                isSpeaking={heroSpeaking && isTyping}
                compact
              />
            </div>
            <div className="mt-1 flex items-center justify-between px-1">
              <span className="text-xs font-extrabold text-rose-200">YOU (RED)</span>
              {heroSpeaking && (
                <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${emo.bg}`}>{emo.label}</span>
              )}
            </div>
          </div>

          {/* Right: Rival / Boss */}
          <div
            className={`relative rounded-xl p-1.5 sm:p-2 border transition-all duration-300 ${
              oppSpeaking
                ? 'border-sky-200 bg-blue-900/75 scale-[1.02] shadow-lg'
                : 'border-sky-300/30 bg-blue-950/45 scale-95 opacity-85'
            }`}
          >
            <div className="h-[115px] sm:h-[180px]">
              <CharacterPreview3D
                team="blue"
                custom={match.opponentCustom}
                facingYaw={-0.62}
                spinEnabled={false}
                isSpeaking={oppSpeaking && isTyping}
                compact
              />
            </div>
            <div className="mt-1 flex items-center justify-between px-1">
              <span className="text-xs font-extrabold text-sky-100 truncate">{match.opponentName}</span>
              {oppSpeaking && (
                <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${emo.bg}`}>{emo.label}</span>
              )}
            </div>
          </div>
        </div>

        {/* Post-Win Rewards Summary Banner */}
        {kind === 'post_win' && winOutcome && (
          <div
            data-testid="story-win-rewards"
            className="mx-4 sm:mx-6 mt-1.5 px-3.5 py-2 rounded-xl bg-emerald-500/25 border border-emerald-300/60 flex flex-wrap items-center justify-between gap-2"
          >
            <div className="flex items-center gap-2 text-emerald-100 text-xs font-extrabold">
              <Sparkles className="w-4 h-4" />
              Stage Rewards Earned!
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-amber-400 text-slate-950 font-extrabold">
                <Coins className="w-3.5 h-3.5" /> +{winOutcome.coinsEarned} Coins
              </span>
              {winOutcome.newlyUnlockedItems.map((item) => (
                <span
                  key={item}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-sky-500/35 border border-sky-200/50 text-white"
                >
                  <Award className="w-3.5 h-3.5" /> {item}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Dialogue Box + Interactive Choices */}
        <div className="p-3 sm:p-4 space-y-2.5">
          <div className="rounded-xl p-3 sm:p-3.5 bg-blue-950/75 border border-sky-300/45 min-h-[78px] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`text-xs font-extrabold uppercase tracking-wider ${
                    activeSpeaker === 'hero'
                      ? 'text-rose-300'
                      : activeSpeaker === 'narrator'
                        ? 'text-amber-300'
                        : 'text-sky-200'
                  }`}
                >
                  {currentLine?.speakerName}
                </span>
              </div>
              <p data-testid="dialogue-text" className="text-xs sm:text-base text-white leading-relaxed font-medium">
                {fullText.slice(0, charCount)}
              </p>
            </div>
          </div>

          {/* Interactive A/B/C Player Choices */}
          {waitingForChoice && currentLine?.choices && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2" data-testid="dialogue-choices">
              {currentLine.choices.map((ch) => (
                <button
                  key={ch.key}
                  type="button"
                  data-testid={`dialogue-choice-${ch.key}`}
                  onClick={() => handlePickChoice(ch)}
                  className="w-full px-3 py-2 rounded-xl bg-blue-900/75 hover:bg-amber-400 hover:text-slate-950 text-left text-xs font-bold text-white border border-sky-300/45 transition-colors cursor-pointer"
                >
                  {ch.label}
                </button>
              ))}
            </div>
          )}

          {/* Action Footer */}
          <div className="flex flex-wrap items-center justify-end gap-2.5">
            {kind === 'post_lose' && onRematch && (
              <button
                type="button"
                data-testid="dialogue-rematch-btn"
                onClick={onRematch}
                className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-xs sm:text-sm cursor-pointer flex items-center gap-1.5"
              >
                <Play className="w-4 h-4 fill-current" />
                Rematch Now
              </button>
            )}
            {!waitingForChoice && (
              <button
                type="button"
                data-testid="dialogue-next-btn"
                onClick={handleNext}
                className="px-6 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 border-2 border-emerald-100 text-slate-950 font-display font-extrabold text-xs sm:text-sm cursor-pointer flex items-center gap-1.5"
              >
                {isTyping
                  ? 'Reveal'
                  : lineIdx + 1 < lines.length
                    ? 'Next'
                    : kind === 'pre_match'
                      ? 'Kick Off Match!'
                      : kind === 'world10_ending'
                        ? 'Champion Parade'
                        : 'Continue'}
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
