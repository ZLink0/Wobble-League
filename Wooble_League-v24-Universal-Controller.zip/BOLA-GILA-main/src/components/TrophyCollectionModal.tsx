import { useRef } from 'react';
import { useDomFocusNav } from '../hooks/useDomFocusNav';
import { Award, Coins, Crown, Lock, Trophy } from 'lucide-react';
import { STORY_WORLDS, StoryProgressState } from '../game/story';

interface TrophyCollectionModalProps {
  progress: StoryProgressState;
  onClose: () => void;
}

export function TrophyCollectionModal({ progress, onClose }: TrophyCollectionModalProps) {
  const navRootRef = useRef<HTMLDivElement | null>(null);
  useDomFocusNav({ rootRef: navRootRef, onBack: onClose });
  return (
    <div
      ref={navRootRef}
      data-testid="trophy-collection-modal"
      className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(12, 32, 68, 0.72)', backdropFilter: 'blur(4px)' }}
    >
      <div className="w-full max-w-4xl max-h-[92vh] rounded-2xl border-2 border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-2xl flex flex-col overflow-hidden">
        <div className="px-4 sm:px-6 py-3 border-b border-sky-300/40 flex flex-wrap items-center justify-between gap-2 bg-blue-950/55">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-6 h-6 text-amber-300" />
            <div>
              <h2 className="font-display font-extrabold text-lg sm:text-xl text-white">Trophy Collection</h2>
              <p className="text-xs text-sky-100">
                Defeat each World Boss Champion to earn all 10 Tour Trophies &amp; Titles
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-400/25 border border-amber-300/60 text-amber-200 text-xs font-extrabold font-mono-num">
              <Coins className="w-4 h-4 text-amber-300" />
              {progress.coins} Coins
            </div>
            <button
              type="button"
              data-testid="trophy-close-btn"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll p-3.5 sm:p-4 space-y-3.5">
          {/* Earned Titles */}
          <div className="rounded-xl p-3 bg-blue-900/65 border border-sky-300/40">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-300 mb-1.5">
              Earned Champion Titles ({progress.unlockedTitles.length}/10)
            </div>
            {progress.unlockedTitles.length === 0 ? (
              <div className="text-xs text-sky-100">
                No Champion Titles unlocked yet — beat World 1 Boss Sir Wooly to earn your first title!
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {progress.unlockedTitles.map((title) => (
                  <span
                    key={title}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-400/25 border border-amber-300/50 text-amber-200 text-xs font-extrabold"
                  >
                    <Crown className="w-3.5 h-3.5 text-amber-300" />
                    {title}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* 10 World Champion Trophies Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {STORY_WORLDS.map((w) => {
              const unlocked = progress.unlockedTrophies.includes(w.trophyId);
              const boss = w.matches[4];
              return (
                <div
                  key={w.trophyId}
                  className={`p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 ${
                    unlocked
                      ? 'bg-blue-900/80 border-amber-300/75 shadow-md'
                      : 'bg-blue-950/60 border-sky-300/25 opacity-75'
                  }`}
                >
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center border"
                    style={{
                      backgroundColor: unlocked ? `${w.themeColor}33` : 'rgba(15, 23, 42, 0.45)',
                      borderColor: unlocked ? w.trophyColor : 'rgba(125, 211, 252, 0.3)',
                    }}
                  >
                    {unlocked ? (
                      <Award className="w-7 h-7" style={{ color: w.trophyColor }} />
                    ) : (
                      <Lock className="w-5 h-5 text-sky-200/70" />
                    )}
                  </div>
                  <div>
                    <div className="text-[10px] font-bold uppercase text-sky-100">World {w.worldNumber}</div>
                    <div className="text-xs font-extrabold text-white">{w.trophyName}</div>
                    <div className="text-[10px] text-sky-100/85 mt-0.5">Boss: {boss.opponentName}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
