import { Component, ReactNode } from 'react';

interface State {
  error: Error | null;
}

/** Mencegah layar blank total: jika ada error render, tampilkan tombol untuk kembali */
export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error) {
    console.error('Game error:', error);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-3 bg-slate-950 text-white p-6 text-center">
        <div className="font-display font-extrabold text-xl text-amber-300">Terjadi kesalahan</div>
        <div className="text-xs text-sky-100 max-w-md break-words">{this.state.error.message}</div>
        <button
          type="button"
          onClick={() => this.setState({ error: null })}
          className="px-5 py-2 rounded-xl bg-emerald-400 text-slate-950 font-extrabold text-sm cursor-pointer"
        >
          Coba lagi
        </button>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="px-5 py-2 rounded-xl bg-sky-500/40 border border-sky-300 text-white font-bold text-xs cursor-pointer"
        >
          Muat ulang game
        </button>
      </div>
    );
  }
}
