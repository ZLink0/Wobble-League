import { AccessorySpec, AnimalSpec, ArenaSpec, BallSpec, CenterItemSpec } from '../game/types';

export function AnimalIcon({ animal, className = 'w-11 h-11' }: { animal: AnimalSpec; className?: string }) {
  const { id, bodyColor, accentColor, snoutColor } = animal;
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <rect x="3" y="3" width="42" height="42" rx="10" fill="#0f172a" stroke="rgba(255,255,255,0.12)" strokeWidth="1.5" />
      {/* Distinct Ears / Gills / Crest */}
      {(id === 'alpaca' || id === 'kangaroo' || id === 'rabbit') && (
        <>
          <rect x="14" y="6" width="5" height="12" rx="2.5" fill={accentColor} stroke="#0f172a" strokeWidth="1.2" />
          <rect x="29" y="6" width="5" height="12" rx="2.5" fill={accentColor} stroke="#0f172a" strokeWidth="1.2" />
        </>
      )}
      {(id === 'shiba' || id === 'red_panda' || id === 'wolf' || id === 'owl') && (
        <>
          <polygon points="12,18 16,7 21,15" fill={accentColor} stroke="#0f172a" strokeWidth="1.2" />
          <polygon points="36,18 32,7 27,15" fill={accentColor} stroke="#0f172a" strokeWidth="1.2" />
        </>
      )}
      {id === 'axolotl' && (
        <>
          <rect x="6" y="16" width="7" height="3.5" rx="1.5" fill={accentColor} />
          <rect x="5" y="21" width="8" height="3.5" rx="1.5" fill={accentColor} />
          <rect x="6" y="26" width="7" height="3.5" rx="1.5" fill={accentColor} />
          <rect x="35" y="16" width="7" height="3.5" rx="1.5" fill={accentColor} />
          <rect x="35" y="21" width="8" height="3.5" rx="1.5" fill={accentColor} />
          <rect x="35" y="26" width="7" height="3.5" rx="1.5" fill={accentColor} />
        </>
      )}
      {(id === 'capybara' || id === 'gorilla' || id === 'tiger' || id === 'hippo' || id === 'bear' || id === 'koala') && (
        <>
          <circle cx="13" cy="15" r="4" fill={accentColor} stroke="#0f172a" strokeWidth="1.2" />
          <circle cx="35" cy="15" r="4" fill={accentColor} stroke="#0f172a" strokeWidth="1.2" />
        </>
      )}
      {id === 'flamingo' && <path d="M21 12 C23 6, 30 7, 29 14 Z" fill={accentColor} />}

      {id === 'lion' && <circle cx="24" cy="25" r="18" fill={accentColor} stroke="#0f172a" strokeWidth="1.4" />}
      {id === 'elephant' && (
        <>
          <ellipse cx="8" cy="24" rx="6" ry="10" fill={snoutColor} stroke="#0f172a" strokeWidth="1.2" />
          <ellipse cx="40" cy="24" rx="6" ry="10" fill={snoutColor} stroke="#0f172a" strokeWidth="1.2" />
        </>
      )}
      {id === 'giraffe' && (
        <>
          <rect x="17" y="5" width="3" height="9" fill={accentColor} />
          <circle cx="18.5" cy="5" r="2.2" fill={accentColor} />
          <rect x="28" y="5" width="3" height="9" fill={accentColor} />
          <circle cx="29.5" cy="5" r="2.2" fill={accentColor} />
        </>
      )}

      {/* Head Silhouette */}
      <rect x="12" y="13" width="24" height="23" rx="8" fill={bodyColor} stroke="#0f172a" strokeWidth="1.6" />

      {/* Penguin white belly/face patch */}
      {id === 'penguin' && <rect x="15" y="18" width="18" height="16" rx="6" fill={accentColor} />}
      {/* Shiba / Red panda cheek highlights */}
      {(id === 'shiba' || id === 'red_panda') && (
        <>
          <ellipse cx="17" cy="27" rx="4.5" ry="3.5" fill={snoutColor} />
          <ellipse cx="31" cy="27" rx="4.5" ry="3.5" fill={snoutColor} />
        </>
      )}

      {id === 'tiger' && (
        <>
          <rect x="15" y="16" width="6" height="2" fill={accentColor} />
          <rect x="27" y="16" width="6" height="2" fill={accentColor} />
          <rect x="22" y="14" width="4" height="3" fill={accentColor} />
        </>
      )}
      {id === 'giraffe' && (
        <>
          <circle cx="30" cy="17" r="2" fill={accentColor} />
          <circle cx="16" cy="19" r="1.6" fill={accentColor} />
        </>
      )}
      {id === 'owl' && (
        <>
          <circle cx="19" cy="22" r="5.2" fill={accentColor} />
          <circle cx="29" cy="22" r="5.2" fill={accentColor} />
        </>
      )}
      {id === 'wolf' && <rect x="14" y="25" width="20" height="9" rx="4" fill={snoutColor} />}

      {/* Eyes */}
      <circle cx="19" cy="22" r="2.3" fill="#0f172a" />
      <circle cx="29" cy="22" r="2.3" fill="#0f172a" />
      <circle cx="19.6" cy="21.2" r="0.8" fill="#ffffff" />
      <circle cx="29.6" cy="21.2" r="0.8" fill="#ffffff" />

      {/* Snout / Beak */}
      {id === 'flamingo' || id === 'penguin' || id === 'owl' ? (
        <polygon points="20,26 28,26 24,33" fill={snoutColor} stroke="#0f172a" strokeWidth="1.2" />
      ) : id === 'crocodile' ? (
        <>
          <rect x="14" y="25" width="20" height="8" rx="3" fill={snoutColor} stroke="#0f172a" strokeWidth="1.2" />
          <rect x="17" y="31" width="2.5" height="2.5" fill="#ffffff" />
          <rect x="28.5" y="31" width="2.5" height="2.5" fill="#ffffff" />
        </>
      ) : id === 'elephant' ? (
        <>
          <rect x="20" y="26" width="8" height="15" rx="4" fill={bodyColor} stroke="#0f172a" strokeWidth="1.2" />
        </>
      ) : id === 'hippo' ? (
        <>
          <rect x="13" y="25" width="22" height="10" rx="5" fill={snoutColor} />
          <circle cx="20" cy="29" r="1.3" fill="#1e293b" />
          <circle cx="28" cy="29" r="1.3" fill="#1e293b" />
        </>
      ) : (
        <>
          <rect x="18" y="25" width="12" height="7.5" rx="3.5" fill={snoutColor} />
          <ellipse cx="24" cy="27" rx="2.3" ry="1.5" fill="#1e293b" />
        </>
      )}
    </svg>
  );
}

export function AccessoryIcon({ item, className = 'w-10 h-10' }: { item: AccessorySpec; className?: string }) {
  const { category, primaryColor, secondaryColor, style } = item;
  return (
    <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
      <rect x="2" y="2" width="40" height="40" rx="9" fill="#0f172a" stroke="rgba(255,255,255,0.12)" strokeWidth="1.4" />
      {style === 'none' ? (
        <>
          <circle cx="22" cy="22" r="10" fill="none" stroke="#64748b" strokeWidth="2.5" strokeDasharray="3 2" />
          <line x1="15" y1="29" x2="29" y2="15" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
        </>
      ) : category === 'hat' ? (
        <>
          {style === 'cone' || style === 'wizard' || style === 'archmage' || style === 'tornwizard' || style === 'witch' ? (
            <>
              <ellipse cx="22" cy="31" rx="13" ry="3.5" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
              <polygon points="13,30 22,8 31,30" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
              <rect x="16" y="20" width="12" height="3.5" fill={secondaryColor} />
            </>
          ) : style === 'crystals' || style === 'elf' || style === 'druid' || style === 'phoenix' ? (
            <>
              <polygon points="22,6 27,16 22,26 17,16" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
              <polygon points="11,14 14,20 11,26 8,20" fill={secondaryColor} stroke="#020617" strokeWidth="1" />
              <polygon points="33,14 36,20 33,26 30,20" fill={secondaryColor} stroke="#020617" strokeWidth="1" />
              <ellipse cx="22" cy="31" rx="12" ry="3" fill={secondaryColor} opacity="0.7" />
            </>
          ) : style === 'dragonhelm' || style === 'brokenhelm' || style === 'raggedcap' ? (
            <>
              <path d="M11 30 C11 15, 33 15, 33 30 Z" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <rect x="11" y="27" width="22" height="4" fill={secondaryColor} />
              {style === 'dragonhelm' && (
                <>
                  <path d="M12 22 C5 19, 5 11, 10 9 C9 14, 12 17, 15 18 Z" fill={secondaryColor} />
                  <path d="M32 22 C39 19, 39 11, 34 9 C35 14, 32 17, 29 18 Z" fill={secondaryColor} />
                </>
              )}
              {style !== 'dragonhelm' && <polyline points="19,17 22,22 20,26" fill="none" stroke="#020617" strokeWidth="1.3" />}
            </>
          ) : style === 'crown' ? (
            <polygon
              points="10,30 12,14 18,22 22,11 26,22 32,14 34,30"
              fill={primaryColor}
              stroke="#020617"
              strokeWidth="1.4"
            />
          ) : style === 'viking' ? (
            <>
              <path d="M12 28 C12 16, 32 16, 32 28 Z" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <path d="M12 22 C6 18, 6 11, 11 10 C10 15, 12 18, 15 19 Z" fill={secondaryColor} />
              <path d="M32 22 C38 18, 38 11, 33 10 C34 15, 32 18, 29 19 Z" fill={secondaryColor} />
            </>
          ) : style === 'chef' ? (
            <>
              <circle cx="16" cy="16" r="6" fill={primaryColor} />
              <circle cx="22" cy="13" r="6.5" fill={primaryColor} />
              <circle cx="28" cy="16" r="6" fill={primaryColor} />
              <rect x="13" y="20" width="18" height="11" rx="2" fill={secondaryColor} stroke="#020617" strokeWidth="1.2" />
            </>
          ) : style === 'propeller' ? (
            <>
              <path d="M11 29 C11 17, 33 17, 33 29 Z" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <rect x="20.5" y="12" width="3" height="6" fill="#94a3b8" />
              <ellipse cx="22" cy="12" rx="11" ry="2.4" fill={secondaryColor} stroke="#020617" strokeWidth="1" />
            </>
          ) : style === 'ufo' ? (
            <>
              <ellipse cx="22" cy="21" rx="7" ry="6" fill={secondaryColor} />
              <ellipse cx="22" cy="25" rx="14" ry="5" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
            </>
          ) : style === 'burger' ? (
            <>
              <path d="M11 20 C11 12, 33 12, 33 20 Z" fill={primaryColor} />
              <rect x="10" y="20" width="24" height="3.5" rx="1.5" fill={secondaryColor} />
              <rect x="11" y="24" width="22" height="4" rx="1.5" fill="#7c2d12" />
              <rect x="11" y="28.5" width="22" height="4.5" rx="2" fill={primaryColor} />
            </>
          ) : style === 'tv' ? (
            <>
              <rect x="10" y="13" width="24" height="19" rx="3" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <rect x="13" y="16" width="18" height="13" rx="2" fill={secondaryColor} />
              <line x1="16" y1="8" x2="21" y2="13" stroke="#cbd5e1" strokeWidth="1.8" />
              <line x1="28" y1="8" x2="23" y2="13" stroke="#cbd5e1" strokeWidth="1.8" />
            </>
          ) : style === 'sombrero' ? (
            <>
              <ellipse cx="22" cy="27" rx="15" ry="4.5" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
              <path d="M15 26 L18 14 L26 14 L29 26 Z" fill={secondaryColor} stroke="#020617" strokeWidth="1.2" />
            </>
          ) : (
            <>
              <ellipse cx="22" cy="29" rx="13" ry="4" fill={secondaryColor} />
              <rect x="13" y="13" width="18" height="15" rx="6" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <circle cx="22" cy="14" r="4" fill={secondaryColor} />
            </>
          )}
        </>
      ) : category === 'mask' ? (
        <>
          {style === 'googly' || style === 'shades' || style === 'snorkel' ? (
            <>
              <rect x="9" y="16" width="11" height="10" rx={style === 'shades' ? '2' : '5'} fill={primaryColor} stroke="#020617" strokeWidth="1.4" />
              <rect x="24" y="16" width="11" height="10" rx={style === 'shades' ? '2' : '5'} fill={primaryColor} stroke="#020617" strokeWidth="1.4" />
              <rect x="19.5" y="19" width="5" height="3" fill={secondaryColor} />
              <circle cx="14.5" cy="21" r="2.2" fill={secondaryColor} />
              <circle cx="29.5" cy="21" r="2.2" fill={secondaryColor} />
            </>
          ) : style === 'visor' ? (
            <rect x="8" y="16" width="28" height="11" rx="4" fill={primaryColor} stroke={secondaryColor} strokeWidth="2" />
          ) : style === 'mustache' ? (
            <>
              <circle cx="22" cy="18" r="5" fill={secondaryColor} />
              <path d="M10 27 C14 21, 20 22, 22 25 C24 22, 30 21, 34 27 C29 30, 24 29, 22 27 C20 29, 15 30, 10 27 Z" fill={primaryColor} />
            </>
          ) : (
            <>
              <rect x="11" y="11" width="22" height="22" rx="7" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <rect x="14" y="18" width="6" height="4" rx="1.5" fill={secondaryColor} />
              <rect x="24" y="18" width="6" height="4" rx="1.5" fill={secondaryColor} />
              <rect x="18" y="26" width="8" height="2.5" rx="1" fill={secondaryColor} />
            </>
          )}
        </>
      ) : (
        /* Cape Silhouette */
        <>
          {style === 'wings' ? (
            <>
              <path d="M22 14 L8 10 L11 29 L22 24 Z" fill={primaryColor} stroke={secondaryColor} strokeWidth="1.3" />
              <path d="M22 14 L36 10 L33 29 L22 24 Z" fill={primaryColor} stroke={secondaryColor} strokeWidth="1.3" />
            </>
          ) : style === 'jetpack' ? (
            <>
              <rect x="13" y="11" width="7" height="19" rx="3" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
              <rect x="24" y="11" width="7" height="19" rx="3" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
              <polygon points="14,30 19,30 16.5,37" fill={secondaryColor} />
              <polygon points="25,30 30,30 27.5,37" fill={secondaryColor} />
            </>
          ) : style === 'pizza' ? (
            <>
              <polygon points="10,11 34,11 22,35" fill={primaryColor} stroke="#b45309" strokeWidth="1.5" />
              <circle cx="19" cy="18" r="2.3" fill={secondaryColor} />
              <circle cx="25" cy="21" r="2.2" fill={secondaryColor} />
              <circle cx="22" cy="27" r="2" fill={secondaryColor} />
            </>
          ) : (
            <>
              <path d="M15 10 L29 10 L34 34 L22 31 L10 34 Z" fill={primaryColor} stroke="#020617" strokeWidth="1.3" />
              <rect x="15" y="10" width="14" height="4" rx="1.5" fill={secondaryColor} />
              <line x1="22" y1="14" x2="22" y2="30" stroke={secondaryColor} strokeWidth="1.5" strokeOpacity="0.65" />
            </>
          )}
        </>
      )}
    </svg>
  );
}

export function BallPreviewIcon({ ball, className = 'w-12 h-12' }: { ball: BallSpec; className?: string }) {
  const { id, primaryColor, secondaryColor } = ball;
  const gradId = `ball-grad-${id}`;
  return (
    <svg viewBox="0 0 56 56" className={className} aria-hidden="true">
      <defs>
        <radialGradient id={gradId} cx="35%" cy="32%" r="68%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
          <stop offset="35%" stopColor={primaryColor} />
          <stop offset="100%" stopColor={secondaryColor} stopOpacity="0.95" />
        </radialGradient>
      </defs>

      {/* Drop shadow */}
      <ellipse cx="28" cy="48" rx="16" ry="3.5" fill="rgba(0,0,0,0.45)" />

      {id === 'hockey' ? (
        /* Flat Dark Cylinder Hockey Puck */
        <>
          <path d="M8 25 L8 35 A20 8 0 0 0 48 35 L48 25 Z" fill="#090d16" stroke="#020617" strokeWidth="1.5" />
          <ellipse cx="28" cy="25" rx="20" ry="8" fill="#1e293b" stroke={secondaryColor} strokeWidth="1.8" />
          <ellipse cx="28" cy="25" rx="12" ry="4.5" fill="none" stroke={secondaryColor} strokeWidth="1.2" strokeOpacity="0.7" />
        </>
      ) : id === 'flat_disc' ? (
        /* Flat Flying Disc with aerodynamic rim */
        <>
          <ellipse cx="28" cy="30" rx="22" ry="7.5" fill="#c2410c" stroke="#020617" strokeWidth="1.4" />
          <ellipse cx="28" cy="27.5" rx="22" ry="7" fill={primaryColor} stroke="#020617" strokeWidth="1.2" />
          <ellipse cx="28" cy="27.5" rx="14" ry="4.2" fill="none" stroke={secondaryColor} strokeWidth="2" />
          <ellipse cx="28" cy="26.5" rx="8" ry="2.2" fill="#38bdf8" opacity="0.85" />
        </>
      ) : id === 'nfl' ? (
        /* Prolate Oval Football */
        <g transform="rotate(-18 28 28)">
          <ellipse cx="28" cy="28" rx="21" ry="13.5" fill={primaryColor} stroke="#020617" strokeWidth="1.6" />
          <ellipse cx="25" cy="23" rx="12" ry="4" fill="#b45309" opacity="0.45" />
          <line x1="14" y1="28" x2="42" y2="28" stroke={secondaryColor} strokeWidth="1.8" />
          <line x1="21" y1="24" x2="21" y2="32" stroke={secondaryColor} strokeWidth="1.8" />
          <line x1="26" y1="24" x2="26" y2="32" stroke={secondaryColor} strokeWidth="1.8" />
          <line x1="31" y1="24" x2="31" y2="32" stroke={secondaryColor} strokeWidth="1.8" />
          <line x1="35" y1="24" x2="35" y2="32" stroke={secondaryColor} strokeWidth="1.8" />
        </g>
      ) : id === 'crystal' ? (
        /* Translucent Sphere + Faceted Inner Crystal */
        <>
          <circle cx="28" cy="28" r="19" fill="url(#ball-grad-crystal)" stroke="#a5f3fc" strokeWidth="1.8" />
          <polygon points="28,13 38,28 28,43 18,28" fill="#e879f9" fillOpacity="0.72" stroke="#f5d0fe" strokeWidth="1.2" />
          <polygon points="28,13 38,28 28,28" fill="#ffffff" fillOpacity="0.4" />
          <circle cx="21" cy="20" r="3.5" fill="#ffffff" fillOpacity="0.75" />
        </>
      ) : id === 'metal' ? (
        /* Brushed Chrome Steel Sphere */
        <>
          <circle cx="28" cy="28" r="19" fill={`url(#${gradId})`} stroke="#0f172a" strokeWidth="1.6" />
          <ellipse cx="28" cy="28" rx="18.5" ry="5" fill="none" stroke="#334155" strokeWidth="1.5" />
          <circle cx="20" cy="20" r="4" fill="#ffffff" opacity="0.7" />
          <circle cx="19" cy="28" r="2" fill="#1e293b" />
          <circle cx="28" cy="28" r="2" fill="#1e293b" />
          <circle cx="37" cy="28" r="2" fill="#1e293b" />
        </>
      ) : id === 'soccer' ? (
        <>
          <circle cx="28" cy="28" r="19" fill="#f8fafc" stroke="#0f172a" strokeWidth="1.6" />
          <path d="M28 16 Q34 22 38 30 Q28 31 18 30 Q22 22 28 16Z" fill="#e2e8f0" stroke="#475569" strokeWidth="1.4" />
          <path d="M28 21 Q31 25 33 29 Q28 29.5 23 29 Q25 25 28 21Z" fill="#334155" />
          <path d="M10 26 Q14 22 18 24" fill="none" stroke="#475569" strokeWidth="1.4" />
          <path d="M46 26 Q42 22 38 24" fill="none" stroke="#475569" strokeWidth="1.4" />
          <path d="M20 42 Q28 36 36 42" fill="none" stroke="#475569" strokeWidth="1.4" />
        </>
      ) : id === 'pro_blue' || id === 'pro_yellow' || id === 'pro_gold' ? (
        <>
          <circle cx="28" cy="28" r="19" fill={id === 'pro_gold' ? '#0b0d12' : '#f8fafc'} stroke="#0f172a" strokeWidth="1.6" />
          <polygon points="28,19 36,24 33,33 23,33 20,24" fill={id === 'pro_gold' ? '#05060a' : '#e2e8f0'} stroke={id === 'pro_gold' ? '#d4a017' : '#94a3b8'} strokeWidth="1" />
          <polygon points="12,30 30,17 24,27 41,22 20,42 25,32" fill={id === 'pro_blue' ? '#1d6fe0' : id === 'pro_yellow' ? '#facc15' : '#d4a017'} />
          <polygon points="30,17 46,26 36,28 40,38 33,30" fill="#0b1220" opacity="0.85" />
        </>
      ) : id === 'soccer_telstar' ? (
        <>
          <circle cx="28" cy="28" r="19" fill="#f8fafc" stroke="#0f172a" strokeWidth="1.6" />
          <polygon points="28,20 35,25 32,34 24,34 21,25" fill="#1e293b" />
          <polygon points="28,9 33,13 28,17 23,13" fill="#1e293b" />
          <polygon points="10,23 15,21 16,28 11,31" fill="#1e293b" />
          <polygon points="46,23 41,21 40,28 45,31" fill="#1e293b" />
          <polygon points="19,44 23,39 27,45" fill="#1e293b" />
          <polygon points="37,44 33,39 29,45" fill="#1e293b" />
        </>
      ) : id === 'rubber' ? (
        <>
          <circle cx="28" cy="28" r="19" fill={primaryColor} stroke="#0f172a" strokeWidth="1.6" />
          <path d="M12 22 Q28 14 44 22" fill="none" stroke={secondaryColor} strokeWidth="3.5" strokeLinecap="round" />
          <path d="M11 33 Q28 41 45 33" fill="none" stroke="#38bdf8" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="20" cy="18" r="3.2" fill="#ffffff" opacity="0.65" />
        </>
      ) : id === 'beach_volleyball' ? (
        <>
          <circle cx="28" cy="28" r="19" fill="#ffffff" stroke="#0f172a" strokeWidth="1.6" />
          <path d="M28 9 A19 19 0 0 1 47 28 L28 28 Z" fill="#ef4444" />
          <path d="M28 9 A19 19 0 0 0 9 28 L28 28 Z" fill="#facc15" />
          <path d="M9 28 A19 19 0 0 0 28 47 L28 28 Z" fill="#3b82f6" />
          <circle cx="28" cy="28" r="19" fill="none" stroke="#0f172a" strokeWidth="1.6" />
          <circle cx="28" cy="28" r="3.5" fill="#ffffff" stroke="#0f172a" strokeWidth="1.2" />
        </>
      ) : id === 'tennis' ? (
        <>
          <circle cx="28" cy="28" r="18" fill={primaryColor} stroke="#0f172a" strokeWidth="1.6" />
          <path d="M16 14 C23 22, 23 34, 16 42" fill="none" stroke={secondaryColor} strokeWidth="2.5" strokeLinecap="round" />
          <path d="M40 14 C33 22, 33 34, 40 42" fill="none" stroke={secondaryColor} strokeWidth="2.5" strokeLinecap="round" />
        </>
      ) : id === 'dice' ? (
        /* Ivory Cube Die with Black & Red Pips */
        <g transform="rotate(-8 28 28)">
          <rect x="10" y="10" width="36" height="36" rx="6" fill={primaryColor} stroke="#0f172a" strokeWidth="1.8" />
          <rect x="13" y="13" width="30" height="30" rx="4" fill="#ffffff" fillOpacity="0.35" />
          <circle cx="19" cy="19" r="3" fill={secondaryColor} />
          <circle cx="37" cy="19" r="3" fill={secondaryColor} />
          <circle cx="28" cy="28" r="3.4" fill="#dc2626" />
          <circle cx="19" cy="37" r="3" fill={secondaryColor} />
          <circle cx="37" cy="37" r="3" fill={secondaryColor} />
        </g>
      ) : id === 'ostrich_egg' ? (
        /* Tall Speckled Cream Ostrich Egg */
        <>
          <path
            d="M28 7 C38 7 44 21 43 34 C42 43 36 47 28 47 C20 47 14 43 13 34 C12 21 18 7 28 7 Z"
            fill={primaryColor}
            stroke="#0f172a"
            strokeWidth="1.7"
          />
          <ellipse cx="23" cy="17" rx="3.5" ry="5" fill="#ffffff" opacity="0.5" transform="rotate(-15 23 17)" />
          <circle cx="21" cy="28" r="1.7" fill={secondaryColor} />
          <circle cx="33" cy="24" r="1.4" fill={secondaryColor} />
          <circle cx="29" cy="35" r="1.9" fill={secondaryColor} />
          <circle cx="23" cy="39" r="1.3" fill={secondaryColor} />
          <circle cx="35" cy="34" r="1.5" fill={secondaryColor} />
        </>
      ) : id === 'timer_bomb' ? (
        /* 15s Timer Bomb Sphere */
        <>
          <rect x="24" y="6" width="8" height="6" rx="1.5" fill="#475569" stroke="#020617" strokeWidth="1.2" />
          <path d="M29 6 Q35 2 39 7" fill="none" stroke="#cbd5e1" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="39.5" cy="7" r="3" fill="#facc15" />
          <circle cx="39.5" cy="7" r="1.4" fill="#ef4444" />
          <circle cx="28" cy="30" r="18" fill={primaryColor} stroke="#020617" strokeWidth="1.8" />
          <path d="M12 27 H44 V33 H12 Z" fill={secondaryColor} opacity="0.88" />
          <rect x="19" y="24" width="18" height="12" rx="3" fill="#0f172a" stroke="#facc15" strokeWidth="1.2" />
          <text
            x="28"
            y="33"
            textAnchor="middle"
            fill="#fde047"
            fontFamily="JetBrains Mono, monospace"
            fontWeight="800"
            fontSize="8.5"
          >
            15s
          </text>
        </>
      ) : id === 'honey_ball' ? (
        /* Sticky Golden Honey Ball */
        <>
          <circle cx="28" cy="28" r="19" fill={primaryColor} stroke="#78350f" strokeWidth="1.7" />
          <path
            d="M12 21 Q18 14 28 16 Q38 18 44 22 L45 30 Q40 35 36 28 Q32 39 27 30 Q22 38 17 29 Q13 33 11 28 Z"
            fill={secondaryColor}
            opacity="0.92"
          />
          <circle cx="21" cy="18" r="3.2" fill="#fef9c3" opacity="0.75" />
          <circle cx="27" cy="44" r="3.2" fill={primaryColor} stroke="#78350f" strokeWidth="1.2" />
        </>
      ) : (
        /* Star Arena Ball */
        <>
          <circle cx="28" cy="28" r="19" fill={primaryColor} stroke="#0f172a" strokeWidth="1.6" />
          <polygon
            points="28,13 32,22 42,23 34,29 36,39 28,34 20,39 22,29 14,23 24,22"
            fill={secondaryColor}
            stroke="#0f172a"
            strokeWidth="1.2"
          />
        </>
      )}
    </svg>
  );
}

export function ArenaPreviewIcon({ arena, className = 'w-full h-14' }: { arena: ArenaSpec; className?: string }) {
  return (
    <svg viewBox="0 0 120 64" className={className} preserveAspectRatio="none" aria-hidden="true">
      {/* Sky Backdrop */}
      <rect x="0" y="0" width="120" height="24" fill={arena.skyTop} />
      <rect x="0" y="17" width="120" height="7" fill={arena.skyFog} opacity="0.6" />

      {/* Theme Landmarks in Sky Horizon */}
      {arena.themeProp === 'trees' || arena.themeProp === 'sakura' || arena.themeProp === 'ruins' ? (
        <>
          <circle cx="18" cy="18" r="6" fill={arena.themeProp === 'sakura' ? '#f472b6' : '#15803d'} />
          <circle cx="102" cy="18" r="6" fill={arena.themeProp === 'sakura' ? '#f9a8d4' : '#166534'} />
        </>
      ) : arena.themeProp === 'volcano_rocks' || arena.themeProp === 'dunes' ? (
        <>
          <polygon points="10,24 24,8 38,24" fill={arena.themeProp === 'volcano_rocks' ? '#7c2d12' : '#d97706'} />
          <polygon points="84,24 98,10 112,24" fill={arena.themeProp === 'volcano_rocks' ? '#9a3412' : '#b45309'} />
        </>
      ) : arena.themeProp === 'floodlights' ? (
        <>
          <rect x="16" y="7" width="3" height="17" fill="#cbd5e1" />
          <rect x="13" y="5" width="9" height="4" fill="#fef08a" />
          <rect x="101" y="7" width="3" height="17" fill="#cbd5e1" />
          <rect x="98" y="5" width="9" height="4" fill="#fef08a" />
        </>
      ) : arena.themeProp === 'ice_pillars' ? (
        <>
          <polygon points="14,24 19,6 24,24" fill="#e0f2fe" />
          <polygon points="96,24 101,8 106,24" fill="#bae6fd" />
        </>
      ) : arena.themeProp === 'palms' ? (
        <>
          <path d="M18 24 L20 12" stroke="#78350f" strokeWidth="2.5" />
          <ellipse cx="20" cy="11" rx="7" ry="2.5" fill="#16a34a" />
          <path d="M102 24 L100 12" stroke="#78350f" strokeWidth="2.5" />
          <ellipse cx="100" cy="11" rx="7" ry="2.5" fill="#16a34a" />
        </>
      ) : arena.themeProp === 'candy' ? (
        <>
          <rect x="17" y="13" width="2" height="11" fill="#ffffff" />
          <circle cx="18" cy="11" r="5" fill="#ec4899" stroke="#fde047" strokeWidth="1.5" />
          <rect x="101" y="13" width="2" height="11" fill="#ffffff" />
          <circle cx="102" cy="11" r="5" fill="#38bdf8" stroke="#f9a8d4" strokeWidth="1.5" />
        </>
      ) : arena.themeProp === 'floating' ? (
        <>
          <ellipse cx="22" cy="15" rx="12" ry="3" fill="#4ade80" />
          <polygon points="12,15 32,15 22,24" fill="#78350f" />
          <ellipse cx="98" cy="11" rx="9" ry="2.5" fill="#4ade80" />
          <polygon points="90,11 106,11 98,18" fill="#78350f" />
        </>
      ) : arena.themeProp === 'rooftop' ? (
        <>
          <rect x="10" y="9" width="10" height="15" fill="#334155" />
          <rect x="24" y="5" width="8" height="19" fill="#475569" />
          <rect x="92" y="7" width="9" height="17" fill="#334155" />
          <rect x="104" y="12" width="9" height="12" fill="#475569" />
          <polygon points="62,6 66,8 62,10 60,8" fill="#f8fafc" />
        </>
      ) : arena.themeProp === 'royal' ? (
        <>
          <polygon points="14,24 14,12 18,16 22,10 26,16 30,12 30,24" fill="#facc15" />
          <polygon points="90,24 90,12 94,16 98,10 102,16 106,12 106,24" fill="#facc15" />
        </>
      ) : (
        <>
          <ellipse cx="26" cy="12" rx="10" ry="4" fill="#ffffff" opacity="0.7" />
          <ellipse cx="94" cy="11" rx="11" ry="4" fill="#ffffff" opacity="0.7" />
        </>
      )}

      {/* Perimeter Border */}
      <rect x="0" y="22" width="120" height="42" fill={arena.borderColor} />

      {/* Striped Pitch */}
      <rect x="6" y="25" width="18" height="35" fill={arena.grassA} />
      <rect x="24" y="25" width="18" height="35" fill={arena.grassB} />
      <rect x="42" y="25" width="18" height="35" fill={arena.grassA} />
      <rect x="60" y="25" width="18" height="35" fill={arena.grassB} />
      <rect x="78" y="25" width="18" height="35" fill={arena.grassA} />
      <rect x="96" y="25" width="18" height="35" fill={arena.grassB} />

      {/* Crisp Pitch Markings + Left/Right Goals */}
      <rect x="6" y="25" width="108" height="35" fill="none" stroke="#ffffff" strokeWidth="1.2" strokeOpacity="0.85" />
      <line x1="60" y1="25" x2="60" y2="60" stroke="#ffffff" strokeWidth="1.2" strokeOpacity="0.85" />
      <circle cx="60" cy="42.5" r="7.5" fill="none" stroke="#ffffff" strokeWidth="1.2" strokeOpacity="0.85" />
      <rect x="2" y="34" width="6" height="17" fill="#dc2626" fillOpacity="0.4" stroke="#ffffff" strokeWidth="1.2" />
      <rect x="112" y="34" width="6" height="17" fill="#2563eb" fillOpacity="0.4" stroke="#ffffff" strokeWidth="1.2" />
    </svg>
  );
}

export function ItemSpawnIcon({ item, className = 'w-8 h-8' }: { item: CenterItemSpec; className?: string }) {
  const { id, color } = item;
  return (
    <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
      <rect x="2" y="2" width="32" height="32" rx="8" fill="#0f172a" stroke="rgba(255,255,255,0.12)" strokeWidth="1.2" />
      {id === 'fire_power' ? (
        <>
          <path d="M18 6 C23 12, 27 17, 25 24 C23 28, 13 28, 11 24 C9 18, 14 14, 15 10 C16 12, 18 11, 18 6 Z" fill="#f97316" />
          <path d="M18 15 C21 19, 22 23, 18 26 C14 23, 15 19, 18 15 Z" fill="#fde047" />
        </>
      ) : id === 'giant_ball' ? (
        <>
          <circle cx="18" cy="18" r="10.5" fill={color} stroke="#fef08a" strokeWidth="1.5" />
          <path d="M11 18 L25 18 M18 11 L18 25" stroke="#0f172a" strokeWidth="1.8" strokeLinecap="round" />
        </>
      ) : id === 'meteor_shower' ? (
        <>
          <line x1="10" y1="8" x2="21" y2="19" stroke="#f97316" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="22" cy="22" r="6" fill={color} stroke="#fde047" strokeWidth="1.3" />
        </>
      ) : id === 'updraft_wind' ? (
        <>
          <path d="M9 13 Q18 9 27 13" fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" />
          <path d="M11 19 Q18 15 25 19" fill="none" stroke="#bae6fd" strokeWidth="2.4" strokeLinecap="round" />
          <path d="M13 25 Q18 22 23 25" fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" />
        </>
      ) : id === 'heavy_ghost' ? (
        <>
          <path d="M11 26 L11 16 A7 7 0 0 1 25 16 L25 26 L22 23 L18 26 L14 23 Z" fill={color} fillOpacity="0.85" />
          <circle cx="15.5" cy="16" r="1.5" fill="#fef08a" />
          <circle cx="20.5" cy="16" r="1.5" fill="#fef08a" />
        </>
      ) : id === 'bomb_ball' ? (
        <>
          <circle cx="17" cy="21" r="8" fill="#1e293b" stroke="#94a3b8" strokeWidth="1.4" />
          <path d="M21 14 Q25 9 27 10" fill="none" stroke="#cbd5e1" strokeWidth="2" />
          <circle cx="27" cy="10" r="2.6" fill="#facc15" />
          <circle cx="27" cy="10" r="1.2" fill="#ef4444" />
        </>
      ) : (
        /* Rubber Ball 10x */
        <>
          <circle cx="18" cy="18" r="9.5" fill={color} stroke="#fbcfe8" strokeWidth="1.6" />
          <path d="M11 15 Q18 10 25 15" fill="none" stroke="#fde047" strokeWidth="2.2" />
          <path d="M11 22 Q18 27 25 22" fill="none" stroke="#38bdf8" strokeWidth="2.2" />
        </>
      )}
    </svg>
  );
}
