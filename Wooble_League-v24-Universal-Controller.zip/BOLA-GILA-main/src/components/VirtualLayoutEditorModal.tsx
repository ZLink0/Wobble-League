import { useRef, useState } from 'react';
import { Check, Move, RotateCcw, X } from 'lucide-react';
import { DEFAULT_VIRTUAL_LAYOUT } from '../game/catalog';
import { ButtonSkinId, VirtualLayoutConfig, VirtualPadSlotId } from '../game/types';
import { DashIcon, GrabIcon, HeadSpinIcon, JumpIcon, KickIcon, SpinKickIcon, StartBarsIcon } from './ButtonIcons';
import { padButtonClass } from './MatchHUD';

interface VirtualLayoutEditorModalProps {
  layout: VirtualLayoutConfig;
  buttonSkin: ButtonSkinId;
  onSave: (next: VirtualLayoutConfig) => void;
  onClose: () => void;
}

const SLOT_LABELS: Record<VirtualPadSlotId, string> = {
  dpad: 'Analog D-Pad',
  system: 'Start',
  shoulderL: 'Tombol L',
  shoulderR: 'Tombol R',
  abxy: 'A B X Y Cluster',
};

const ALL_SLOTS: VirtualPadSlotId[] = ['dpad', 'system', 'shoulderL', 'shoulderR', 'abxy'];

/** Batas geser per tombol (px, relatif terhadap posisi default). START berangkat dari pojok kanan atas. */
const DRAG_BOUNDS: Record<VirtualPadSlotId, { minX: number; maxX: number; minY: number; maxY: number }> = {
  dpad: { minX: -40, maxX: 560, minY: -330, maxY: 110 },
  system: { minX: -760, maxX: 20, minY: -10, maxY: 330 },
  shoulderL: { minX: -560, maxX: 240, minY: -330, maxY: 110 },
  shoulderR: { minX: -560, maxX: 240, minY: -330, maxY: 110 },
  abxy: { minX: -560, maxX: 240, minY: -330, maxY: 110 },
};

function cloneLayout(src: VirtualLayoutConfig): VirtualLayoutConfig {
  const out = {} as VirtualLayoutConfig;
  for (const k of ALL_SLOTS) out[k] = { ...src[k] };
  return out;
}

export function VirtualLayoutEditorModal({
  layout,
  buttonSkin,
  onSave,
  onClose,
}: VirtualLayoutEditorModalProps) {
  const [draft, setDraft] = useState<VirtualLayoutConfig>(() => cloneLayout(layout));
  const [selectedSlot, setSelectedSlot] = useState<VirtualPadSlotId>('abxy');
  const dragRef = useRef<{
    slot: VirtualPadSlotId;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const isTransparent = buttonSkin === 'transparent' || buttonSkin === 'icons_clear';
  const isIconSkin = buttonSkin === 'icons' || buttonSkin === 'icons_clear';

  const beginDrag = (slot: VirtualPadSlotId) => (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    setSelectedSlot(slot);
    dragRef.current = {
      slot,
      startX: e.clientX,
      startY: e.clientY,
      origX: draft[slot].xOffset,
      origY: draft[slot].yOffset,
    };
  };

  const onDragMove = (slot: VirtualPadSlotId) => (e: React.PointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    if (!d || d.slot !== slot) return;
    const b = DRAG_BOUNDS[slot];
    const dx = Math.max(b.minX, Math.min(b.maxX, Math.round(d.origX + (e.clientX - d.startX))));
    const dy = Math.max(b.minY, Math.min(b.maxY, Math.round(d.origY + (e.clientY - d.startY))));
    setDraft((prev) => ({
      ...prev,
      [slot]: { ...prev[slot], xOffset: dx, yOffset: dy },
    }));
  };

  const endDrag = () => {
    dragRef.current = null;
  };

  const updateSelectedScale = (scale: number) => {
    setDraft((prev) => ({
      ...prev,
      [selectedSlot]: { ...prev[selectedSlot], scale },
    }));
  };

  const slotHighlight = (slot: VirtualPadSlotId) =>
    selectedSlot === slot
      ? 'ring-4 ring-amber-300 bg-sky-400/20 rounded-2xl p-1.5 cursor-grab active:cursor-grabbing'
      : 'ring-2 ring-white/40 bg-slate-950/15 rounded-2xl p-1.5 hover:ring-amber-200 cursor-grab active:cursor-grabbing';

  const placement = (slot: VirtualPadSlotId) =>
    `translate(${draft[slot].xOffset}px, ${draft[slot].yOffset}px) scale(${draft[slot].scale})`;

  const cur = draft[selectedSlot];
  const iconSm = 'w-6 h-6 sm:w-8 sm:h-8';

  return (
    <div
      data-testid="virtual-layout-editor"
      className="fixed inset-0 z-50 flex flex-col justify-between bg-gradient-to-b from-sky-400 via-sky-300/85 to-emerald-500 select-none overflow-hidden"
    >
      {/* Top Horizontal Editor Bar (sisakan ruang kanan untuk preview START di pojok kanan atas) */}
      <div className="px-3 sm:px-5 pr-28 sm:pr-36 py-2.5 bg-gradient-to-r from-blue-800 via-blue-700 to-sky-700 border-b-[3px] border-sky-300 shadow-lg flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Move className="w-4 h-4 text-amber-300" />
          <span className="font-display font-extrabold text-sm sm:text-base text-white tracking-wide">
            CUSTOM VIRTUAL BUTTON LAYOUT
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-blue-950/75 border border-sky-300/45">
            <span className="text-[11px] font-extrabold text-amber-300">
              {SLOT_LABELS[selectedSlot]} Size:
            </span>
            <input
              type="range"
              aria-label="Button Cluster Scale"
              data-testid="vlayout-scale-slider"
              min={0.65}
              max={1.45}
              step={0.05}
              value={cur.scale}
              onChange={(e) => updateSelectedScale(Number(e.target.value))}
              className="w-24 sm:w-28 accent-amber-400 cursor-pointer"
            />
            <span className="font-mono-num text-[11px] font-bold text-white w-9 text-right">
              {Math.round(cur.scale * 100)}%
            </span>
          </div>

          <button
            type="button"
            data-testid="vlayout-reset"
            onClick={() => setDraft(cloneLayout(DEFAULT_VIRTUAL_LAYOUT))}
            className="px-3 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 border border-sky-300/50 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>

          <button
            type="button"
            data-testid="vlayout-cancel"
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-400 border border-rose-200 text-white text-xs font-extrabold flex items-center gap-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
            Cancel
          </button>

          <button
            type="button"
            data-testid="vlayout-save"
            onClick={() => onSave(cloneLayout(draft))}
            className="px-4 py-1.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 border border-emerald-100 text-slate-950 text-xs font-extrabold flex items-center gap-1 cursor-pointer shadow"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            Save Layout
          </button>
        </div>
      </div>

      {/* START preview: pojok kanan atas (sama dengan posisi default di dalam game) */}
      <div
        data-testid="vlayout-drag-system"
        onPointerDown={beginDrag('system')}
        onPointerMove={onDragMove('system')}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        style={{ transform: placement('system'), transformOrigin: 'top right' }}
        className={`absolute top-2.5 right-2.5 sm:top-4 sm:right-4 md:top-5 md:right-5 z-10 touch-none ${slotHighlight('system')}`}
      >
        <div className={`${padButtonClass(buttonSkin, 'start', 'slate')} pointer-events-none`}>
          <StartBarsIcon className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="font-mono-num font-extrabold text-[9px] sm:text-[10px] tracking-wider">START</span>
        </div>
      </div>

      {/* Pitch Preview Hint */}
      <div className="flex-1 relative flex items-center justify-center pointer-events-none px-4">
        <div className="px-4 py-2 rounded-2xl bg-blue-900/75 border-2 border-sky-300 text-white text-xs sm:text-sm font-bold text-center shadow-lg">
          Geser tiap tombol (D-Pad, Start, L, R, ABXY) ke posisi yang kamu mau, atau ketuk lalu atur ukurannya.
        </div>
      </div>

      {/* Bottom Interactive Horizontal Pad Preview */}
      <div className="px-3 sm:px-6 pb-3 flex items-end justify-between gap-2">
        {/* 1. D-Pad */}
        <div
          data-testid="vlayout-drag-dpad"
          onPointerDown={beginDrag('dpad')}
          onPointerMove={onDragMove('dpad')}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          style={{ transform: placement('dpad'), transformOrigin: 'bottom left' }}
          className={`touch-none shrink-0 ${slotHighlight('dpad')}`}
        >
          <div
            className={
              isTransparent
                ? 'relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-slate-950/15 border-[3px] border-white/90 flex items-center justify-center'
                : 'relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-slate-200/90 border-[4px] border-slate-950 flex items-center justify-center'
            }
          >
            <div className="w-10 h-10 rounded-full bg-slate-800 border-2 border-slate-950" />
          </div>
        </div>

        {/* Right Side: L, R & ABXY — masing-masing bisa digeser sendiri */}
        <div className="flex flex-col items-end gap-2 shrink-0">
          <div className="flex items-center gap-3">
            <div
              data-testid="vlayout-drag-shoulderL"
              onPointerDown={beginDrag('shoulderL')}
              onPointerMove={onDragMove('shoulderL')}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
              style={{ transform: placement('shoulderL'), transformOrigin: 'bottom right' }}
              className={`touch-none ${slotHighlight('shoulderL')}`}
            >
              <div className={`${padButtonClass(buttonSkin, 'shoulder', 'violet')} pointer-events-none`}>
                {isIconSkin ? <HeadSpinIcon className="w-6 h-6 sm:w-7 sm:h-7" /> : 'L'}
              </div>
            </div>
            <div
              data-testid="vlayout-drag-shoulderR"
              onPointerDown={beginDrag('shoulderR')}
              onPointerMove={onDragMove('shoulderR')}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
              style={{ transform: placement('shoulderR'), transformOrigin: 'bottom right' }}
              className={`touch-none ${slotHighlight('shoulderR')}`}
            >
              <div className={`${padButtonClass(buttonSkin, 'shoulder', 'violet')} pointer-events-none`}>
                {isIconSkin ? <DashIcon className="w-6 h-6 sm:w-7 sm:h-7" /> : 'R'}
              </div>
            </div>
          </div>

          <div
            data-testid="vlayout-drag-abxy"
            onPointerDown={beginDrag('abxy')}
            onPointerMove={onDragMove('abxy')}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            style={{ transform: placement('abxy'), transformOrigin: 'bottom right' }}
            className={`touch-none ${slotHighlight('abxy')}`}
          >
            <div className="grid grid-cols-3 grid-rows-3 gap-1 place-items-center w-[116px] h-[104px] sm:w-[136px] sm:h-[120px] pointer-events-none">
              <div className={`col-start-2 row-start-1 ${padButtonClass(buttonSkin, 'face', 'blue')}`}>
                {isIconSkin ? <SpinKickIcon className={iconSm} /> : 'X'}
              </div>
              <div className={`col-start-1 row-start-2 ${padButtonClass(buttonSkin, 'face', 'green')}`}>
                {isIconSkin ? <GrabIcon className={iconSm} /> : 'Y'}
              </div>
              <div className={`col-start-3 row-start-2 ${padButtonClass(buttonSkin, 'face', 'red')}`}>
                {isIconSkin ? <KickIcon className={iconSm} /> : 'A'}
              </div>
              <div className={`col-start-2 row-start-3 ${padButtonClass(buttonSkin, 'face', 'amber')}`}>
                {isIconSkin ? <JumpIcon className={iconSm} /> : 'B'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
