import { useRef } from 'react';
import { useDomFocusNav } from '../hooks/useDomFocusNav';
import { GameMode, MatchSubMode, TeamId } from '../game/types';

interface PauseGameOverModalProps {
  mode: 'paused' | 'gameover';
  gameMode: GameMode;
  matchSubMode?: MatchSubMode;
  tournamentRound?: number;
  p1Team: TeamId;
  redScore: number;
  blueScore: number;
  hasNextStoryStage: boolean;
  hasReplay?: boolean;
  onResume: () => void;
  onRestart: () => void;
  onNextStoryStage: () => void;
  onNextTournamentRound?: () => void;
  onOpenStoryMap?: () => void;
  onOpenReplay?: () => void;
  onOpenOptions: () => void;
  onMainMenu: () => void;
}

export function PauseGameOverModal({
  mode,
  gameMode,
  matchSubMode,
  tournamentRound = 1,
  p1Team,
  redScore,
  blueScore,
  hasNextStoryStage,
  hasReplay,
  onResume,
  onRestart,
  onNextStoryStage,
  onNextTournamentRound,
  onOpenStoryMap,
  onOpenReplay,
  onOpenOptions,
  onMainMenu,
}: PauseGameOverModalProps) {
  const navRootRef = useRef<HTMLDivElement | null>(null);
  useDomFocusNav({ rootRef: navRootRef });
  const playerScore = p1Team === 'red' ? redScore : blueScore;
  const oppScore = p1Team === 'red' ? blueScore : redScore;
  const isWin = playerScore > oppScore;
  const isDraw = playerScore === oppScore;
  const isTournament = matchSubMode === 'tournament' && gameMode === 'quick';
  const isTournamentChamp = isTournament && isWin && tournamentRound >= 3;

  return (
    <div ref={navRootRef} className="fixed inset-0 z-30 flex items-center justify-center p-3 bg-gradient-to-b from-sky-500/75 via-sky-300/45 to-emerald-500/45 backdrop-blur-sm pointer-events-auto">
      <div className="w-full max-w-md max-h-[94vh] overflow-y-auto custom-scroll rounded-2xl p-4 sm:p-6 border-[3px] border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-[0_16px_42px_rgba(2,132,199,0.5)] text-center">
        <div className="text-[11px] font-extrabold uppercase tracking-widest text-amber-300 mb-0.5">
          {mode === 'paused'
            ? 'Match Paused'
            : isTournament
              ? `Tournament · Round ${tournamentRound} of 3`
              : gameMode === 'story'
                ? 'World Tour Match Result'
                : gameMode === 'training'
                  ? 'Training Session'
                  : 'Full Time'}
        </div>

        <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white mb-3.5">
          {mode === 'paused'
            ? 'Take a Breather'
            : isTournamentChamp
              ? 'TOURNAMENT CHAMPION!'
              : isDraw
                ? 'Draw Match!'
                : isWin
                  ? 'Victory!'
                  : 'Match Complete'}
        </h2>

        {/* Score Summary Tiles */}
        <div className="grid grid-cols-2 gap-2.5 mb-4">
          <div className="p-2.5 rounded-xl bg-gradient-to-b from-red-600/80 to-red-900/90 border-2 border-red-300/70">
            <div className="text-[11px] font-extrabold text-white">RED TEAM</div>
            <div className="font-display font-extrabold text-2xl sm:text-3xl text-white font-mono-num">{redScore}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-gradient-to-b from-sky-500/80 to-blue-900/90 border-2 border-sky-200/70">
            <div className="text-[11px] font-extrabold text-white">BLUE TEAM</div>
            <div className="font-display font-extrabold text-2xl sm:text-3xl text-white font-mono-num">{blueScore}</div>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          {mode === 'paused' ? (
            <button
              type="button"
              onClick={onResume}
              className="w-full py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 border-2 border-emerald-100 text-slate-950 font-display font-extrabold text-sm sm:text-base cursor-pointer shadow"
            >
              Resume Match
            </button>
          ) : (
            <>
              {hasReplay && onOpenReplay && (
                <button
                  type="button"
                  data-testid="watch-replay-btn"
                  onClick={onOpenReplay}
                  className="w-full py-2.5 rounded-xl bg-sky-300 hover:bg-sky-200 border-2 border-white text-slate-950 font-display font-extrabold text-sm sm:text-base cursor-pointer shadow"
                >
                  Watch Game Replay (15s)
                </button>
              )}
              {isTournament && isWin && tournamentRound < 3 && onNextTournamentRound && (
                <button
                  type="button"
                  data-start="true"
                  onClick={onNextTournamentRound}
                  className="w-full py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 border-2 border-emerald-100 text-slate-950 font-display font-extrabold text-sm sm:text-base cursor-pointer shadow"
                >
                  {tournamentRound === 1 ? 'Advance to Semifinal' : 'Advance to Grand Final'}
                </button>
              )}
              {gameMode === 'story' && isWin && hasNextStoryStage && (
                <button
                  type="button"
                  data-start="true"
                  onClick={onNextStoryStage}
                  className="w-full py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 border-2 border-emerald-100 text-slate-950 font-display font-extrabold text-sm sm:text-base cursor-pointer shadow"
                >
                  Continue World Tour
                </button>
              )}
              <button
                type="button"
                data-start="true"
                onClick={onRestart}
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 border-2 border-amber-100 text-slate-950 font-display font-extrabold text-sm sm:text-base cursor-pointer shadow"
              >
                {gameMode === 'story' ? 'Rematch Stage' : 'Play Again'}
              </button>
            </>
          )}

          {mode === 'paused' && (
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={onRestart}
                className="w-full py-2 rounded-xl bg-blue-900/80 hover:bg-blue-800 border border-sky-300/45 text-white text-xs sm:text-sm font-bold cursor-pointer"
              >
                Restart Match
              </button>
              <button
                type="button"
                onClick={onOpenOptions}
                className="w-full py-2 rounded-xl bg-amber-400 hover:bg-amber-300 border border-amber-200 text-slate-950 text-xs sm:text-sm font-extrabold cursor-pointer"
              >
                Options
              </button>
            </div>
          )}

          {gameMode === 'story' && onOpenStoryMap && (
            <button
              type="button"
              data-testid="return-story-map-btn"
              onClick={onOpenStoryMap}
              className="w-full py-2 rounded-xl bg-sky-500 hover:bg-sky-400 border border-sky-200 text-white text-xs sm:text-sm font-extrabold cursor-pointer"
            >
              Back to Adventure Map
            </button>
          )}

          <button
            type="button"
            onClick={onMainMenu}
            className="w-full py-2 rounded-xl bg-blue-950/75 hover:bg-blue-900 text-sky-100 text-xs sm:text-sm font-bold border border-sky-300/40 cursor-pointer"
          >
            Main Menu
          </button>
        </div>
      </div>
    </div>
  );
}
