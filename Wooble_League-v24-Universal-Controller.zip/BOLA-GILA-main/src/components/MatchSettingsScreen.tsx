import { useEffect, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  CloudRain,
  Dices,
  Dumbbell,
  Gamepad2,
  Play,
  Settings,
  Shuffle,
  Snowflake,
  Sun,
  Timer,
  Trophy,
  User,
  Users,
  Wifi,
  Zap,
  CloudSun,
  Landmark,
} from 'lucide-react';
import type { ReactNode } from 'react';
import { useT } from '../game/i18n';
import { ALL_ITEM_IDS, ARENAS, BALLS, createTrainingConfig } from '../game/catalog';
import { AiDifficulty, GrassPatternId, MatchConfig, NetStyleId, MatchSubMode, WeatherMode } from '../game/types';
import { useMenuController } from '../hooks/useMenuController';
import { ArenaPreviewIcon, BallPreviewIcon } from './MenuIcons';

interface MatchSettingsScreenProps {
  active: boolean;
  config: MatchConfig;
  lanRoomCode: string | null;
  lanRole: 'host' | 'guest' | null;
  onChangeConfig: (next: MatchConfig) => void;
  onSetLan: (roomCode: string | null, role: 'host' | 'guest' | null) => void;
  onBack: () => void;
  onContinue: () => void;
}

const SUB_MODES: Array<{ id: MatchSubMode; label: string }> = [
  { id: 'quick', label: 'Quick Match' },
  { id: 'local_multiplayer', label: 'Local Multiplayer' },
  { id: 'tournament', label: 'Tournament' },
  { id: 'training', label: 'Training 1v1' },
  { id: 'lan', label: 'WiFi LAN' },
];

const DURATIONS: Array<2 | 3 | 5 | 10> = [2, 3, 5, 10];
const SCORE_LIMITS: Array<number | null> = [null, 3, 5, 7, 10];
const PLAYER_COUNTS: Array<1 | 2 | 3 | 4> = [1, 2, 3, 4];
const DIFFICULTIES: Array<{ id: AiDifficulty; label: string }> = [
  { id: 'easy', label: 'Easy' },
  { id: 'normal', label: 'Normal' },
  { id: 'hard', label: 'Hard' },
];
const WEATHERS: Array<{ id: WeatherMode; label: string }> = [
  { id: 'auto', label: 'Auto' },
  { id: 'sunny', label: 'Sunny' },
  { id: 'rain', label: 'Rain' },
  { id: 'snow', label: 'Snow' },
];
const ROW_COUNT = 12;

// Default semuanya 'random'; label diterjemahkan lewat kamus bahasa (ms.net.* / ms.grass.*)
const NET_STYLES: Array<{ id: NetStyleId | 'random' }> = [
  { id: 'random' },
  { id: 'white' },
  { id: 'checker' },
  { id: 'striped' },
];

const GRASS_PATTERNS: Array<{ id: GrassPatternId | 'random' }> = [
  { id: 'random' },
  { id: 'stripes' },
  { id: 'checker' },
  { id: 'diamond' },
  { id: 'rings' },
];

const MODE_ICONS: Record<MatchSubMode, ReactNode> = {
  quick: <Zap className="w-3.5 h-3.5" />,
  local_multiplayer: <Users className="w-3.5 h-3.5" />,
  tournament: <Trophy className="w-3.5 h-3.5" />,
  training: <Dumbbell className="w-3.5 h-3.5" />,
  lan: <Wifi className="w-3.5 h-3.5" />,
};

const WEATHER_ICONS: Record<WeatherMode, ReactNode> = {
  auto: <Settings className="w-3.5 h-3.5" />,
  sunny: <Sun className="w-3.5 h-3.5" />,
  rain: <CloudRain className="w-3.5 h-3.5" />,
  snow: <Snowflake className="w-3.5 h-3.5" />,
};

/** Panel bergaya neon seperti desain referensi: tab judul kuning + badge nilai di kanan atas */
function NeonPanel({
  title,
  icon,
  badge,
  focused,
  row,
  onHover,
  children,
}: {
  title: string;
  icon: ReactNode;
  badge?: string;
  focused: boolean;
  row: number;
  onHover: () => void;
  children: ReactNode;
}) {
  return (
    <section
      data-row={row}
      onMouseEnter={onHover}
      className={`relative rounded-lg border-2 p-1 bg-gradient-to-b from-[#0b2a6b]/95 to-[#071b4a]/95 transition-shadow ${
        focused
          ? 'border-amber-300 shadow-[0_0_18px_rgba(252,211,77,0.55)]'
          : 'border-sky-400/80 shadow-[0_0_14px_rgba(56,189,248,0.35)]'
      }`}
    >
      <div className="flex items-center justify-between gap-2 mb-1">
        <div className="flex items-center gap-1.5 pl-1 pr-3 py-0 rounded-lg bg-gradient-to-r from-[#0a1f55] to-transparent">
          <span className="text-sky-100">{icon}</span>
          <h3 className="font-display font-extrabold italic text-[11px] sm:text-xs tracking-wide text-white uppercase">
            {title}
          </h3>
        </div>
        {badge && (
          <span className="px-2 py-0 rounded-md border border-amber-300/90 bg-[#0a1f55] text-amber-300 font-display font-extrabold italic text-[9px] sm:text-[10px] uppercase truncate max-w-[55%]">
            {badge}
          </span>
        )}
      </div>
      {children}
    </section>
  );
}

const optBtn = (active: boolean) =>
  `flex flex-col sm:flex-row items-center justify-center gap-1 px-1 py-1 rounded-md border-2 text-[10px] sm:text-[11px] font-display font-extrabold cursor-pointer transition-all ${
    active
      ? 'bg-gradient-to-b from-amber-300 to-amber-400 text-slate-950 border-amber-100 shadow-[0_0_12px_rgba(252,211,77,0.7)]'
      : 'bg-gradient-to-b from-[#1d56b8] to-[#123b8a] text-white border-sky-400/70 hover:brightness-125'
  }`;

const GAME_SPEEDS: Array<{ val: 0.85 | 1.0 | 1.25; label: string }> = [
  { val: 0.85, label: '0.85x' },
  { val: 1.0, label: '1.0x' },
  { val: 1.25, label: '1.25x' },
];

export function MatchSettingsScreen({
  active,
  config,
  lanRoomCode,
  lanRole,
  onChangeConfig,
  onSetLan,
  onBack,
  onContinue,
}: MatchSettingsScreenProps) {
  const [focusedRow, setFocusedRow] = useState(0);
  const [lanInput, setLanInput] = useState(lanRoomCode ?? 'PITCH-101');

  const subMode: MatchSubMode =
    config.matchSubMode ??
    (config.mode === 'training'
      ? 'training'
      : config.mode === 'coop' || (config.localPlayerCount ?? 1) >= 2
        ? 'local_multiplayer'
        : config.mode === 'lan'
          ? 'lan'
          : 'quick');

  const localPlayers = config.localPlayerCount ?? (config.mode === 'coop' ? 2 : 1);
  const weatherMode: WeatherMode = config.weatherMode ?? 'auto';
  const aiDiff: AiDifficulty = config.aiDifficulty ?? 'normal';
  const gameSpeed: 0.85 | 1.0 | 1.25 = config.gameSpeed ?? 1.0;
  const propsEnabled = config.propsEnabled ?? true;

  const t = useT();
  const arenaRandom = config.arenaRandom !== false;
  const currentArena = ARENAS.find((a) => a.id === config.arena) ?? ARENAS[0];
  const currentBall = BALLS.find((b) => b.id === config.ballType) ?? BALLS[0];

  const applySubMode = (m: MatchSubMode) => {
    if (m === 'training') {
      onChangeConfig(createTrainingConfig(config));
    } else if (m === 'local_multiplayer') {
      const count = Math.max(2, localPlayers) as 2 | 3 | 4;
      onChangeConfig({
        ...config,
        mode: 'coop',
        matchSubMode: 'local_multiplayer',
        localPlayerCount: count,
        redCount: Math.max(config.redCount, count >= 3 ? 2 : 1),
        blueCount: Math.max(config.blueCount, count >= 3 ? 2 : 1),
      });
    } else if (m === 'tournament') {
      onChangeConfig({
        ...config,
        mode: 'quick',
        matchSubMode: 'tournament',
        localPlayerCount: 1,
        redCount: 2,
        blueCount: 2,
        tournamentRound: 1,
        tournamentWins: 0,
      });
    } else if (m === 'lan') {
      onChangeConfig({
        ...config,
        mode: 'lan',
        matchSubMode: 'lan',
        localPlayerCount: 1,
      });
    } else {
      onChangeConfig({
        ...config,
        mode: 'quick',
        matchSubMode: 'quick',
        localPlayerCount: 1,
      });
    }
  };

  const applyPlayerCount = (cnt: 1 | 2 | 3 | 4) => {
    const minPerTeam = cnt >= 3 ? 2 : 1;
    onChangeConfig({
      ...config,
      mode: cnt >= 2 ? 'coop' : subMode === 'lan' ? 'lan' : subMode === 'training' ? 'training' : 'quick',
      matchSubMode: cnt >= 2 && subMode === 'quick' ? 'local_multiplayer' : subMode,
      localPlayerCount: cnt,
      redCount: Math.max(config.redCount, minPerTeam),
      blueCount: Math.max(config.blueCount, minPerTeam),
    });
  };

  const stepRow = (rowIdx: number, dir: -1 | 1) => {
    if (rowIdx === 0) {
      const idx = SUB_MODES.findIndex((s) => s.id === subMode);
      const next = SUB_MODES[(idx + dir + SUB_MODES.length) % SUB_MODES.length];
      applySubMode(next.id);
    } else if (rowIdx === 1) {
      const idx = Math.max(0, DURATIONS.indexOf(config.durationMinutes as 2 | 3 | 5 | 10));
      onChangeConfig({ ...config, durationMinutes: DURATIONS[(idx + dir + DURATIONS.length) % DURATIONS.length] });
    } else if (rowIdx === 2) {
      const idx = Math.max(0, SCORE_LIMITS.indexOf(config.scoreLimit ?? null));
      onChangeConfig({ ...config, scoreLimit: SCORE_LIMITS[(idx + dir + SCORE_LIMITS.length) % SCORE_LIMITS.length] });
    } else if (rowIdx === 3) {
      const idx = Math.max(0, PLAYER_COUNTS.indexOf(localPlayers));
      applyPlayerCount(PLAYER_COUNTS[(idx + dir + PLAYER_COUNTS.length) % PLAYER_COUNTS.length]);
    } else if (rowIdx === 4) {
      const idx = DIFFICULTIES.findIndex((d) => d.id === aiDiff);
      onChangeConfig({ ...config, aiDifficulty: DIFFICULTIES[(idx + dir + DIFFICULTIES.length) % DIFFICULTIES.length].id });
    } else if (rowIdx === 5) {
      // Urutan: Random, lalu semua stadion
      const total = ARENAS.length + 1;
      const cur = arenaRandom ? 0 : ARENAS.findIndex((a) => a.id === config.arena) + 1;
      const nextIdx = (cur + dir + total) % total;
      if (nextIdx === 0) onChangeConfig({ ...config, arenaRandom: true });
      else onChangeConfig({ ...config, arenaRandom: false, arena: ARENAS[nextIdx - 1].id });
    } else if (rowIdx === 6) {
      const idx = WEATHERS.findIndex((w) => w.id === weatherMode);
      onChangeConfig({ ...config, weatherMode: WEATHERS[(idx + dir + WEATHERS.length) % WEATHERS.length].id });
    } else if (rowIdx === 7) {
      const idx = BALLS.findIndex((b) => b.id === config.ballType);
      onChangeConfig({ ...config, ballType: BALLS[(idx + dir + BALLS.length) % BALLS.length].id });
    } else if (rowIdx === 8) {
      const nextItems = config.itemSpawnMode === 'off' ? 'on' : 'off';
      onChangeConfig({
        ...config,
        itemSpawnMode: nextItems,
        enabledItems: nextItems === 'on' ? ALL_ITEM_IDS : config.enabledItems,
      });
    } else if (rowIdx === 9) {
      const idx = Math.max(0, GAME_SPEEDS.findIndex((g) => g.val === gameSpeed));
      onChangeConfig({ ...config, gameSpeed: GAME_SPEEDS[(idx + dir + GAME_SPEEDS.length) % GAME_SPEEDS.length].val });
    } else if (rowIdx === 11) {
      const cur = config.netStyle ?? 'random';
      const idx = Math.max(0, NET_STYLES.findIndex((n) => n.id === cur));
      onChangeConfig({ ...config, netStyle: NET_STYLES[(idx + dir + NET_STYLES.length) % NET_STYLES.length].id });
    } else if (rowIdx === 10) {
      const cur = config.grassPattern ?? 'random';
      const idx = Math.max(0, GRASS_PATTERNS.findIndex((g) => g.id === cur));
      onChangeConfig({ ...config, grassPattern: GRASS_PATTERNS[(idx + dir + GRASS_PATTERNS.length) % GRASS_PATTERNS.length].id });
    }
  };

  // Stadion acak diputuskan saat lanjut, supaya layar preview menampilkan stadion yang sama dengan match
  const handleContinue = () => {
    if (arenaRandom) {
      const pick = ARENAS[Math.floor(Math.random() * ARENAS.length)].id;
      onChangeConfig({ ...config, arena: pick });
    }
    onContinue();
  };

  useMenuController({
    active,
    onAction: (action) => {
      if (action === 'up') setFocusedRow((r) => (r + ROW_COUNT - 1) % ROW_COUNT);
      else if (action === 'down') setFocusedRow((r) => (r + 1) % ROW_COUNT);
      else if (action === 'left') stepRow(focusedRow, -1);
      else if (action === 'right') stepRow(focusedRow, 1);
      else if (action === 'confirm') stepRow(focusedRow, 1);
      else if (action === 'back') onBack();
      else if (action === 'start') handleContinue();
    },
  });

  useEffect(() => {
    document
      .querySelector(`[data-testid="match-settings-screen"] [data-row="${focusedRow}"]`)
      ?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [focusedRow]);

  const hover = (idx: number) => () => setFocusedRow(idx);
  const smallBtn = (active: boolean) =>
    `py-0.5 rounded-md border-2 text-[9px] font-display font-extrabold cursor-pointer transition-all ${
      active
        ? 'bg-gradient-to-b from-amber-300 to-amber-400 text-slate-950 border-amber-100 shadow-[0_0_10px_rgba(252,211,77,0.6)]'
        : 'bg-gradient-to-b from-[#1d56b8] to-[#123b8a] text-white border-sky-400/70 hover:brightness-125'
    }`;
  const arrowBtn =
    'shrink-0 w-7 h-7 rounded-lg bg-gradient-to-b from-[#2f7bff] to-[#1546b8] border-2 border-sky-200 text-white flex items-center justify-center cursor-pointer hover:brightness-125 shadow-[0_0_10px_rgba(56,189,248,0.6)]';

  const stadiumName = arenaRandom ? t('ms.randomStadium') : currentArena.name;
  const gameModeBadge = t(`ms.mode.${subMode}`);
  const durationBadge =
    subMode === 'training'
      ? t('ms.unlimited')
      : `${config.durationMinutes} ${(config.halves ?? 2) === 2 ? t('ms.perHalf') : t('ms.min')}`;
  const grassCur = config.grassPattern ?? 'random';
  const netCur = config.netStyle ?? 'random';

  return (
    <div
      data-testid="match-settings-screen"
      className="fixed inset-0 z-30 flex flex-col p-1.5 sm:p-2 bg-gradient-to-b from-sky-500/80 via-sky-400/55 to-emerald-500/60 backdrop-blur-sm pointer-events-auto"
    >
      <div className="w-full max-w-5xl mx-auto flex-1 min-h-0 flex flex-col gap-1.5">
        {/* Header */}
        <div className="flex items-start justify-between gap-2">
          <div className="relative pl-9 pr-5 py-0.5 -skew-x-6 rounded-lg border-2 border-amber-300 bg-gradient-to-r from-[#0a1f55] to-[#123b8a] shadow-[0_0_16px_rgba(56,189,248,0.5)]">
            <div className="skew-x-6">
              <div className="text-[8px] font-extrabold italic uppercase tracking-[0.18em] text-amber-300">
                {t('ms.step')}
              </div>
              <h2 className="font-display font-extrabold italic text-sm sm:text-lg text-white leading-tight drop-shadow">
                {t('ms.title')}
              </h2>
            </div>
            <span className="absolute left-2 top-1/2 -translate-y-1/2 skew-x-6 w-6 h-6 rounded-full bg-white border-2 border-slate-900 flex items-center justify-center text-xs">
              ⚽
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              data-testid="settings-random-btn"
              onClick={() => {
                const randA = ARENAS[Math.floor(Math.random() * ARENAS.length)].id;
                const randB = BALLS[Math.floor(Math.random() * BALLS.length)].id;
                onChangeConfig({ ...config, arena: randA, arenaRandom: false, ballType: randB });
              }}
              className="px-2.5 py-1 rounded-xl bg-gradient-to-b from-[#2f7bff] to-[#1546b8] border-2 border-sky-200 text-white text-[11px] font-display font-extrabold flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(56,189,248,0.6)] hover:brightness-110"
            >
              <Shuffle className="w-3 h-3 text-amber-300" /> {t('ms.random')}
            </button>
            <button
              type="button"
              data-testid="settings-back-btn"
              onClick={onBack}
              className="px-2.5 py-1 rounded-xl bg-gradient-to-b from-rose-500 to-rose-700 border-2 border-rose-200 text-white text-[11px] font-display font-extrabold flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(244,63,94,0.55)] hover:brightness-110"
            >
              <span className="w-4 h-4 rounded-full bg-white text-rose-600 text-[9px] flex items-center justify-center">B</span>
              {t('ms.back')}
            </button>
          </div>
        </div>

        {/* Isi: 4 panel utama (2x2) + opsi lainnya, dapat di-scroll */}
        <div className="flex-1 min-h-0 overflow-y-auto custom-scroll pr-11 pb-14 flex flex-col gap-1.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 items-start">
            {/* GAME MODE */}
            <NeonPanel
              title={t('ms.gameMode')}
              icon={<Gamepad2 className="w-3.5 h-3.5" />}
              badge={gameModeBadge}
              focused={focusedRow === 0}
              row={0}
              onHover={hover(0)}
            >
              <div className="grid grid-cols-2 gap-2">
                {SUB_MODES.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    data-testid={`mode-opt-${m.id}`}
                    onClick={() => {
                      setFocusedRow(0);
                      applySubMode(m.id);
                    }}
                    className={`${optBtn(subMode === m.id)} !px-1.5 min-h-[26px] leading-tight`}
                  >
                    {MODE_ICONS[m.id]}
                    <span className="text-left">{t(`ms.mode.${m.id}`)}</span>
                  </button>
                ))}
              </div>

              {subMode === 'lan' && (
                <div className="mt-1.5 pt-1.5 border-t border-sky-300/30 flex flex-wrap items-center gap-2">
                  <Wifi className="w-4 h-4 text-sky-200" />
                  <input
                    type="text"
                    aria-label="LAN Room Code"
                    value={lanInput}
                    onChange={(e) => setLanInput(e.target.value.toUpperCase())}
                    className="px-2.5 py-1 rounded-md bg-blue-950/75 border border-sky-300/45 text-xs text-white font-mono-num w-28"
                  />
                  <button
                    type="button"
                    onClick={() => onSetLan(lanInput || 'PITCH-101', 'host')}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold cursor-pointer border ${
                      lanRole === 'host'
                        ? 'bg-emerald-400 text-slate-950 border-emerald-100'
                        : 'bg-sky-500/30 text-white border-sky-300/40'
                    }`}
                  >
                    Host
                  </button>
                  <button
                    type="button"
                    onClick={() => onSetLan(lanInput || 'PITCH-101', 'guest')}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold cursor-pointer border ${
                      lanRole === 'guest'
                        ? 'bg-sky-300 text-slate-950 border-white'
                        : 'bg-sky-500/30 text-white border-sky-300/40'
                    }`}
                  >
                    Join
                  </button>
                </div>
              )}
            </NeonPanel>

            {/* STADIUM */}
            <NeonPanel
              title={`${t('ms.stadium')} (${ARENAS.length})`}
              icon={<Landmark className="w-3.5 h-3.5" />}
              badge={stadiumName}
              focused={focusedRow === 5}
              row={5}
              onHover={hover(5)}
            >
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  aria-label="Previous Stadium"
                  onClick={() => {
                    setFocusedRow(5);
                    stepRow(5, -1);
                  }}
                  className={arrowBtn}
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="flex-1 flex items-center gap-2 p-1 rounded-lg bg-[#071b4a] border-2 border-cyan-300/80 shadow-[0_0_12px_rgba(103,232,249,0.45)]">
                  {arenaRandom ? (
                    <div className="w-16 h-10 rounded-md shrink-0 bg-gradient-to-br from-violet-500 via-sky-400 to-emerald-400 flex items-center justify-center">
                      <Dices className="w-8 h-8 text-white drop-shadow" />
                    </div>
                  ) : (
                    <ArenaPreviewIcon arena={currentArena} className="w-16 h-10 rounded-md shrink-0" />
                  )}
                  <div className="min-w-0">
                    <div className="text-xs sm:text-sm font-display font-extrabold text-white truncate">
                      {stadiumName}
                    </div>
                    <div className="text-[9px] text-sky-200 capitalize truncate">
                      {arenaRandom
                        ? t('ms.randomStadiumHint')
                        : `${t('ms.barrier')}: ${currentArena.barrierStyle.replace(/_/g, ' ')}`}
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  aria-label="Next Stadium"
                  onClick={() => {
                    setFocusedRow(5);
                    stepRow(5, 1);
                  }}
                  className={arrowBtn}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </NeonPanel>

            {/* MATCH DURATION */}
            <NeonPanel
              title={t('ms.duration')}
              icon={<Timer className="w-3.5 h-3.5" />}
              badge={durationBadge}
              focused={focusedRow === 1}
              row={1}
              onHover={hover(1)}
            >
              <div className="grid grid-cols-4 gap-2">
                {DURATIONS.map((min) => (
                  <button
                    key={min}
                    type="button"
                    data-testid={`duration-${min}m`}
                    onClick={() => {
                      setFocusedRow(1);
                      onChangeConfig({ ...config, durationMinutes: min });
                    }}
                    className={`${optBtn(config.durationMinutes === min)} font-mono-num`}
                  >
                    {min} {t('ms.min')}
                  </button>
                ))}
              </div>
            </NeonPanel>

            {/* WEATHER */}
            <NeonPanel
              title={t('ms.weather')}
              icon={<CloudSun className="w-3.5 h-3.5" />}
              badge={t(`ms.weather.${weatherMode}`)}
              focused={focusedRow === 6}
              row={6}
              onHover={hover(6)}
            >
              <div className="grid grid-cols-4 gap-2">
                {WEATHERS.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    data-testid={`weather-opt-${w.id}`}
                    onClick={() => {
                      setFocusedRow(6);
                      onChangeConfig({ ...config, weatherMode: w.id });
                    }}
                    className={optBtn(weatherMode === w.id)}
                  >
                    {WEATHER_ICONS[w.id]}
                    <span>{t(`ms.weather.${w.id}`)}</span>
                  </button>
                ))}
              </div>
            </NeonPanel>
          </div>

          {/* Opsi lainnya (gaya panel sama) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 items-start">
            <NeonPanel
              title={t('ms.scoreLimit')}
              icon={<Trophy className="w-3.5 h-3.5" />}
              badge={config.scoreLimit ? `${t('ms.firstTo')} ${config.scoreLimit}` : t('ms.offClock')}
              focused={focusedRow === 2}
              row={2}
              onHover={hover(2)}
            >
              <div className="grid grid-cols-5 gap-1.5">
                {SCORE_LIMITS.map((lim) => (
                  <button
                    key={String(lim)}
                    type="button"
                    data-testid={`score-limit-${lim ?? 'off'}`}
                    onClick={() => {
                      setFocusedRow(2);
                      onChangeConfig({ ...config, scoreLimit: lim });
                    }}
                    className={`${smallBtn((config.scoreLimit ?? null) === lim)} font-mono-num`}
                  >
                    {lim === null ? t('op.off') : `${lim}`}
                  </button>
                ))}
              </div>
            </NeonPanel>

            <NeonPanel
              title={t('ms.players')}
              icon={<Users className="w-3.5 h-3.5" />}
              badge={`${localPlayers} ${t('ms.human')} · ${config.redCount}v${config.blueCount}`}
              focused={focusedRow === 3}
              row={3}
              onHover={hover(3)}
            >
              <div className="grid grid-cols-4 gap-1.5">
                {PLAYER_COUNTS.map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    data-testid={`player-count-${cnt}`}
                    onClick={() => {
                      setFocusedRow(3);
                      applyPlayerCount(cnt);
                    }}
                    className={smallBtn(localPlayers === cnt)}
                  >
                    {cnt}P
                  </button>
                ))}
              </div>
              <div className="mt-1.5 grid grid-cols-4 gap-1.5">
                {([1, 2, 3, 4] as const).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => onChangeConfig({ ...config, redCount: sz, blueCount: sz })}
                    className={smallBtn(config.redCount === sz && config.blueCount === sz)}
                  >
                    {sz}v{sz}
                  </button>
                ))}
              </div>
            </NeonPanel>

            <NeonPanel
              title={t('ms.ai')}
              icon={<User className="w-3.5 h-3.5" />}
              badge={t(`ms.${aiDiff}`)}
              focused={focusedRow === 4}
              row={4}
              onHover={hover(4)}
            >
              <div className="grid grid-cols-3 gap-2">
                {DIFFICULTIES.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    data-testid={`ai-diff-${d.id}`}
                    onClick={() => {
                      setFocusedRow(4);
                      onChangeConfig({ ...config, aiDifficulty: d.id });
                    }}
                    className={smallBtn(aiDiff === d.id)}
                  >
                    {t(`ms.${d.id}`)}
                  </button>
                ))}
              </div>
            </NeonPanel>

            <NeonPanel
              title={`${t('ms.ball')} (${BALLS.length})`}
              icon={<Gamepad2 className="w-3.5 h-3.5" />}
              badge={currentBall.name}
              focused={focusedRow === 7}
              row={7}
              onHover={hover(7)}
            >
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  aria-label="Previous Ball"
                  onClick={() => {
                    setFocusedRow(7);
                    stepRow(7, -1);
                  }}
                  className={arrowBtn}
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="flex-1 flex items-center gap-2 p-1 rounded-lg bg-[#071b4a] border-2 border-cyan-300/60">
                  <BallPreviewIcon ball={currentBall} className="w-8 h-8 shrink-0" />
                  <div className="min-w-0">
                    <div className="text-sm font-display font-bold text-white truncate">{currentBall.name}</div>
                    <div className="text-[9px] text-sky-200 capitalize">
                      {t('ms.shape')}: {currentBall.shape} · {t('ms.bounce')}: {Math.round(currentBall.restitution * 100)}%
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  aria-label="Next Ball"
                  onClick={() => {
                    setFocusedRow(7);
                    stepRow(7, 1);
                  }}
                  className={arrowBtn}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </NeonPanel>

            <NeonPanel
              title={t('ms.rules')}
              icon={<Settings className="w-3.5 h-3.5" />}
              focused={focusedRow === 8}
              row={8}
              onHover={hover(8)}
            >
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const nextItems = config.itemSpawnMode === 'off' ? 'on' : 'off';
                    onChangeConfig({
                      ...config,
                      itemSpawnMode: nextItems,
                      enabledItems: nextItems === 'on' ? ALL_ITEM_IDS : config.enabledItems,
                    });
                  }}
                  className={smallBtn(config.itemSpawnMode !== 'off')}
                >
                  {t('ms.items')}: {config.itemSpawnMode === 'off' ? t('op.off') : t('op.on')}
                </button>
                <button
                  type="button"
                  onClick={() => onChangeConfig({ ...config, propsEnabled: !propsEnabled })}
                  className={smallBtn(propsEnabled)}
                >
                  {t('ms.props')}: {propsEnabled ? t('op.on') : t('op.off')}
                </button>
                <button
                  type="button"
                  onClick={() => onChangeConfig({ ...config, halves: (config.halves ?? 2) === 2 ? 1 : 2 })}
                  className={smallBtn(false)}
                >
                  {(config.halves ?? 2) === 2 ? t('ms.halves2') : t('ms.halves1')}
                </button>
              </div>
            </NeonPanel>

            <NeonPanel
              title={t('ms.speed')}
              icon={<Zap className="w-3.5 h-3.5" />}
              badge={`${gameSpeed}x`}
              focused={focusedRow === 9}
              row={9}
              onHover={hover(9)}
            >
              <div className="grid grid-cols-3 gap-2">
                {GAME_SPEEDS.map((gs) => (
                  <button
                    key={gs.val}
                    type="button"
                    data-testid={`speed-opt-${gs.val}`}
                    onClick={() => {
                      setFocusedRow(9);
                      onChangeConfig({ ...config, gameSpeed: gs.val });
                    }}
                    className={`${smallBtn(gameSpeed === gs.val)} font-mono-num`}
                  >
                    {gs.label}
                  </button>
                ))}
              </div>
            </NeonPanel>

            <NeonPanel
              title={t('ms.grass')}
              icon={<Sun className="w-3.5 h-3.5" />}
              badge={t(`ms.grass.${grassCur}`)}
              focused={focusedRow === 10}
              row={10}
              onHover={hover(10)}
            >
              <div className="grid grid-cols-5 gap-1.5">
                {GRASS_PATTERNS.map((gp) => (
                  <button
                    key={gp.id}
                    type="button"
                    data-testid={`grass-opt-${gp.id}`}
                    onClick={() => {
                      setFocusedRow(10);
                      onChangeConfig({ ...config, grassPattern: gp.id });
                    }}
                    className={`${smallBtn(grassCur === gp.id)} !text-[11px]`}
                  >
                    {t(`ms.grass.${gp.id}`)}
                  </button>
                ))}
              </div>
            </NeonPanel>

            <NeonPanel
              title={t('ms.net')}
              icon={<Trophy className="w-3.5 h-3.5" />}
              badge={t(`ms.net.${netCur}`)}
              focused={focusedRow === 11}
              row={11}
              onHover={hover(11)}
            >
              <div className="grid grid-cols-4 gap-1.5">
                {NET_STYLES.map((ns) => (
                  <button
                    key={ns.id}
                    type="button"
                    data-testid={`net-opt-${ns.id}`}
                    onClick={() => {
                      setFocusedRow(11);
                      onChangeConfig({ ...config, netStyle: ns.id });
                    }}
                    className={`${smallBtn(netCur === ns.id)} !text-[11px]`}
                  >
                    {t(`ms.net.${ns.id}`)}
                  </button>
                ))}
              </div>
              <p className="mt-1.5 text-[10px] text-sky-200/80">{t('ms.netNote')}</p>
            </NeonPanel>
          </div>
        </div>

      </div>
    </div>
  );
}
