import { useEffect, useRef, useState } from 'react';
import { ChevronsUpDown } from 'lucide-react';

/** Cari elemen yang bisa di-scroll vertikal dan sedang tampil (yang paling akhir di DOM = paling atas) */
function findScrollable(): HTMLElement | null {
  const els = Array.from(
    document.querySelectorAll<HTMLElement>('.overflow-y-auto, .overflow-auto, .custom-scroll')
  );
  for (let i = els.length - 1; i >= 0; i--) {
    const el = els[i];
    if (el.offsetParent !== null && el.scrollHeight > el.clientHeight + 6) return el;
  }
  return null;
}

const THUMB = 44; // tinggi pegangan (px)

/**
 * Satu pegangan scroll di sisi kanan layar untuk SEMUA menu
 * (layar sentuh game menonaktifkan geser jari, jadi scroll dilakukan dengan menarik pegangan ini ke atas/bawah).
 */
export function ScrollButtons({ hidden = false }: { hidden?: boolean }) {
  const [available, setAvailable] = useState(false);
  const [ratio, setRatio] = useState(0);
  const [dragging, setDragging] = useState(false);
  const trackRef = useRef<HTMLDivElement | null>(null);
  const targetRef = useRef<HTMLElement | null>(null);

  // Pantau elemen scroll yang aktif + posisinya
  useEffect(() => {
    const tick = () => {
      const el = findScrollable();
      targetRef.current = el;
      setAvailable(el !== null);
      if (el) {
        const max = el.scrollHeight - el.clientHeight;
        setRatio(max > 0 ? Math.min(1, Math.max(0, el.scrollTop / max)) : 0);
      }
    };
    tick();
    const id = window.setInterval(tick, 120);
    return () => window.clearInterval(id);
  }, []);

  const scrollToPointer = (clientY: number) => {
    const track = trackRef.current;
    const el = targetRef.current ?? findScrollable();
    if (!track || !el) return;
    const rect = track.getBoundingClientRect();
    const usable = Math.max(1, rect.height - THUMB);
    const r = Math.min(1, Math.max(0, (clientY - rect.top - THUMB / 2) / usable));
    el.scrollTop = r * (el.scrollHeight - el.clientHeight);
    setRatio(r);
  };

  if (hidden || !available) return null;

  return (
    <div
      data-testid="scroll-buttons"
      className="fixed right-1.5 top-1/2 -translate-y-1/2 z-[70] pointer-events-none"
    >
      <div
        ref={trackRef}
        aria-label="Scroll"
        role="scrollbar"
        className="relative w-8 rounded-full bg-slate-950/45 border-2 border-sky-200/70 pointer-events-auto touch-none select-none"
        style={{ height: 'min(52vh, 320px)' }}
        onPointerDown={(e) => {
          e.preventDefault();
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          setDragging(true);
          scrollToPointer(e.clientY);
        }}
        onPointerMove={(e) => {
          if (dragging) scrollToPointer(e.clientY);
        }}
        onPointerUp={() => setDragging(false)}
        onPointerCancel={() => setDragging(false)}
      >
        <div
          className={`absolute left-0 right-0 mx-auto w-7 rounded-full bg-gradient-to-b from-[#2f7bff] to-[#1546b8] border-2 border-sky-200 text-white flex items-center justify-center shadow-[0_0_10px_rgba(56,189,248,0.7)] ${
            dragging ? 'brightness-125' : ''
          }`}
          style={{ height: THUMB, top: `calc((100% - ${THUMB}px) * ${ratio})` }}
        >
          <ChevronsUpDown className="w-5 h-5" strokeWidth={3} />
        </div>
      </div>
    </div>
  );
}
