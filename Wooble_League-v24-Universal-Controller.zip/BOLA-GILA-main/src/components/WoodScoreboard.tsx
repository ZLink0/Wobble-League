import woodUrl from '../assets/scoreboard/board_wood.png';
import capyUrl from '../assets/scoreboard/board_capy.png';
import esportsUrl from '../assets/scoreboard/board_esports.png';
import royalUrl from '../assets/scoreboard/board_royal.png';
import cleanUrl from '../assets/scoreboard/board_clean.png';
import type { ScoreHudStyleId } from '../game/types';

/**
 * Papan skor bergambar (5 gaya). Gambar dikosongkan dari angka;
 * skor, jam, dan label babak ditulis sebagai teks di atasnya.
 */

type StyleCfg = {
  url: string;
  aspect: number; // lebar / tinggi gambar
  red: [number, number]; // pusat teks skor merah (fraksi lebar, tinggi)
  blue: [number, number];
  clock: [number, number];
  label: [number, number];
  scoreFs: number; // ukuran font (fraksi lebar papan)
  clockFs: number;
  labelFs: number;
  clockColor: string;
  labelColor: string;
  labelStroke?: string;
};

const STYLES: Record<Exclude<ScoreHudStyleId, 'random'>, StyleCfg> = {
  wood: {
    url: woodUrl,
    aspect: 2172 / 719,
    red: [0.19, 0.577],
    blue: [0.81, 0.577],
    clock: [0.5, 0.577],
    label: [0.501, 0.182],
    scoreFs: 0.14,
    clockFs: 0.1,
    labelFs: 0.072,
    clockColor: '#2a1409',
    labelColor: '#2a1409',
  },
  capy: {
    url: capyUrl,
    aspect: 2172 / 724,
    red: [0.185, 0.656],
    blue: [0.8, 0.656],
    clock: [0.5, 0.66],
    label: [0.496, 0.307],
    scoreFs: 0.138,
    clockFs: 0.104,
    labelFs: 0.069,
    clockColor: '#111111',
    labelColor: '#ffffff',
    labelStroke: '#111111',
  },
  esports: {
    url: esportsUrl,
    aspect: 2164 / 660,
    red: [0.199, 0.627],
    blue: [0.803, 0.63],
    clock: [0.502, 0.645],
    label: [0.5, 0.215],
    scoreFs: 0.139,
    clockFs: 0.104,
    labelFs: 0.069,
    clockColor: '#111111',
    labelColor: '#ffffff',
    labelStroke: '#111111',
  },
  royal: {
    url: royalUrl,
    aspect: 2059 / 724,
    red: [0.193, 0.635],
    blue: [0.819, 0.635],
    clock: [0.507, 0.635],
    label: [0.508, 0.276],
    scoreFs: 0.146,
    clockFs: 0.108,
    labelFs: 0.06,
    clockColor: '#2a1409',
    labelColor: '#ffffff',
    labelStroke: '#2a1042',
  },
  clean: {
    url: cleanUrl,
    aspect: 2156 / 701,
    red: [0.191, 0.569],
    blue: [0.812, 0.559],
    clock: [0.504, 0.563],
    label: [0.502, 0.181],
    scoreFs: 0.139,
    clockFs: 0.104,
    labelFs: 0.065,
    clockColor: '#111111',
    labelColor: '#111111',
  },
};

export const SCORE_HUD_STYLE_IDS = ['wood', 'capy', 'esports', 'royal', 'clean'] as const;

export function pickRandomScoreHudStyle(): Exclude<ScoreHudStyleId, 'random'> {
  return SCORE_HUD_STYLE_IDS[Math.floor(Math.random() * SCORE_HUD_STYLE_IDS.length)];
}

const OUTLINE = '#1a0f0a';

interface WoodScoreboardProps {
  redScore: number;
  blueScore: number;
  /** Teks di papan kecil atas, contoh "1ST" / "2ND" / "3RD" */
  topLabel: string;
  /** Teks jam di tengah, contoh "02:20" */
  clock: string;
  /** Mode latihan: jam tak terbatas */
  training?: boolean;
  /** Gaya papan skor (sudah bukan 'random') */
  styleId?: Exclude<ScoreHudStyleId, 'random'>;
}

function at(pos: [number, number]): React.CSSProperties {
  return { left: `${pos[0] * 100}%`, top: `${pos[1] * 100}%`, transform: 'translate(-50%, -50%)' };
}

function ScoreText({ score, tone, cfg }: { score: number; tone: 'red' | 'blue'; cfg: StyleCfg }) {
  const digits = String(score).length;
  const scale = digits <= 2 ? 1 : digits === 3 ? 0.82 : 0.64;
  return (
    <span
      data-testid={tone === 'red' ? 'red-score' : 'blue-score'}
      className="font-display absolute text-center leading-none"
      style={{
        ...at(tone === 'red' ? cfg.red : cfg.blue),
        fontSize: `calc(var(--sw) * ${cfg.scoreFs * scale})`,
        fontWeight: 800,
        fontStyle: 'italic',
        color: '#ffffff',
        WebkitTextStroke: `calc(var(--sw) * 0.0055) ${OUTLINE}`,
        paintOrder: 'stroke fill',
        textShadow: `0 calc(var(--sw) * 0.004) 0 rgba(0,0,0,0.25)`,
        whiteSpace: 'nowrap',
      }}
    >
      {String(score).padStart(2, '0')}
    </span>
  );
}

export function WoodScoreboard({ redScore, blueScore, topLabel, clock, training, styleId = 'wood' }: WoodScoreboardProps) {
  const cfg = STYLES[styleId] ?? STYLES.wood;
  return (
    <div
      data-testid="score-hud"
      data-score-style={styleId}
      className="relative select-none pointer-events-none"
      style={
        {
          // lebar papan; menyesuaikan layar kecil (HP landscape) sampai desktop
          '--sw': 'clamp(170px, 31vh, 290px)',
          width: 'var(--sw)',
          aspectRatio: String(cfg.aspect),
          filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.45))',
        } as React.CSSProperties
      }
    >
      <img
        src={cfg.url}
        alt=""
        draggable={false}
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', display: 'block' }}
      />

      <ScoreText score={redScore} tone="red" cfg={cfg} />
      <ScoreText score={blueScore} tone="blue" cfg={cfg} />

      {/* label babak */}
      <div className="absolute flex items-center justify-center" style={{ ...at(cfg.label), width: '24%', height: '17%' }}>
        {training ? (
          <span
            data-testid="training-mode-badge"
            className="font-display"
            style={{ fontSize: 'calc(var(--sw) * 0.04)', fontWeight: 800, color: cfg.labelColor, letterSpacing: '0.04em', lineHeight: 1 }}
          >
            TRAINING
          </span>
        ) : (
          <span
            data-testid="match-half-badge"
            className="font-display"
            style={{
              fontSize: `calc(var(--sw) * ${cfg.labelFs})`,
              fontWeight: 800,
              fontStyle: 'italic',
              color: cfg.labelColor,
              lineHeight: 1,
              WebkitTextStroke: cfg.labelStroke ? `calc(var(--sw) * 0.003) ${cfg.labelStroke}` : undefined,
              paintOrder: 'stroke fill',
            }}
          >
            {topLabel}
          </span>
        )}
      </div>

      {/* jam */}
      <div className="absolute flex items-center justify-center" style={{ ...at(cfg.clock), width: '28%', height: '24%' }}>
        {training ? (
          <span
            data-testid="training-unlimited-clock"
            aria-label="Unlimited time"
            className="font-display"
            style={{ fontSize: `calc(var(--sw) * ${cfg.clockFs * 1.2})`, fontWeight: 800, color: cfg.clockColor, lineHeight: 1 }}
          >
            ∞
          </span>
        ) : (
          <span
            className="font-display"
            style={{
              fontSize: `calc(var(--sw) * ${cfg.clockFs})`,
              fontWeight: 800,
              color: cfg.clockColor,
              lineHeight: 1,
              fontVariantNumeric: 'tabular-nums',
              whiteSpace: 'nowrap',
            }}
          >
            {clock}
          </span>
        )}
      </div>
    </div>
  );
}
