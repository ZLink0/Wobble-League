import { useState } from 'react';
import { Award } from 'lucide-react';
import { STORY_WORLDS, StoryProgressState } from '../game/story';
import { useMenuController } from '../hooks/useMenuController';

export type MainMenuDestination =
  | 'story'
  | 'quick'
  | 'local_multiplayer'
  | 'tournament'
  | 'character'
  | 'settings';

interface TitleScreenProps {
  active: boolean;
  storyProgress: StoryProgressState;
  onSelectMenu: (dest: MainMenuDestination) => void;
  onOpenTrophies: () => void;
}

const MENU_ITEMS: Array<{
  id: MainMenuDestination;
  label: string;
  testId: string;
}> = [
  { id: 'story', label: 'STORY MODE', testId: 'title-story-btn' },
  { id: 'quick', label: 'QUICK MATCH', testId: 'title-quick-btn' },
  { id: 'local_multiplayer', label: 'LOCAL MULTIPLAYER', testId: 'title-multiplayer-btn' },
  { id: 'tournament', label: 'TOURNAMENT', testId: 'title-tournament-btn' },
  { id: 'character', label: 'CHARACTER', testId: 'title-characters-btn' },
  { id: 'settings', label: 'SETTINGS', testId: 'open-options-btn' },
];

export function TitleScreen({
  active,
  storyProgress,
  onSelectMenu,
  onOpenTrophies,
}: TitleScreenProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const currentWorld =
    STORY_WORLDS[storyProgress.highestWorldUnlocked] ?? STORY_WORLDS[0];

  useMenuController({
    active,
    onAction: (action) => {
      if (action === 'up') {
        setSelectedIndex((prev) => (prev - 1 + MENU_ITEMS.length) % MENU_ITEMS.length);
      } else if (action === 'down') {
        setSelectedIndex((prev) => (prev + 1) % MENU_ITEMS.length);
      } else if (action === 'confirm' || action === 'start') {
        const chosen = MENU_ITEMS[selectedIndex];
        if (chosen) onSelectMenu(chosen.id);
      }
    },
  });

  // Each item is h-12 (48px) with 10px gap -> 58px vertical pitch
  const ITEM_PITCH_PX = 58;

  return (
    <div className="fixed inset-0 z-20 flex flex-col items-center justify-center p-2.5 sm:p-4 bg-gradient-to-b from-sky-500/45 via-sky-300/20 to-emerald-500/25 pointer-events-none">
      {/* Bright Trophy Shortcut Top-Right */}
      <button
        type="button"
        data-testid="title-trophies-btn"
        onClick={onOpenTrophies}
        className="pointer-events-auto fixed top-3 right-3 sm:top-4 sm:right-5 px-3 py-1.5 rounded-xl bg-gradient-to-b from-amber-300 to-amber-400 hover:brightness-105 text-slate-950 border-2 border-amber-100 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-lg"
      >
        <Award className="w-4 h-4" />
        <span>TROPHIES ({storyProgress.unlockedTrophies.length}/10)</span>
      </button>

      {/* Centered Bright Arcade Main Menu Container (Fits Horizontal Mobile & Desktop) */}
      <div className="pointer-events-auto w-full max-w-[460px] lg:max-w-[390px] max-h-[94vh] overflow-y-auto custom-scroll rounded-2xl px-4 py-3 lg:px-6 lg:py-5 border-[3px] border-sky-300 bg-gradient-to-b from-blue-600/92 via-blue-700/94 to-indigo-900/95 backdrop-blur-md shadow-[0_16px_42px_rgba(2,132,199,0.5)] flex flex-col items-center">
        {/* Clean Game Header */}
        <div className="text-center mb-2 lg:mb-4">
          <div className="inline-flex items-center justify-center gap-2">
            <svg viewBox="0 0 36 36" className="w-6 h-6 lg:w-7 lg:h-7 shrink-0" aria-hidden="true">
              <circle cx="18" cy="18" r="15" fill="#f8fafc" stroke="#0f172a" strokeWidth="2.5" />
              <polygon points="18,10 24,15 22,22 14,22 12,15" fill="#1e293b" />
              <path
                d="M18 3 V10 M24 15 L31 13 M22 22 L27 29 M14 22 L9 29 M12 15 L5 13"
                stroke="#1e293b"
                strokeWidth="2.2"
                strokeLinecap="round"
              />
            </svg>
            <h1 className="font-display font-extrabold text-xl lg:text-2xl tracking-tight text-white drop-shadow-[0_2px_0_rgba(15,23,42,0.55)]">
              WOBBLE LEAGUE
            </h1>
          </div>
          <div className="text-[10px] lg:text-[11px] font-display font-extrabold uppercase tracking-[0.32em] text-amber-300 mt-0.5">
            FOOTBALL
          </div>
          <div className="text-[10px] font-bold text-sky-100 mt-0.5 hidden lg:block">
            World {currentWorld.worldNumber}: {currentWorld.name}
          </div>
        </div>

        {/* 6 Uniform Menu Buttons (2-col compact on tight horizontal screens, pure 1-col centered on desktop) */}
        <div className="relative w-full" role="menu" aria-label="Main Menu">
          <div className="grid grid-cols-2 lg:grid-cols-1 gap-1.5 lg:gap-2">
            {MENU_ITEMS.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="menuitem"
                  data-testid={item.testId}
                  data-selected={isSelected ? 'true' : 'false'}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  onFocus={() => setSelectedIndex(idx)}
                  onClick={() => {
                    setSelectedIndex(idx);
                    onSelectMenu(item.id);
                  }}
                  className={`w-full h-9 lg:h-11 px-3 lg:px-4 rounded-xl font-display font-extrabold text-xs lg:text-sm tracking-wider uppercase transition-all duration-150 flex items-center justify-center cursor-pointer border-2 ${
                    idx === 0 ? 'col-span-2 lg:col-span-1' : ''
                  } ${
                    isSelected
                      ? 'bg-gradient-to-b from-amber-300 to-amber-400 text-slate-950 border-amber-100 shadow-[0_3px_0_#b45309] scale-[1.01]'
                      : 'bg-blue-900/70 text-white border-sky-300/40 hover:bg-blue-800/85 hover:border-sky-200'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Console Footer Prompts */}
        <div className="w-full mt-2 lg:mt-4 pt-2 lg:pt-3 border-t border-sky-300/35 flex items-center justify-center gap-4 text-[10px] font-extrabold tracking-wider text-sky-100">
          <span className="flex items-center gap-1">
            <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-mono-num">A</span>
            <span>SELECT</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="px-1.5 py-0.5 rounded bg-rose-500 text-white font-mono-num">B</span>
            <span>BACK</span>
          </span>
          <span className="text-sky-200 hidden sm:inline">D-PAD / ARROWS</span>
        </div>
      </div>
    </div>
  );
}
