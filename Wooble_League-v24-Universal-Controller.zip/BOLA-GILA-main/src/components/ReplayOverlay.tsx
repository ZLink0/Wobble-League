import { gamepadManager } from '../game/gamepadManager';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Camera, Pause, Play, RotateCcw, X } from 'lucide-react';
import {
  ReplayBundle,
  ReplayCameraAngle,
  ReplayFrame,
  sampleReplayFrame,
} from '../game/replay';
import { TeamId } from '../game/types';

interface ReplayOverlayProps {
  bundle: ReplayBundle;
  onFrameChange: (frame: ReplayFrame | null, angle: ReplayCameraAngle, focusTeam: TeamId | null) => void;
  onExit: () => void;
}

const SPEEDS = [0.25, 0.5, 1.0] as const;

const CAMERA_ANGLES: Array<{ id: ReplayCameraAngle; label: string }> = [
  { id: 'broadcast', label: 'Pinggir Tengah' },
  { id: 'goal_cam', label: 'Pinggir Gawang' },
  { id: 'follow_ball', label: 'Pinggir Rendah' },
  { id: 'overhead', label: 'Pinggir Tinggi' },
];

export function ReplayOverlay({ bundle, onFrameChange, onExit }: ReplayOverlayProps) {
  const [selectedClip, setSelectedClip] = useState<'tail' | number>(() =>
    bundle.goals.length > 0 ? 0 : 'tail'
  );
  const [isPlaying, setIsPlaying] = useState(true);
  const [speed, setSpeed] = useState<number>(0.5);
  const [cameraAngle, setCameraAngle] = useState<ReplayCameraAngle>('broadcast');

  const activeClip = useMemo(() => {
    if (selectedClip === 'tail') {
      return {
        label: 'Last 15s',
        frames: bundle.tailFrames,
        focusTeam: null as TeamId | null,
      };
    }
    const g = bundle.goals[selectedClip];
    if (!g) {
      return {
        label: 'Last 15s',
        frames: bundle.tailFrames,
        focusTeam: null as TeamId | null,
      };
    }
    return {
      label: `Goal ${selectedClip + 1}`,
      frames: g.clipFrames && g.clipFrames.length > 0 ? g.clipFrames : bundle.tailFrames,
      focusTeam: g.team,
    };
  }, [bundle, selectedClip]);

  const startTime = activeClip.frames[0]?.time ?? 0;
  const endTime = activeClip.frames[activeClip.frames.length - 1]?.time ?? startTime;
  const duration = Math.max(0.1, endTime - startTime);

  const [offsetSec, setOffsetSec] = useState(0);
  const offsetRef = useRef(0);

  // Reset playhead when switching clips
  useEffect(() => {
    offsetRef.current = 0;
    setOffsetSec(0);
    setIsPlaying(true);
  }, [selectedClip]);

  // Playback timer
  useEffect(() => {
    if (!isPlaying) return;
    let lastTs = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const dt = Math.min(0.1, (now - lastTs) / 1000);
      lastTs = now;
      let next = offsetRef.current + dt * speed;
      if (next >= duration) {
        next = 0;
      }
      offsetRef.current = next;
      setOffsetSec(next);
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, speed, duration]);

  // Sample interpolated frame & emit up to EngineCanvas
  const currentFrame = useMemo(
    () => sampleReplayFrame(activeClip.frames, startTime + offsetSec),
    [activeClip.frames, startTime, offsetSec]
  );

  useEffect(() => {
    onFrameChange(currentFrame, cameraAngle, activeClip.focusTeam);
  }, [currentFrame, cameraAngle, activeClip.focusTeam, onFrameChange]);

  // Start pada controller mana pun keluar dari Replay
  useEffect(() => {
    const id = window.setInterval(() => {
      if (gamepadManager.edgeAny('replay-overlay', [9])) onExit();
    }, 60);
    return () => window.clearInterval(id);
  }, [onExit]);

  return (
    <div
      data-testid="replay-overlay"
      className="fixed inset-0 z-30 pointer-events-none flex flex-col justify-between p-2.5 sm:p-4"
    >
      {/* Top-Right Minimal Icon-Only Exit Button (Zero Goal/Replay caption text on screen) */}
      <div className="flex items-center justify-end pointer-events-auto">
        <button
          type="button"
          aria-label="Exit Replay"
          data-testid="exit-replay-btn"
          onClick={onExit}
          className="w-9 h-9 rounded-full bg-blue-800/90 hover:bg-blue-700 text-white border-2 border-sky-300 flex items-center justify-center shadow-lg cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Bright Sky-Blue Bottom Transport & Camera Controls */}
      <div className="w-full max-w-4xl mx-auto rounded-2xl p-2.5 sm:p-3.5 border-[3px] border-sky-400 bg-gradient-to-b from-blue-600/92 via-blue-700/94 to-indigo-900/95 backdrop-blur-md shadow-[0_12px_32px_rgba(2,132,199,0.45)] pointer-events-auto space-y-2">
        {/* Clip Selector + Camera Angles */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              data-testid="replay-clip-tail"
              onClick={() => setSelectedClip('tail')}
              className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer border ${
                selectedClip === 'tail'
                  ? 'bg-amber-400 text-slate-950 border-amber-200'
                  : 'bg-blue-900/80 text-white border-sky-300/40 hover:bg-blue-800'
              }`}
            >
              Last 15s
            </button>
            {bundle.goals.map((g, idx) => (
              <button
                key={g.id}
                type="button"
                data-testid={`replay-clip-goal-${idx}`}
                onClick={() => setSelectedClip(idx)}
                className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer border ${
                  selectedClip === idx
                    ? 'bg-amber-400 text-slate-950 border-amber-200'
                    : g.team === 'red'
                      ? 'bg-red-600/85 text-white border-red-300/60 hover:bg-red-500'
                      : 'bg-sky-600/85 text-white border-sky-300/60 hover:bg-sky-500'
                }`}
              >
                Clip {idx + 1}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <Camera className="w-3.5 h-3.5 text-amber-300 mr-0.5" />
            {CAMERA_ANGLES.map((cam) => (
              <button
                key={cam.id}
                type="button"
                data-testid={`replay-cam-${cam.id}`}
                onClick={() => setCameraAngle(cam.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer border ${
                  cameraAngle === cam.id
                    ? 'bg-amber-400 text-slate-950 border-amber-200'
                    : 'bg-blue-900/80 text-white border-sky-300/40 hover:bg-blue-800'
                }`}
              >
                {cam.label}
              </button>
            ))}
          </div>
        </div>

        {/* Scrubber */}
        <div className="flex items-center gap-3">
          <span className="font-mono-num text-xs text-white font-bold w-11 text-right">
            {offsetSec.toFixed(1)}s
          </span>
          <input
            type="range"
            aria-label="Replay Timeline"
            data-testid="replay-scrubber"
            min={0}
            max={duration}
            step={0.04}
            value={offsetSec}
            onChange={(e) => {
              const v = Number(e.target.value);
              offsetRef.current = v;
              setOffsetSec(v);
              setIsPlaying(false);
            }}
            className="flex-1 accent-amber-400 cursor-pointer"
          />
          <span className="font-mono-num text-xs text-sky-200 font-bold w-11">
            {duration.toFixed(1)}s
          </span>
        </div>

        {/* Playback Controls + Slow-Mo Speed */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              data-testid="replay-play-toggle"
              onClick={() => setIsPlaying((p) => !p)}
              className="flex items-center gap-1.5 px-3.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              type="button"
              onClick={() => {
                offsetRef.current = 0;
                setOffsetSec(0);
                setIsPlaying(true);
              }}
              className="flex items-center gap-1 px-3 py-1 rounded-lg bg-blue-900/80 hover:bg-blue-800 border border-sky-300/40 text-white text-xs font-bold cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Restart
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            {SPEEDS.map((sp) => (
              <button
                key={sp}
                type="button"
                data-testid={`replay-speed-${sp}`}
                onClick={() => setSpeed(sp)}
                className={`px-2.5 py-1 rounded-lg font-mono-num text-xs font-extrabold cursor-pointer border ${
                  speed === sp
                    ? 'bg-emerald-400 text-slate-950 border-emerald-200'
                    : 'bg-blue-900/80 text-white border-sky-300/40 hover:bg-blue-800'
                }`}
              >
                {sp}x
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
