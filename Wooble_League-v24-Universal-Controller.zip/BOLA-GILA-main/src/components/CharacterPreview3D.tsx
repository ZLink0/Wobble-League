import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { buildCharacterRig, CharacterRig } from '../game/models';
import { RoomEnvironment } from '../game/environment';
import { createContactShadowTexture } from '../game/textures';
import { PlayerCustomization, TeamId } from '../game/types';

interface Props {
  team: TeamId;
  custom: PlayerCustomization;
  facingYaw?: number;
  spinEnabled?: boolean;
  isSpeaking?: boolean;
  compact?: boolean;
  openPitch?: boolean;
  zoomLevel?: number;
  dragRotate?: boolean;
  onYawChange?: (yaw: number) => void;
}

/** Bebaskan geometri, material, dan tekstur rig lama (kecuali tekstur bayangan bersama) agar GPU tidak penuh */
function disposeRig(root: THREE.Object3D, keep: THREE.Texture) {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mats = mesh.material ? (Array.isArray(mesh.material) ? mesh.material : [mesh.material]) : [];
    for (const m of mats) {
      for (const v of Object.values(m as unknown as Record<string, unknown>)) {
        if (v instanceof THREE.Texture && v !== keep) v.dispose();
      }
      m.dispose();
    }
  });
}

export function CharacterPreview3D({
  team,
  custom,
  facingYaw = 0.42,
  spinEnabled = true,
  isSpeaking = false,
  compact = false,
  openPitch = false,
  zoomLevel = 1.0,
  dragRotate = false,
  onYawChange,
}: Props) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const spinEnabledRef = useRef(spinEnabled);
  spinEnabledRef.current = spinEnabled;
  const isSpeakingRef = useRef(isSpeaking);
  isSpeakingRef.current = isSpeaking;
  const facingYawRef = useRef(facingYaw);
  facingYawRef.current = facingYaw;
  const dragYawRef = useRef(0);
  const dragStartRef = useRef<{ x: number; startYaw: number } | null>(null);

  const stateRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    rig: CharacterRig | null;
    shadowTex: THREE.CanvasTexture;
    requestRender: () => void;
    isSoftwareGl: boolean;
  } | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({ antialias: !isSoftwareGl, alpha: true });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = openPitch ? 1.15 : 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || 260, container.clientHeight || 260);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    scene.environment = pmrem.fromScene(roomEnv, 0.04).texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(
      openPitch ? 34 : 36,
      (container.clientWidth || 260) / (container.clientHeight || 260),
      0.1,
      40
    );
    const zScale = 1 / Math.max(0.65, Math.min(1.55, zoomLevel));
    camera.position.set(
      (openPitch ? 0.32 : compact ? 0.25 : 1.35) * zScale,
      (openPitch ? 1.36 : 1.38) * zScale,
      (openPitch ? 4.05 : compact ? 2.85 : 2.75) * zScale
    );
    camera.lookAt(0, openPitch ? 0.9 : 0.72, 0);

    const keyLight = new THREE.DirectionalLight('#fffbeb', openPitch ? 1.75 : 1.6);
    keyLight.position.set(3, 5, 4);
    scene.add(keyLight);
    scene.add(new THREE.HemisphereLight('#bae6fd', openPitch ? '#166534' : '#334155', 0.9));

    if (openPitch) {
      const turfPad = new THREE.Mesh(
        new THREE.CylinderGeometry(0.95, 1.0, 0.06, 32),
        new THREE.MeshStandardMaterial({ color: '#2f8e41', roughness: 0.85, metalness: 0.05 })
      );
      turfPad.position.y = -0.03;
      const whiteRing = new THREE.Mesh(
        new THREE.RingGeometry(0.76, 0.84, 32),
        new THREE.MeshBasicMaterial({ color: '#f8fafc', transparent: true, opacity: 0.75, side: THREE.DoubleSide })
      );
      whiteRing.rotation.x = -Math.PI / 2;
      whiteRing.position.y = 0.005;
      scene.add(turfPad, whiteRing);
    } else {
      const pedestal = new THREE.Mesh(
        new THREE.CylinderGeometry(0.85, 0.92, 0.12, 24),
        new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.4, metalness: 0.2 })
      );
      pedestal.position.y = -0.06;
      scene.add(pedestal);
    }

    const shadowTex = createContactShadowTexture();

    let frameId = 0;
    let renderQueued = false;
    let disposed = false;

    const requestRender = () => {
      if (disposed || renderQueued) return;
      renderQueued = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderQueued = false;
        renderer.render(scene, camera);
      });
    };

    stateRef.current = {
      scene,
      camera,
      renderer,
      rig: null,
      shadowTex,
      requestRender,
      isSoftwareGl,
    };

    const ro = new ResizeObserver(() => {
      const w = container.clientWidth || 260;
      const h = container.clientHeight || 260;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    });
    ro.observe(container);

    let spinTimer = 0;
    if (!isSoftwareGl) {
      let t = 0;
      const spin = () => {
        if (disposed) return;
        t += 0.06;
        const rig = stateRef.current?.rig;
        if (rig) {
          if (spinEnabledRef.current && !dragStartRef.current) {
            rig.root.rotation.y += 0.008;
          } else {
            rig.root.rotation.y =
              facingYawRef.current +
              dragYawRef.current +
              (isSpeakingRef.current ? Math.sin(t * 1.4) * 0.05 : 0);
            rig.neckPivot.rotation.x = isSpeakingRef.current ? Math.sin(t * 2.8) * 0.1 : 0;
            rig.root.position.y = isSpeakingRef.current ? Math.abs(Math.sin(t * 2.2)) * 0.045 : 0;
          }
        }
        renderer.render(scene, camera);
        spinTimer = requestAnimationFrame(spin);
      };
      spinTimer = requestAnimationFrame(spin);
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      cancelAnimationFrame(spinTimer);
      clearTimeout(frameId);
      ro.disconnect();
      shadowTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      stateRef.current = null;
    };
  }, [compact, openPitch]);

  useEffect(() => {
    const st = stateRef.current;
    if (!st) return;
    const zScale = 1 / Math.max(0.65, Math.min(1.55, zoomLevel));
    st.camera.position.set(
      (openPitch ? 0.32 : compact ? 0.25 : 1.35) * zScale,
      (openPitch ? 1.36 : 1.38) * zScale,
      (openPitch ? 4.05 : compact ? 2.85 : 2.75) * zScale
    );
    st.camera.lookAt(0, openPitch ? 0.9 : 0.72, 0);
    st.requestRender();
  }, [zoomLevel, compact, openPitch]);

  useEffect(() => {
    const st = stateRef.current;
    if (!st) return;
    if (st.rig) {
      st.scene.remove(st.rig.root);
      disposeRig(st.rig.root, st.shadowTex);
      st.rig = null;
    }
    try {
      const rig = buildCharacterRig(team, false, custom, st.shadowTex);
      rig.root.rotation.y = facingYawRef.current + dragYawRef.current;
      st.scene.add(rig.root);
      st.rig = rig;
    } catch (err) {
      console.error('Gagal membangun karakter preview', err);
    }
    st.requestRender();
    // facingYaw sengaja tidak jadi dependensi: rotasi ditangani efek terpisah agar rig tidak dibangun ulang terus-menerus
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [team, custom]);

  useEffect(() => {
    return () => {
      const st = stateRef.current;
      if (st?.rig) disposeRig(st.rig.root, st.shadowTex);
    };
  }, []);

  useEffect(() => {
    const st = stateRef.current;
    if (!st || !st.rig) return;
    if (!spinEnabled) {
      st.rig.root.rotation.y = facingYaw + dragYawRef.current;
      st.rig.neckPivot.rotation.x = isSpeaking ? 0.08 : 0;
      st.requestRender();
    }
  }, [facingYaw, isSpeaking, spinEnabled]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRotate) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragStartRef.current = { x: e.clientX, startYaw: dragYawRef.current };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRotate || !dragStartRef.current) return;
    const delta = (e.clientX - dragStartRef.current.x) * 0.014;
    dragYawRef.current = dragStartRef.current.startYaw + delta;
    const st = stateRef.current;
    if (st?.rig) {
      st.rig.root.rotation.y = facingYaw + dragYawRef.current;
      st.requestRender();
    }
    onYawChange?.(facingYaw + dragYawRef.current);
  };

  const handlePointerUp = () => {
    dragStartRef.current = null;
  };

  return (
    <div
      ref={mountRef}
      data-testid="character-preview-3d"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className={`w-full h-full min-h-[160px] select-none overflow-hidden ${
        openPitch
          ? 'bg-transparent'
          : 'rounded-xl bg-gradient-to-b from-slate-800/80 to-slate-950/90 border border-white/10'
      } ${dragRotate ? 'cursor-grab active:cursor-grabbing touch-none' : ''}`}
    />
  );
}
