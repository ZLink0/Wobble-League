import type { SVGProps } from 'react';

type IconProps = SVGProps<SVGSVGElement>;

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  'aria-hidden': true,
};

/** A — sepatu menendang bola */
export function KickIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      {/* sepatu bola */}
      <path d="M2.5 18.5V12.2c0-.6.5-1 1-1h3.2l1.6 2.3 3.1 1.1c1.3.4 2.1 1.5 2.1 2.8v1.1H2.5Z" fill="currentColor" fillOpacity={0.25} />
      <path d="M2.5 20.2h12.7" />
      <path d="M5 20.2v-1.3M8 20.2v-1.3M11 20.2v-1.3" strokeWidth={1.4} />
      {/* bola */}
      <circle cx="18" cy="8.2" r="3.9" fill="currentColor" fillOpacity={0.18} />
      <path d="m18 6.2 1.7 1.2-.65 2h-2.1l-.65-2L18 6.2Z" fill="currentColor" strokeWidth={1.1} />
      {/* garis gerak */}
      <path d="M14.2 12.6l1.6-1.5M17.5 13.4l.4-1.6" strokeWidth={1.4} />
    </svg>
  );
}

/** X — tendangan putar (sepatu + panah melingkar) */
export function SpinKickIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 4.2a7.8 7.8 0 1 1-7.5 5.7" />
      <path d="m3.2 6.8 1.5 3.4 3.4-1.4" />
      <path d="M9.2 14.6v-3.1c0-.4.3-.7.7-.7h1.6l1.2 1.7 1.7.7c.7.3 1.1.9 1.1 1.6v.8H9.2Z" fill="currentColor" fillOpacity={0.3} />
      <path d="M9.2 16.6h5.5" strokeWidth={1.4} />
    </svg>
  );
}

/** Y — ambil / lepas benda (tangan memegang) */
export function GrabIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M8 11V6.2a1.3 1.3 0 0 1 2.6 0V10M10.6 9.6V4.8a1.3 1.3 0 0 1 2.6 0V10M13.2 10V5.8a1.3 1.3 0 0 1 2.6 0V11" />
      <path d="M15.8 9.2a1.3 1.3 0 0 1 2.5.4V14c0 3.6-2.2 6-5.5 6h-.7c-2 0-3.3-.9-4.4-2.6L4.9 13.5a1.4 1.4 0 0 1 2.3-1.6L8 13V11" fill="currentColor" fillOpacity={0.2} />
    </svg>
  );
}

/** B — lompat */
export function JumpIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3.5v10.2" />
      <path d="m7.4 8 4.6-4.6L16.6 8" />
      <path d="M6 17.2c1.2-.9 2.4.9 3.6 0s2.4.9 3.6 0 2.4.9 3.6 0" strokeWidth={1.5} />
      <path d="M7 20.4h10" strokeWidth={1.5} />
    </svg>
  );
}

/** L — sundulan putar 360° (kepala + panah melingkar) */
export function HeadSpinIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="12.8" r="3.3" fill="currentColor" fillOpacity={0.25} />
      <path d="M10.7 12.4h.01M13.3 12.4h.01" strokeWidth={2.2} />
      <path d="M17.6 7.2A8 8 0 0 0 5.2 8.6" />
      <path d="m4.6 5.2.5 3.7 3.5-.9" />
      <path d="M6.4 17.4a8 8 0 0 0 12.4-1.4" />
      <path d="m19.4 19 -.5-3.7-3.5.9" />
    </svg>
  );
}

/** R — lari kencang / dash (petir + garis kecepatan) */
export function DashIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="m13.8 3-6.4 9h4.3l-1.5 9 6.6-10.2h-4.4L13.8 3Z" fill="currentColor" fillOpacity={0.3} />
      <path d="M3.5 9h2.6M2.5 13h3.4M3.5 17h2.6" strokeWidth={1.5} />
    </svg>
  );
}

/** START — dua garis potret (jeda) */
export function StartBarsIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="6.2" y="4.5" width="4" height="15" rx="1.2" fill="currentColor" />
      <rect x="13.8" y="4.5" width="4" height="15" rx="1.2" fill="currentColor" />
    </svg>
  );
}
