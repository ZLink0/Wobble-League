import { useEffect, useRef, useState } from 'react';
import { useDomFocusNav } from '../hooks/useDomFocusNav';
import { Award, Check, Coins, Crown, Flag, Lock, Play, Swords, UserCheck } from 'lucide-react';
import { ANIMALS, ARENAS, BALLS } from '../game/catalog';
import {
  isMatchCompleted,
  isMatchUnlocked,
  isWorldCleared,
  isWorldUnlocked,
  STORY_WORLDS,
  StoryProgressState,
} from '../game/story';
import { PlayerCustomization } from '../game/types';
import { AnimalIcon, ArenaPreviewIcon, BallPreviewIcon } from './MenuIcons';

interface StoryMapModalProps {
  progress: StoryProgressState;
  heroCustom: PlayerCustomization;
  initialWorldIdx?: number;
  initialMatchIdx?: number;
  travelFromWorldIdx?: number | null;
  onSelectNode: (worldIdx: number, matchIdx: number) => void;
  onChallengeMatch: (worldIdx: number, matchIdx: number) => void;
  onOpenCharacterLocker: () => void;
  onOpenTrophies: () => void;
  onReplayEnding?: () => void;
  onBack: () => void;
}

export function StoryMapModal({
  progress,
  heroCustom,
  initialWorldIdx,
  initialMatchIdx,
  travelFromWorldIdx,
  onSelectNode,
  onChallengeMatch,
  onOpenCharacterLocker,
  onOpenTrophies,
  onReplayEnding,
  onBack,
}: StoryMapModalProps) {
  const [selectedWorld, setSelectedWorld] = useState<number>(
    initialWorldIdx ?? progress.lastSelectedWorld
  );
  const [selectedMatch, setSelectedMatch] = useState<number>(
    initialMatchIdx ?? progress.lastSelectedMatch
  );

  const startWorld = STORY_WORLDS[travelFromWorldIdx ?? selectedWorld] ?? STORY_WORLDS[0];
  const [heroPos, setHeroPos] = useState<{ x: number; y: number }>({
    x: startWorld.mapX,
    y: startWorld.mapY,
  });
  const [isTraveling, setIsTraveling] = useState(false);
  const heroPosRef = useRef(heroPos);
  heroPosRef.current = heroPos;

  // Animate hero character walking along the map trail whenever selectedWorld changes
  useEffect(() => {
    const dest = STORY_WORLDS[selectedWorld] ?? STORY_WORLDS[0];
    const startX = heroPosRef.current.x;
    const startY = heroPosRef.current.y;
    const dist = Math.hypot(dest.mapX - startX, dest.mapY - startY);
    if (dist < 2) {
      setHeroPos({ x: dest.mapX, y: dest.mapY });
      setIsTraveling(false);
      return;
    }

    let raf = 0;
    const startTime = performance.now();
    const duration = Math.min(720, Math.max(320, dist * 2.2));
    setIsTraveling(true);

    const step = (now: number) => {
      const t = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const arcLift = Math.sin(t * Math.PI) * 16;
      setHeroPos({
        x: startX + (dest.mapX - startX) * eased,
        y: startY + (dest.mapY - startY) * eased - arcLift,
      });
      if (t < 1) {
        raf = requestAnimationFrame(step);
      } else {
        setIsTraveling(false);
      }
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [selectedWorld]);

  const world = STORY_WORLDS[selectedWorld] ?? STORY_WORLDS[0];
  const worldArena = ARENAS.find((a) => a.id === world.arena) ?? ARENAS[0];
  const activeMatch = world.matches[selectedMatch] ?? world.matches[0];
  const activeOpponentAnimal =
    ANIMALS.find((a) => a.id === activeMatch.opponentCustom.animal) ?? ANIMALS[0];
  const activeBall = BALLS.find((b) => b.id === activeMatch.ball) ?? BALLS[0];
  const heroAnimal = ANIMALS.find((a) => a.id === heroCustom.animal) ?? ANIMALS[0];

  const handleChooseWorld = (wIdx: number) => {
    if (!isWorldUnlocked(progress, wIdx)) return;
    setSelectedWorld(wIdx);
    const highestOpen = Math.min(4, progress.highestMatchPerWorld[wIdx] ?? 0);
    setSelectedMatch(highestOpen);
    onSelectNode(wIdx, highestOpen);
  };

  const handleChooseMatch = (mIdx: number) => {
    if (!isMatchUnlocked(progress, selectedWorld, mIdx)) return;
    setSelectedMatch(mIdx);
    onSelectNode(selectedWorld, mIdx);
  };

  const navRootRef = useRef<HTMLDivElement | null>(null);
  useDomFocusNav({ rootRef: navRootRef, onBack });

  // Build smooth SVG path across all 10 worlds
  const trailPath = STORY_WORLDS.map((w, i) => `${i === 0 ? 'M' : 'L'} ${w.mapX} ${w.mapY}`).join(' ');

  return (
    <div
      ref={navRootRef}
      data-testid="story-map-modal"
      className="fixed inset-0 z-30 flex items-center justify-center p-2 sm:p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(12, 32, 68, 0.72)', backdropFilter: 'blur(4px)' }}
    >
      <div className="w-full max-w-6xl max-h-[95vh] rounded-2xl border-2 border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-2xl flex flex-col overflow-hidden">
        {/* Top World Tour Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 sm:px-6 py-2.5 sm:py-3 border-b border-sky-300/40 bg-blue-950/55">
          <div>
            <div className="text-[10px] sm:text-[11px] font-bold uppercase tracking-widest text-amber-300">
              World Tour Challenge · 10 Worlds
            </div>
            <h2 className="font-display font-extrabold text-base sm:text-xl text-white">
              Adventure Map
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            {/* Coin Counter */}
            <div
              data-testid="story-coins"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-400/25 border border-amber-300/60 text-amber-200 text-xs font-extrabold font-mono-num"
            >
              <Coins className="w-4 h-4 text-amber-300" />
              {progress.coins}
            </div>

            {/* Trophies Button */}
            <button
              type="button"
              data-testid="story-open-trophies"
              onClick={onOpenTrophies}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sky-500/35 hover:bg-sky-400/45 text-amber-200 text-xs font-bold cursor-pointer border border-sky-300/45"
            >
              <Award className="w-4 h-4 text-amber-300" />
              Trophies ({progress.unlockedTrophies.length}/10)
            </button>

            {/* Customize Hero */}
            <button
              type="button"
              onClick={onOpenCharacterLocker}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sky-500/35 hover:bg-sky-400/45 text-white text-xs font-bold cursor-pointer border border-sky-300/45"
            >
              <UserCheck className="w-4 h-4 text-sky-200" />
              Hero Outfit
            </button>

            {progress.championEndingCleared && onReplayEnding && (
              <button
                type="button"
                onClick={onReplayEnding}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold cursor-pointer border border-amber-200"
              >
                <Crown className="w-4 h-4" />
                Finals Credits
              </button>
            )}

            <button
              type="button"
              data-testid="story-map-back"
              onClick={onBack}
              className="px-3 py-1 rounded-lg bg-sky-500/35 hover:bg-sky-400/45 border border-sky-300/50 text-white text-xs font-bold cursor-pointer"
            >
              Main Menu
            </button>
          </div>
        </div>

        {/* Main Adventure Layout: Side-by-side on horizontal sm+ screens */}
        <div className="flex-1 overflow-y-auto custom-scroll p-2.5 sm:p-4 grid grid-cols-1 sm:grid-cols-12 gap-3">
          {/* Left: Illustrated Adventure Map (7 cols) */}
          <div className="sm:col-span-7 flex flex-col gap-2.5">
            <div className="relative rounded-2xl border-2 border-sky-300/50 bg-gradient-to-b from-sky-500/30 to-blue-900/60 overflow-hidden p-1.5">
              <svg
                viewBox="0 0 1000 460"
                className="w-full h-auto select-none"
                role="img"
                aria-label="10-World Adventure Map"
              >
                <defs>
                  <linearGradient id="seaBg" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#0284c7" />
                    <stop offset="100%" stopColor="#0369a1" />
                  </linearGradient>
                </defs>
                <rect x="0" y="0" width="1000" height="460" rx="18" fill="url(#seaBg)" />

                {/* Bright Decorative Continent / Island Blobs behind Worlds */}
                <ellipse cx="140" cy="310" rx="125" ry="95" fill="#22c55e" opacity="0.45" />
                <ellipse cx="320" cy="175" rx="125" ry="88" fill="#38bdf8" opacity="0.45" />
                <ellipse cx="520" cy="190" rx="135" ry="100" fill="#a855f7" opacity="0.35" />
                <ellipse cx="730" cy="235" rx="130" ry="110" fill="#6366f1" opacity="0.42" />
                <ellipse cx="900" cy="280" rx="95" ry="135" fill="#eab308" opacity="0.42" />

                {/* Dashed Unexplored Path */}
                <path
                  d={trailPath}
                  fill="none"
                  stroke="#bae6fd"
                  strokeOpacity="0.45"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray="14 14"
                />

                {/* Unlocked Golden Road Progress */}
                <path
                  d={STORY_WORLDS.slice(0, progress.highestWorldUnlocked + 1)
                    .map((w, i) => `${i === 0 ? 'M' : 'L'} ${w.mapX} ${w.mapY}`)
                    .join(' ')}
                  fill="none"
                  stroke="#fde047"
                  strokeWidth="7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  opacity="0.95"
                />

                {/* World Map Nodes */}
                {STORY_WORLDS.map((w) => {
                  const unlocked = isWorldUnlocked(progress, w.worldIndex);
                  const cleared = isWorldCleared(progress, w.worldIndex);
                  const isCurrent = selectedWorld === w.worldIndex;

                  return (
                    <g
                      key={w.worldIndex}
                      onClick={() => handleChooseWorld(w.worldIndex)}
                      className={unlocked ? 'cursor-pointer' : 'cursor-not-allowed'}
                      data-testid={`world-node-${w.worldNumber}`}
                    >
                      {isCurrent && (
                        <circle
                          cx={w.mapX}
                          cy={w.mapY}
                          r="31"
                          fill="none"
                          stroke="#fde047"
                          strokeWidth="4"
                          opacity="0.95"
                        />
                      )}

                      <circle
                        cx={w.mapX}
                        cy={w.mapY}
                        r="23"
                        fill={unlocked ? w.themeColor : '#1e3a8a'}
                        stroke={cleared ? '#fde047' : unlocked ? '#ffffff' : '#60a5fa'}
                        strokeWidth={isCurrent ? '4' : '2.5'}
                      />

                      <text
                        x={w.mapX}
                        y={w.mapY + 5}
                        textAnchor="middle"
                        fill={unlocked ? '#0f172a' : '#bae6fd'}
                        fontWeight="900"
                        fontSize="16"
                      >
                        {w.worldNumber}
                      </text>

                      {cleared && (
                        <g transform={`translate(${w.mapX + 14}, ${w.mapY - 28})`}>
                          <rect x="0" y="0" width="3" height="20" fill="#ffffff" />
                          <polygon points="3,0 19,5 3,11" fill="#fde047" />
                        </g>
                      )}

                      {!unlocked && (
                        <g transform={`translate(${w.mapX + 12}, ${w.mapY - 24})`}>
                          <circle cx="8" cy="8" r="9" fill="#1e3a8a" stroke="#93c5fd" strokeWidth="1.5" />
                          <rect x="4" y="7" width="8" height="6" rx="1.5" fill="#e0f2fe" />
                          <path d="M5.5 7 V5 A2.5 2.5 0 0 1 10.5 5 V7" fill="none" stroke="#e0f2fe" strokeWidth="1.5" />
                        </g>
                      )}

                      <rect
                        x={w.mapX - 54}
                        y={w.mapY + 29}
                        width="108"
                        height="20"
                        rx="6"
                        fill={isCurrent ? '#facc15' : '#1e3a8a'}
                        fillOpacity="0.94"
                        stroke={unlocked ? 'rgba(255,255,255,0.45)' : 'rgba(147,197,253,0.28)'}
                      />
                      <text
                        x={w.mapX}
                        y={w.mapY + 42}
                        textAnchor="middle"
                        fill={isCurrent ? '#0f172a' : unlocked ? '#ffffff' : '#93c5fd'}
                        fontWeight="800"
                        fontSize="10.5"
                      >
                        {w.name}
                      </text>
                    </g>
                  );
                })}

                {/* Animated Traveling Hero Marker */}
                <g
                  transform={`translate(${heroPos.x}, ${heroPos.y - 36})`}
                  style={{ pointerEvents: 'none' }}
                  data-testid="story-hero-marker"
                >
                  <circle cx="0" cy="0" r="17" fill="#dc2626" stroke="#fde047" strokeWidth="3" />
                  <circle cx="0" cy="-2" r="8.5" fill={heroAnimal.bodyColor} />
                  <circle cx="-3" cy="-3" r="1.5" fill="#0f172a" />
                  <circle cx="3" cy="-3" r="1.5" fill="#0f172a" />
                  <polygon points="-5,14 5,14 0,22" fill="#fde047" />
                </g>
              </svg>

              {isTraveling && (
                <div className="absolute top-3 left-3 px-3 py-1 rounded-lg bg-amber-400 text-slate-950 text-xs font-extrabold shadow">
                  Traveling to {world.name}...
                </div>
              )}
            </div>

            {/* Quick World Selector Strip */}
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
              {STORY_WORLDS.map((w) => {
                const unlocked = isWorldUnlocked(progress, w.worldIndex);
                const cleared = isWorldCleared(progress, w.worldIndex);
                const active = selectedWorld === w.worldIndex;
                return (
                  <button
                    key={w.worldIndex}
                    type="button"
                    disabled={!unlocked}
                    onClick={() => handleChooseWorld(w.worldIndex)}
                    className={`py-1.5 px-1 rounded-lg text-[11px] font-extrabold border flex flex-col items-center gap-0.5 transition-colors ${
                      !unlocked
                        ? 'bg-blue-950/60 border-sky-300/20 text-sky-300/45 cursor-not-allowed'
                        : active
                          ? 'bg-amber-400 text-slate-950 border-amber-200 cursor-pointer'
                          : 'bg-blue-900/75 text-white border-sky-300/40 hover:bg-blue-800/80 cursor-pointer'
                    }`}
                  >
                    <span>W{w.worldNumber}</span>
                    {cleared ? (
                      <Flag className="w-3 h-3 text-emerald-300" />
                    ) : !unlocked ? (
                      <Lock className="w-3 h-3 opacity-65" />
                    ) : (
                      <span className="text-[9px] opacity-90">
                        {Math.min(5, progress.highestMatchPerWorld[w.worldIndex] ?? 0)}/5
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Selected World & 5 Match Nodes (5 cols) */}
          <div className="sm:col-span-5 flex flex-col gap-2">
            {/* World Arena Header Card */}
            <div className="rounded-xl p-2.5 bg-blue-900/65 border border-sky-300/40">
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
                    World {world.worldNumber} · {worldArena.name}
                  </div>
                  <div className="font-display font-extrabold text-base sm:text-lg text-white leading-tight">
                    {world.name}
                  </div>
                  <div className="text-[11px] text-sky-100">{world.subtitle}</div>
                </div>
                {isWorldCleared(progress, world.worldIndex) && (
                  <span className="px-2.5 py-0.5 rounded-lg bg-emerald-400/25 border border-emerald-300/60 text-emerald-200 text-[10px] font-extrabold">
                    CLEARED
                  </span>
                )}
              </div>
              <ArenaPreviewIcon arena={worldArena} className="w-full h-10 rounded-lg" />
            </div>

            {/* 5 Matches List */}
            <div className="rounded-xl p-2 bg-blue-900/65 border border-sky-300/40 space-y-1.5">
              <div className="text-[10px] font-bold uppercase tracking-wider text-sky-100 px-1">
                World Challengers (5 Stages)
              </div>
              {world.matches.map((m) => {
                const unlocked = isMatchUnlocked(progress, world.worldIndex, m.matchIndex);
                const cleared = isMatchCompleted(progress, world.worldIndex, m.matchIndex);
                const selected = selectedMatch === m.matchIndex;
                const oppAnimal = ANIMALS.find((a) => a.id === m.opponentCustom.animal) ?? ANIMALS[0];
                const mBall = BALLS.find((b) => b.id === m.ball) ?? BALLS[0];
                return (
                  <button
                    key={m.matchIndex}
                    type="button"
                    data-testid={`story-match-node-${m.matchIndex + 1}`}
                    disabled={!unlocked}
                    onClick={() => handleChooseMatch(m.matchIndex)}
                    className={`w-full px-2.5 py-1.5 rounded-xl border text-left flex items-center justify-between gap-2 transition-colors ${
                      !unlocked
                        ? 'bg-blue-950/60 border-sky-300/20 text-sky-200/45 cursor-not-allowed opacity-75'
                        : selected
                          ? m.isBoss
                            ? 'bg-rose-500/35 border-rose-300 text-white cursor-pointer'
                            : 'bg-amber-400/30 border-amber-300 text-white cursor-pointer'
                          : 'bg-blue-950/55 border-sky-300/35 text-white hover:bg-blue-800/70 cursor-pointer'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <AnimalIcon animal={oppAnimal} className="w-8 h-8 shrink-0" />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-extrabold text-amber-300">
                            {m.matchIndex + 1}. {m.rank}
                          </span>
                          {m.isBoss && <Crown className="w-3 h-3 text-amber-300 shrink-0" />}
                        </div>
                        <div className="text-xs font-bold truncate">{m.opponentName}</div>
                        <div className="text-[10px] text-sky-100 truncate">
                          {mBall.name} · +{m.reward.coins} Coins
                          {m.bossStyleLabel ? ` · ${m.bossStyleLabel}` : ''}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <BallPreviewIcon ball={mBall} className="w-6 h-6" />
                      {cleared ? (
                        <span className="w-5 h-5 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </span>
                      ) : !unlocked ? (
                        <Lock className="w-3.5 h-3.5 text-sky-200/60" />
                      ) : null}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Match Summary + Launch CTA */}
            <div className="rounded-xl p-2.5 bg-blue-950/65 border border-amber-300/50 flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <AnimalIcon animal={activeOpponentAnimal} className="w-9 h-9 shrink-0" />
                  <div className="min-w-0">
                    <div className="text-[10px] font-bold uppercase text-amber-300">
                      {activeMatch.isBoss ? 'BOSS CHAMPION DUEL' : `Stage ${activeMatch.matchIndex + 1} · ${activeMatch.rank}`}
                    </div>
                    <div className="font-display font-extrabold text-sm text-white truncate">
                      vs {activeMatch.opponentName}
                    </div>
                    <div className="text-[10px] text-sky-100 truncate">
                      Ball: {activeBall.name} · 2 Halves (2:00)
                    </div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-[10px] uppercase text-sky-100 font-bold">Reward</div>
                  <div className="text-xs font-extrabold text-amber-300">+{activeMatch.reward.coins} Coins</div>
                  {activeMatch.reward.trophyName && (
                    <div className="text-[10px] text-emerald-300 font-bold">+ World Trophy</div>
                  )}
                </div>
              </div>

              <button
                type="button"
                data-testid="story-challenge-btn"
                onClick={() => onChallengeMatch(selectedWorld, selectedMatch)}
                className={`w-full py-2 rounded-xl font-display font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95 border-2 ${
                  activeMatch.isBoss
                    ? 'bg-gradient-to-r from-amber-300 via-orange-400 to-rose-400 border-amber-100 text-slate-950'
                    : 'bg-emerald-400 hover:bg-emerald-300 border-emerald-100 text-slate-950'
                }`}
              >
                {activeMatch.isBoss ? <Swords className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                {isMatchCompleted(progress, selectedWorld, selectedMatch)
                  ? `Rematch ${activeMatch.opponentName}`
                  : activeMatch.isBoss
                    ? `Challenge Boss: ${activeMatch.opponentName}`
                    : `Challenge ${activeMatch.opponentName}`}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
