import { ControllerStatus } from './ControllerStatus';
import { gamepadManager } from '../game/gamepadManager';
import { useEffect, useRef, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Dices } from 'lucide-react';
import {
  ANIMALS,
  CAPES,
  CLOTHES_STYLES,
  DEFAULT_CONTROL_MAPPING,
  FUR_COLOR_PALETTE,
  HATS,
  MASKS,
  randomNpcCustomization,
  SHOE_STYLES,
} from '../game/catalog';
import { ControlMapping, KeyBindingConfig, MatchConfig, PlayerCustomization, TeamId } from '../game/types';
import { CharacterPreview3D } from './CharacterPreview3D';

type SplitCategory = 'species' | 'clothes' | 'headwear' | 'glasses' | 'shoes' | 'colors' | 'accessories';

const SPLIT_CATEGORIES: Array<{ id: SplitCategory; label: string }> = [
  { id: 'species', label: 'Athlete' },
  { id: 'clothes', label: 'Clothes' },
  { id: 'headwear', label: 'Headwear' },
  { id: 'glasses', label: 'Glasses' },
  { id: 'shoes', label: 'Shoes' },
  { id: 'colors', label: 'Colors' },
  { id: 'accessories', label: 'Accessories' },
];

interface MultiplayerSplitCustomizationProps {
  active: boolean;
  config: MatchConfig;
  controls: ControlMapping;
  onChangeConfig: (next: MatchConfig) => void;
  onBack: () => void;
  onContinue: () => void;
}

type SlotNum = 1 | 2 | 3 | 4;

export function MultiplayerSplitCustomization({
  active,
  config,
  controls,
  onChangeConfig,
  onBack,
  onContinue,
}: MultiplayerSplitCustomizationProps) {
  const playerCount = Math.max(2, Math.min(4, config.localPlayerCount ?? 2)) as 2 | 3 | 4;
  const activeSlots: SlotNum[] = ([1, 2, 3, 4] as SlotNum[]).slice(0, playerCount);

  const [catBySlot, setCatBySlot] = useState<Record<SlotNum, SplitCategory>>({
    1: 'clothes',
    2: 'clothes',
    3: 'clothes',
    4: 'clothes',
  });
  const [readyBySlot, setReadyBySlot] = useState<Record<SlotNum, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false,
  });
  const [yawBySlot, setYawBySlot] = useState<Record<SlotNum, number>>({
    1: 0.36,
    2: -0.36,
    3: 0.36,
    4: -0.36,
  });

  const allReady = activeSlots.every((s) => readyBySlot[s]);

  const configRef = useRef(config);
  const controlsRef = useRef(controls);
  const catRef = useRef(catBySlot);
  const allReadyRef = useRef(allReady);
  configRef.current = config;
  controlsRef.current = controls;
  catRef.current = catBySlot;
  allReadyRef.current = allReady;

  const getSlotCustom = (cfg: MatchConfig, slot: SlotNum): PlayerCustomization => {
    if (slot === 1) return cfg.p1Custom;
    if (slot === 2) return cfg.p2Custom;
    if (slot === 3) return cfg.p3Custom ?? cfg.p1Custom;
    return cfg.p4Custom ?? cfg.p2Custom;
  };

  const getSlotTeam = (cfg: MatchConfig, slot: SlotNum): TeamId => {
    if (slot === 1) return cfg.p1Team;
    if (slot === 2) return cfg.p2Team;
    if (slot === 3) return cfg.p3Team ?? 'red';
    return cfg.p4Team ?? 'blue';
  };

  const updateSlotCustom = (slot: SlotNum, patch: Partial<PlayerCustomization>) => {
    const cfg = configRef.current;
    const nextCustom = { ...getSlotCustom(cfg, slot), ...patch };
    if (slot === 1) onChangeConfig({ ...cfg, p1Custom: nextCustom });
    else if (slot === 2) onChangeConfig({ ...cfg, p2Custom: nextCustom });
    else if (slot === 3) onChangeConfig({ ...cfg, p3Custom: nextCustom });
    else onChangeConfig({ ...cfg, p4Custom: nextCustom });
  };

  const updateSlotTeam = (slot: SlotNum, team: TeamId) => {
    const cfg = configRef.current;
    if (slot === 1) onChangeConfig({ ...cfg, p1Team: team });
    else if (slot === 2) onChangeConfig({ ...cfg, p2Team: team });
    else if (slot === 3) onChangeConfig({ ...cfg, p3Team: team });
    else onChangeConfig({ ...cfg, p4Team: team });
  };

  const stepSlotCategory = (slot: SlotNum, dir: -1 | 1) => {
    setCatBySlot((prev) => {
      const idx = SPLIT_CATEGORIES.findIndex((c) => c.id === prev[slot]);
      const next = SPLIT_CATEGORIES[(idx + dir + SPLIT_CATEGORIES.length) % SPLIT_CATEGORIES.length].id;
      return { ...prev, [slot]: next };
    });
  };

  const stepSlotItem = (slot: SlotNum, dir: -1 | 1) => {
    const cfg = configRef.current;
    const cur = getSlotCustom(cfg, slot);
    const cat = catRef.current[slot];

    if (cat === 'species') {
      const idx = Math.max(0, ANIMALS.findIndex((a) => a.id === cur.animal));
      updateSlotCustom(slot, { animal: ANIMALS[(idx + dir + ANIMALS.length) % ANIMALS.length].id });
    } else if (cat === 'clothes') {
      const idx = Math.max(0, CLOTHES_STYLES.findIndex((c) => c.id === (cur.clothes ?? 'solid')));
      updateSlotCustom(slot, { clothes: CLOTHES_STYLES[(idx + dir + CLOTHES_STYLES.length) % CLOTHES_STYLES.length].id });
    } else if (cat === 'headwear') {
      const idx = Math.max(0, HATS.findIndex((h) => h.id === cur.hat));
      updateSlotCustom(slot, { hat: HATS[(idx + dir + HATS.length) % HATS.length].id });
    } else if (cat === 'glasses') {
      const idx = Math.max(0, MASKS.findIndex((m) => m.id === cur.mask));
      updateSlotCustom(slot, { mask: MASKS[(idx + dir + MASKS.length) % MASKS.length].id });
    } else if (cat === 'shoes') {
      const idx = Math.max(0, SHOE_STYLES.findIndex((s) => s.id === (cur.shoes ?? 'classic_cleats')));
      updateSlotCustom(slot, { shoes: SHOE_STYLES[(idx + dir + SHOE_STYLES.length) % SHOE_STYLES.length].id });
    } else if (cat === 'colors') {
      const idx = Math.max(0, FUR_COLOR_PALETTE.findIndex((f) => f.hex === (cur.furColor ?? '')));
      updateSlotCustom(slot, { furColor: FUR_COLOR_PALETTE[(idx + dir + FUR_COLOR_PALETTE.length) % FUR_COLOR_PALETTE.length].hex });
    } else {
      const idx = Math.max(0, CAPES.findIndex((c) => c.id === cur.cape));
      updateSlotCustom(slot, { cape: CAPES[(idx + dir + CAPES.length) % CAPES.length].id });
    }
  };

  const toggleReady = (slot: SlotNum) => {
    setReadyBySlot((prev) => ({ ...prev, [slot]: !prev[slot] }));
  };

  // Strictly isolated P1..P4 keyboard & per-slot Gamepad 0..3 input listeners
  useEffect(() => {
    if (!active) return;

    const getKeyMap = (slot: SlotNum): KeyBindingConfig => {
      if (slot === 1) return controlsRef.current.p1;
      if (slot === 2) return controlsRef.current.p2;
      if (slot === 3) return controlsRef.current.p3 ?? DEFAULT_CONTROL_MAPPING.p3!;
      return controlsRef.current.p4 ?? DEFAULT_CONTROL_MAPPING.p4!;
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        e.preventDefault();
        onBack();
        return;
      }
      for (const slot of activeSlots) {
        const km = getKeyMap(slot);
        if (e.code === km.up) {
          e.preventDefault();
          stepSlotCategory(slot, -1);
          return;
        }
        if (e.code === km.down) {
          e.preventDefault();
          stepSlotCategory(slot, 1);
          return;
        }
        if (e.code === km.left) {
          e.preventDefault();
          stepSlotItem(slot, -1);
          return;
        }
        if (e.code === km.right) {
          e.preventDefault();
          stepSlotItem(slot, 1);
          return;
        }
        if (e.code === km.kick) {
          e.preventDefault();
          toggleReady(slot);
          return;
        }
        if (e.code === km.headSpinLeft) {
          e.preventDefault();
          updateSlotTeam(slot, getSlotTeam(configRef.current, slot) === 'red' ? 'blue' : 'red');
          return;
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);

    let rafId = 0;
    const prevGpBtns: Record<SlotNum, boolean[]> = { 1: [], 2: [], 3: [], 4: [] };
    const lastStickAt: Record<SlotNum, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };

    const poll = () => {
      const now = performance.now();
      for (const slot of activeSlots) {
        // Tiap player hanya membaca controller yang ditugaskan kepadanya
        const gp = gamepadManager.getStd(slot as 1 | 2 | 3 | 4);
        if (!gp) {
          prevGpBtns[slot] = [];
          continue;
        }
        const prev = prevGpBtns[slot];
        const edge = (idx: number) => !!gp.buttons[idx]?.pressed && !prev[idx];

        if (edge(0)) toggleReady(slot); // A -> Toggle THIS player's Ready ONLY
        else if (edge(1)) {
          if (slot === 1 && !readyBySlot[1]) onBack();
          else setReadyBySlot((r) => ({ ...r, [slot]: false }));
        } else if (edge(4)) stepSlotCategory(slot, -1); // LB
        else if (edge(5)) stepSlotCategory(slot, 1); // RB
        else if (edge(3)) updateSlotTeam(slot, getSlotTeam(configRef.current, slot) === 'red' ? 'blue' : 'red'); // Y swaps team
        else if (edge(9) && allReadyRef.current) onContinue(); // START only when ALL ready

        const axX = gp.axes[0] || 0;
        const axY = gp.axes[1] || 0;
        if (edge(12)) stepSlotCategory(slot, -1);
        else if (edge(13)) stepSlotCategory(slot, 1);
        else if (edge(14)) stepSlotItem(slot, -1);
        else if (edge(15)) stepSlotItem(slot, 1);
        else if (now - lastStickAt[slot] > 230) {
          if (axY < -0.6) {
            stepSlotCategory(slot, -1);
            lastStickAt[slot] = now;
          } else if (axY > 0.6) {
            stepSlotCategory(slot, 1);
            lastStickAt[slot] = now;
          } else if (axX < -0.6) {
            stepSlotItem(slot, -1);
            lastStickAt[slot] = now;
          } else if (axX > 0.6) {
            stepSlotItem(slot, 1);
            lastStickAt[slot] = now;
          }
        }

        const rx = gp.axes[2] || 0;
        if (Math.abs(rx) > 0.2) {
          setYawBySlot((prevY) => ({ ...prevY, [slot]: prevY[slot] + rx * 0.055 }));
        }

        prevGpBtns[slot] = gp.buttons.map((b) => !!b.pressed);
      }
      rafId = requestAnimationFrame(poll);
    };
    rafId = requestAnimationFrame(poll);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      cancelAnimationFrame(rafId);
    };
  }, [active, playerCount, onBack, onContinue]);

  const currentItemLabel = (slot: SlotNum): string => {
    const cur = getSlotCustom(config, slot);
    const cat = catBySlot[slot];
    if (cat === 'species') return ANIMALS.find((a) => a.id === cur.animal)?.name ?? 'Alpaca';
    if (cat === 'clothes') return CLOTHES_STYLES.find((c) => c.id === (cur.clothes ?? 'solid'))?.name ?? 'Plain Solid';
    if (cat === 'headwear') return HATS.find((h) => h.id === cur.hat)?.name ?? 'No Hat';
    if (cat === 'glasses') return MASKS.find((m) => m.id === cur.mask)?.name ?? 'No Mask';
    if (cat === 'shoes') return SHOE_STYLES.find((s) => s.id === (cur.shoes ?? 'classic_cleats'))?.name ?? 'Classic Cleats';
    if (cat === 'colors') return FUR_COLOR_PALETTE.find((f) => f.hex === (cur.furColor ?? ''))?.name ?? 'Default Fur';
    return CAPES.find((c) => c.id === cur.cape)?.name ?? 'No Cape';
  };

  return (
    <div
      data-testid="multiplayer-split-screen"
      className="fixed inset-0 z-30 flex items-center justify-center p-2 sm:p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(12, 32, 68, 0.72)', backdropFilter: 'blur(4px)' }}
    >
      <div className="w-full max-w-7xl h-[96vh] sm:h-[95vh] rounded-2xl border-2 border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 sm:px-6 py-2.5 sm:py-3 border-b border-sky-300/40 bg-blue-950/55">
          <div>
            <div className="text-[10px] sm:text-[11px] font-bold uppercase tracking-[0.22em] text-amber-300">
              STEP 02 · {playerCount}P SPLIT CUSTOMIZATION
            </div>
            <h2 className="font-display font-extrabold text-base sm:text-xl text-white">
              LOCAL MULTIPLAYER CUSTOMIZATION
            </h2>
            <ControllerStatus compact />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-sky-100 px-3 py-1 rounded-lg bg-blue-900/75 border border-sky-300/35">
              {activeSlots.filter((s) => readyBySlot[s]).length} / {playerCount} READY
            </span>
            <button
              type="button"
              data-testid="split-back-btn"
              onClick={onBack}
              className="px-3.5 py-1.5 rounded-lg bg-sky-500/35 hover:bg-sky-400/45 border border-sky-300/50 text-white text-xs font-bold cursor-pointer"
            >
              B : Back
            </button>
          </div>
        </div>

        {/* 50:50 (2P) or 4-Column (3P/4P) Horizontal Split Grid */}
        <div
          className={`flex-1 min-h-0 overflow-hidden p-2 sm:p-3 grid gap-2 sm:gap-3 grid-cols-2 ${
            playerCount === 2 ? 'grid-rows-1' : 'grid-rows-2'
          }`}
        >
          {activeSlots.map((slot) => {
            const team = getSlotTeam(config, slot);
            const custom = getSlotCustom(config, slot);
            const cat = catBySlot[slot];
            const isReady = readyBySlot[slot];
            const km =
              slot === 1
                ? controls.p1
                : slot === 2
                  ? controls.p2
                  : slot === 3
                    ? (controls.p3 ?? DEFAULT_CONTROL_MAPPING.p3!)
                    : (controls.p4 ?? DEFAULT_CONTROL_MAPPING.p4!);

            return (
              <section
                key={slot}
                data-testid={`split-panel-p${slot}`}
                className={`min-h-0 overflow-y-auto custom-scroll rounded-2xl p-2 sm:p-3 border-2 flex flex-col gap-1.5 sm:gap-2 transition-colors ${
                  isReady
                    ? 'bg-emerald-700/45 border-emerald-300'
                    : team === 'red'
                      ? 'bg-blue-900/65 border-rose-400/70'
                      : 'bg-blue-900/65 border-sky-300/70'
                }`}
              >
                {/* Player Slot Header + Input Badge */}
                <div className="flex items-center justify-between gap-1.5">
                  <div className="min-w-0">
                    <div className="font-display font-extrabold text-sm sm:text-base text-white">
                      PLAYER {slot}
                    </div>
                    <div className="text-[10px] font-mono-num text-sky-100 truncate">
                      Pad {slot} · {km.left}/{km.right} · {km.kick}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => updateSlotTeam(slot, 'red')}
                      className={`px-2 py-1 rounded text-[10px] font-extrabold cursor-pointer ${
                        team === 'red'
                          ? 'bg-rose-500 text-white border border-rose-200'
                          : 'bg-blue-950/70 text-sky-100 border border-sky-300/30'
                      }`}
                    >
                      RED
                    </button>
                    <button
                      type="button"
                      onClick={() => updateSlotTeam(slot, 'blue')}
                      className={`px-2 py-1 rounded text-[10px] font-extrabold cursor-pointer ${
                        team === 'blue'
                          ? 'bg-sky-400 text-slate-950 border border-white'
                          : 'bg-blue-950/70 text-sky-100 border border-sky-300/30'
                      }`}
                    >
                      BLUE
                    </button>
                    <button
                      type="button"
                      aria-label={`Randomize Player ${slot}`}
                      onClick={() => updateSlotCustom(slot, randomNpcCustomization(Math.floor(Math.random() * 10000)))}
                      className="p-1.5 rounded bg-blue-950/70 hover:bg-blue-800 border border-sky-300/35 text-amber-300 cursor-pointer"
                    >
                      <Dices className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Independent 3D Character Viewport */}
                <div className={`flex-1 shrink-0 ${playerCount === 2 ? 'min-h-[90px]' : 'min-h-[64px]'}`}>
                  <CharacterPreview3D
                    team={team}
                    custom={custom}
                    facingYaw={yawBySlot[slot]}
                    spinEnabled={false}
                    compact={playerCount >= 3}
                    dragRotate={true}
                    onYawChange={(y) => setYawBySlot((prev) => ({ ...prev, [slot]: y }))}
                  />
                </div>

                {/* Category Stepper */}
                <div className="flex items-center justify-between gap-2 rounded-xl px-2 py-1.5 bg-blue-950/60 border border-sky-300/35">
                  <button
                    type="button"
                    aria-label={`Player ${slot} Previous Category`}
                    data-testid={`split-p${slot}-cat-prev`}
                    onClick={() => stepSlotCategory(slot, -1)}
                    className="p-1 rounded-lg bg-sky-500/30 hover:bg-sky-400/45 border border-sky-300/40 text-white cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <div className="text-center min-w-0">
                    <div className="text-[9px] font-bold uppercase tracking-wider text-sky-100">
                      Category
                    </div>
                    <div className="text-xs font-extrabold text-amber-300 uppercase">
                      {SPLIT_CATEGORIES.find((c) => c.id === cat)?.label}
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label={`Player ${slot} Next Category`}
                    data-testid={`split-p${slot}-cat-next`}
                    onClick={() => stepSlotCategory(slot, 1)}
                    className="p-1 rounded-lg bg-sky-500/30 hover:bg-sky-400/45 border border-sky-300/40 text-white cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Item Option Stepper */}
                <div className="flex items-center justify-between gap-2 rounded-xl px-2 py-1.5 bg-blue-950/60 border border-sky-300/35">
                  <button
                    type="button"
                    aria-label={`Player ${slot} Previous Option`}
                    data-testid={`split-p${slot}-item-prev`}
                    onClick={() => stepSlotItem(slot, -1)}
                    className="p-1 rounded-lg bg-sky-500/30 hover:bg-sky-400/45 border border-sky-300/40 text-white cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <div className="text-center min-w-0 flex-1">
                    <div
                      data-testid={`split-p${slot}-item-label`}
                      className="text-xs sm:text-sm font-bold text-white truncate"
                    >
                      {currentItemLabel(slot)}
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label={`Player ${slot} Next Option`}
                    data-testid={`split-p${slot}-item-next`}
                    onClick={() => stepSlotItem(slot, 1)}
                    className="p-1 rounded-lg bg-sky-500/30 hover:bg-sky-400/45 border border-sky-300/40 text-white cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Independent READY Toggle */}
                <button
                  type="button"
                  data-testid={`ready-btn-p${slot}`}
                  data-ready={isReady ? 'true' : 'false'}
                  onClick={() => toggleReady(slot)}
                  className={`mt-auto w-full py-2 rounded-xl font-display font-extrabold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-1.5 cursor-pointer ${
                    isReady
                      ? 'bg-emerald-400 text-slate-950 border-2 border-emerald-100'
                      : 'bg-sky-500/35 hover:bg-sky-400/45 text-white border border-sky-300/50'
                  }`}
                >
                  {isReady && <Check className="w-4 h-4" />}
                  {isReady ? 'READY' : `PLAYER ${slot} READY`}
                </button>
              </section>
            );
          })}
        </div>

        {/* Footer Action Bar */}
        <div className="px-4 sm:px-6 py-2.5 sm:py-3 border-t border-sky-300/40 bg-blue-950/60 flex flex-wrap items-center justify-between gap-2">
          <div className="hidden sm:block text-[11px] font-bold text-sky-100">
            UP/DOWN: CATEGORY · LEFT/RIGHT: OPTION · EACH CONTROLLER &amp; KEY SET IS INDEPENDENT
          </div>

          <button
            type="button"
            data-testid="split-continue-btn"
            disabled={!allReady}
            onClick={onContinue}
            className={`px-6 py-2 rounded-xl font-display font-extrabold text-xs sm:text-sm tracking-wide ${
              allReady
                ? 'bg-emerald-400 hover:bg-emerald-300 border-2 border-emerald-100 text-slate-950 cursor-pointer shadow'
                : 'bg-blue-950/75 text-sky-200/60 border border-sky-300/25 cursor-not-allowed'
            }`}
          >
            {allReady ? 'START : MATCH PREVIEW' : 'ALL PLAYERS MUST BE READY'}
          </button>
        </div>
      </div>
    </div>
  );
}
