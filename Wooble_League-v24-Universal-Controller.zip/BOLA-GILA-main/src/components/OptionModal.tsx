import { useRef, useState } from 'react';
import { useDomFocusNav } from '../hooks/useDomFocusNav';
import { Gamepad2, Globe, Move, Sliders, Volume2, VolumeX } from 'lucide-react';
import { DEFAULT_GAME_OPTIONS, DEFAULT_VIRTUAL_LAYOUT } from '../game/catalog';
import { AppLanguage, ButtonSkinId, ControlMapping, GameOptions, VirtualPadVisibility } from '../game/types';
import { useT } from '../game/i18n';
import { ControlMappingPanel } from './ControlMappingModal';
import { VirtualLayoutEditorModal } from './VirtualLayoutEditorModal';
import { DashIcon, GrabIcon, HeadSpinIcon, JumpIcon, KickIcon, SpinKickIcon } from './ButtonIcons';

interface OptionModalProps {
  options: GameOptions;
  controls: ControlMapping;
  onChangeOptions: (next: GameOptions) => void;
  onChangeControls: (next: ControlMapping) => void;
  onClose: () => void;
}

function SkinMiniPreview({ skin }: { skin: ButtonSkinId }) {
  if (skin === 'icons' || skin === 'icons_clear') {
    const clear = skin === 'icons_clear';
    const items: Array<{ key: string; Icon: typeof KickIcon; tone: string }> = [
      { key: 'L', Icon: HeadSpinIcon, tone: 'from-violet-400 to-violet-600' },
      { key: 'R', Icon: DashIcon, tone: 'from-violet-400 to-violet-600' },
      { key: 'A', Icon: KickIcon, tone: 'from-red-400 to-red-600' },
      { key: 'X', Icon: SpinKickIcon, tone: 'from-sky-400 to-blue-600' },
      { key: 'B', Icon: JumpIcon, tone: 'from-amber-300 to-amber-500' },
      { key: 'Y', Icon: GrabIcon, tone: 'from-emerald-400 to-emerald-600' },
    ];
    return (
      <div className="flex flex-wrap items-center gap-1.5 px-2.5 py-2 rounded-lg bg-emerald-600/80 border border-white/40">
        {items.map(({ key, Icon, tone }) => (
          <span
            key={key}
            className={`w-7 h-7 rounded-full flex items-center justify-center text-white ${
              clear
                ? 'border-2 border-white/90 bg-slate-950/25'
                : `border-2 border-white/90 bg-gradient-to-b ${tone} shadow-[0_2px_0_rgba(15,23,42,0.8)]`
            }`}
          >
            <Icon className="w-4 h-4" />
          </span>
        ))}
      </div>
    );
  }
  if (skin === 'transparent') {
    return (
      <div className="flex flex-wrap items-center gap-1.5 px-2.5 py-2 rounded-lg bg-emerald-600/80 border border-white/40">
        {['L', 'R', 'A', 'X', 'B', 'Y'].map((letter) => (
          <span
            key={letter}
            className="w-6 h-6 rounded-full border-2 border-white bg-transparent text-white font-display font-extrabold text-[9px] flex items-center justify-center"
          >
            {letter}
          </span>
        ))}
      </div>
    );
  }
  return (
    <div className="flex flex-wrap items-center gap-1.5 px-2.5 py-2 rounded-lg bg-emerald-600/80 border border-white/40">
      <span className="w-6 h-5 rounded-t-md rounded-b-sm border-2 border-slate-950 bg-slate-200 text-slate-950 font-display font-extrabold text-[10px] flex items-center justify-center">
        L
      </span>
      <span className="w-6 h-5 rounded-t-md rounded-b-sm border-2 border-slate-950 bg-slate-200 text-slate-950 font-display font-extrabold text-[10px] flex items-center justify-center">
        R
      </span>
      <span className="w-6 h-6 rounded-full border-2 border-slate-950 bg-red-500 text-white font-display font-extrabold text-[10px] flex items-center justify-center">
        A
      </span>
      <span className="w-6 h-6 rounded-full border-2 border-slate-950 bg-blue-500 text-white font-display font-extrabold text-[10px] flex items-center justify-center">
        X
      </span>
      <span className="w-6 h-6 rounded-full border-2 border-slate-950 bg-amber-400 text-slate-950 font-display font-extrabold text-[10px] flex items-center justify-center">
        B
      </span>
      <span className="w-6 h-6 rounded-full border-2 border-slate-950 bg-emerald-500 text-white font-display font-extrabold text-[10px] flex items-center justify-center">
        Y
      </span>
    </div>
  );
}

export function OptionModal({
  options,
  controls,
  onChangeOptions,
  onChangeControls,
  onClose,
}: OptionModalProps) {
  const t = useT();
  const [tab, setTab] = useState<'general' | 'mapping'>('general');
  const [editingLayout, setEditingLayout] = useState(false);
  const navRootRef = useRef<HTMLDivElement | null>(null);
  useDomFocusNav({
    rootRef: navRootRef,
    active: !editingLayout,
    onBack: onClose,
    onBumper: (dir) => setTab((t) => (dir > 0 ? (t === 'general' ? 'mapping' : 'general') : t === 'mapping' ? 'general' : 'mapping')),
  });

  const updateOpt = <K extends keyof GameOptions>(key: K, val: GameOptions[K]) => {
    onChangeOptions({ ...options, [key]: val });
  };

  if (editingLayout) {
    return (
      <VirtualLayoutEditorModal
        layout={options.virtualLayout ?? DEFAULT_VIRTUAL_LAYOUT}
        buttonSkin={options.buttonSkin}
        onSave={(nextLayout) => {
          onChangeOptions({ ...options, virtualLayout: nextLayout });
          setEditingLayout(false);
        }}
        onClose={() => setEditingLayout(false)}
      />
    );
  }

  return (
    <div
      ref={navRootRef}
      className="fixed inset-0 z-40 flex items-center justify-center p-2.5 sm:p-4 bg-gradient-to-b from-sky-500/75 via-sky-300/45 to-emerald-500/45 backdrop-blur-sm pointer-events-auto"
      data-testid="options-modal"
    >
      <div className="w-full max-w-xl rounded-2xl border-[3px] border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-[0_16px_42px_rgba(2,132,199,0.5)] overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header + Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 border-b border-sky-300/35 bg-blue-900/45">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-300" />
            <h2 className="font-display font-extrabold text-lg sm:text-xl text-white tracking-wide">
              {t('op.title')}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              data-testid="tab-options-general"
              onClick={() => setTab('general')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer border transition-colors ${
                tab === 'general'
                  ? 'bg-amber-400 text-slate-950 border-amber-200'
                  : 'bg-blue-900/80 text-white border-sky-300/40 hover:bg-blue-800'
              }`}
            >
              {t('op.tabGeneral')}
            </button>
            <button
              type="button"
              data-testid="tab-options-mapping"
              onClick={() => setTab('mapping')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer border transition-colors ${
                tab === 'mapping'
                  ? 'bg-amber-400 text-slate-950 border-amber-200'
                  : 'bg-blue-900/80 text-white border-sky-300/40 hover:bg-blue-800'
              }`}
            >
              {t('op.tabMapping')}
            </button>
          </div>
        </div>

        {/* Scrollable Body (satu kolom agar rapi) */}
        <div className="p-4 sm:p-5 overflow-y-auto custom-scroll">
          {tab === 'general' ? (
            <div className="flex flex-col gap-5">
              {/* Bahasa */}
              <section className="space-y-2" data-testid="language-section">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-amber-300" />
                  <h3 className="font-display font-extrabold text-xs uppercase tracking-wider text-sky-100">
                    {t('op.language')}
                  </h3>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { id: 'en', label: 'English' },
                      { id: 'id', label: 'Bahasa Indonesia' },
                    ] as Array<{ id: AppLanguage; label: string }>
                  ).map((lng) => (
                    <button
                      key={lng.id}
                      type="button"
                      data-testid={`lang-${lng.id}`}
                      onClick={() => updateOpt('language', lng.id)}
                      className={`py-2.5 px-2 rounded-xl border-2 text-xs font-extrabold cursor-pointer transition-colors ${
                        (options.language ?? 'en') === lng.id
                          ? 'bg-amber-400 text-slate-950 border-amber-200'
                          : 'bg-blue-950/55 text-white border-sky-300/35 hover:bg-blue-800'
                      }`}
                    >
                      {lng.label}
                    </button>
                  ))}
                </div>
              </section>

              {/* Button Skin + Virtual Pad Mode + Custom Layout */}
              <div className="space-y-5">
                <section className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Gamepad2 className="w-4 h-4 text-amber-300" />
                    <h3 className="font-display font-extrabold text-xs uppercase tracking-wider text-sky-100">
                      {t('op.skin')}
                    </h3>
                  </div>
                  <div className="flex flex-col gap-2.5">
                    {(
                      [
                        { id: 'nintendo', label: 'Classic' },
                        { id: 'transparent', label: 'Transparent' },
                        { id: 'icons', label: 'Icon Solid' },
                        { id: 'icons_clear', label: 'Icon Clear' },
                      ] as Array<{ id: ButtonSkinId; label: string }>
                    ).map((skin) => (
                      <button
                        key={skin.id}
                        type="button"
                        data-testid={`skin-${skin.id === 'icons_clear' ? 'icons-clear' : skin.id}`}
                        onClick={() => updateOpt('buttonSkin', skin.id)}
                        className={`p-2.5 rounded-xl border-2 text-left transition-colors cursor-pointer flex items-center justify-between gap-3 ${
                          options.buttonSkin === skin.id
                            ? 'bg-sky-400/35 border-amber-300'
                            : 'bg-blue-950/55 border-sky-300/35 hover:border-sky-200'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-xs text-white">{t(`op.skin.${skin.id}`)}</span>
                          {options.buttonSkin === skin.id && (
                            <span className="text-[10px] font-extrabold text-amber-300">ON</span>
                          )}
                        </div>
                        <SkinMiniPreview skin={skin.id} />
                      </button>
                    ))}
                  </div>
                </section>

                <section className="space-y-2">
                  <h3 className="font-display font-extrabold text-xs uppercase tracking-wider text-sky-100">
                    {t('op.vpad')}
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        { id: 'auto', label: 'op.vpad.auto' },
                        { id: 'on', label: 'op.vpad.on' },
                        { id: 'off', label: 'op.vpad.off' },
                      ] as Array<{ id: VirtualPadVisibility; label: string }>
                    ).map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        data-testid={`vpad-mode-${item.id}`}
                        onClick={() => updateOpt('virtualPadMode', item.id)}
                        className={`py-2 px-2 rounded-xl border text-xs font-extrabold cursor-pointer transition-colors ${
                          options.virtualPadMode === item.id
                            ? 'bg-amber-400 text-slate-950 border-amber-200'
                            : 'bg-blue-950/55 text-white border-sky-300/35 hover:bg-blue-800'
                        }`}
                      >
                        {t(item.label)}
                      </button>
                    ))}
                  </div>

                  <h3 className="font-display font-extrabold text-xs uppercase tracking-wider text-sky-100 pt-1">
                    {t('op.scorepos')}
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    {(['left', 'center', 'right'] as const).map((pos) => (
                      <button
                        key={pos}
                        type="button"
                        data-testid={`score-pos-${pos}`}
                        onClick={() => updateOpt('scoreHudPos', pos)}
                        className={`py-2 px-2 rounded-xl border text-xs font-extrabold cursor-pointer transition-colors ${
                          (options.scoreHudPos ?? 'center') === pos
                            ? 'bg-amber-400 text-slate-950 border-amber-200'
                            : 'bg-blue-950/55 text-white border-sky-300/35 hover:bg-blue-800'
                        }`}
                      >
                        {t(`op.scorepos.${pos}`)}
                      </button>
                    ))}
                  </div>

                  <h3 className="font-display font-extrabold text-xs uppercase tracking-wider text-sky-100 pt-1">
                    {t('op.scorestyle')}
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    {(['random', 'wood', 'capy', 'esports', 'royal', 'clean'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        data-testid={`score-style-${st}`}
                        onClick={() => updateOpt('scoreHudStyle', st)}
                        className={`py-2 px-1 rounded-xl border text-xs font-extrabold cursor-pointer transition-colors ${
                          (options.scoreHudStyle ?? 'random') === st
                            ? 'bg-amber-400 text-slate-950 border-amber-200'
                            : 'bg-blue-950/55 text-white border-sky-300/35 hover:bg-blue-800'
                        }`}
                      >
                        {t(`op.scorestyle.${st}`)}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    data-testid="open-virtual-layout-editor"
                    onClick={() => setEditingLayout(true)}
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-300 to-amber-400 hover:brightness-105 border-2 border-amber-100 text-slate-950 font-display font-extrabold text-xs tracking-wide flex items-center justify-center gap-2 cursor-pointer shadow"
                  >
                    <Move className="w-4 h-4" />
                    {t('op.layout')}
                  </button>
                </section>
              </div>

              {/* Audio BGM & SFX */}
              <div className="space-y-3">
                <h3 className="font-display font-extrabold text-xs uppercase tracking-wider text-sky-100">
                  {t('op.audio')}
                </h3>

                {/* BGM */}
                <div className="p-3.5 rounded-xl bg-blue-950/55 border-2 border-sky-300/35 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {options.bgmEnabled ? (
                        <Volume2 className="w-4 h-4 text-amber-300" />
                      ) : (
                        <VolumeX className="w-4 h-4 text-sky-300/60" />
                      )}
                      <span className="text-xs sm:text-sm font-bold text-white">{t('op.bgm')}</span>
                    </div>
                    <button
                      type="button"
                      data-testid="toggle-bgm"
                      onClick={() => updateOpt('bgmEnabled', !options.bgmEnabled)}
                      className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer ${
                        options.bgmEnabled ? 'bg-emerald-400 text-slate-950' : 'bg-blue-900 text-sky-200'
                      }`}
                    >
                      {options.bgmEnabled ? t('op.on') : t('op.off')}
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      aria-label="BGM Volume"
                      min={0}
                      max={100}
                      value={Math.round(options.bgmVolume * 100)}
                      onChange={(e) => updateOpt('bgmVolume', Number(e.target.value) / 100)}
                      className="flex-1 accent-amber-400 cursor-pointer"
                    />
                    <span className="w-11 text-right font-mono-num text-xs font-bold text-amber-300">
                      {Math.round(options.bgmVolume * 100)}%
                    </span>
                  </div>
                </div>

                {/* SFX */}
                <div className="p-3.5 rounded-xl bg-blue-950/55 border-2 border-sky-300/35 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {options.sfxEnabled ? (
                        <Volume2 className="w-4 h-4 text-sky-300" />
                      ) : (
                        <VolumeX className="w-4 h-4 text-sky-300/60" />
                      )}
                      <span className="text-xs sm:text-sm font-bold text-white">{t('op.sfx')}</span>
                    </div>
                    <button
                      type="button"
                      data-testid="toggle-sfx"
                      onClick={() => updateOpt('sfxEnabled', !options.sfxEnabled)}
                      className={`px-3 py-1 rounded-lg text-xs font-extrabold cursor-pointer ${
                        options.sfxEnabled ? 'bg-emerald-400 text-slate-950' : 'bg-blue-900 text-sky-200'
                      }`}
                    >
                      {options.sfxEnabled ? t('op.on') : t('op.off')}
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      aria-label="SFX Volume"
                      min={0}
                      max={100}
                      value={Math.round(options.sfxVolume * 100)}
                      onChange={(e) => updateOpt('sfxVolume', Number(e.target.value) / 100)}
                      className="flex-1 accent-sky-300 cursor-pointer"
                    />
                    <span className="w-11 text-right font-mono-num text-xs font-bold text-sky-200">
                      {Math.round(options.sfxVolume * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <ControlMappingPanel mapping={controls} onChange={onChangeControls} />
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-sky-300/35 flex items-center justify-between bg-blue-950/55">
          <button
            type="button"
            onClick={() => onChangeOptions(DEFAULT_GAME_OPTIONS)}
            className="px-4 py-2 rounded-xl bg-blue-800 hover:bg-blue-700 border border-sky-300/40 text-white text-xs font-bold cursor-pointer"
          >
            {t('op.reset')}
          </button>
          <button
            type="button"
            data-testid="options-done"
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 border border-emerald-100 text-slate-950 text-xs font-extrabold cursor-pointer shadow"
          >
            {t('op.done')}
          </button>
        </div>
      </div>
    </div>
  );
}
