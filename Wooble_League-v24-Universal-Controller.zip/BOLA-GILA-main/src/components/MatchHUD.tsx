import { useRef, useState } from 'react';
import { DEFAULT_VIRTUAL_LAYOUT } from '../game/catalog';
import { HudSnapshot, VirtualPadState } from '../game/EngineCanvas';
import { ButtonSkinId, GameMode, ScoreHudStyleId, VirtualLayoutConfig } from '../game/types';
import { WoodScoreboard, pickRandomScoreHudStyle } from './WoodScoreboard';
import { DashIcon, GrabIcon, HeadSpinIcon, JumpIcon, KickIcon, SpinKickIcon, StartBarsIcon } from './ButtonIcons';

type PadTone = 'red' | 'blue' | 'green' | 'amber' | 'violet' | 'slate';

const ICON_TONES: Record<PadTone, string> = {
  red: 'from-red-400 to-red-600',
  blue: 'from-sky-400 to-blue-600',
  green: 'from-emerald-400 to-emerald-600',
  amber: 'from-amber-300 to-amber-500',
  violet: 'from-violet-400 to-violet-600',
  slate: 'from-slate-300 to-slate-500',
};
const CLASSIC_TONES: Record<PadTone, string> = {
  red: 'bg-red-500 active:bg-red-400 text-white',
  blue: 'bg-blue-500 active:bg-blue-400 text-white',
  green: 'bg-emerald-500 active:bg-emerald-400 text-white',
  amber: 'bg-amber-400 active:bg-amber-300 text-slate-950',
  violet: 'bg-slate-200 active:bg-slate-300 text-slate-950',
  slate: 'bg-slate-300 active:bg-slate-400 text-slate-950',
};

/** Kelas tombol sesuai skin. shape: face = bulat ABXY, shoulder = L/R, start = pil START */
export function padButtonClass(skin: ButtonSkinId, shape: 'face' | 'shoulder' | 'start', tone: PadTone): string {
  const size =
    shape === 'face'
      ? 'w-9 h-9 sm:w-12 sm:h-12 rounded-full'
      : shape === 'shoulder'
        ? 'w-12 h-8 sm:w-14 sm:h-9 rounded-2xl'
        : 'h-8 sm:h-9 px-2.5 sm:px-3 rounded-xl gap-1.5';
  const common = 'flex items-center justify-center font-display font-extrabold cursor-pointer touch-none select-none';
  if (skin === 'transparent') {
    return `${size} ${common} bg-slate-950/20 active:bg-white/25 border-[3px] border-white shadow-[0_2px_8px_rgba(0,0,0,0.55)] text-white text-xs sm:text-sm`;
  }
  if (skin === 'icons_clear') {
    return `${size} ${common} bg-slate-950/25 active:bg-white/30 border-[2.5px] border-white/90 shadow-[0_2px_8px_rgba(0,0,0,0.55)] text-white backdrop-blur-[1px]`;
  }
  if (skin === 'icons') {
    return `${size} ${common} bg-gradient-to-b ${ICON_TONES[tone]} active:brightness-90 border-[3px] border-white/90 shadow-[0_3px_0_rgba(15,23,42,0.85),inset_0_2px_3px_rgba(255,255,255,0.55)] text-white drop-shadow`;
  }
  return `${size} ${common} ${CLASSIC_TONES[tone]} border-[3px] border-slate-950 pixel-shadow-sm text-xs sm:text-sm`;
}

interface MatchHUDProps {
  hud: HudSnapshot;
  gameMode?: GameMode;
  showVirtualPad: boolean;
  buttonSkin: ButtonSkinId;
  virtualLayout?: VirtualLayoutConfig;
  scoreHudPos?: 'left' | 'center' | 'right';
  scoreHudStyle?: ScoreHudStyleId;
  virtualPadRef: React.MutableRefObject<VirtualPadState>;
  onToggleMute: () => void;
  onPause: () => void;
  onSkipGoalReplay?: () => void;
}

function formatClock(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${String(m).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

/** 1 -> 1ST, 2 -> 2ND, 3 -> 3RD (golden goal / perpanjangan), dst. */
function ordinalLabel(n: number): string {
  const suffix = n === 1 ? 'ST' : n === 2 ? 'ND' : n === 3 ? 'RD' : 'TH';
  return `${n}${suffix}`;
}

export function MatchHUD({
  hud,
  gameMode,
  showVirtualPad,
  buttonSkin,
  virtualLayout,
  scoreHudPos = 'center',
  scoreHudStyle = 'random',
  virtualPadRef,
  onToggleMute,
  onPause,
  onSkipGoalReplay,
}: MatchHUDProps) {
  // Gaya acak dipilih sekali tiap pertandingan (komponen HUD dibuat ulang saat pertandingan mulai)
  const [randomStyle] = useState(pickRandomScoreHudStyle);
  const resolvedScoreStyle = scoreHudStyle === 'random' ? randomStyle : scoreHudStyle;
  const joyBaseRef = useRef<HTMLDivElement | null>(null);
  const [joyKnob, setJoyKnob] = useState({ x: 0, y: 0 });
  const activePointerId = useRef<number | null>(null);

  const isTransparent = buttonSkin === 'transparent' || buttonSkin === 'icons_clear';
  const isIconSkin = buttonSkin === 'icons' || buttonSkin === 'icons_clear';
  void onToggleMute;
  const vLayout = virtualLayout ?? DEFAULT_VIRTUAL_LAYOUT;

  const updateStick = (clientX: number, clientY: number) => {
    const el = joyBaseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.42;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    setJoyKnob({ x: dx, y: dy });
    virtualPadRef.current.moveX = dx / maxR;
    virtualPadRef.current.moveZ = dy / maxR;
  };

  const resetStick = () => {
    activePointerId.current = null;
    setJoyKnob({ x: 0, y: 0 });
    virtualPadRef.current.moveX = 0;
    virtualPadRef.current.moveZ = 0;
  };

  const bindActionBtn = (
    field: keyof Pick<
      VirtualPadState,
      'kick' | 'kickRightSpin' | 'grabProp' | 'jump' | 'headSpinLeft' | 'dash'
    >
  ) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      virtualPadRef.current[field] = true;
    },
    onPointerUp: () => {
      virtualPadRef.current[field] = false;
    },
    onPointerLeave: () => {
      virtualPadRef.current[field] = false;
    },
    onPointerCancel: () => {
      virtualPadRef.current[field] = false;
    },
  });

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-2.5 sm:p-4 md:p-5">
      {/* Top Row: Compact Pixel Red & Blue Flag Banners + Match Clock */}
      <div
        className="relative w-full flex items-center min-h-[36px]"
        style={{ justifyContent: scoreHudPos === 'left' ? 'flex-start' : scoreHudPos === 'right' ? 'flex-end' : 'center' }}
      >
        {!hud.isGoalReplay && (
        <WoodScoreboard
          redScore={hud.redScore}
          blueScore={hud.blueScore}
          topLabel={ordinalLabel(hud.goldenGoal ? 3 : hud.currentHalf)}
          clock={formatClock(hud.timeRemaining)}
          training={gameMode === 'training'}
          styleId={resolvedScoreStyle}
        />
        )}
      </div>

      {/* Goal / Halftime / Active Mechanic Banners (Hidden cleanly during Replay!) */}
      <div className="flex flex-col items-center gap-1.5 mt-1.5">
        {hud.goalBannerTeam && !hud.isGoalReplay && (
          <div
            data-testid="goal-banner"
            className={`px-6 py-1.5 border-[3px] border-sky-200 shadow-xl font-display font-extrabold text-xl md:text-3xl tracking-wider text-white rounded-xl ${
              hud.goalBannerTeam === 'red' ? 'bg-red-600' : 'bg-blue-600'
            }`}
          >
            GOAL!
          </div>
        )}
        {!hud.goalBannerTeam && !hud.isGoalReplay && hud.halfTimeBanner && (
          <div
            data-testid="halftime-banner"
            className="px-5 py-1 bg-amber-400 border-[3px] border-sky-900 rounded-xl shadow font-display font-extrabold text-base md:text-xl tracking-wider text-slate-950"
          >
            {hud.goldenGoal ? 'GOLDEN GOAL!' : hud.currentHalf === 1 ? '1ST MATCH!' : '2ND MATCH!'}
          </div>
        )}
        {!hud.isGoalReplay && (
          <div className="flex flex-wrap items-center justify-center gap-2">
            {hud.bombCountdown !== null && (
              <div
                data-testid="bomb-countdown-badge"
                className={`px-3 py-1 border-2 border-sky-300 rounded-lg shadow font-mono-num font-extrabold text-xs tracking-wider ${
                  hud.bombCountdown <= 3.5 ? 'bg-red-600 text-white' : 'bg-blue-900 text-amber-300'
                }`}
              >
                BOMB {Math.ceil(hud.bombCountdown)}s
              </div>
            )}
            {hud.p1KickCharge > 0 && (
              <div
                data-testid="super-kick-badge"
                className="px-3 py-1 bg-red-600 border-2 border-white rounded-lg shadow font-mono-num font-extrabold text-[11px] text-white"
              >
                SUPER KICK {Math.round(hud.p1KickCharge * 100)}%
              </div>
            )}
          </div>
        )}
      </div>

      {/* START: pojok kanan atas (default), bisa digeser lewat Custom Layout */}
      {showVirtualPad && (
        <button
          type="button"
          aria-label="START"
          data-testid="btn-start"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => (hud.isGoalReplay && onSkipGoalReplay ? onSkipGoalReplay() : onPause())}
          style={{
            transform: `translate(${vLayout.system.xOffset}px, ${vLayout.system.yOffset}px) scale(${vLayout.system.scale})`,
            transformOrigin: 'top right',
          }}
          className={`absolute top-2.5 right-2.5 sm:top-4 sm:right-4 md:top-5 md:right-5 pointer-events-auto ${padButtonClass(buttonSkin, 'start', 'slate')}`}
        >
          <StartBarsIcon className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="font-mono-num font-extrabold text-[9px] sm:text-[10px] tracking-wider">START</span>
        </button>
      )}

      {/* Bottom Area: Classic / Transparent / Icon skins */}
      <div className="mt-auto">
        {showVirtualPad && (
          <div
            className="flex items-end justify-between gap-2 pb-1 px-0.5 sm:px-2 pointer-events-auto"
            data-testid="virtual-controls"
            data-skin={buttonSkin}
          >
            {/* Left: Analog D-Pad */}
            <div
              ref={joyBaseRef}
              onPointerDown={(e) => {
                e.currentTarget.setPointerCapture(e.pointerId);
                activePointerId.current = e.pointerId;
                updateStick(e.clientX, e.clientY);
              }}
              onPointerMove={(e) => {
                if (activePointerId.current === e.pointerId) {
                  updateStick(e.clientX, e.clientY);
                }
              }}
              onPointerUp={resetStick}
              onPointerCancel={resetStick}
              style={{
                transform: `translate(${vLayout.dpad.xOffset}px, ${vLayout.dpad.yOffset}px) scale(${vLayout.dpad.scale})`,
                transformOrigin: 'bottom left',
              }}
              className={
                isTransparent
                  ? 'relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-slate-950/15 border-[3px] border-white/90 shadow-[0_2px_8px_rgba(0,0,0,0.45)] flex items-center justify-center touch-none shrink-0'
                  : 'relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-slate-200/85 border-[4px] border-slate-950 pixel-shadow flex items-center justify-center touch-none shrink-0'
              }
            >
              <div
                className={`absolute w-14 h-4 pointer-events-none ${
                  isTransparent ? 'bg-white/30' : 'bg-slate-700/45'
                }`}
              />
              <div
                className={`absolute w-4 h-14 pointer-events-none ${
                  isTransparent ? 'bg-white/30' : 'bg-slate-700/45'
                }`}
              />
              <div
                className={
                  isTransparent
                    ? 'relative w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-slate-950/20 border-[3px] border-white shadow-[0_2px_6px_rgba(0,0,0,0.5)]'
                    : 'relative w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-slate-800 border-[3px] border-slate-950 shadow-md'
                }
                style={{ transform: `translate(${joyKnob.x}px, ${joyKnob.y}px)` }}
              />
            </div>

            {/* Right: L & R (terpisah, masing-masing bisa digeser) + ABXY */}
            <div className="flex flex-col items-center gap-1.5 sm:gap-2 shrink-0">
              <div className="flex items-center gap-3 w-full justify-between px-1">
                <button
                  type="button"
                  aria-label="L"
                  data-testid="btn-l"
                  {...bindActionBtn('headSpinLeft')}
                  style={{
                    transform: `translate(${vLayout.shoulderL.xOffset}px, ${vLayout.shoulderL.yOffset}px) scale(${vLayout.shoulderL.scale})`,
                    transformOrigin: 'bottom right',
                  }}
                  className={padButtonClass(buttonSkin, 'shoulder', 'violet')}
                >
                  {isIconSkin ? <HeadSpinIcon className="w-6 h-6 sm:w-7 sm:h-7" /> : 'L'}
                </button>
                <button
                  type="button"
                  aria-label="R"
                  data-testid="btn-r"
                  {...bindActionBtn('dash')}
                  style={{
                    transform: `translate(${vLayout.shoulderR.xOffset}px, ${vLayout.shoulderR.yOffset}px) scale(${vLayout.shoulderR.scale})`,
                    transformOrigin: 'bottom right',
                  }}
                  className={padButtonClass(buttonSkin, 'shoulder', 'violet')}
                >
                  {isIconSkin ? <DashIcon className="w-6 h-6 sm:w-7 sm:h-7" /> : 'R'}
                </button>
              </div>

              <div
                style={{
                  transform: `translate(${vLayout.abxy.xOffset}px, ${vLayout.abxy.yOffset}px) scale(${vLayout.abxy.scale})`,
                  transformOrigin: 'bottom right',
                }}
                className="grid grid-cols-3 grid-rows-3 gap-1 place-items-center w-[120px] h-[108px] sm:w-[144px] sm:h-[128px]"
              >
                {/* X (Atas - Tendangan putar kanan / tahan: Mega Punch) */}
                <div className="col-start-2 row-start-1">
                  <button
                    type="button"
                    aria-label="X"
                    data-testid="btn-x"
                    {...bindActionBtn('kickRightSpin')}
                    className={padButtonClass(buttonSkin, 'face', 'blue')}
                  >
                    {isIconSkin ? <SpinKickIcon className="w-6 h-6 sm:w-8 sm:h-8" /> : 'X'}
                  </button>
                </div>

                {/* Y (Kiri - Ambil / Lepas Prop) */}
                <div className="col-start-1 row-start-2">
                  <button
                    type="button"
                    aria-label="Y"
                    data-testid="btn-y"
                    {...bindActionBtn('grabProp')}
                    className={padButtonClass(buttonSkin, 'face', 'green')}
                  >
                    {isIconSkin ? <GrabIcon className="w-6 h-6 sm:w-8 sm:h-8" /> : 'Y'}
                  </button>
                </div>

                {/* A (Kanan - Tendang / tahan: Super Kick / Lempar) */}
                <div className="col-start-3 row-start-2">
                  <button
                    type="button"
                    aria-label="A"
                    data-testid="btn-a"
                    {...bindActionBtn('kick')}
                    className={padButtonClass(buttonSkin, 'face', 'red')}
                  >
                    {isIconSkin ? <KickIcon className="w-6 h-6 sm:w-8 sm:h-8" /> : 'A'}
                  </button>
                </div>

                {/* B (Bawah - Lompat) */}
                <div className="col-start-2 row-start-3">
                  <button
                    type="button"
                    aria-label="B"
                    data-testid="btn-b"
                    {...bindActionBtn('jump')}
                    className={padButtonClass(buttonSkin, 'face', 'amber')}
                  >
                    {isIconSkin ? <JumpIcon className="w-6 h-6 sm:w-8 sm:h-8" /> : 'B'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
