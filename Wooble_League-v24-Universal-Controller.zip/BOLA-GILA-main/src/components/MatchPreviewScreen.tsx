import { ANIMALS, ARENAS, BALLS, CLOTHES_STYLES } from '../game/catalog';
import { MatchConfig, PlayerCustomization, TeamId } from '../game/types';
import { useMenuController } from '../hooks/useMenuController';
import { AnimalIcon, ArenaPreviewIcon, BallPreviewIcon } from './MenuIcons';

interface MatchPreviewScreenProps {
  active: boolean;
  config: MatchConfig;
  onBack: () => void;
  onStartMatch: () => void;
}

interface RosterSpot {
  label: string;
  team: TeamId;
  custom: PlayerCustomization;
}

export function MatchPreviewScreen({
  active,
  config,
  onBack,
  onStartMatch,
}: MatchPreviewScreenProps) {
  useMenuController({
    active,
    onAction: (action) => {
      if (action === 'back') onBack();
      else if (action === 'confirm' || action === 'start') onStartMatch();
    },
  });

  const arena = ARENAS.find((a) => a.id === config.arena) ?? ARENAS[0];
  const ball = BALLS.find((b) => b.id === config.ballType) ?? BALLS[0];
  const localPlayers = config.localPlayerCount ?? 1;

  const spots: RosterSpot[] = [{ label: 'P1', team: config.p1Team, custom: config.p1Custom }];
  if (localPlayers >= 2) spots.push({ label: 'P2', team: config.p2Team, custom: config.p2Custom });
  if (localPlayers >= 3 && config.p3Custom) {
    spots.push({ label: 'P3', team: config.p3Team ?? 'red', custom: config.p3Custom });
  }
  if (localPlayers >= 4 && config.p4Custom) {
    spots.push({ label: 'P4', team: config.p4Team ?? 'blue', custom: config.p4Custom });
  }

  const redHumans = spots.filter((s) => s.team === 'red');
  const blueHumans = spots.filter((s) => s.team === 'blue');
  const redCpus = Math.max(0, config.redCount - redHumans.length);
  const blueCpus = Math.max(0, config.blueCount - blueHumans.length);

  const subModeTitle =
    config.matchSubMode === 'tournament'
      ? `TOURNAMENT · ROUND ${config.tournamentRound ?? 1} OF 3`
      : config.mode === 'training'
        ? 'TRAINING · 1V1 KEEPER'
        : localPlayers >= 2
          ? `LOCAL MULTIPLAYER · ${localPlayers}P`
          : 'QUICK MATCH';

  return (
    <div
      data-testid="match-preview-screen"
      className="fixed inset-0 z-30 flex items-center justify-center p-2 sm:p-4 bg-gradient-to-b from-sky-500/75 via-sky-300/45 to-emerald-500/45 backdrop-blur-sm pointer-events-auto"
    >
      <div className="w-full max-w-2xl max-h-[88vh] rounded-xl border-2 border-sky-300 bg-gradient-to-b from-blue-600/95 via-blue-700/95 to-indigo-900/95 shadow-[0_16px_42px_rgba(2,132,199,0.5)] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-3 sm:px-4 py-1.5 sm:py-2 border-b border-sky-300/35 bg-blue-900/45 flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="text-[9px] font-extrabold uppercase tracking-[0.18em] text-amber-300">
              STEP 03 · KICKOFF BRIEFING
            </div>
            <h2 className="font-display font-extrabold text-sm sm:text-lg text-white leading-tight">
              MATCH PREVIEW · {subModeTitle}
            </h2>
          </div>

          <button
            type="button"
            data-testid="preview-back-btn"
            onClick={onBack}
            className="px-2.5 py-1 rounded-lg bg-rose-500 hover:bg-rose-400 border border-rose-200 text-white text-[11px] font-extrabold cursor-pointer"
          >
            B : Customize
          </button>
        </div>

        {/* Team VS Card + Stadium/Ball Card (Horizontal on Landscape!) */}
        <div className="flex-1 overflow-y-auto custom-scroll p-2.5 sm:p-3 space-y-2 sm:space-y-2.5">
          <div className="grid grid-cols-11 gap-2 sm:gap-2.5 items-center">
            {/* RED TEAM */}
            <div className="col-span-5 rounded-lg p-2 bg-gradient-to-b from-red-600/75 to-red-900/85 border border-red-300/70">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-white">
                  RED SQUAD
                </span>
                <span className="text-[10px] font-mono-num font-bold text-red-100">{config.redCount} PLAYERS</span>
              </div>
              <div className="space-y-1">
                {redHumans.map((h) => {
                  const sp = ANIMALS.find((a) => a.id === h.custom.animal) ?? ANIMALS[0];
                  const kit = CLOTHES_STYLES.find((c) => c.id === (h.custom.clothes ?? 'solid'))?.name;
                  return (
                    <div key={h.label} className="flex items-center gap-1.5 p-1 rounded-md bg-slate-950/35 border border-white/15">
                      <AnimalIcon animal={sp} className="w-6 h-6 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-[11px] font-extrabold text-white">
                          {h.label} · {sp.name}
                        </div>
                        <div className="text-[9px] text-amber-200">{kit}</div>
                      </div>
                    </div>
                  );
                })}
                {Array.from({ length: redCpus }).map((_, i) => (
                  <div key={`rcpu-${i}`} className="px-2 py-1 rounded-md bg-slate-950/30 text-[11px] text-red-100 font-semibold">
                    CPU Teammate #{i + 1} · {config.aiDifficulty ?? 'normal'}
                  </div>
                ))}
              </div>
            </div>

            <div className="col-span-1 text-center font-display font-extrabold text-base sm:text-lg text-amber-300 drop-shadow">
              VS
            </div>

            {/* BLUE TEAM */}
            <div className="col-span-5 rounded-lg p-2 bg-gradient-to-b from-sky-500/75 to-blue-900/85 border border-sky-200/70">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-white">
                  BLUE SQUAD
                </span>
                <span className="text-[10px] font-mono-num font-bold text-sky-100">{config.blueCount} PLAYERS</span>
              </div>
              <div className="space-y-1">
                {blueHumans.map((h) => {
                  const sp = ANIMALS.find((a) => a.id === h.custom.animal) ?? ANIMALS[0];
                  const kit = CLOTHES_STYLES.find((c) => c.id === (h.custom.clothes ?? 'solid'))?.name;
                  return (
                    <div key={h.label} className="flex items-center gap-1.5 p-1 rounded-md bg-slate-950/35 border border-white/15">
                      <AnimalIcon animal={sp} className="w-6 h-6 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-[11px] font-extrabold text-white">
                          {h.label} · {sp.name}
                        </div>
                        <div className="text-[9px] text-amber-200">{kit}</div>
                      </div>
                    </div>
                  );
                })}
                {Array.from({ length: blueCpus }).map((_, i) => (
                  <div key={`bcpu-${i}`} className="px-2 py-1 rounded-md bg-slate-950/30 text-[11px] text-sky-100 font-semibold">
                    CPU Rival #{i + 1} · {config.aiDifficulty ?? 'normal'}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Match Conditions Grid */}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg p-2 bg-blue-950/55 border border-sky-300/35 flex items-center gap-2">
              <ArenaPreviewIcon arena={arena} className="w-16 h-9 rounded-md shrink-0" />
              <div className="min-w-0">
                <div className="text-[9px] font-bold uppercase tracking-wider text-sky-200">
                  STADIUM &amp; WEATHER
                </div>
                <div className="text-xs font-extrabold text-white truncate">{arena.name}</div>
                <div className="text-[10px] text-amber-300 uppercase font-bold">
                  Weather: {config.weatherMode ?? 'auto'}
                </div>
              </div>
            </div>

            <div className="rounded-lg p-2 bg-blue-950/55 border border-sky-300/35 flex items-center gap-2">
              <BallPreviewIcon ball={ball} className="w-8 h-8 shrink-0" />
              <div className="min-w-0">
                <div className="text-[9px] font-bold uppercase tracking-wider text-sky-200">
                  MATCH RULES &amp; BALL
                </div>
                <div className="text-xs font-extrabold text-white truncate">{ball.name}</div>
                <div className="text-[10px] text-amber-300 font-mono-num font-bold">
                  {config.mode === 'training' ? '∞ Free' : `${config.durationMinutes}m`} ·{' '}
                  {config.scoreLimit ? `First to ${config.scoreLimit}` : 'Clock'} ·{' '}
                  {config.gameSpeed ?? 1.0}x
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Kickoff CTA */}
        <div className="px-3 sm:px-4 py-1.5 sm:py-2 border-t border-sky-300/35 bg-blue-950/60 flex flex-wrap items-center justify-between gap-2">
          <div className="text-[10px] font-bold text-sky-100">
            B : BACK · A / START : KICK OFF
          </div>

          <button
            type="button"
            data-testid="preview-start-match-btn"
            data-start="true"
            onClick={onStartMatch}
            className="px-5 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 border border-emerald-100 text-slate-950 font-display font-extrabold text-xs sm:text-sm tracking-wide cursor-pointer shadow-lg"
          >
            04 · START MATCH
          </button>
        </div>
      </div>
    </div>
  );
}
