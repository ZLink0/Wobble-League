import type { RagdollState } from './ragdoll';

export type TeamId = 'red' | 'blue';

export type AppLanguage = 'en' | 'id';

export type GameMode = 'quick' | 'story' | 'training' | 'coop' | 'lan';

export type MatchSubMode = 'quick' | 'local_multiplayer' | 'tournament' | 'training' | 'lan';

export type GameScreenState =
  | 'title'
  | 'match_settings'
  | 'character_custom'
  | 'multiplayer_split'
  | 'match_preview'
  | 'setup'
  | 'playing'
  | 'paused'
  | 'gameover';

export type AnimalId =
  | 'alpaca'
  | 'capybara'
  | 'shiba'
  | 'red_panda'
  | 'kangaroo'
  | 'flamingo'
  | 'crocodile'
  | 'penguin'
  | 'gorilla'
  | 'axolotl'
  | 'lion'
  | 'tiger'
  | 'elephant'
  | 'rabbit'
  | 'wolf'
  | 'owl'
  | 'koala'
  | 'hippo'
  | 'giraffe'
  | 'bear';

export type BallTypeId =
  | 'soccer'
  | 'soccer_telstar'
  | 'pro_yellow'
  | 'pro_gold'
  | 'pro_blue'
  | 'hockey'
  | 'rubber'
  | 'metal'
  | 'beach_volleyball'
  | 'crystal'
  | 'nfl'
  | 'flat_disc'
  | 'tennis'
  | 'star_gbc'
  | 'dice'
  | 'ostrich_egg'
  | 'timer_bomb'
  | 'honey_ball';

export type BallShapeKind = 'sphere' | 'cylinder' | 'ellipsoid' | 'disc' | 'cube' | 'egg';
export type BallColliderKind = 'sphere' | 'cylinder' | 'ellipsoid' | 'box';

export type ArenaBarrierStyle =
  | 'sports_fence'
  | 'futsal_mesh'
  | 'gravity_wall'
  | 'volcano_basalt'
  | 'ice_glass'
  | 'bamboo_rope'
  | 'shrine_torii'
  | 'sandstone_wall'
  | 'sky_forcefield'
  | 'temple_stone'
  | 'candy_fence'
  | 'royal_gold';

export type NetStyleId = 'white' | 'checker' | 'striped';

export type GrassPatternId = 'stripes' | 'checker' | 'diamond' | 'rings';

export type ArenaId =
  | 'meadow_park'
  | 'gbc_pixel_bowl'
  | 'futsal_court_blue'
  | 'futsal_court_orange'
  | 'neon_dome'
  | 'volcano_caldera'
  | 'glacier_rink'
  | 'tropical_beach'
  | 'sakura_shrine'
  | 'desert_oasis'
  | 'sky_citadel'
  | 'jungle_temple'
  | 'candy_kingdom'
  | 'grand_championship'
  | 'floating_isles'
  | 'rooftop_skyline';

export type CenterItemType =
  | 'fire_power'
  | 'giant_ball'
  | 'meteor_shower'
  | 'updraft_wind'
  | 'heavy_ghost'
  | 'bomb_ball'
  | 'jelly_10x';

export type ItemSpawnMode = 'on' | 'off' | 'custom';

export type AnimationState =
  | 'idle'
  | 'slow_walk'
  | 'normal_walk'
  | 'run'
  | 'turn_left'
  | 'turn_right'
  | 'stop'
  | 'kick_prep'
  | 'rubber_kick'
  | 'spin_kick_360'
  | 'head_spin_360'
  | 'head_rubber'
  | 'salto_head'
  | 'super_kick_charge'
  | 'super_kick'
  | 'backflip_front'
  | 'backflip_back'
  | 'punch_charge'
  | 'punch_strike'
  | 'jump'
  | 'landing'
  | 'collision'
  | 'fall'
  | 'get_up';

export type KickVariant =
  | 'forward'
  | 'left'
  | 'right'
  | 'backward'
  | 'diag_left'
  | 'diag_right'
  | 'spin_left'
  | 'spin_right'
  | 'super_kick'
  | 'backflip_front_fire'
  | 'backflip_lob'
  | 'jump_kick';

export type HeadVariant =
  | 'spin_left'
  | 'spin_right'
  | 'forward'
  | 'left'
  | 'right'
  | 'backward'
  | 'salto_curved';

export interface AnimalSpec {
  id: AnimalId;
  name: string;
  bodyColor: string;
  accentColor: string;
  snoutColor: string;
  speedBonus: number;
  kickPowerBonus: number;
}

export interface AccessorySpec {
  id: string;
  name: string;
  category: 'hat' | 'mask' | 'cape';
  primaryColor: string;
  secondaryColor: string;
  style: string;
}

export interface BallSpec {
  id: BallTypeId;
  name: string;
  radius: number;
  mass: number;
  restitution: number;
  airDrag: number;
  groundFriction: number;
  shape: BallShapeKind;
  colliderType: BallColliderKind;
  prolateScaleZ?: number;
  cylinderHeight?: number;
  sliding?: boolean;
  primaryColor: string;
  secondaryColor: string;
}

export interface ArenaSpec {
  id: ArenaId;
  name: string;
  grassA: string;
  grassB: string;
  borderColor: string;
  skyTop: string;
  skyFog: string;
  ambientCool: string;
  sunWarm: string;
  themeProp: string;
  barrierStyle: ArenaBarrierStyle;
}

export interface CenterItemSpec {
  id: CenterItemType;
  name: string;
  color: string;
  duration: number;
}

export type ClothesStyleId =
  | 'solid'
  | 'stripe_vertical'
  | 'stripe_horizontal'
  | 'classic_sash'
  | 'split_hoop'
  | 'pro_vneck';

export type ShoeStyleId =
  | 'classic_cleats'
  | 'speed_stripes'
  | 'gold_boots'
  | 'heavy_stompers'
  | 'white_trainers';

export type WeatherMode = 'auto' | 'sunny' | 'rain' | 'snow';
export type AiDifficulty = 'easy' | 'normal' | 'hard';

export interface PlayerCustomization {
  animal: AnimalId;
  hat: string;
  mask: string;
  cape: string;
  clothes?: ClothesStyleId;
  shoes?: ShoeStyleId;
  furColor?: string;
  trimColor?: string;
}

export type BossAiStyle =
  | 'power_shot'
  | 'rubber_header'
  | 'curve_master'
  | 'elastic_reach'
  | 'aerial_flip'
  | 'balanced_titan';

export interface StoryAiProfile {
  difficulty: number; // 0.35 (Rookie) .. 1.0 (World Champion)
  bossStyle?: BossAiStyle;
  opponentName?: string;
}

/** Pengali statistik atlet (1.0 = normal). Dipakai Story Mode open world. */
export interface StatMods {
  speed: number;
  accel: number;
  strength: number;
  jump: number;
  balance: number;
  stamina: number;
  accuracy: number;
  power: number;
  control: number;
  reaction: number;
}

export interface MatchConfig {
  mode: GameMode;
  matchSubMode?: MatchSubMode;
  localPlayerCount?: 1 | 2 | 3 | 4;
  redCount: number;
  blueCount: number;
  durationMinutes: 2 | 3 | 5 | 10 | 15;
  scoreLimit?: number | null;
  halves?: 1 | 2;
  ballType: BallTypeId;
  arena: ArenaId;
  weatherMode?: WeatherMode;
  aiDifficulty?: AiDifficulty;
  gameSpeed?: 0.85 | 1.0 | 1.25;
  /** Pola rumput lapangan (default: stripes) */
  grassPattern?: GrassPatternId | 'random';
  /** Warna gawang: putih / belang (kotak) / bergaris putih-hitam */
  netStyle?: NetStyleId | 'random';
  /** Stadium diacak saat pertandingan dimulai (default: true) */
  arenaRandom?: boolean;
  propsEnabled?: boolean;
  itemSpawnMode: ItemSpawnMode;
  enabledItems: CenterItemType[];
  p1Team: TeamId;
  p2Team: TeamId;
  p3Team?: TeamId;
  p4Team?: TeamId;
  p1Custom: PlayerCustomization;
  p2Custom: PlayerCustomization;
  p3Custom?: PlayerCustomization;
  p4Custom?: PlayerCustomization;
  tournamentRound?: number;
  tournamentWins?: number;
  storyStageIndex: number;
  storyWorldIndex?: number;
  storyMatchIndex?: number;
  storyAi?: StoryAiProfile;
  storyOpponentCustom?: PlayerCustomization;
  /** Statistik per pemain (kunci = id pemain, contoh 'red_0') */
  playerStats?: Record<string, StatMods>;
  /** Kostum per pemain AI (kunci = id pemain) */
  teamCustoms?: Record<string, PlayerCustomization>;
  /** Penanda pertandingan Story Mode open world */
  adventure?: { stadium: number; match: number };
}

export type ButtonSkinId = 'nintendo' | 'transparent' | 'icons' | 'icons_clear';
export type VirtualPadVisibility = 'auto' | 'on' | 'off';
/** system = tombol START (default pojok kanan atas); L dan R terpisah agar bisa digeser sendiri-sendiri */
export type VirtualPadSlotId = 'dpad' | 'system' | 'shoulderL' | 'shoulderR' | 'abxy';

export interface VirtualControlPlacement {
  xOffset: number;
  yOffset: number;
  scale: number;
}

export type VirtualLayoutConfig = Record<VirtualPadSlotId, VirtualControlPlacement>;

export type ScoreHudStyleId = 'random' | 'wood' | 'capy' | 'esports' | 'royal' | 'clean';

export interface GameOptions {
  /** Bahasa antarmuka menu: Inggris / Indonesia */
  language?: AppLanguage;
  buttonSkin: ButtonSkinId;
  bgmEnabled: boolean;
  bgmVolume: number;
  sfxEnabled: boolean;
  sfxVolume: number;
  virtualPadMode: VirtualPadVisibility;
  virtualLayout?: VirtualLayoutConfig;
  /** Posisi HUD skor di bagian atas layar saat bermain */
  scoreHudPos?: 'left' | 'center' | 'right';
  /** Gaya HUD skor; 'random' = acak tiap pertandingan (default) */
  scoreHudStyle?: ScoreHudStyleId;
}

export interface KeyBindingConfig {
  up: string;
  down: string;
  left: string;
  right: string;
  kick: string;          // A: 180° Spin Kick Left / Hold for Super Kick / Jump+A Fire Backflip / Throw Prop
  kickRightSpin: string; // X: 180° Spin Kick Right / Hold Long to Charge Punch / Jump+X Lob Backflip
  grabProp: string;      // Y: Grab / Drop Arena Prop
  jump: string;          // B: Normal Jump
  headSpinLeft: string;  // L: 360° Long Neck Head
  dash: string;          // R: Unlimited Dash (1s cooldown)
  run: string;
}

export interface ControlMapping {
  p1: KeyBindingConfig;
  p2: KeyBindingConfig;
  p3?: KeyBindingConfig;
  p4?: KeyBindingConfig;
}

export interface InputFrame {
  moveX: number;
  moveZ: number;
  runHeld: boolean;
  kickPressed: boolean;
  kickHeld?: boolean;
  kickRightSpinPressed: boolean;
  kickRightHeld?: boolean;
  grabPressed?: boolean;
  jumpPressed: boolean;
  headSpinLeftPressed: boolean;
  dashPressed: boolean;
}

export interface PlayerSim {
  id: string;
  stats?: StatMods;
  team: TeamId;
  isHuman: boolean;
  humanSlot: 0 | 1 | 2 | 3 | 4;
  custom: PlayerCustomization;

  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  facing: number;
  turnRateVisual: number;

  animState: AnimationState;
  walkCycle: number;
  squashX: number;
  squashY: number;

  // Rubber kick, Super Kick Charge & 180° Spin Kick + Aerial Backflips
  kickPhase: 'none' | 'super_charge' | 'prep' | 'extend' | 'retract';
  kickTimer: number;
  kickVariant: KickVariant;
  kickLeg: 'left' | 'right';
  kickStretch: number;
  kickSpinAngle: number; // -PI/2..+PI/2 for 180 spin kick
  kickSpinDir: -1 | 0 | 1;
  kickTargetDirX: number;
  kickTargetDirZ: number;
  kickPendingTurn: number; // body rotation before backward/side kick
  kickHitApplied: boolean;
  kickHoldTimer: number;
  wasKickHeld: boolean;
  kickCharge: number;
  backflipAngle: number;

  // Rubber Neck Heading (L/R 360°, Directional L/R/F/B, and X Salto with Long Curved Neck)
  headPhase: 'none' | 'turn_first' | 'prep' | 'extend' | 'retract';
  headTimer: number;
  headVariant: HeadVariant;
  neckStretch: number;
  neckCurve: number;
  headSpinAngle: number; // 0..2*PI for L/R 360 head swing
  headSpinDir: -1 | 0 | 1; // +1 = CCW Left, -1 = CW Right
  saltoAngle: number; // 0..2*PI for X Salto flip
  headTargetDirX: number;
  headTargetDirY: number;
  headTargetDirZ: number;
  headDesiredFacing: number;
  headHitApplied: boolean;

  // Dash & Status
  dashTimer: number;
  dashCooldown: number;
  /** Efek ramuan: ukuran tampil pemain (1 = normal) */
  /** Sedang menunggangi banteng (id) atau null */
  ridingBullId: string | null;
  sizeScale: number;
  sizeTarget: number;
  sizeTimer: number;

  // Instant Limp Articulated Ragdoll & Ghost debuff
  fallTimer: number;
  ragdollBlend: number; // 0..1 blend into limp ragdoll pose
  ragdollPitch: number;
  ragdollRoll: number;
  ragdollVelPitch: number;
  ragdollVelRoll: number;
  ragdollArmL: number;
  ragdollArmR: number;
  ragdollLegL: number;
  ragdollLegR: number;
  ragdollNeck: number;
  ragdollHeadRoll: number;
  /** Ragdoll fisik penuh (rangka partikel + sendi); null bila tidak sedang jatuh */
  ragdoll: RagdollState | null;
  collisionStunTimer: number;
  ghostAttachedTimer: number;

  // B Prop Carry & Hold-X Charge Punch
  carryingPropId: string | null;
  punchPhase: 'none' | 'charge' | 'strike' | 'recover';
  punchTimer: number;
  punchCharge: number;
  punchHitApplied: boolean;
  wasPunchHeld: boolean;
  punchHoldTimer: number;
}

export interface BallSim {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  rotX: number;
  rotY: number;
  rotZ: number;
  spinX: number;
  spinY: number;
  spinZ: number;
  radius: number;
  mass: number;
  restitution: number;
  airDrag: number;
  groundFriction: number;
  shape: BallShapeKind;
  colliderType: BallColliderKind;
  prolateScaleZ: number;
  cylinderHeight: number;
  sliding: boolean;

  untouchedTimer: number;
  lastTouchTeam: TeamId | null;
  lastTouchPlayerId: string | null;

  isClashedFire: boolean;
  clashFireTimer: number;
  scaleMultiplier: number;
  isBombArmed: boolean;
  isJelly10x: boolean;
  hitFlashTimer: number;

  // Special Ball Mechanics (Timer Bomb 15s & Sticky Honey Ball)
  bombCountdown: number;
  isStickyBall: boolean;
  stickyTargetPlayerId: string | null;
  stickyTimer: number;
  stickyCooldown: number;
}

export interface JellyPostSpring {
  dispX: number;
  dispY: number;
  dispZ: number;
  velX: number;
  velY: number;
  velZ: number;
}

export interface GoalPostsState {
  leftGoal: {
    leftPost: JellyPostSpring;
    rightPost: JellyPostSpring;
    crossbar: JellyPostSpring;
  };
  rightGoal: {
    leftPost: JellyPostSpring;
    rightPost: JellyPostSpring;
    crossbar: JellyPostSpring;
  };
}

export interface ActiveCenterItem {
  type: CenterItemType;
  remaining: number;
  targetPlayerId: string | null;
}

export interface CenterPickupOrb {
  active: boolean;
  type: CenterItemType;
  x: number;
  y: number;
  z: number;
  respawnTimer: number;
  bobPhase: number;
}

export interface MeteorHazard {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vy: number;
  impacted: boolean;
  life: number;
}

export interface PuddleSpot {
  x: number;
  z: number;
  radius: number;
}

export interface WeatherState {
  hasRainInMatch: boolean;
  isRaining: boolean;
  isSnowing?: boolean;
  rainTimer: number; // counts down from 120s (2 minutes)
  wetness: number; // 0..1 surface wetness
  puddles: PuddleSpot[];
}

export type PropKind =
  | 'wooden_chair'
  | 'wooden_box'
  | 'oil_drum'
  | 'water_gallon'
  | 'bomb'
  | 'potion'
  | 'ostrich_egg';

/** Banteng yang menetas dari telur burung unta: menyeruduk tiap pemain selama 20 detik */
export interface BullSim {
  id: string;
  x: number;
  z: number;
  vx: number;
  vz: number;
  facing: number;
  timer: number;
  stun: number;
  targetId: string | null;
  visited: string[];
}

export interface ArenaPropSim {
  id: string;
  /** Sumbu waktu internal: sumbu bom / penetasan telur (detik) */
  fuse?: number;
  done?: boolean;
  kind: PropKind;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  rotY: number;
  radius: number;
  usesRemaining: number;
  carriedByPlayerId: string | null;
  thrownActive: boolean;
  thrownByPlayerId: string | null;
  thrownByTeam: TeamId | null;
  flashTimer: number;
}

export interface SimEvent {
  type:
    | 'kick'
    | 'ball_bounce'
    | 'clash'
    | 'goal'
    | 'post_hit'
    | 'ragdoll_fall'
    | 'item_pickup'
    | 'bomb_explode'
    | 'meteor_impact'
    | 'ball_respawn'
    | 'water_splash'
    | 'whistle'
    | 'halftime'
    | 'prop_spawn'
    | 'prop_grab'
    | 'prop_throw'
    | 'prop_drop'
    | 'prop_break'
    | 'punch_hit'
    | 'save'
    | 'foul'
    | 'honey_stick'
    /** Percikan cahaya saat bola menabrak pembatas (terlihat maupun tak terlihat) */
    | 'wall_spark';
  team?: TeamId;
  x?: number;
  y?: number;
  z?: number;
  intensity?: number;
  label?: string;
  /** Arah normal pembatas (menjauhi dinding, ke dalam lapangan) untuk event wall_spark */
  nx?: number;
  nz?: number;
}

export interface MatchSimulation {
  config: MatchConfig;
  players: PlayerSim[];
  ball: BallSim;
  goalPosts: GoalPostsState;
  pickupOrb: CenterPickupOrb;
  activeItems: ActiveCenterItem[];
  meteors: MeteorHazard[];
  weather: WeatherState;

  props: ArenaPropSim[];
  bulls: BullSim[];
  propSpawnTimer: number;
  propBatchCount: number;

  redScore: number;
  blueScore: number;
  timeRemaining: number;
  elapsedTime: number;
  currentHalf: 1 | 2;
  halfTimeBannerTimer: number;
  /** Perpanjangan golden goal: gol pertama menang (jika seri di akhir babak 2) */
  goldenGoal: boolean;

  goalCelebrationTimer: number;
  lastScoringTeam: TeamId | null;
  hitstopTimer: number;
  cameraTrauma: number;
  cameraZoomPulse: number;
  matchEnded: boolean;

  lastKickCollisionTick: { playerId: string; team: TeamId; time: number } | null;
  events: SimEvent[];
}
