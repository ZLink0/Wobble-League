import assert from 'node:assert/strict';
import test from 'node:test';
import {
  completeStoryMatch,
  createInitialStoryProgress,
  createStoryMatchConfig,
  isMatchCompleted,
  isMatchUnlocked,
  isWorldCleared,
  isWorldUnlocked,
  normalizeStoryProgress,
  STORY_WORLDS,
  WORLD_10_CELEBRATION_CAST,
  WORLD_10_ENDING_DIALOGUE,
} from './story';
import { DEFAULT_CUSTOMIZATION } from './catalog';

test('Story World Tour defines 10 distinct worlds with 5 matches each and unique Boss Champions', () => {
  assert.equal(STORY_WORLDS.length, 10, 'Expected 10 Adventure Worlds');
  const worldNames = new Set(STORY_WORLDS.map((w) => w.name));
  assert.equal(worldNames.size, 10, 'All 10 World names must be unique');

  const bossNames = new Set<string>();
  for (let wi = 0; wi < STORY_WORLDS.length; wi++) {
    const w = STORY_WORLDS[wi];
    assert.equal(w.matches.length, 5, `World ${w.name} must have 5 matches`);
    for (let mi = 0; mi < 5; mi++) {
      const m = w.matches[mi];
      assert.ok(m.preMatchDialogue.length >= 2, `World ${wi + 1} match ${mi + 1} needs pre-match dialogue`);
      assert.ok(
        m.preMatchDialogue.some((line) => line.choices && line.choices.length === 3),
        `World ${wi + 1} match ${mi + 1} needs interactive A/B/C choices`
      );
      assert.ok(m.postWinDialogue.length >= 1);
      assert.ok(m.reward.coins > 0);
      if (mi === 4) {
        assert.equal(m.isBoss, true);
        assert.ok(m.bossStyle, `World ${w.name} Boss needs a bossStyle AI profile`);
        assert.ok(m.reward.trophyId, `World ${w.name} Boss must award a World Trophy`);
        bossNames.add(m.opponentName);
      } else {
        assert.equal(m.isBoss, false);
      }
    }
  }
  assert.equal(bossNames.size, 10, 'All 10 World Boss Champions must be unique');
  assert.equal(WORLD_10_CELEBRATION_CAST.length, 10);
  assert.ok(WORLD_10_ENDING_DIALOGUE.length >= 3);
});

test('Story Mode progression locks future worlds/matches and unlocks them sequentially on victories', () => {
  let state = createInitialStoryProgress();

  assert.equal(isWorldUnlocked(state, 0), true);
  assert.equal(isWorldUnlocked(state, 1), false);
  assert.equal(isMatchUnlocked(state, 0, 0), true);
  assert.equal(isMatchUnlocked(state, 0, 1), false);

  // Beat matches 1..4 in World 1
  for (let m = 0; m < 4; m++) {
    const res = completeStoryMatch(state, 0, m);
    state = res.nextState;
    assert.equal(res.firstTimeClear, true);
    assert.equal(res.unlockedNextWorld, null, 'Non-boss wins do not unlock next world yet');
    assert.equal(isMatchCompleted(state, 0, m), true);
    assert.equal(isMatchUnlocked(state, 0, m + 1), true);
  }
  assert.equal(isWorldUnlocked(state, 1), false, 'World 2 remains locked until World 1 Boss is defeated');

  // Beat Boss Champion in World 1 (matchIdx = 4) -> unlocks World 2 + awards World 1 Trophy & Title
  const bossWin = completeStoryMatch(state, 0, 4);
  state = bossWin.nextState;
  assert.equal(bossWin.unlockedNextWorld, 1);
  assert.equal(isWorldCleared(state, 0), true);
  assert.equal(isWorldUnlocked(state, 1), true);
  assert.equal(isMatchUnlocked(state, 1, 0), true);
  assert.ok(state.unlockedTrophies.includes('trophy_green_valley'));
  assert.ok(state.unlockedTitles.includes('Valley Kickoff Star'));
  assert.ok(state.coins >= 300);

  // Progress survives normalization round-trip (localStorage serialization)
  const restored = normalizeStoryProgress(JSON.parse(JSON.stringify(state)));
  assert.deepEqual(restored, state);
});

test('World 10 Boss clear triggers Grand Champion ending flag and WORLD CHAMPION title', () => {
  let state = createInitialStoryProgress();
  state.highestWorldUnlocked = 9;
  state.highestMatchPerWorld[9] = 4;

  const finale = completeStoryMatch(state, 9, 4);
  assert.equal(finale.completedStoryEnding, true);
  assert.equal(finale.nextState.championEndingCleared, true);
  assert.ok(finale.nextState.unlockedTrophies.includes('trophy_world_champion'));
  assert.ok(finale.nextState.unlockedTitles.includes('WORLD CHAMPION'));
});

test('createStoryMatchConfig builds 1v1 story config with arena, ball, opponent costume, and Boss AI', () => {
  const cfg = createStoryMatchConfig(6, 4, DEFAULT_CUSTOMIZATION);
  assert.equal(cfg.mode, 'story');
  assert.equal(cfg.arena, 'candy_kingdom');
  assert.equal(cfg.ballType, 'star_gbc');
  assert.equal(cfg.redCount, 1);
  assert.equal(cfg.blueCount, 1);
  assert.equal(cfg.storyWorldIndex, 6);
  assert.equal(cfg.storyMatchIndex, 4);
  assert.equal(cfg.storyAi?.bossStyle, 'curve_master');
  assert.equal(cfg.storyOpponentCustom?.animal, 'axolotl');
});
