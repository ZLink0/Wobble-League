import { ANIMALS } from './catalog';
import { AnimalId } from './types';
import { Building, D, Poi, T, TILE, WORLD_H, WORLD_W, WorldData, hash2 } from './openWorldMap';

/* Penggambar open world top-down bergaya kartun (Canvas 2D, pseudo-3D) */

export const TERRAIN_COLORS: Record<number, string> = {
  [T.GRASS]: '#6cc66b',
  [T.JUNGLE]: '#2f9a4f',
  [T.WATER]: '#3b94e6',
  [T.SAND]: '#ecd391',
  [T.SNOW]: '#eaf5fb',
  [T.ROCK]: '#9a948c',
  [T.ROAD]: '#d2bb8e',
  [T.BRIDGE]: '#a8723e',
  [T.CONCRETE]: '#929aa4',
  [T.NEON]: '#241b45',
  [T.MARBLE]: '#e6e0d3',
  [T.BEACH]: '#f4e4ae',
  [T.DIRT]: '#b58d5c',
};

function shade(hex: string, f: number): string {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, Math.round(((n >> 16) & 255) * f)));
  const g = Math.max(0, Math.min(255, Math.round(((n >> 8) & 255) * f)));
  const b = Math.max(0, Math.min(255, Math.round((n & 255) * f)));
  return `rgb(${r},${g},${b})`;
}

/* --------------------------- mini map (1 tile = scale px) --------------------------- */
const miniCache = new Map<number, HTMLCanvasElement>();
export function renderMinimapCanvas(w: WorldData, scale = 4): HTMLCanvasElement {
  const hit = miniCache.get(scale);
  if (hit) return hit;
  const c = document.createElement('canvas');
  c.width = WORLD_W * scale;
  c.height = WORLD_H * scale;
  const g = c.getContext('2d')!;
  for (let y = 0; y < WORLD_H; y++) {
    for (let x = 0; x < WORLD_W; x++) {
      const k = y * WORLD_W + x;
      let col = TERRAIN_COLORS[w.terrain[k]] ?? '#888';
      const d = w.deco[k];
      if (d === D.TREE || d === D.PINE || d === D.PALM) col = w.terrain[k] === T.SNOW ? '#9fc7a8' : '#2f8f4b';
      else if (d === D.BOULDER) col = '#777068';
      g.fillStyle = col;
      g.fillRect(x * scale, y * scale, scale, scale);
    }
  }
  for (const b of w.buildings) {
    g.fillStyle = b.kind === 'stadium' ? '#1e293b' : b.kind === 'save' ? '#ef4444' : b.kind === 'house' ? '#b45309' : '#2563eb';
    g.fillRect(b.x * scale, b.y * scale, b.w * scale, b.h * scale);
  }
  miniCache.set(scale, c);
  return c;
}

/* ------------------------------- sprite hewan ------------------------------- */
export type Dir = 'down' | 'up' | 'left' | 'right';

export function drawAnimal(
  g: CanvasRenderingContext2D,
  animal: AnimalId,
  fx: number, // posisi kaki (px layar)
  fy: number,
  size: number,
  dir: Dir,
  walk: number,
  opts: { headband?: string; tint?: string } = {}
) {
  const spec = ANIMALS.find((a) => a.id === animal) ?? ANIMALS[0];
  const s = size;
  const body = opts.tint ?? spec.bodyColor;
  const swing = Math.sin(walk) * s * 0.12;
  // bayangan
  g.fillStyle = 'rgba(0,0,0,0.22)';
  g.beginPath();
  g.ellipse(fx, fy, s * 0.38, s * 0.14, 0, 0, Math.PI * 2);
  g.fill();
  // kaki
  g.fillStyle = shade(spec.accentColor, 0.9);
  const lx = dir === 'left' || dir === 'right' ? s * 0.08 : s * 0.16;
  g.fillRect(fx - lx - s * 0.07, fy - s * 0.22 + swing * 0.4, s * 0.14, s * 0.2);
  g.fillRect(fx + lx - s * 0.07, fy - s * 0.22 - swing * 0.4, s * 0.14, s * 0.2);
  // badan
  const bodyW = s * 0.62;
  const bodyH = s * 0.5;
  g.fillStyle = body;
  g.strokeStyle = 'rgba(0,0,0,0.55)';
  g.lineWidth = Math.max(1, s * 0.04);
  g.beginPath();
  g.roundRect(fx - bodyW / 2, fy - s * 0.2 - bodyH, bodyW, bodyH, s * 0.18);
  g.fill();
  g.stroke();
  if (dir !== 'up') {
    g.fillStyle = spec.accentColor;
    g.beginPath();
    g.ellipse(fx, fy - s * 0.3, bodyW * 0.28, bodyH * 0.28, 0, 0, Math.PI * 2);
    g.fill();
  }
  // kepala
  const hy = fy - s * 0.2 - bodyH - s * 0.2;
  const hr = s * 0.3;
  const earLong = animal === 'rabbit' || animal === 'alpaca' || animal === 'giraffe';
  g.fillStyle = body;
  // telinga
  const earW = animal === 'elephant' ? hr * 0.75 : hr * 0.42;
  for (const sx of [-1, 1]) {
    g.beginPath();
    if (earLong) g.ellipse(fx + sx * hr * 0.55, hy - hr * 1.05, hr * 0.22, hr * 0.7, 0, 0, Math.PI * 2);
    else g.ellipse(fx + sx * hr * 0.82, hy - hr * 0.55, earW, earW, 0, 0, Math.PI * 2);
    g.fill();
    g.stroke();
  }
  g.beginPath();
  g.arc(fx, hy, hr, 0, Math.PI * 2);
  g.fill();
  g.stroke();
  if (opts.headband) {
    g.fillStyle = opts.headband;
    g.fillRect(fx - hr, hy - hr * 0.55, hr * 2, hr * 0.32);
  }
  if (dir !== 'up') {
    const ox = dir === 'left' ? -hr * 0.25 : dir === 'right' ? hr * 0.25 : 0;
    g.fillStyle = spec.snoutColor;
    g.beginPath();
    g.ellipse(fx + ox * 1.4, hy + hr * 0.3, hr * 0.42, hr * 0.3, 0, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = '#111';
    for (const sx of [-1, 1]) {
      g.beginPath();
      g.arc(fx + ox + sx * hr * 0.38, hy - hr * 0.1, hr * 0.12, 0, Math.PI * 2);
      g.fill();
    }
    g.beginPath();
    g.arc(fx + ox * 1.4, hy + hr * 0.2, hr * 0.1, 0, Math.PI * 2);
    g.fill();
  }
}

/* ------------------------------- dekorasi ------------------------------- */
function drawDeco(g: CanvasRenderingContext2D, d: number, x: number, y: number, ts: number, t: number, terrain: number, seed: number) {
  const cx = x + ts / 2;
  const by = y + ts * 0.92;
  const sway = Math.sin(t * 1.4 + seed * 7) * ts * 0.02;
  const shadow = () => {
    g.fillStyle = 'rgba(0,0,0,0.2)';
    g.beginPath();
    g.ellipse(cx, by, ts * 0.32, ts * 0.12, 0, 0, Math.PI * 2);
    g.fill();
  };
  if (d === D.TREE) {
    shadow();
    g.fillStyle = '#7a4a22';
    g.fillRect(cx - ts * 0.07, by - ts * 0.45, ts * 0.14, ts * 0.45);
    g.fillStyle = '#2f9d4a';
    g.beginPath();
    g.arc(cx + sway, by - ts * 0.72, ts * 0.38, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = '#46b85f';
    g.beginPath();
    g.arc(cx - ts * 0.1 + sway, by - ts * 0.8, ts * 0.2, 0, Math.PI * 2);
    g.fill();
  } else if (d === D.PINE) {
    shadow();
    g.fillStyle = '#6b4423';
    g.fillRect(cx - ts * 0.06, by - ts * 0.2, ts * 0.12, ts * 0.2);
    for (let i = 0; i < 3; i++) {
      g.fillStyle = terrain === T.SNOW ? (i === 0 ? '#e6f4f1' : '#2a8a5c') : '#1f7a45';
      g.beginPath();
      g.moveTo(cx + sway, by - ts * (0.95 - i * 0.05) + i * ts * 0.3 - ts * 0.35);
      g.lineTo(cx + ts * (0.32 - i * 0.04), by - ts * 0.2 - i * ts * 0.14);
      g.lineTo(cx - ts * (0.32 - i * 0.04), by - ts * 0.2 - i * ts * 0.14);
      g.closePath();
      g.fill();
    }
  } else if (d === D.PALM) {
    shadow();
    g.strokeStyle = '#8a5a2b';
    g.lineWidth = ts * 0.1;
    g.beginPath();
    g.moveTo(cx, by);
    g.quadraticCurveTo(cx + ts * 0.12, by - ts * 0.45, cx + sway * 2, by - ts * 0.8);
    g.stroke();
    g.fillStyle = '#2fb356';
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + (i - 2) * 0.62;
      g.beginPath();
      g.ellipse(cx + sway * 2 + Math.cos(a) * ts * 0.25, by - ts * 0.8 + Math.sin(a) * ts * 0.2, ts * 0.22, ts * 0.08, a, 0, Math.PI * 2);
      g.fill();
    }
  } else if (d === D.CACTUS) {
    shadow();
    g.fillStyle = '#3f9d4b';
    g.beginPath();
    g.roundRect(cx - ts * 0.1, by - ts * 0.7, ts * 0.2, ts * 0.7, ts * 0.1);
    g.fill();
    g.beginPath();
    g.roundRect(cx - ts * 0.3, by - ts * 0.5, ts * 0.14, ts * 0.3, ts * 0.07);
    g.roundRect(cx + ts * 0.16, by - ts * 0.55, ts * 0.14, ts * 0.32, ts * 0.07);
    g.fill();
  } else if (d === D.BOULDER) {
    shadow();
    g.fillStyle = '#8c8680';
    g.beginPath();
    g.ellipse(cx, by - ts * 0.25, ts * 0.38, ts * 0.3, 0, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = 'rgba(255,255,255,0.28)';
    g.beginPath();
    g.ellipse(cx - ts * 0.1, by - ts * 0.35, ts * 0.16, ts * 0.1, -0.4, 0, Math.PI * 2);
    g.fill();
  } else if (d === D.CRATE) {
    shadow();
    g.fillStyle = '#c7882f';
    g.fillRect(cx - ts * 0.34, by - ts * 0.6, ts * 0.68, ts * 0.6);
    g.strokeStyle = '#7c4f12';
    g.lineWidth = ts * 0.05;
    g.strokeRect(cx - ts * 0.34, by - ts * 0.6, ts * 0.68, ts * 0.6);
    g.beginPath();
    g.moveTo(cx - ts * 0.34, by - ts * 0.6);
    g.lineTo(cx + ts * 0.34, by);
    g.moveTo(cx + ts * 0.34, by - ts * 0.6);
    g.lineTo(cx - ts * 0.34, by);
    g.stroke();
  } else if (d === D.PILLAR) {
    const hue = seed % 2 === 0 ? '#22d3ee' : '#f0abfc';
    g.fillStyle = '#0f0a24';
    g.fillRect(cx - ts * 0.12, by - ts * 0.9, ts * 0.24, ts * 0.9);
    g.fillStyle = hue;
    g.globalAlpha = 0.55 + 0.4 * Math.sin(t * 3 + seed);
    g.fillRect(cx - ts * 0.05, by - ts * 0.85, ts * 0.1, ts * 0.8);
    g.globalAlpha = 1;
  } else if (d === D.STATUE) {
    shadow();
    g.fillStyle = '#cfc8b8';
    g.fillRect(cx - ts * 0.2, by - ts * 0.3, ts * 0.4, ts * 0.3);
    g.fillRect(cx - ts * 0.1, by - ts * 0.75, ts * 0.2, ts * 0.45);
    g.fillStyle = '#f5c542';
    g.beginPath();
    g.arc(cx, by - ts * 0.85, ts * 0.14, 0, Math.PI * 2);
    g.fill();
  } else if (d === D.BUSH) {
    g.fillStyle = 'rgba(30,110,50,0.9)';
    g.beginPath();
    g.ellipse(cx, by - ts * 0.12, ts * 0.25, ts * 0.16, 0, 0, Math.PI * 2);
    g.fill();
  } else if (d === D.FLOWER) {
    const cols = ['#ff6b9a', '#ffd34d', '#ffffff', '#b794f6'];
    g.fillStyle = cols[seed % 4];
    g.beginPath();
    g.arc(x + ts * 0.3, y + ts * 0.65, ts * 0.06, 0, Math.PI * 2);
    g.arc(x + ts * 0.65, y + ts * 0.4, ts * 0.05, 0, Math.PI * 2);
    g.fill();
  }
}

/* -------------------------------- bangunan -------------------------------- */
function labelText(g: CanvasRenderingContext2D, text: string, x: number, y: number, size: number, color = '#fff') {
  g.font = `800 ${size}px system-ui, sans-serif`;
  g.textAlign = 'center';
  g.lineWidth = Math.max(2, size * 0.25);
  g.strokeStyle = 'rgba(0,0,0,0.7)';
  g.strokeText(text, x, y);
  g.fillStyle = color;
  g.fillText(text, x, y);
}

export function drawBuilding(g: CanvasRenderingContext2D, b: Building, px: number, py: number, ts: number, t: number, discovered: boolean, cleared: boolean) {
  const w = b.w * ts;
  const h = b.h * ts;
  g.lineJoin = 'round';
  if (b.kind === 'training') {
    g.fillStyle = '#8fc43a';
    g.fillRect(px, py, w, h);
    g.strokeStyle = '#fff';
    g.lineWidth = Math.max(2, ts * 0.06);
    g.strokeRect(px + ts * 0.3, py + ts * 0.3, w - ts * 0.6, h - ts * 0.6);
    g.beginPath();
    g.moveTo(px + w / 2, py + ts * 0.3);
    g.lineTo(px + w / 2, py + h - ts * 0.3);
    g.stroke();
    for (const cx of [px + ts, px + w - ts]) {
      g.fillStyle = '#f97316';
      g.beginPath();
      g.moveTo(cx, py + h * 0.4);
      g.lineTo(cx - ts * 0.15, py + h * 0.4 + ts * 0.3);
      g.lineTo(cx + ts * 0.15, py + h * 0.4 + ts * 0.3);
      g.fill();
    }
    labelText(g, '⚽ AREA LATIHAN', px + w / 2, py - ts * 0.15, ts * 0.34, '#fde68a');
    return;
  }
  if (b.kind === 'stadium') {
    // bayangan & tribun
    g.fillStyle = 'rgba(0,0,0,0.25)';
    g.beginPath();
    g.roundRect(px + ts * 0.3, py + ts * 0.5, w, h, ts * 1.6);
    g.fill();
    g.fillStyle = '#1e293b';
    g.beginPath();
    g.roundRect(px, py, w, h, ts * 1.6);
    g.fill();
    g.fillStyle = b.color;
    g.beginPath();
    g.roundRect(px + ts * 0.35, py + ts * 0.35, w - ts * 0.7, h - ts * 0.7, ts * 1.4);
    g.fill();
    // kursi tribun
    g.fillStyle = 'rgba(255,255,255,0.28)';
    for (let i = 0; i < 4; i++) {
      g.strokeStyle = 'rgba(255,255,255,0.35)';
      g.lineWidth = 1;
      g.beginPath();
      g.roundRect(px + ts * (0.7 + i * 0.28), py + ts * (0.7 + i * 0.28), w - ts * (1.4 + i * 0.56), h - ts * (1.4 + i * 0.56), ts);
      g.stroke();
    }
    // lapangan
    g.fillStyle = '#3fa655';
    g.beginPath();
    g.roundRect(px + ts * 2.2, py + ts * 2, w - ts * 4.4, h - ts * 4, ts * 0.6);
    g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.8)';
    g.lineWidth = Math.max(1.5, ts * 0.05);
    g.strokeRect(px + ts * 2.6, py + ts * 2.4, w - ts * 5.2, h - ts * 4.8);
    g.beginPath();
    g.moveTo(px + w / 2, py + ts * 2.4);
    g.lineTo(px + w / 2, py + h - ts * 2.4);
    g.stroke();
    g.beginPath();
    g.arc(px + w / 2, py + h / 2, ts * 0.9, 0, Math.PI * 2);
    g.stroke();
    // gerbang
    g.fillStyle = '#fbbf24';
    g.fillRect(px + w / 2 - ts * 1, py + h - ts * 0.55, ts * 2, ts * 0.55);
    g.fillStyle = '#0f172a';
    g.fillRect(px + w / 2 - ts * 0.6, py + h - ts * 0.4, ts * 1.2, ts * 0.4);
    // papan nama
    const name = b.stadium !== undefined ? `${b.stadium + 1}` : '';
    g.fillStyle = cleared ? '#facc15' : '#0f172a';
    g.beginPath();
    g.arc(px + w / 2, py + ts * 1.15, ts * 0.55, 0, Math.PI * 2);
    g.fill();
    labelText(g, cleared ? '🏆' : name, px + w / 2, py + ts * 1.15 + ts * 0.15, ts * 0.5, cleared ? '#7c2d12' : '#fff');
    if (!discovered) labelText(g, '???', px + w / 2, py - ts * 0.15, ts * 0.4, '#e2e8f0');
    return;
  }
  // rumah / toko / aula / save
  const roofH = h * 0.55;
  g.fillStyle = 'rgba(0,0,0,0.2)';
  g.fillRect(px + ts * 0.2, py + h - ts * 0.1, w, ts * 0.3);
  g.fillStyle = b.color;
  g.fillRect(px, py + roofH * 0.7, w, h - roofH * 0.7);
  g.strokeStyle = 'rgba(0,0,0,0.5)';
  g.lineWidth = Math.max(1.5, ts * 0.05);
  g.strokeRect(px, py + roofH * 0.7, w, h - roofH * 0.7);
  g.fillStyle = b.roof;
  g.beginPath();
  g.moveTo(px - ts * 0.25, py + roofH);
  g.lineTo(px + ts * 0.3, py);
  g.lineTo(px + w - ts * 0.3, py);
  g.lineTo(px + w + ts * 0.25, py + roofH);
  g.closePath();
  g.fill();
  g.stroke();
  g.fillStyle = 'rgba(255,255,255,0.18)';
  g.fillRect(px + ts * 0.3, py + ts * 0.1, w - ts * 0.6, ts * 0.12);
  // pintu & jendela
  const dw = ts * 0.7;
  g.fillStyle = '#5b3a1e';
  g.fillRect(px + w / 2 - dw / 2, py + h - ts * 1.0, dw, ts * 1.0);
  g.fillStyle = '#bfe3ff';
  const winY = py + roofH + ts * 0.05;
  if (w > ts * 3) {
    g.fillRect(px + ts * 0.5, winY, ts * 0.6, ts * 0.5);
    g.fillRect(px + w - ts * 1.1, winY, ts * 0.6, ts * 0.5);
  }
  if (b.label) {
    const ls = b.kind === 'house' ? 0 : ts * 0.3;
    if (ls) labelText(g, b.label, px + w / 2, py - ts * 0.1 + Math.sin(t * 2) * 0, ls, b.kind === 'save' ? '#fecaca' : '#fff');
  }
  if (b.kind === 'save') {
    g.fillStyle = '#1d4ed8';
    g.fillRect(px + w / 2 - ts * 0.3, py + roofH * 0.2, ts * 0.6, ts * 0.6);
    g.fillStyle = '#fff';
    g.fillRect(px + w / 2 - ts * 0.2, py + roofH * 0.2 + ts * 0.05, ts * 0.4, ts * 0.2);
  }
}

/* ------------------------------ render dunia ------------------------------ */
export interface DrawEntity {
  y: number; // kunci urutan
  draw: (g: CanvasRenderingContext2D) => void;
}

export interface WorldView {
  camX: number; // dalam tile (float)
  camY: number;
  ts: number; // px per tile
  vw: number;
  vh: number;
  time: number;
}

export function drawGround(g: CanvasRenderingContext2D, w: WorldData, v: WorldView) {
  const { ts, vw, vh, camX, camY, time } = v;
  const x0 = Math.floor(camX - vw / ts / 2) - 1;
  const y0 = Math.floor(camY - vh / ts / 2) - 1;
  const x1 = Math.ceil(camX + vw / ts / 2) + 1;
  const y1 = Math.ceil(camY + vh / ts / 2) + 1;
  g.fillStyle = '#1e4d7a';
  g.fillRect(0, 0, vw, vh);
  for (let ty = y0; ty <= y1; ty++) {
    for (let tx = x0; tx <= x1; tx++) {
      const sx = Math.floor((tx - camX) * ts + vw / 2);
      const sy = Math.floor((ty - camY) * ts + vh / 2);
      const size = Math.ceil(ts) + 1;
      if (tx < 0 || ty < 0 || tx >= WORLD_W || ty >= WORLD_H) {
        g.fillStyle = '#1e4d7a';
        g.fillRect(sx, sy, size, size);
        continue;
      }
      const k = ty * WORLD_W + tx;
      const t = w.terrain[k];
      const r = hash2(tx, ty, 5);
      g.fillStyle = shade(TERRAIN_COLORS[t] ?? '#777', 0.95 + r * 0.1);
      g.fillRect(sx, sy, size, size);
      if (t === T.WATER) {
        g.strokeStyle = 'rgba(255,255,255,0.35)';
        g.lineWidth = 1.5;
        const ph = time * 1.5 + tx * 0.7 + ty * 0.4;
        g.beginPath();
        g.moveTo(sx + ts * 0.15, sy + ts * 0.5 + Math.sin(ph) * ts * 0.06);
        g.quadraticCurveTo(sx + ts * 0.5, sy + ts * 0.35 + Math.sin(ph) * ts * 0.06, sx + ts * 0.85, sy + ts * 0.5 + Math.sin(ph) * ts * 0.06);
        g.stroke();
      } else if (t === T.GRASS || t === T.JUNGLE) {
        if (r > 0.7) {
          g.fillStyle = 'rgba(255,255,255,0.12)';
          g.fillRect(sx + ts * 0.3, sy + ts * 0.3, ts * 0.12, ts * 0.12);
        }
      } else if (t === T.ROAD || t === T.DIRT) {
        // tepi jalan
        const nb = (dx: number, dy: number) => {
          const nx = tx + dx;
          const ny = ty + dy;
          if (nx < 0 || ny < 0 || nx >= WORLD_W || ny >= WORLD_H) return t;
          return w.terrain[ny * WORLD_W + nx];
        };
        g.fillStyle = 'rgba(120,90,50,0.35)';
        if (nb(0, -1) !== t && nb(0, -1) !== T.BRIDGE) g.fillRect(sx, sy, size, Math.max(2, ts * 0.08));
        if (nb(0, 1) !== t && nb(0, 1) !== T.BRIDGE) g.fillRect(sx, sy + size - Math.max(2, ts * 0.08), size, Math.max(2, ts * 0.08));
        if (nb(-1, 0) !== t && nb(-1, 0) !== T.BRIDGE) g.fillRect(sx, sy, Math.max(2, ts * 0.08), size);
        if (nb(1, 0) !== t && nb(1, 0) !== T.BRIDGE) g.fillRect(sx + size - Math.max(2, ts * 0.08), sy, Math.max(2, ts * 0.08), size);
        if (r > 0.8) {
          g.fillStyle = 'rgba(255,255,255,0.16)';
          g.fillRect(sx + ts * 0.4, sy + ts * 0.5, ts * 0.12, ts * 0.08);
        }
      } else if (t === T.BRIDGE) {
        g.strokeStyle = 'rgba(70,40,15,0.6)';
        g.lineWidth = 1.5;
        for (let i = 1; i < 4; i++) {
          g.beginPath();
          g.moveTo(sx, sy + (ts * i) / 4);
          g.lineTo(sx + ts, sy + (ts * i) / 4);
          g.stroke();
        }
      } else if (t === T.CONCRETE) {
        g.strokeStyle = 'rgba(0,0,0,0.12)';
        g.lineWidth = 1;
        g.strokeRect(sx + 0.5, sy + 0.5, size - 1, size - 1);
      } else if (t === T.NEON) {
        g.strokeStyle = `rgba(${r > 0.5 ? '34,211,238' : '240,171,252'},${0.25 + 0.15 * Math.sin(time * 2 + tx)})`;
        g.lineWidth = 1.5;
        g.strokeRect(sx + 1, sy + 1, size - 2, size - 2);
      } else if (t === T.MARBLE) {
        if ((tx + ty) % 2 === 0) {
          g.fillStyle = 'rgba(0,0,0,0.05)';
          g.fillRect(sx, sy, size, size);
        }
      } else if (t === T.SNOW) {
        if (r > 0.85) {
          g.fillStyle = 'rgba(160,200,230,0.5)';
          g.fillRect(sx + ts * 0.4, sy + ts * 0.4, ts * 0.1, ts * 0.1);
        }
      } else if (t === T.ROCK) {
        if (r > 0.6) {
          g.fillStyle = 'rgba(0,0,0,0.1)';
          g.fillRect(sx + ts * 0.2, sy + ts * 0.5, ts * 0.5, ts * 0.12);
        }
      }
    }
  }
}

export function collectDeco(w: WorldData, v: WorldView, out: DrawEntity[]) {
  const { ts, vw, vh, camX, camY, time } = v;
  const x0 = Math.floor(camX - vw / ts / 2) - 1;
  const y0 = Math.floor(camY - vh / ts / 2) - 1;
  const x1 = Math.ceil(camX + vw / ts / 2) + 1;
  const y1 = Math.ceil(camY + vh / ts / 2) + 3;
  for (let ty = Math.max(0, y0); ty <= Math.min(WORLD_H - 1, y1); ty++) {
    for (let tx = Math.max(0, x0); tx <= Math.min(WORLD_W - 1, x1); tx++) {
      const k = ty * WORLD_W + tx;
      const d = w.deco[k];
      if (d === D.NONE) continue;
      const sx = (tx - camX) * ts + vw / 2;
      const sy = (ty - camY) * ts + vh / 2;
      const seed = Math.floor(hash2(tx, ty, 9) * 1000);
      const terrain = w.terrain[k];
      out.push({ y: ty + 0.9, draw: (g) => drawDeco(g, d, sx, sy, ts, time, terrain, seed) });
    }
  }
}

export function collectBuildings(
  w: WorldData,
  v: WorldView,
  discovered: boolean[],
  trophies: boolean[],
  out: DrawEntity[]
) {
  const { ts, vw, vh, camX, camY, time } = v;
  for (const b of w.buildings) {
    const sx = (b.x - camX) * ts + vw / 2;
    const sy = (b.y - camY) * ts + vh / 2;
    if (sx > vw + ts * 2 || sy > vh + ts * 2 || sx + b.w * ts < -ts * 2 || sy + b.h * ts < -ts * 2) continue;
    const disc = b.stadium === undefined ? true : Boolean(discovered[b.stadium]);
    const clr = b.stadium === undefined ? false : Boolean(trophies[b.stadium]);
    out.push({ y: b.kind === 'training' ? b.y - 5 : b.y + b.h - 0.05, draw: (g) => drawBuilding(g, b, sx, sy, ts, time, disc, clr) });
  }
}

export function drawPoiProp(g: CanvasRenderingContext2D, p: Poi, sx: number, sy: number, ts: number, opened: boolean) {
  if (p.kind === 'chest') {
    g.fillStyle = 'rgba(0,0,0,0.2)';
    g.beginPath();
    g.ellipse(sx + ts / 2, sy + ts * 0.9, ts * 0.3, ts * 0.1, 0, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = opened ? '#7c5a2a' : '#b9772c';
    g.fillRect(sx + ts * 0.2, sy + ts * 0.45, ts * 0.6, ts * 0.4);
    g.fillStyle = opened ? '#5b3f1c' : '#d99a3b';
    g.fillRect(sx + ts * 0.2, sy + ts * (opened ? 0.28 : 0.35), ts * 0.6, ts * (opened ? 0.1 : 0.2));
    g.fillStyle = '#fde047';
    g.fillRect(sx + ts * 0.46, sy + ts * 0.5, ts * 0.08, ts * 0.12);
  } else if (p.kind === 'sign') {
    g.fillStyle = '#6b4423';
    g.fillRect(sx + ts * 0.46, sy + ts * 0.5, ts * 0.08, ts * 0.4);
    g.fillStyle = '#c98a4a';
    g.fillRect(sx + ts * 0.15, sy + ts * 0.2, ts * 0.7, ts * 0.38);
    g.strokeStyle = '#6b4423';
    g.lineWidth = 1.5;
    g.strokeRect(sx + ts * 0.15, sy + ts * 0.2, ts * 0.7, ts * 0.38);
  } else if (p.kind === 'rest') {
    g.fillStyle = '#8b5a2b';
    g.fillRect(sx + ts * 0.1, sy + ts * 0.5, ts * 0.8, ts * 0.15);
    g.fillRect(sx + ts * 0.1, sy + ts * 0.3, ts * 0.8, ts * 0.1);
    g.fillRect(sx + ts * 0.15, sy + ts * 0.65, ts * 0.08, ts * 0.2);
    g.fillRect(sx + ts * 0.77, sy + ts * 0.65, ts * 0.08, ts * 0.2);
  }
}
