import { ArenaId, BallTypeId, GameOptions } from './types';

interface BgmTheme {
  bpm: number;
  wave: OscillatorType;
  bassWave: OscillatorType;
  melody: number[]; // MIDI note numbers (0 = rest)
  bass: number[];
}

const ARENA_BGM_THEMES: Record<ArenaId, BgmTheme> = {
  meadow_park: {
    bpm: 132,
    wave: 'triangle',
    bassWave: 'sine',
    melody: [72, 76, 79, 0, 76, 79, 84, 0, 81, 79, 76, 74, 72, 74, 76, 0],
    bass: [48, 0, 55, 0, 53, 0, 55, 0, 48, 0, 55, 0, 50, 0, 55, 0],
  },
  gbc_pixel_bowl: {
    bpm: 146,
    wave: 'square',
    bassWave: 'triangle',
    melody: [72, 72, 79, 79, 81, 81, 79, 0, 77, 77, 76, 76, 74, 74, 72, 0],
    bass: [48, 60, 48, 60, 53, 65, 55, 67, 53, 65, 52, 64, 50, 62, 48, 55],
  },
  futsal_court_blue: {
    bpm: 150,
    wave: 'square',
    bassWave: 'triangle',
    melody: [74, 74, 81, 81, 83, 83, 81, 0, 79, 79, 78, 78, 76, 76, 74, 0],
    bass: [50, 62, 50, 62, 55, 67, 57, 69, 55, 67, 54, 66, 52, 64, 50, 57],
  },
  futsal_court_orange: {
    bpm: 144,
    wave: 'square',
    bassWave: 'triangle',
    melody: [69, 69, 76, 76, 78, 78, 76, 0, 74, 74, 73, 73, 71, 71, 69, 0],
    bass: [45, 57, 45, 57, 50, 62, 52, 64, 50, 62, 49, 61, 47, 59, 45, 52],
  },
  neon_dome: {
    bpm: 138,
    wave: 'sawtooth',
    bassWave: 'sawtooth',
    melody: [69, 0, 72, 76, 79, 0, 76, 74, 72, 0, 74, 76, 71, 0, 74, 0],
    bass: [45, 45, 57, 45, 48, 48, 60, 48, 43, 43, 55, 43, 40, 40, 52, 40],
  },
  volcano_caldera: {
    bpm: 140,
    wave: 'sawtooth',
    bassWave: 'square',
    melody: [64, 65, 68, 0, 71, 69, 68, 64, 65, 68, 71, 0, 76, 74, 71, 0],
    bass: [40, 0, 40, 47, 41, 0, 41, 48, 40, 0, 40, 47, 43, 0, 40, 0],
  },
  glacier_rink: {
    bpm: 124,
    wave: 'sine',
    bassWave: 'triangle',
    melody: [76, 79, 83, 0, 84, 83, 79, 76, 74, 78, 81, 0, 79, 76, 74, 0],
    bass: [52, 0, 59, 0, 48, 0, 55, 0, 50, 0, 57, 0, 55, 0, 52, 0],
  },
  tropical_beach: {
    bpm: 126,
    wave: 'triangle',
    bassWave: 'sine',
    melody: [74, 77, 81, 79, 77, 74, 72, 0, 74, 76, 79, 81, 79, 76, 74, 0],
    bass: [50, 0, 57, 50, 53, 0, 48, 55, 50, 0, 57, 50, 55, 0, 50, 0],
  },
  sakura_shrine: {
    bpm: 120,
    wave: 'sine',
    bassWave: 'triangle',
    melody: [74, 76, 79, 83, 81, 79, 76, 0, 74, 71, 74, 76, 79, 76, 74, 0],
    bass: [50, 0, 55, 0, 57, 0, 52, 0, 47, 0, 50, 0, 55, 0, 50, 0],
  },
  desert_oasis: {
    bpm: 134,
    wave: 'triangle',
    bassWave: 'sawtooth',
    melody: [69, 70, 73, 74, 76, 74, 73, 70, 69, 73, 74, 77, 76, 74, 73, 0],
    bass: [45, 45, 52, 45, 46, 46, 53, 46, 45, 45, 52, 45, 43, 0, 45, 0],
  },
  sky_citadel: {
    bpm: 136,
    wave: 'triangle',
    bassWave: 'sine',
    melody: [76, 81, 83, 88, 86, 83, 81, 79, 76, 79, 83, 86, 84, 83, 81, 0],
    bass: [52, 0, 59, 64, 50, 0, 57, 62, 48, 0, 55, 60, 55, 0, 52, 0],
  },
  jungle_temple: {
    bpm: 128,
    wave: 'square',
    bassWave: 'triangle',
    melody: [67, 70, 72, 74, 75, 74, 72, 70, 67, 72, 74, 79, 77, 74, 72, 0],
    bass: [43, 0, 43, 50, 46, 0, 48, 55, 43, 0, 43, 50, 41, 0, 43, 0],
  },
  candy_kingdom: {
    bpm: 136,
    wave: 'triangle',
    bassWave: 'sine',
    melody: [76, 79, 83, 84, 83, 79, 76, 0, 74, 77, 81, 83, 81, 77, 74, 0],
    bass: [48, 60, 55, 60, 53, 65, 55, 67, 50, 62, 55, 62, 48, 55, 52, 0],
  },
  floating_isles: {
    bpm: 112,
    wave: 'triangle',
    bassWave: 'sine',
    melody: [74, 77, 81, 84, 81, 77, 74, 0, 72, 76, 79, 83, 81, 79, 76, 0],
    bass: [50, 0, 57, 0, 48, 0, 55, 0, 53, 0, 60, 0, 52, 0, 59, 0],
  },
  rooftop_skyline: {
    bpm: 124,
    wave: 'square',
    bassWave: 'sawtooth',
    melody: [69, 0, 72, 76, 74, 0, 72, 69, 67, 0, 71, 74, 72, 0, 69, 0],
    bass: [45, 45, 0, 45, 43, 43, 0, 43, 41, 41, 0, 41, 43, 43, 45, 0],
  },
  grand_championship: {
    bpm: 142,
    wave: 'sawtooth',
    bassWave: 'triangle',
    melody: [72, 0, 76, 79, 84, 0, 83, 84, 86, 84, 83, 79, 81, 79, 76, 0],
    bass: [48, 48, 55, 48, 53, 53, 60, 53, 55, 55, 62, 55, 48, 55, 60, 0],
  },
};

function midiToFreq(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

class GameAudio {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private bgmGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private bgmTimer: number | null = null;
  private bgmStep = 0;
  private currentArena: ArenaId | null = null;
  private paused = false;
  /** Aplikasi di latar belakang / diminimalkan: semua suara dihentikan */
  private backgrounded = false;
  private rainSource: AudioBufferSourceNode | null = null;
  private rainGain: GainNode | null = null;
  private rainWanted = false;

  public muted = false;
  public bgmEnabled = true;
  public bgmVolume = 0.8;
  public sfxEnabled = true;
  public sfxVolume = 0.85;

  private get effectiveBgmGain(): number {
    return this.muted || this.paused || !this.bgmEnabled ? 0 : 0.065 * Math.max(0, Math.min(1, this.bgmVolume));
  }

  private get effectiveSfxGain(): number {
    return this.muted || !this.sfxEnabled ? 0 : Math.max(0, Math.min(1, this.sfxVolume));
  }

  private get effectiveRainGain(): number {
    return this.muted || this.paused || !this.rainWanted || !this.sfxEnabled
      ? 0
      : 0.045 * Math.max(0, Math.min(1, this.sfxVolume));
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || this.backgrounded || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    if (!this.bgmGain && this.ctx) {
      this.bgmGain = this.ctx.createGain();
      this.bgmGain.gain.value = this.effectiveBgmGain;
      this.bgmGain.connect(this.ctx.destination);
    }
    if (!this.sfxGain && this.ctx) {
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.effectiveSfxGain;
      this.sfxGain.connect(this.ctx.destination);
    }
    if (!this.noiseBuffer && this.ctx) {
      const len = Math.floor(this.ctx.sampleRate * 2.0);
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      let b0 = 0;
      let b1 = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        b0 = 0.96 * b0 + w * 0.04;
        b1 = 0.85 * b1 + w * 0.15;
        data[i] = w * 0.45 + b1 * 0.35 + b0 * 0.2;
      }
      this.noiseBuffer = buf;
    }
    return this.ctx;
  }

  private getSfxTarget(): { ctx: AudioContext; out: AudioNode } | null {
    if (!this.sfxEnabled || this.sfxVolume <= 0.005) return null;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return null;
    return { ctx, out: this.sfxGain };
  }

  public unlock() {
    this.ensureContext();
  }

  public applyOptions(opts: Pick<GameOptions, 'bgmEnabled' | 'bgmVolume' | 'sfxEnabled' | 'sfxVolume'>) {
    this.bgmEnabled = opts.bgmEnabled;
    this.bgmVolume = opts.bgmVolume;
    this.sfxEnabled = opts.sfxEnabled;
    this.sfxVolume = opts.sfxVolume;

    if (this.ctx) {
      if (this.bgmGain) {
        this.bgmGain.gain.setTargetAtTime(this.effectiveBgmGain, this.ctx.currentTime, 0.04);
      }
      if (this.sfxGain) {
        this.sfxGain.gain.setTargetAtTime(this.effectiveSfxGain, this.ctx.currentTime, 0.03);
      }
      if (this.rainGain) {
        this.rainGain.gain.setTargetAtTime(this.effectiveRainGain, this.ctx.currentTime, 0.08);
      }
    }
    if (!this.bgmEnabled) {
      this.stopBgmTimerOnly();
    } else if (this.currentArena && !this.paused && !this.muted && this.bgmTimer === null) {
      this.startBgm(this.currentArena);
    }
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (this.ctx) {
      if (this.bgmGain) {
        this.bgmGain.gain.setTargetAtTime(this.effectiveBgmGain, this.ctx.currentTime, 0.04);
      }
      if (this.sfxGain) {
        this.sfxGain.gain.setTargetAtTime(this.effectiveSfxGain, this.ctx.currentTime, 0.04);
      }
      if (this.rainGain) {
        this.rainGain.gain.setTargetAtTime(this.effectiveRainGain, this.ctx.currentTime, 0.08);
      }
    }
    if (muted) {
      this.stopBgm();
    } else if (this.currentArena && !this.paused && this.bgmEnabled) {
      this.startBgm(this.currentArena);
    }
  }

  /** Dipanggil saat tab/aplikasi disembunyikan atau kembali tampil. */
  public setBackgrounded(bg: boolean) {
    this.backgrounded = bg;
    if (!this.ctx) return;
    if (bg) {
      this.ctx.suspend().catch(() => {});
    } else if (!this.muted) {
      this.ctx.resume().catch(() => {});
    }
  }

  public setPaused(paused: boolean) {
    this.paused = paused;
    if (this.ctx) {
      if (this.bgmGain) {
        this.bgmGain.gain.setTargetAtTime(this.effectiveBgmGain, this.ctx.currentTime, 0.05);
      }
      if (this.rainGain) {
        this.rainGain.gain.setTargetAtTime(this.effectiveRainGain, this.ctx.currentTime, 0.08);
      }
    }
  }

  public setRaining(active: boolean) {
    this.rainWanted = active;
    if (this.muted || !active || !this.sfxEnabled) {
      if (this.rainGain && this.ctx) {
        this.rainGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.12);
      }
      return;
    }
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;
    if (!this.rainSource) {
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer;
      src.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 1850;
      filter.Q.value = 0.6;

      const gain = ctx.createGain();
      gain.gain.value = 0;

      src.connect(filter).connect(gain).connect(ctx.destination);
      src.start();
      this.rainSource = src;
      this.rainGain = gain;
    }
    if (this.rainGain) {
      this.rainGain.gain.setTargetAtTime(this.effectiveRainGain, ctx.currentTime, 0.18);
    }
  }

  private stopBgmTimerOnly() {
    if (this.bgmTimer !== null && typeof window !== 'undefined') {
      window.clearInterval(this.bgmTimer);
      this.bgmTimer = null;
    }
  }

  public startBgm(arenaId: ArenaId) {
    this.currentArena = arenaId;
    if (this.muted || !this.bgmEnabled || typeof window === 'undefined') return;
    this.stopBgmTimerOnly();

    const theme = ARENA_BGM_THEMES[arenaId] ?? ARENA_BGM_THEMES.meadow_park;
    const stepMs = (60 / theme.bpm / 2) * 1000;
    this.bgmStep = 0;

    const triggerStep = () => {
      if (this.muted || this.paused || !this.bgmEnabled) return;
      const ctx = this.ensureContext();
      if (!ctx || !this.bgmGain || ctx.state !== 'running') return;

      const idx = this.bgmStep % theme.melody.length;
      this.bgmStep++;
      const t = ctx.currentTime + 0.02;
      const dur = Math.min(0.22, stepMs / 1000);

      const mNote = theme.melody[idx];
      if (mNote > 0) {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = theme.wave;
        osc.frequency.setValueAtTime(midiToFreq(mNote), t);
        g.gain.setValueAtTime(0.45, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + dur * 0.92);
        osc.connect(g).connect(this.bgmGain);
        osc.start(t);
        osc.stop(t + dur);
      }

      const bNote = theme.bass[idx];
      if (bNote > 0) {
        const oscB = ctx.createOscillator();
        const gB = ctx.createGain();
        oscB.type = theme.bassWave;
        oscB.frequency.setValueAtTime(midiToFreq(bNote), t);
        gB.gain.setValueAtTime(0.55, t);
        gB.gain.exponentialRampToValueAtTime(0.001, t + dur * 0.95);
        oscB.connect(gB).connect(this.bgmGain);
        oscB.start(t);
        oscB.stop(t + dur);
      }
    };

    this.bgmTimer = window.setInterval(triggerStep, stepMs);
  }

  public stopBgm() {
    this.stopBgmTimerOnly();
    this.setRaining(false);
  }

  public playJump() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(190, t);
    osc.frequency.exponentialRampToValueAtTime(410, t + 0.11);
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.14);
  }

  public playSpinKick() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(240, t);
    osc.frequency.linearRampToValueAtTime(480, t + 0.08);
    osc.frequency.linearRampToValueAtTime(180, t + 0.2);
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.23);
  }

  public playRubberKick(intensity = 0.7) {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    const base = 150 + Math.random() * 25;
    osc.frequency.setValueAtTime(base, t);
    osc.frequency.exponentialRampToValueAtTime(base * 2.4, t + 0.06);
    osc.frequency.exponentialRampToValueAtTime(75, t + 0.16);
    gain.gain.setValueAtTime(0.22 * intensity, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.19);
  }

  public playBallBounce(intensity = 0.6, ballType: BallTypeId = 'soccer') {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const vol = Math.min(0.24, Math.max(0.05, intensity * 0.22));
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (ballType === 'metal') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, t);
      osc.frequency.exponentialRampToValueAtTime(52, t + 0.16);
      gain.gain.setValueAtTime(vol * 1.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.17);
      osc.connect(gain).connect(out);
      osc.start(t);
      osc.stop(t + 0.18);
    } else if (ballType === 'crystal') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1180, t);
      osc.frequency.exponentialRampToValueAtTime(740, t + 0.12);
      gain.gain.setValueAtTime(vol * 0.85, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);
      osc.connect(gain).connect(out);
      osc.start(t);
      osc.stop(t + 0.14);
    } else if (ballType === 'hockey' || ballType === 'flat_disc' || ballType === 'dice') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(ballType === 'dice' ? 520 : ballType === 'hockey' ? 420 : 340, t);
      osc.frequency.exponentialRampToValueAtTime(145, t + 0.055);
      gain.gain.setValueAtTime(vol * 0.9, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
      osc.connect(gain).connect(out);
      osc.start(t);
      osc.stop(t + 0.07);
    } else if (ballType === 'honey_ball') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(130, t);
      osc.frequency.exponentialRampToValueAtTime(52, t + 0.08);
      gain.gain.setValueAtTime(vol * 0.75, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      osc.connect(gain).connect(out);
      osc.start(t);
      osc.stop(t + 0.1);
    } else if (ballType === 'rubber' || ballType === 'beach_volleyball' || ballType === 'ostrich_egg') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(ballType === 'rubber' ? 280 : ballType === 'ostrich_egg' ? 240 : 220, t);
      osc.frequency.exponentialRampToValueAtTime(125, t + 0.14);
      gain.gain.setValueAtTime(vol, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      osc.connect(gain).connect(out);
      osc.start(t);
      osc.stop(t + 0.16);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(165, t);
      osc.frequency.exponentialRampToValueAtTime(62, t + 0.09);
      gain.gain.setValueAtTime(vol, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      osc.connect(gain).connect(out);
      osc.start(t);
      osc.stop(t + 0.11);
    }
  }

  public playWaterSplash(intensity = 0.6) {
    const s = this.getSfxTarget();
    if (!s || !this.noiseBuffer) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(1400, t);
    filter.frequency.exponentialRampToValueAtTime(500, t + 0.22);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.14 * Math.max(0.4, intensity), t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.24);

    src.connect(filter).connect(gain).connect(out);
    src.start(t);
    src.stop(t + 0.25);
  }

  public playClash() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc2.type = 'square';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(45, t + 0.35);
    osc2.frequency.setValueAtTime(520, t);
    osc2.frequency.exponentialRampToValueAtTime(180, t + 0.3);
    gain.gain.setValueAtTime(0.28, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.36);
    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(out);
    osc.start(t);
    osc2.start(t);
    osc.stop(t + 0.37);
    osc2.stop(t + 0.37);
  }

  public playJellyPost() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(280, t);
    osc.frequency.linearRampToValueAtTime(360, t + 0.06);
    osc.frequency.linearRampToValueAtTime(240, t + 0.12);
    osc.frequency.linearRampToValueAtTime(310, t + 0.18);
    osc.frequency.exponentialRampToValueAtTime(140, t + 0.3);
    gain.gain.setValueAtTime(0.22, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.33);
  }

  public playGoal() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;

    if (this.noiseBuffer) {
      const crowdSrc = ctx.createBufferSource();
      crowdSrc.buffer = this.noiseBuffer;
      crowdSrc.loop = true;

      const crowdFilter = ctx.createBiquadFilter();
      crowdFilter.type = 'bandpass';
      crowdFilter.frequency.setValueAtTime(620, t);
      crowdFilter.frequency.linearRampToValueAtTime(1180, t + 0.45);
      crowdFilter.frequency.linearRampToValueAtTime(840, t + 1.85);
      crowdFilter.Q.value = 1.1;

      const crowdGain = ctx.createGain();
      crowdGain.gain.setValueAtTime(0.001, t);
      crowdGain.gain.linearRampToValueAtTime(0.28, t + 0.18);
      crowdGain.gain.setValueAtTime(0.24, t + 1.1);
      crowdGain.gain.exponentialRampToValueAtTime(0.001, t + 2.05);

      crowdSrc.connect(crowdFilter).connect(crowdGain).connect(out);
      crowdSrc.start(t);
      crowdSrc.stop(t + 2.1);
    }

    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const start = t + i * 0.085;
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.14, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.34);
      osc.connect(gain).connect(out);
      osc.start(start);
      osc.stop(start + 0.36);
    });
  }

  public playWhistle() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(2350, t);
    osc.frequency.setValueAtTime(2550, t + 0.06);
    osc.frequency.setValueAtTime(2350, t + 0.12);
    gain.gain.setValueAtTime(0.11, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.29);
  }

  public playItemPickup() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, t);
    osc.frequency.setValueAtTime(660, t + 0.06);
    osc.frequency.setValueAtTime(880, t + 0.12);
    gain.gain.setValueAtTime(0.16, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.26);
  }

  public playExplosion() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, t);
    osc.frequency.exponentialRampToValueAtTime(28, t + 0.38);
    gain.gain.setValueAtTime(0.28, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.42);
  }

  public playPunchHit(charge = 0.5) {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(170 + charge * 90, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 0.24);
    gain.gain.setValueAtTime(0.24 + charge * 0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.26);
  }

  public playPropGrab() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(260, t);
    osc.frequency.exponentialRampToValueAtTime(440, t + 0.08);
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.11);
  }

  public playPropBreak() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    if (this.noiseBuffer) {
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(950, t);
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0.26, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
      src.connect(filter).connect(nGain).connect(out);
      src.start(t);
      src.stop(t + 0.25);
    }
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(210, t);
    osc.frequency.exponentialRampToValueAtTime(65, t + 0.16);
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.19);
  }

  public playBallKickImpact(intensity = 0.7, ballType: BallTypeId = 'soccer', isFire = false) {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const clamped = Math.max(0.25, Math.min(1.2, intensity));

    // Punchy low-end ball body thump
    const bodyOsc = ctx.createOscillator();
    const bodyGain = ctx.createGain();
    const startHz =
      ballType === 'metal'
        ? 110
        : ballType === 'beach_volleyball' || ballType === 'rubber'
          ? 240
          : ballType === 'honey_ball'
            ? 145
            : 185;
    bodyOsc.type = ballType === 'dice' ? 'triangle' : 'sine';
    bodyOsc.frequency.setValueAtTime(startHz + clamped * 45, t);
    bodyOsc.frequency.exponentialRampToValueAtTime(48, t + 0.11);
    bodyGain.gain.setValueAtTime(0.24 * clamped, t);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);
    bodyOsc.connect(bodyGain).connect(out);
    bodyOsc.start(t);
    bodyOsc.stop(t + 0.14);

    // Crisp leather/surface transient noise snap
    if (this.noiseBuffer) {
      const nSrc = ctx.createBufferSource();
      nSrc.buffer = this.noiseBuffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(isFire ? 2400 : 1450, t);
      filter.Q.value = 1.4;
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime((isFire ? 0.22 : 0.14) * clamped, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + (isFire ? 0.18 : 0.08));
      nSrc.connect(filter).connect(nGain).connect(out);
      nSrc.start(t);
      nSrc.stop(t + (isFire ? 0.19 : 0.09));
    }
  }

  public playBallRollTick(speed: number, ballType: BallTypeId = 'soccer') {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const vol = Math.min(0.045, Math.max(0.01, (speed - 2) * 0.0045));
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = ballType === 'dice' ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(ballType === 'dice' ? 280 : ballType === 'metal' ? 140 : 115, t);
    osc.frequency.exponentialRampToValueAtTime(55, t + 0.035);
    gain.gain.setValueAtTime(vol, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.045);
  }

  public playHoneySquelch() {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(190, t);
    osc.frequency.exponentialRampToValueAtTime(340, t + 0.06);
    osc.frequency.exponentialRampToValueAtTime(150, t + 0.13);
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.15);
  }

  public playBombTick(urgency = 0.5) {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(880 + urgency * 440, t);
    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.045);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.05);
  }

  public playVoiceChirp(pitchBase = 420, emotion: 'happy' | 'angry' | 'surprised' | 'confident' | 'neutral' = 'neutral') {
    const s = this.getSfxTarget();
    if (!s) return;
    const { ctx, out } = s;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = emotion === 'angry' ? 'sawtooth' : 'triangle';
    const f0 =
      emotion === 'angry'
        ? pitchBase * 0.78
        : emotion === 'surprised'
          ? pitchBase * 1.18
          : emotion === 'happy'
            ? pitchBase * 1.12
            : pitchBase;
    const f1 =
      emotion === 'angry'
        ? f0 * 0.85
        : emotion === 'surprised'
          ? f0 * 1.32
          : emotion === 'happy'
            ? f0 * 1.2
            : f0 * 1.06;
    osc.frequency.setValueAtTime(f0, t);
    osc.frequency.exponentialRampToValueAtTime(f1, t + 0.055);
    gain.gain.setValueAtTime(0.055, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.065);
    osc.connect(gain).connect(out);
    osc.start(t);
    osc.stop(t + 0.07);
  }
}

export const gameAudio = new GameAudio();
