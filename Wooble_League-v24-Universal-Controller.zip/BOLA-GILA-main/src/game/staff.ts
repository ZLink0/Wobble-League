import * as THREE from 'three';
import { createStaffSpriteTexture, type StaffSpriteKind } from './textures';

type Team = 'red' | 'blue';

export interface StaffRig {
  group: THREE.Group;
  disposables: Array<{ dispose: () => void }>;
  /**
   * t = waktu, scoringTeam = tim yang baru mencetak gol (atau null), excite 0..1 = keramaian,
   * camPos = posisi kamera (agar sprite 2D selalu menghadap kamera)
   */
  update: (t: number, scoringTeam: Team | null, excite: number, camPos?: THREE.Vector3) => void;
}

interface StaffParams {
  pitchHalfX: number;
  pitchHalfZ: number;
  goalDepth: number;
  benchXs: [number, number]; // [merah, biru]
  benchZ: number;
  seats: Array<{ x: number; y: number; z: number }>;
}

/** Jumlah bendera penonton: 4 merah + 4 biru, dibagi rata di empat sudut tribun (2 per sudut) */
export const FLAGS_PER_TEAM = 4;

const SPRITE_W = 1.15;
const SPRITE_H = 1.725; // rasio 128:192

interface Sprite2D {
  root: THREE.Group; // posisi + hadap kamera (rotasi Y)
  body: THREE.Mesh; // bidang sprite (bisa miring/gepeng/dibalik)
}

/** Sprite 2D berdiri, titik tumpu di kaki. */
function makeSprite(
  disposables: Array<{ dispose: () => void }>,
  kind: StaffSpriteKind,
  height: number
): Sprite2D {
  const tex = createStaffSpriteTexture(kind);
  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    alphaTest: 0.35,
    side: THREE.DoubleSide,
  });
  const w = (SPRITE_W / SPRITE_H) * height;
  const geo = new THREE.PlaneGeometry(w, height);
  geo.translate(0, height / 2, 0);
  const body = new THREE.Mesh(geo, mat);

  // bayangan bulat di tanah
  const shadowGeo = new THREE.CircleGeometry(w * 0.36, 16);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.28, depthWrite: false });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.03;
  shadow.scale.z = 0.6;

  const root = new THREE.Group();
  root.add(shadow, body);
  disposables.push(tex, mat, geo, shadowGeo, shadowMat);
  return { root, body };
}

export function buildStaff(params: StaffParams): StaffRig {
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];
  const { pitchHalfX, goalDepth, benchXs, benchZ, seats } = params;

  // ---------- Pelatih merah & biru (2D) dekat bangku masing-masing ----------
  interface Coach {
    sprite: Sprite2D;
    team: Team;
    cx: number;
    z: number;
    phase: number;
  }
  const coaches: Coach[] = [];
  (['red', 'blue'] as const).forEach((team, idx) => {
    const sprite = makeSprite(disposables, team === 'red' ? 'coach_red' : 'coach_blue', 1.9);
    const z = benchZ - 0.95;
    sprite.root.position.set(benchXs[idx], 0, z);
    group.add(sprite.root);
    coaches.push({ sprite, team, cx: benchXs[idx], z, phase: idx * 1.7 });
  });

  // ---------- Petugas keamanan: tepat 1 orang di belakang tiap gawang (2D, berpatroli) ----------
  interface Guard {
    sprite: Sprite2D;
    gx: number;
    phase: number;
  }
  const guards: Guard[] = [];
  for (const side of [-1, 1] as const) {
    // Dekatkan ke penonton: berdiri tepat di depan tribun ujung (sejajar tengah gawang)
    let nearestSeat = Infinity;
    for (const st of seats) {
      if (Math.sign(st.x) === side && Math.abs(st.z) < 4) nearestSeat = Math.min(nearestSeat, Math.abs(st.x));
    }
    const defaultX = pitchHalfX + goalDepth + 1.1;
    const gx = side * (Number.isFinite(nearestSeat) ? Math.max(defaultX, nearestSeat - 1.0) : defaultX + 2.2);
    const sprite = makeSprite(disposables, side < 0 ? 'guard_bear' : 'guard_wolf', 1.95);
    sprite.root.position.set(gx, 0, 0);
    group.add(sprite.root);
    guards.push({ sprite, gx, phase: side < 0 ? 0 : 2.4 });
  }
  const GUARD_PATROL = 3.4; // jarak patroli ke kiri/kanan dari tengah gawang

  // ---------- Bendera penonton: 8 saja (4 merah + 4 biru), di sudut-sudut tribun ----------
  let maxAbsX = 0;
  let maxAbsZ = 0;
  for (const s of seats) {
    maxAbsX = Math.max(maxAbsX, Math.abs(s.x));
    maxAbsZ = Math.max(maxAbsZ, Math.abs(s.z));
  }
  const flagSeats: Array<{ x: number; y: number; z: number }> = [];
  const flagTeam: Team[] = [];
  if (seats.length > 0) {
    for (const sx of [-1, 1] as const) {
      for (const sz of [-1, 1] as const) {
        // Titik sudut tribun (bentuk tribun melingkar: sudut ~84% dari jari-jari)
        const tx = sx * maxAbsX * 0.84;
        const tz = sz * maxAbsZ * 0.84;
        const sorted = [...seats].sort(
          (a, b) => Math.hypot(a.x - tx, a.z - tz) - Math.hypot(b.x - tx, b.z - tz)
        );
        const first = sorted[0];
        const second = sorted.find((c) => Math.hypot(c.x - first.x, c.z - first.z) >= 1.8) ?? sorted[1] ?? first;
        flagSeats.push(first, second);
        flagTeam.push('red', 'blue'); // tiap sudut: 1 merah + 1 biru => total 4 merah, 4 biru
      }
    }
  }
  const flagCount = flagSeats.length;
  const FLAG_SCALE = 1.5; // hanya 8, jadi dibuat lebih besar agar jelas terlihat
  const poleGeo = new THREE.CylinderGeometry(0.025, 0.025, 1.5, 6);
  const poleMat = new THREE.MeshStandardMaterial({ color: '#e5e7eb', roughness: 0.5 });
  const flagGeo = new THREE.PlaneGeometry(0.72, 0.46);
  const flagMat = new THREE.MeshBasicMaterial({ color: '#ffffff', side: THREE.DoubleSide });
  disposables.push(poleGeo, poleMat, flagGeo, flagMat);
  const poles = new THREE.InstancedMesh(poleGeo, poleMat, Math.max(1, flagCount));
  const flags = new THREE.InstancedMesh(flagGeo, flagMat, Math.max(1, flagCount));
  poles.frustumCulled = false;
  flags.frustumCulled = false;
  poles.count = flagCount;
  flags.count = flagCount;
  const red = new THREE.Color('#ef4444');
  const blue = new THREE.Color('#2563eb');
  flagTeam.forEach((team, i) => flags.setColorAt(i, team === 'red' ? red : blue));
  if (flags.instanceColor) flags.instanceColor.needsUpdate = true;
  group.add(poles, flags);
  const dummy = new THREE.Object3D();

  const update = (t: number, scoringTeam: Team | null, excite: number, camPos?: THREE.Vector3) => {
    const face = (root: THREE.Group) => {
      if (camPos) root.rotation.y = Math.atan2(camPos.x - root.position.x, camPos.z - root.position.z);
    };

    // Pelatih: mondar-mandir; melompat saat timnya mencetak gol; lesu saat timnya kebobolan
    for (const c of coaches) {
      const s = c.sprite;
      const w = t * 0.45 + c.phase;
      const px = c.cx + Math.sin(w) * 1.5;
      const dir = Math.cos(w) >= 0 ? 1 : -1;
      s.root.position.x = px;
      s.root.position.z = c.z;
      face(s.root);
      if (scoringTeam === c.team) {
        // Merayakan: lompat tinggi + goyang
        const hop = Math.abs(Math.sin(t * 9));
        s.body.position.y = hop * 0.55;
        s.body.scale.set(dir, 1 + hop * 0.08, 1);
        s.body.rotation.z = Math.sin(t * 14) * 0.12;
      } else if (scoringTeam !== null) {
        // Kecewa: badan membungkuk lesu
        s.body.position.y = 0;
        s.body.scale.set(dir, 0.9, 1);
        s.body.rotation.z = Math.sin(t * 2) * 0.05 + 0.1 * dir;
      } else {
        // Berjalan: hentakan kecil + miring mengikuti langkah
        const step = Math.abs(Math.sin(t * 5 + c.phase));
        s.body.position.y = step * 0.07;
        s.body.scale.set(dir, 1 - step * 0.02, 1);
        s.body.rotation.z = Math.sin(t * 5 + c.phase) * 0.05;
        // sesekali berteriak/menunjuk: lonjakan kecil
        const shout = Math.sin(t * 0.8 + c.phase * 2) > 0.55;
        if (shout) s.body.position.y += Math.abs(Math.sin(t * 7)) * 0.08;
      }
    }

    // Petugas keamanan: 1 orang per gawang, berpatroli menyusuri garis gawang
    for (const g of guards) {
      const s = g.sprite;
      const w = t * 0.4 + g.phase;
      const z = Math.sin(w) * GUARD_PATROL;
      const dir = Math.cos(w) >= 0 ? 1 : -1;
      s.root.position.set(g.gx, 0, z);
      face(s.root);
      const step = Math.abs(Math.sin(t * 4.2 + g.phase));
      s.body.position.y = step * 0.06;
      s.body.scale.set(dir, 1 - step * 0.015, 1);
      s.body.rotation.z = Math.sin(t * 4.2 + g.phase) * 0.045;
    }

    // Bendera penonton: berkibar; lebih heboh saat gol (dua tim) dan makin tinggi saat keramaian
    const boost = 1 + excite * 1.4;
    const k = FLAG_SCALE;
    for (let i = 0; i < flagCount; i++) {
      const s = flagSeats[i];
      const ph = i * 0.77;
      const celebrate = scoringTeam !== null && flagTeam[i] === scoringTeam ? 1 : 0;
      const sway = Math.sin(t * 3.2 * boost + ph) * (0.14 + celebrate * 0.22) * boost;
      const base = s.y + 0.78 + 0.55;
      dummy.position.set(s.x, base + 0.75 * k + celebrate * 0.15, s.z);
      dummy.rotation.set(0, 0, sway);
      dummy.scale.set(k, k, k);
      dummy.updateMatrix();
      poles.setMatrixAt(i, dummy.matrix);

      dummy.position.set(
        s.x + 0.38 * k * Math.cos(sway),
        base + 1.25 * k + celebrate * 0.15 - 0.38 * k * Math.sin(sway) * 0.2,
        s.z
      );
      dummy.rotation.set(Math.sin(t * 6 + ph) * 0.12, Math.sin(t * 7 * boost + ph) * 0.55, sway);
      dummy.scale.set((0.85 + 0.15 * Math.sin(t * 9 + ph)) * k, k, k);
      dummy.updateMatrix();
      flags.setMatrixAt(i, dummy.matrix);
    }
    poles.instanceMatrix.needsUpdate = true;
    flags.instanceMatrix.needsUpdate = true;
  };

  update(0, null, 0);
  return { group, disposables, update };
}
