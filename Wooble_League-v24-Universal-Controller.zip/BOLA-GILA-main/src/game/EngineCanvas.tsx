import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from './environment';
import { ARENAS, BALLS, DEFAULT_CONTROL_MAPPING } from './catalog';
import { gameAudio } from './audio';
import {
  ArenaRig,
  BallRig,
  buildArena3D,
  buildBall3D,
  buildCharacterRig,
  buildItemPickupModels,
  buildBullMesh,
  buildPropMesh,
  syncBullRig,
  type BullRig,
  CharacterRig,
  PropRig,
  syncArenaGoalNets,
  syncArenaSpectators,
  syncArenaWeather,
  syncBallRig,
  syncCharacterRig,
  syncJellyGoalPosts,
  syncPropRig,
  updateBallTextureAndShape,
} from './models';
import {
  createMatchSimulation,
  getDisplayClock,
  HALF_BREAK_SECONDS,
  PITCH_HALF_X,
  PITCH_HALF_Z,
  resetPositionsForKickoff,
  stepSimulation,
} from './physics';
import {
  computeReplayCameraPose,
  ReplayBundle,
  ReplayCameraAngle,
  ReplayFrame,
  ReplayRecorder,
  sampleReplayFrame,
} from './replay';
import { createContactShadowTexture } from './textures';
import { gamepadManager } from './gamepadManager';
import {
  CenterItemType,
  ControlMapping,
  GameScreenState,
  GrassPatternId,
  InputFrame,
  MatchConfig,
  MatchSimulation,
  NetStyleId,
  TeamId,
} from './types';

export interface HudSnapshot {
  redScore: number;
  blueScore: number;
  timeRemaining: number;
  currentHalf: 1 | 2;
  /** Jumlah babak pada pertandingan ini (1 atau 2), untuk tampilan "1/2" di papan skor */
  totalHalves?: 1 | 2;
  halfTimeBanner: boolean;
  goldenGoal?: boolean;
  breakSeconds?: number;
  goalBannerTeam: TeamId | null;
  matchEnded: boolean;
  bombCountdown: number | null;
  p1CarryingProp: boolean;
  p1PunchCharge: number;
  p1KickCharge: number;
  isGoalReplay: boolean;
}

export interface VirtualPadState {
  moveX: number;
  moveZ: number;
  kick: boolean;
  kickRightSpin: boolean;
  grabProp: boolean;
  jump: boolean;
  headSpinLeft: boolean;
  dash: boolean;
}

interface EngineCanvasProps {
  screenState: GameScreenState;
  config: MatchConfig;
  controls: ControlMapping;
  virtualPadRef: React.MutableRefObject<VirtualPadState>;
  matchNonce: number;
  lanRoomCode: string | null;
  lanRole: 'host' | 'guest' | null;
  onHudUpdate: (snap: HudSnapshot) => void;
  onMatchEnd: (redScore: number, blueScore: number) => void;
  onReplayAvailable?: (bundle: ReplayBundle) => void;
  skipGoalReplayRef?: React.MutableRefObject<(() => void) | null>;
  replayActive?: boolean;
  replayFrame?: ReplayFrame | null;
  replayCameraAngle?: ReplayCameraAngle;
  replayFocusTeam?: TeamId | null;
}

interface ParticleSlot {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
  color: THREE.Color;
}

interface RainDropSlot {
  x: number;
  y: number;
  z: number;
  speed: number;
}

const MAX_PARTICLES = 120;
const MAX_RAIN_DROPS = 220;
const MAX_SNOW_FLAKES = 200;
const _dummy = new THREE.Object3D();
const _rainDummy = new THREE.Object3D();
const _snowDummy = new THREE.Object3D();
const _sparkDummy = new THREE.Object3D();
const _sparkQuat = new THREE.Quaternion();
const _sparkDir = new THREE.Vector3();
const _sparkZ = new THREE.Vector3(0, 0, 1);
const _sparkColor = new THREE.Color();

const isMenuScreen = (st: GameScreenState): boolean =>
  st === 'title' ||
  st === 'setup' ||
  st === 'match_settings' ||
  st === 'character_custom' ||
  st === 'multiplayer_split' ||
  st === 'match_preview';

export function EngineCanvas({
  screenState,
  config,
  controls,
  virtualPadRef,
  matchNonce,
  lanRoomCode,
  lanRole,
  onHudUpdate,
  onMatchEnd,
  onReplayAvailable,
  skipGoalReplayRef,
  replayActive = false,
  replayFrame = null,
  replayCameraAngle = 'broadcast',
  replayFocusTeam = null,
}: EngineCanvasProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const screenRef = useRef(screenState);
  const configRef = useRef(config);
  const controlsRef = useRef(controls);
  const hudCbRef = useRef(onHudUpdate);
  const endCbRef = useRef(onMatchEnd);
  const replayCbRef = useRef(onReplayAvailable);
  const lanRef = useRef({ roomCode: lanRoomCode, role: lanRole });
  const replayStateRef = useRef({
    active: replayActive,
    frame: replayFrame,
    cameraAngle: replayCameraAngle,
    focusTeam: replayFocusTeam,
  });

  screenRef.current = screenState;
  configRef.current = config;
  controlsRef.current = controls;
  hudCbRef.current = onHudUpdate;
  endCbRef.current = onMatchEnd;
  replayCbRef.current = onReplayAvailable;
  lanRef.current = { roomCode: lanRoomCode, role: lanRole };
  replayStateRef.current = {
    active: replayActive,
    frame: replayFrame,
    cameraAngle: replayCameraAngle,
    focusTeam: replayFocusTeam,
  };

  const rebuildMatchRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    rebuildMatchRef.current?.();
  }, [matchNonce, config.arena, config.ballType, config.weatherMode, config.localPlayerCount, config.grassPattern, config.netStyle]);

  // Manage Arena BGM lifecycle across screenState & arena changes
  useEffect(() => {
    if (screenState === 'playing') {
      gameAudio.setPaused(false);
      gameAudio.startBgm(config.arena);
    } else if (screenState === 'paused') {
      gameAudio.setPaused(true);
    } else {
      gameAudio.stopBgm();
    }
  }, [screenState, config.arena]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const urlRainParam = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('rain') : null;
    const simWeatherOpt = urlRainParam === '1' ? { forceRain: true } : urlRainParam === '0' ? { forceRain: false } : undefined;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    scene.environment = pmrem.fromScene(roomEnv, 0.04).texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(
      40,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.5,
      180
    );
    camera.position.set(0, 16.0, 18.2);
    camera.lookAt(0, 0, 0);

    const keyLight = new THREE.DirectionalLight('#fffbeb', 1.65);
    keyLight.position.set(10, 22, 12);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 2;
    keyLight.shadow.camera.far = 55;
    keyLight.shadow.camera.left = -16;
    keyLight.shadow.camera.right = 16;
    keyLight.shadow.camera.top = 14;
    keyLight.shadow.camera.bottom = -14;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight('#bae6fd', '#1e293b', 0.85);
    scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight('#93c5fd', 0.45);
    rimLight.position.set(-12, 10, -14);
    scene.add(rimLight);

    const shadowTex = createContactShadowTexture();

    // Pooled Burst Particle InstancedMesh (Zero-GC)
    const particleGeo = new THREE.BoxGeometry(0.18, 0.18, 0.18);
    const particleMat = new THREE.MeshBasicMaterial({ color: '#ffffff' });
    const particleMesh = new THREE.InstancedMesh(particleGeo, particleMat, MAX_PARTICLES);
    particleMesh.frustumCulled = false;
    scene.add(particleMesh);

    const particles: ParticleSlot[] = Array.from({ length: MAX_PARTICLES }, () => ({
      active: false,
      x: 0,
      y: -10,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      life: 0,
      maxLife: 1,
      size: 1,
      color: new THREE.Color('#ffffff'),
    }));
    let particleCursor = 0;

    // Pooled Falling Rain Streaks InstancedMesh (Zero-GC)
    const rainGeo = new THREE.BoxGeometry(0.032, 0.62, 0.032);
    const rainMat = new THREE.MeshBasicMaterial({
      color: '#bae6fd',
      transparent: true,
      opacity: 0.68,
      depthWrite: false,
    });
    const rainMesh = new THREE.InstancedMesh(rainGeo, rainMat, MAX_RAIN_DROPS);
    rainMesh.frustumCulled = false;
    rainMesh.visible = false;
    const rainDrops: RainDropSlot[] = Array.from({ length: MAX_RAIN_DROPS }, () => ({
      x: (Math.random() - 0.5) * (PITCH_HALF_X * 2 + 12),
      y: Math.random() * 14,
      z: (Math.random() - 0.5) * (PITCH_HALF_Z * 2 + 10),
      speed: 17 + Math.random() * 6,
    }));
    rainDrops.forEach((d, idx) => {
      _rainDummy.position.set(d.x, d.y, d.z);
      _rainDummy.rotation.set(0, 0, -0.14);
      _rainDummy.updateMatrix();
      rainMesh.setMatrixAt(idx, _rainDummy.matrix);
    });
    rainMesh.instanceMatrix.needsUpdate = true;
    rainMesh.computeBoundingSphere();
    scene.add(rainMesh);

    // Pooled Falling Snow Flakes InstancedMesh (Zero-GC)
    const snowGeo = new THREE.BoxGeometry(0.11, 0.11, 0.11);
    const snowMat = new THREE.MeshBasicMaterial({
      color: '#f8fafc',
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
    });
    const snowMesh = new THREE.InstancedMesh(snowGeo, snowMat, MAX_SNOW_FLAKES);
    snowMesh.frustumCulled = false;
    snowMesh.visible = false;
    const snowFlakes = Array.from({ length: MAX_SNOW_FLAKES }, (_, idx) => ({
      x: (Math.random() - 0.5) * (PITCH_HALF_X * 2 + 12),
      y: Math.random() * 14,
      z: (Math.random() - 0.5) * (PITCH_HALF_Z * 2 + 10),
      speed: 2.3 + Math.random() * 1.8,
      phase: idx * 0.45,
    }));
    snowFlakes.forEach((f, idx) => {
      _snowDummy.position.set(f.x, f.y, f.z);
      _snowDummy.updateMatrix();
      snowMesh.setMatrixAt(idx, _snowDummy.matrix);
    });
    snowMesh.instanceMatrix.needsUpdate = true;
    snowMesh.computeBoundingSphere();
    scene.add(snowMesh);

    const spawnBurst = (x: number, y: number, z: number, count: number, hex: string, speed = 5) => {
      for (let i = 0; i < count; i++) {
        const slot = particles[particleCursor];
        particleCursor = (particleCursor + 1) % MAX_PARTICLES;
        slot.active = true;
        slot.x = x;
        slot.y = y;
        slot.z = z;
        const a = Math.random() * Math.PI * 2;
        const s = (0.35 + Math.random() * 0.65) * speed;
        slot.vx = Math.cos(a) * s;
        slot.vy = 1.5 + Math.random() * speed * 0.9;
        slot.vz = Math.sin(a) * s;
        slot.maxLife = 0.35 + Math.random() * 0.35;
        slot.life = slot.maxLife;
        slot.size = 0.6 + Math.random() * 0.8;
        slot.color.set(hex);
      }
    };

    // Partikel permukaan lapangan: rumput (potongan daun/serpihan) di lapangan rumput,
    // debu/pasir/abu/salju di lapangan futsal, gurun, pantai, gunung api, dan es.
    const surfaceKind = (() => {
      const id = configRef.current.arena;
      if (['meadow_park', 'jungle_temple', 'sakura_shrine', 'grand_championship'].includes(id))
        return { shape: 'blade' as const, colors: ['#4ade80', '#22c55e', '#16a34a', '#86efac'] };
      if (id === 'floating_isles')
        return { shape: 'blade' as const, colors: ['#86efac', '#c084fc', '#f9a8d4', '#67e8f9'] };
      if (id === 'rooftop_skyline')
        return { shape: 'puff' as const, colors: ['#9ca3af', '#d1d5db', '#6b7280'] };
      if (id === 'candy_kingdom')
        return { shape: 'blade' as const, colors: ['#f472b6', '#60a5fa', '#fde047', '#a78bfa'] };
      if (id === 'desert_oasis' || id === 'tropical_beach')
        return { shape: 'puff' as const, colors: ['#e7c98f', '#d9b36c', '#f1dba8'] };
      if (id === 'volcano_caldera') return { shape: 'puff' as const, colors: ['#57534e', '#78716c', '#44403c'] };
      if (id === 'glacier_rink') return { shape: 'puff' as const, colors: ['#f0f9ff', '#bae6fd', '#e0f2fe'] };
      return { shape: 'puff' as const, colors: ['#cbd5e1', '#e2e8f0', '#94a3b8'] };
    })();
    const MAX_DUST = 160;
    const isBlade = surfaceKind.shape === 'blade';
    const dustGeo = isBlade ? new THREE.BoxGeometry(0.07, 0.17, 0.03) : new THREE.SphereGeometry(0.13, 7, 5);
    const dustMat = new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      opacity: isBlade ? 0.95 : 0.42,
      depthWrite: false,
    });
    const dustMesh = new THREE.InstancedMesh(dustGeo, dustMat, MAX_DUST);
    dustMesh.frustumCulled = false;
    dustMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_DUST * 3), 3);
    scene.add(dustMesh);
    const dustSlots = Array.from({ length: MAX_DUST }, () => ({
      active: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.5, size: 1, rot: 0, rotV: 0,
    }));
    const _dustColor = new THREE.Color();
    let dustCursor = 0;
    const walkDustTimers = new Map<string, number>();
    const spawnDust = (x: number, z: number, size: number, spread: number, lift = 1) => {
      const i = dustCursor;
      const d = dustSlots[i];
      dustCursor = (dustCursor + 1) % MAX_DUST;
      const a = Math.random() * Math.PI * 2;
      const sp = spread * (0.4 + Math.random() * 0.9);
      d.active = true;
      d.x = x + Math.cos(a) * 0.12;
      d.y = 0.07;
      d.z = z + Math.sin(a) * 0.12;
      d.vx = Math.cos(a) * sp;
      d.vz = Math.sin(a) * sp;
      d.vy = isBlade ? (2.2 + Math.random() * 2.8) * lift : (0.5 + Math.random() * 0.6) * lift;
      d.maxLife = isBlade ? 0.55 + Math.random() * 0.45 : 0.55 + Math.random() * 0.4;
      d.life = d.maxLife;
      d.size = size * (0.8 + Math.random() * 0.6);
      d.rot = Math.random() * Math.PI;
      d.rotV = (Math.random() - 0.5) * 14;
      _dustColor.set(surfaceKind.colors[Math.floor(Math.random() * surfaceKind.colors.length)]);
      dustMesh.setColorAt(i, _dustColor);
      if (dustMesh.instanceColor) dustMesh.instanceColor.needsUpdate = true;
    };
    const spawnDustBurst = (x: number, z: number, count: number, size: number, spread: number, lift = 1) => {
      for (let k = 0; k < count; k++) spawnDust(x, z, size, spread, lift);
    };

    // Debu putih tipis saat dash (sedikit, memudar cepat)
    const MAX_DASH_PUFF = 28;
    const dashGeo = new THREE.SphereGeometry(0.14, 7, 5);
    const dashMat = new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.4, depthWrite: false });
    const dashMesh = new THREE.InstancedMesh(dashGeo, dashMat, MAX_DASH_PUFF);
    dashMesh.frustumCulled = false;
    scene.add(dashMesh);
    const dashSlots = Array.from({ length: MAX_DASH_PUFF }, () => ({
      active: false, x: 0, y: 0, z: 0, vx: 0, vz: 0, life: 0, maxLife: 0.4,
    }));
    let dashCursor = 0;
    const dashPrev = new Map<string, number>();
    const dashPuffTimer = new Map<string, number>();
    const spawnDashPuff = (x: number, z: number, backX: number, backZ: number) => {
      const d = dashSlots[dashCursor];
      dashCursor = (dashCursor + 1) % MAX_DASH_PUFF;
      d.active = true;
      d.x = x + (Math.random() - 0.5) * 0.2;
      d.y = 0.1;
      d.z = z + (Math.random() - 0.5) * 0.2;
      d.vx = backX * 1.2 + (Math.random() - 0.5) * 0.6;
      d.vz = backZ * 1.2 + (Math.random() - 0.5) * 0.6;
      d.maxLife = 0.3 + Math.random() * 0.2;
      d.life = d.maxLife;
    };

    // Percikan cahaya saat bola memantul di pembatas (terlihat maupun tak terlihat)
    const MAX_SPARKS = 48;
    const MAX_FLASHES = 6;
    const SPARK_PALETTE = ['#ffffff', '#fff2a8', '#ffd24a', '#8eeaff', '#c9f6ff'].map((c) => new THREE.Color(c));
    const sparkGeo = new THREE.BoxGeometry(0.035, 0.035, 0.34);
    const sparkMat = new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const sparkMesh = new THREE.InstancedMesh(sparkGeo, sparkMat, MAX_SPARKS);
    sparkMesh.frustumCulled = false;
    sparkMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_SPARKS * 3), 3);
    scene.add(sparkMesh);
    const sparkSlots = Array.from({ length: MAX_SPARKS }, () => ({
      active: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.4,
      color: new THREE.Color('#ffffff'),
    }));
    let sparkCursor = 0;

    // Kilatan cahaya bulat di titik benturan (selalu menghadap kamera)
    const flashCanvas = document.createElement('canvas');
    flashCanvas.width = flashCanvas.height = 64;
    {
      const fc = flashCanvas.getContext('2d')!;
      const g = fc.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(255,255,255,1)');
      g.addColorStop(0.25, 'rgba(255,244,190,0.85)');
      g.addColorStop(0.55, 'rgba(120,225,255,0.35)');
      g.addColorStop(1, 'rgba(120,225,255,0)');
      fc.fillStyle = g;
      fc.fillRect(0, 0, 64, 64);
      // sinar silang tipis
      fc.fillStyle = 'rgba(255,255,255,0.9)';
      fc.fillRect(30, 4, 4, 56);
      fc.fillRect(4, 30, 56, 4);
    }
    const flashTex = new THREE.CanvasTexture(flashCanvas);
    flashTex.colorSpace = THREE.SRGBColorSpace;
    const flashGeo = new THREE.PlaneGeometry(1, 1);
    const flashMat = new THREE.MeshBasicMaterial({
      map: flashTex,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const flashMesh = new THREE.InstancedMesh(flashGeo, flashMat, MAX_FLASHES);
    flashMesh.frustumCulled = false;
    flashMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_FLASHES * 3), 3);
    scene.add(flashMesh);
    const flashSlots = Array.from({ length: MAX_FLASHES }, () => ({
      active: false, x: 0, y: 0, z: 0, life: 0, maxLife: 0.24, size: 1,
    }));
    let flashCursor = 0;

    const spawnWallSpark = (ev: { x?: number; y?: number; z?: number; nx?: number; nz?: number; intensity?: number }) => {
      const inten = Math.max(0.15, Math.min(1, ev.intensity ?? 0.5));
      const ox = ev.x ?? 0;
      const oy = ev.y ?? 0.5;
      const oz = ev.z ?? 0;
      let nx = ev.nx ?? 0;
      let nz = ev.nz ?? 0;
      let ny = 0;
      if (nx === 0 && nz === 0) ny = -1; // atap/palang: percikan memantul ke bawah
      // tangen horizontal (tegak lurus normal) untuk sebaran samping
      const tx = -nz;
      const tz = nx;
      const flash = flashSlots[flashCursor];
      flashCursor = (flashCursor + 1) % MAX_FLASHES;
      flash.active = true;
      flash.x = ox + nx * 0.06;
      flash.y = oy + ny * 0.06;
      flash.z = oz + nz * 0.06;
      flash.maxLife = 0.2 + inten * 0.14;
      flash.life = flash.maxLife;
      flash.size = 0.45 + inten * 0.55;
      const count = 3 + Math.round(inten * 5);
      for (let i = 0; i < count; i++) {
        const sp = sparkSlots[sparkCursor];
        sparkCursor = (sparkCursor + 1) % MAX_SPARKS;
        sp.active = true;
        sp.x = ox + nx * 0.05;
        sp.y = oy;
        sp.z = oz + nz * 0.05;
        const out = (0.25 + Math.random() * 0.75) * (2.5 + inten * 4); // menjauhi dinding
        const side = (Math.random() - 0.5) * (3.5 + inten * 5); // menyamping sepanjang dinding
        const up = (Math.random() - 0.1) * (2.2 + inten * 4);
        sp.vx = nx * out + tx * side;
        sp.vz = nz * out + tz * side;
        sp.vy = ny * out + up;
        sp.maxLife = 0.22 + Math.random() * 0.3 + inten * 0.12;
        sp.life = sp.maxLife;
        sp.color.copy(SPARK_PALETTE[Math.floor(Math.random() * SPARK_PALETTE.length)]);
      }
    };

    // 7 Distinct Sculpted 3D Center Pickup Models
    const orbGroup = new THREE.Group();
    const itemModels = buildItemPickupModels();
    (Object.keys(itemModels) as CenterItemType[]).forEach((k) => {
      itemModels[k].visible = false;
      orbGroup.add(itemModels[k]);
    });
    const orbBaseRing = new THREE.Mesh(
      new THREE.RingGeometry(0.55, 0.72, 24),
      new THREE.MeshBasicMaterial({ color: '#fef08a', transparent: true, opacity: 0.75, side: THREE.DoubleSide })
    );
    orbBaseRing.rotation.x = -Math.PI / 2;
    orbBaseRing.position.y = -0.58;
    orbGroup.add(orbBaseRing);
    orbGroup.visible = false;
    scene.add(orbGroup);

    // Meteor Pool
    const meteorMeshes: THREE.Group[] = Array.from({ length: 4 }, () => {
      const mGroup = new THREE.Group();
      const rock = new THREE.Mesh(
        new THREE.DodecahedronGeometry(0.65, 0),
        new THREE.MeshStandardMaterial({ color: '#44403c', emissive: '#ef4444', emissiveIntensity: 0.75, roughness: 0.65 })
      );
      const tail = new THREE.Mesh(
        new THREE.ConeGeometry(0.55, 1.5, 8),
        new THREE.MeshBasicMaterial({ color: '#f97316', transparent: true, opacity: 0.72 })
      );
      tail.position.y = 0.9;
      mGroup.add(rock, tail);
      mGroup.visible = false;
      scene.add(mGroup);
      return mGroup;
    });

    let sim: MatchSimulation = createMatchSimulation(configRef.current, simWeatherOpt);
    const replayRecorder = new ReplayRecorder();
    let arenaRig: ArenaRig | null = null;
    const playerRigs: Map<string, CharacterRig> = new Map();
    const propRigs: Map<string, PropRig> = new Map();
    const bullRigs: Map<string, BullRig> = new Map();
    const disposeBullRig = (rig: BullRig) => {
      scene.remove(rig.group);
      rig.geometries.forEach((g) => g.dispose());
      rig.materials.forEach((m) => m.dispose());
    };
    const ballRig: BallRig = buildBall3D(sim.ball, maxAniso, shadowTex);
    scene.add(ballRig.group, ballRig.shadowMesh);

    let pendingAutoReplay: { team: TeamId; triggerAt: number } | null = null;
    let autoGoalReplay: {
      frames: ReplayFrame[];
      playhead: number;
      endTime: number;
      speed: number;
      angle: ReplayCameraAngle;
      focusTeam: TeamId;
    } | null = null;

    const disposePropRig = (rig: PropRig) => {
      scene.remove(rig.group);
      rig.materials.forEach((m) => m.dispose());
      rig.textures.forEach((t) => t.dispose());
      rig.durabilityPips.forEach((pip) => {
        pip.geometry.dispose();
        (pip.material as THREE.Material).dispose();
      });
      rig.shadowMesh.geometry.dispose();
      (rig.shadowMesh.material as THREE.Material).dispose();
    };

    const buildSceneFromConfig = () => {
      const cfg = configRef.current;
      sim = createMatchSimulation(cfg, simWeatherOpt);
      // Match 1 juga diawali jeda 2 detik + banner (seperti pergantian babak); training tanpa jeda
      if (cfg.mode !== 'training') sim.halfTimeBannerTimer = HALF_BREAK_SECONDS;
      replayRecorder.reset();
      replayRecorder.recordStep(sim, 0, true);
      pendingAutoReplay = null;
      autoGoalReplay = null;

      if (arenaRig) {
        scene.remove(arenaRig.group);
        arenaRig.disposables.forEach((d) => d.dispose());
      }
      propRigs.forEach(disposePropRig);
      propRigs.clear();
      bullRigs.forEach(disposeBullRig);
      bullRigs.clear();

      const arenaSpec = ARENAS.find((a) => a.id === cfg.arena) ?? ARENAS[0];
      scene.background = new THREE.Color(arenaSpec.skyTop);
      // Arena langit/atap: kabut lebih tipis agar pulau jauh & pesawat tetap terlihat
      const openSky = arenaSpec.id === 'floating_isles' || arenaSpec.id === 'rooftop_skyline';
      scene.fog = new THREE.FogExp2(
        arenaSpec.skyFog,
        openSky ? (sim.weather.isRaining ? 0.009 : 0.0045) : sim.weather.isRaining ? 0.015 : 0.01
      );
      hemiLight.color.set(arenaSpec.ambientCool);
      keyLight.color.set(arenaSpec.sunWarm);

      const GRASS_CHOICES: GrassPatternId[] = ['stripes', 'checker', 'diamond', 'rings'];
      const NET_CHOICES: NetStyleId[] = ['white', 'checker', 'striped'];
      const rawGrass = cfg.grassPattern ?? 'random';
      const rawNet = cfg.netStyle ?? 'random';
      const grassChoice: GrassPatternId =
        rawGrass === 'random' ? GRASS_CHOICES[Math.floor(Math.random() * GRASS_CHOICES.length)] : rawGrass;
      const netChoice: NetStyleId =
        rawNet === 'random' ? NET_CHOICES[Math.floor(Math.random() * NET_CHOICES.length)] : rawNet;
      arenaRig = buildArena3D(arenaSpec, maxAniso, grassChoice, netChoice);
      syncArenaWeather(arenaRig, sim.weather, 0);
      scene.add(arenaRig.group);

      const ballSpec = BALLS.find((b) => b.id === cfg.ballType) ?? BALLS[0];
      updateBallTextureAndShape(ballRig, sim.ball, maxAniso, ballSpec.id);

      playerRigs.forEach((r) => scene.remove(r.root));
      playerRigs.clear();
      for (const p of sim.players) {
        const rig = buildCharacterRig(p.team, p.isHuman, p.custom, shadowTex);
        scene.add(rig.root);
        playerRigs.set(p.id, rig);
        syncCharacterRig(rig, p, 0);
      }

      if (!isSoftwareGl) {
        renderer.compile(scene, camera);
      }
    };

    buildSceneFromConfig();
    rebuildMatchRef.current = buildSceneFromConfig;

    const keysHeld = new Set<string>();
    const keysJustPressed = new Set<string>();

    const onKeyDown = (e: KeyboardEvent) => {
      if (screenRef.current !== 'playing') return;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
      if (!e.repeat && !keysHeld.has(e.code)) {
        keysJustPressed.add(e.code);
      }
      keysHeld.add(e.code);
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysHeld.delete(e.code);
    };

    const clearInputs = () => {
      keysHeld.clear();
      keysJustPressed.clear();
    };

    window.addEventListener('keydown', onKeyDown, { passive: false });
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearInputs);
    document.addEventListener('visibilitychange', clearInputs);

    let prevPad = {
      kick: false,
      kickRightSpin: false,
      grabProp: false,
      jump: false,
      headSpinLeft: false,
      dash: false,
    };
    let prevReplayVpA = false;

    let lanChannel: BroadcastChannel | null = null;
    let lanGuestInput: InputFrame | null = null;
    if (typeof BroadcastChannel !== 'undefined') {
      lanChannel = new BroadcastChannel('rubber-pitch-lan');
      lanChannel.onmessage = (ev) => {
        if (ev.data?.type === 'guest_input' && ev.data?.room === lanRef.current.roomCode) {
          lanGuestInput = ev.data.input;
        }
      };
    }

    const readPlayerInput = (slot: 1 | 2 | 3 | 4): InputFrame => {
      const map =
        slot === 1
          ? controlsRef.current.p1
          : slot === 2
            ? controlsRef.current.p2
            : slot === 3
              ? (controlsRef.current.p3 ?? DEFAULT_CONTROL_MAPPING.p3!)
              : (controlsRef.current.p4 ?? DEFAULT_CONTROL_MAPPING.p4!);

      let moveX = 0;
      let moveZ = 0;
      if (keysHeld.has(map.left)) moveX -= 1;
      if (keysHeld.has(map.right)) moveX += 1;
      if (keysHeld.has(map.up)) moveZ -= 1;
      if (keysHeld.has(map.down)) moveZ += 1;

      const runHeld = keysHeld.has(map.run);
      const kickPressed = keysJustPressed.has(map.kick);
      const kickHeld = keysHeld.has(map.kick);
      const kickRightSpinPressed = keysJustPressed.has(map.kickRightSpin);
      const kickRightHeld = keysHeld.has(map.kickRightSpin);
      const grabPressed = keysJustPressed.has(map.grabProp);
      const jumpPressed = keysJustPressed.has(map.jump);
      const headSpinLeftPressed = keysJustPressed.has(map.headSpinLeft);
      const dashPressed = keysJustPressed.has(map.dash);

      let vpRun = false;
      let vpKick = false;
      let vpKickHeld = false;
      let vpKickRight = false;
      let vpKickRightHeld = false;
      let vpGrab = false;
      let vpJump = false;
      let vpL = false;
      let vpDash = false;

      if (slot === 1) {
        const vp = virtualPadRef.current;
        if (Math.abs(vp.moveX) > 0.05 || Math.abs(vp.moveZ) > 0.05) {
          moveX = vp.moveX;
          moveZ = vp.moveZ;
        }
        const vMag = Math.hypot(vp.moveX, vp.moveZ);
        vpRun = vMag > 0.7;

        vpKick = vp.kick && !prevPad.kick;
        vpKickHeld = Boolean(vp.kick);
        vpKickRight = vp.kickRightSpin && !prevPad.kickRightSpin;
        vpKickRightHeld = Boolean(vp.kickRightSpin);
        vpGrab = vp.grabProp && !prevPad.grabProp;
        vpJump = vp.jump && !prevPad.jump;
        vpL = vp.headSpinLeft && !prevPad.headSpinLeft;
        vpDash = vp.dash && !prevPad.dash;
        prevPad = {
          kick: vp.kick,
          kickRightSpin: vp.kickRightSpin,
          grabProp: vp.grabProp,
          jump: vp.jump,
          headSpinLeft: vp.headSpinLeft,
          dash: vp.dash,
        };
      }

      if (slot === 2 && lanRef.current.roomCode && lanRef.current.role === 'host' && lanGuestInput) {
        const g = lanGuestInput;
        lanGuestInput = null;
        return g;
      }

      // Gamepad per player: tiap controller punya Device ID & mapping sendiri (lihat gamepadManager).
      // Slot N hanya membaca controller yang ditugaskan ke Player N — bukan "gamepad index N-1".
      const pad = gamepadManager.readSlot(slot as 1 | 2 | 3 | 4, 'match');
      const gpKick = pad?.kickPressed ?? false;
      const gpKickHeld = pad?.kickHeld ?? false;
      const gpKickRight = pad?.kickRightPressed ?? false;
      const gpKickRightHeld = pad?.kickRightHeld ?? false;
      const gpGrab = pad?.grabPressed ?? false;
      const gpJump = pad?.jumpPressed ?? false;
      const gpL = pad?.headPressed ?? false;
      const gpDash = pad?.dashPressed ?? false;
      const gpRun = pad?.run ?? false;
      if (pad && (pad.moveX !== 0 || pad.moveZ !== 0)) {
        moveX = pad.moveX;
        moveZ = pad.moveZ;
      }

      return {
        moveX,
        moveZ,
        runHeld: runHeld || vpRun || gpRun,
        kickPressed: kickPressed || vpKick || gpKick,
        kickHeld: kickHeld || vpKickHeld || gpKickHeld,
        kickRightSpinPressed: kickRightSpinPressed || vpKickRight || gpKickRight,
        kickRightHeld: kickRightHeld || vpKickRightHeld || gpKickRightHeld,
        grabPressed: grabPressed || vpGrab || gpGrab,
        jumpPressed: jumpPressed || vpJump || gpJump,
        headSpinLeftPressed: headSpinLeftPressed || vpL || gpL,
        dashPressed: dashPressed || vpDash || gpDash,
      };
    };

    const handleResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    let frameId = 0;
    let lastTime = performance.now();
    let hudTimer = 0;
    let rollTickTimer = 0;
    let lastBombWholeSec = 15;
    let endReported = false;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const st = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (st === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const pushHudNow = () => {
      const p1 = sim.players.find((pl) => pl.humanSlot === 1);
      hudCbRef.current({
        redScore: sim.redScore,
        blueScore: sim.blueScore,
        timeRemaining: getDisplayClock(sim),
        currentHalf: sim.currentHalf,
        totalHalves: sim.config.halves ?? 2,
        halfTimeBanner: sim.halfTimeBannerTimer > 0,
        goldenGoal: sim.goldenGoal,
        breakSeconds: Math.ceil(sim.halfTimeBannerTimer),
        goalBannerTeam: autoGoalReplay ? autoGoalReplay.focusTeam : sim.goalCelebrationTimer > 0 ? sim.lastScoringTeam : null,
        matchEnded: sim.matchEnded,
        bombCountdown: sim.config.ballType === 'timer_bomb' ? sim.ball.bombCountdown : null,
        p1CarryingProp: Boolean(p1?.carryingPropId),
        p1PunchCharge: p1?.punchPhase === 'charge' ? p1.punchCharge : 0,
        p1KickCharge: p1?.kickPhase === 'super_charge' ? p1.kickCharge : 0,
        isGoalReplay: Boolean(autoGoalReplay),
      });
    };

    if (skipGoalReplayRef) {
      skipGoalReplayRef.current = () => {
        if (!autoGoalReplay) return;
        autoGoalReplay = null;
        pendingAutoReplay = null;
        sim.goalCelebrationTimer = 0;
        resetPositionsForKickoff(sim);
        keysJustPressed.clear();
        pushHudNow();
      };
    }

    const camTargetPos = new THREE.Vector3(0, 16.0, 18.2);
    const camLookTarget = new THREE.Vector3(0, 0, 0);

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const rawDt = Math.max(0.001, (now - lastTime) / 1000);
      lastTime = now;
      const dt = Math.min(rawDt, 0.05);

      const st = screenRef.current;

      if (st === 'playing') {
        if (autoGoalReplay) {
          // Tombol A (kick) di keyboard / layar sentuh / gamepad juga melewati replay
          const c = controlsRef.current;
          const kickKeys = [c.p1.kick, c.p2.kick, c.p3?.kick, c.p4?.kick].filter(Boolean) as string[];
          const kbA = kickKeys.some((k) => keysJustPressed.has(k));
          const vpNow = Boolean(virtualPadRef.current.kick);
          const vpA = vpNow && !prevReplayVpA;
          prevReplayVpA = vpNow;
          keysJustPressed.clear();
          // Controller mana pun: Start atau A (tombol bawah) melewati replay
          const gpSkip = gamepadManager.edgeAny('goal-replay', [0, 9]);
          if (gpSkip || kbA || vpA) {
            prevPad = { ...prevPad, kick: vpNow };
            skipGoalReplayRef?.current?.();
          } else {
            autoGoalReplay.playhead += dt * autoGoalReplay.speed;
            if (autoGoalReplay.playhead >= autoGoalReplay.endTime) {
              autoGoalReplay = null;
              sim.goalCelebrationTimer = 0;
              resetPositionsForKickoff(sim);
              pushHudNow();
            }
          }
        } else {
          const p1Input = readPlayerInput(1);
          const p2Input = readPlayerInput(2);
          const p3Input = readPlayerInput(3);
          const p4Input = readPlayerInput(4);
          keysJustPressed.clear();

          if (lanRef.current.roomCode && lanRef.current.role === 'guest' && lanChannel) {
            lanChannel.postMessage({
              type: 'guest_input',
              room: lanRef.current.roomCode,
              input: p1Input,
            });
          }


          const speedMult = configRef.current.gameSpeed ?? 1.0;
          stepSimulation(sim, dt * speedMult, {
            p1: p1Input,
            p2: p2Input,
            p3: p3Input,
            p4: p4Input,
          });
          replayRecorder.recordStep(sim, dt * speedMult, sim.matchEnded);
          gameAudio.setRaining(sim.weather.isRaining);

          // Ground roll / dribble tick audio when ball rolls fast along the pitch
          const ballHorizSpeed = Math.hypot(sim.ball.vx, sim.ball.vz);
          if (sim.ball.y < 0.72 && ballHorizSpeed > 2.4 && sim.goalCelebrationTimer <= 0) {
            rollTickTimer -= dt;
            if (rollTickTimer <= 0) {
              gameAudio.playBallRollTick(ballHorizSpeed, configRef.current.ballType);
              rollTickTimer = Math.max(0.11, 0.28 - ballHorizSpeed * 0.012);
            }
          } else {
            rollTickTimer = 0.05;
          }

          // 15s Timer Bomb countdown tick sound when urgency is <= 5s
          if (sim.config.ballType === 'timer_bomb' && sim.goalCelebrationTimer <= 0) {
            const wholeSec = Math.ceil(sim.ball.bombCountdown);
            if (wholeSec !== lastBombWholeSec) {
              lastBombWholeSec = wholeSec;
              if (wholeSec >= 1 && wholeSec <= 5) {
                gameAudio.playBombTick(1 - (wholeSec - 1) / 5);
              }
            }
          }

          const isBallOnFireNow =
            sim.ball.isClashedFire || sim.activeItems.some((i) => i.type === 'fire_power');

          for (const ev of sim.events) {
            if (ev.type === 'kick') {
              gameAudio.playBallKickImpact(ev.intensity ?? 0.7, configRef.current.ballType, isBallOnFireNow);
              spawnBurst(ev.x ?? 0, ev.y ?? 0.4, ev.z ?? 0, 5, '#f8fafc', 4);
              spawnDustBurst(ev.x ?? 0, ev.z ?? 0, 5, 0.9, 2.2);
            } else if (ev.type === 'ball_bounce') {
              gameAudio.playBallBounce(ev.intensity ?? 0.6, configRef.current.ballType);
              // Debu / partikel rumput saat bola memantul di tanah
              if ((ev.intensity ?? 0) >= 0.3 && (ev.y ?? 1) < 0.9) {
                spawnDustBurst(ev.x ?? 0, ev.z ?? 0, 6 + Math.round((ev.intensity ?? 0.5) * 12), 0.9, 1.6 + (ev.intensity ?? 0.5) * 2);
              }
            } else if (ev.type === 'wall_spark') {
              spawnWallSpark(ev);
            } else if (ev.type === 'honey_stick') {
              gameAudio.playHoneySquelch();
            } else if (ev.type === 'water_splash') {
              gameAudio.playWaterSplash(ev.intensity ?? 0.6);
              spawnBurst(ev.x ?? 0, 0.12, ev.z ?? 0, 10, '#7dd3fc', 4.2);
            } else if (ev.type === 'clash') {
              gameAudio.playClash();
              gameAudio.playBallKickImpact(1.0, configRef.current.ballType, true);
              spawnBurst(ev.x ?? 0, ev.y ?? 0.6, ev.z ?? 0, 22, '#f97316', 8.5);
            } else if (ev.type === 'post_hit') {
              gameAudio.playJellyPost();
              spawnBurst(ev.x ?? 0, ev.y ?? 1.2, ev.z ?? 0, 5, '#ffffff', 4);
            } else if (ev.type === 'goal') {
              gameAudio.playGoal();
              const c = ev.team === 'red' ? '#ef4444' : '#3b82f6';
              spawnBurst(ev.x ?? 0, 1.4, ev.z ?? 0, 28, c, 9);
              spawnBurst(ev.x ?? 0, 1.8, ev.z ?? 0, 16, '#facc15', 7);
              pendingAutoReplay = { team: ev.team ?? 'red', triggerAt: sim.elapsedTime + 0.65 };
            } else if (ev.type === 'save') {
              spawnBurst(ev.x ?? 0, ev.y ?? 1.0, ev.z ?? 0, 12, '#38bdf8', 5.5);
            } else if (ev.type === 'foul') {
              spawnBurst(ev.x ?? 0, ev.y ?? 0.9, ev.z ?? 0, 14, '#facc15', 5.0);
            } else if (ev.type === 'halftime') {
              gameAudio.playWhistle();
              spawnBurst(0, 1.4, 0, 18, '#facc15', 6);
            } else if (ev.type === 'item_pickup') {
              gameAudio.playItemPickup();
              spawnBurst(0, 0.8, 0, 16, '#facc15', 6);
            } else if (ev.type === 'bomb_explode' || ev.type === 'meteor_impact') {
              gameAudio.playExplosion();
              spawnBurst(ev.x ?? 0, 0.5, ev.z ?? 0, 24, '#ef4444', 9);
            } else if (ev.type === 'punch_hit') {
              gameAudio.playPunchHit(ev.intensity ?? 0.7);
              spawnBurst(ev.x ?? 0, ev.y ?? 0.8, ev.z ?? 0, 18, '#fde047', 8);
            } else if (ev.type === 'prop_grab') {
              gameAudio.playPropGrab();
            } else if (ev.type === 'prop_throw') {
              gameAudio.playSpinKick();
            } else if (ev.type === 'prop_spawn') {
              spawnBurst(ev.x ?? 0, 1.4, ev.z ?? 0, 8, '#a3e635', 3.5);
            } else if (ev.type === 'prop_break') {
              gameAudio.playPropBreak();
              spawnBurst(ev.x ?? 0, ev.y ?? 0.4, ev.z ?? 0, 16, '#d97706', 6);
            } else if (ev.type === 'whistle') {
              gameAudio.playWhistle();
            } else if (ev.type === 'ball_respawn') {
              spawnBurst(0, 1.4, 0, 12, '#38bdf8', 5);
            }
          }

          // Debu putih dash: 3 gumpalan saat mulai dash, lalu 1 gumpalan tiap 0.1 detik
          for (const p of sim.players) {
            const prev = dashPrev.get(p.id) ?? 0;
            if (p.dashTimer > 0 && p.fallTimer <= 0) {
              const bx = -Math.sin(p.facing);
              const bz = -Math.cos(p.facing);
              if (prev <= 0) {
                for (let k = 0; k < 3; k++) spawnDashPuff(p.x + bx * 0.3, p.z + bz * 0.3, bx, bz);
                dashPuffTimer.set(p.id, 0.1);
              } else {
                const left = (dashPuffTimer.get(p.id) ?? 0.1) - dt;
                if (left <= 0) {
                  spawnDashPuff(p.x + bx * 0.3, p.z + bz * 0.3, bx, bz);
                  dashPuffTimer.set(p.id, 0.1);
                } else {
                  dashPuffTimer.set(p.id, left);
                }
              }
            }
            dashPrev.set(p.id, p.dashTimer);
          }

          // Partikel langkah: lebih banyak saat berlari, mengikuti jenis lapangan
          for (const p of sim.players) {
            const sp = Math.hypot(p.vx, p.vz);
            const left = (walkDustTimers.get(p.id) ?? 0.2) - dt;
            if (sp > 2.6 && p.y < 0.15 && p.fallTimer <= 0) {
              if (left <= 0) {
                const run = sp > 5;
                spawnDustBurst(p.x - Math.sin(p.facing) * 0.25, p.z - Math.cos(p.facing) * 0.25, run ? 4 : 2, 0.6, run ? 1.8 : 1.0, 0.8);
                walkDustTimers.set(p.id, run ? 0.16 : 0.26);
              } else {
                walkDustTimers.set(p.id, left);
              }
            } else {
              walkDustTimers.set(p.id, Math.max(left, 0.1));
            }
          }

          if (pendingAutoReplay && sim.elapsedTime >= pendingAutoReplay.triggerAt && !sim.matchEnded) {
            const clip = replayRecorder.getRecentClip(4.2);
            if (clip.length >= 2) {
              autoGoalReplay = {
                frames: clip,
                playhead: clip[0].time,
                endTime: clip[clip.length - 1].time,
                speed: 0.52,
                angle: 'goal_cam',
                focusTeam: pendingAutoReplay.team,
              };
            }
            pendingAutoReplay = null;
            pushHudNow();
          }

          if (sim.matchEnded && !endReported) {
            endReported = true;
            pendingAutoReplay = null;
            autoGoalReplay = null;
            replayCbRef.current?.(replayRecorder.getBundle());
            endCbRef.current(sim.redScore, sim.blueScore);
          }
          if (!sim.matchEnded) {
            endReported = false;
          }
        }
      } else if (isMenuScreen(st)) {
        sim.elapsedTime += dt;
        sim.ball.rotY += dt * 0.8;
        gameAudio.setRaining(false);
      }

      const rState = replayStateRef.current;
      const autoFrame = autoGoalReplay ? sampleReplayFrame(autoGoalReplay.frames, autoGoalReplay.playhead) : null;
      const activeReplayFrame = rState.active && rState.frame ? rState.frame : autoFrame;
      const useReplay = activeReplayFrame !== null;

      if (useReplay && activeReplayFrame) {
        const rf = activeReplayFrame;
        for (const p of rf.players) {
          const rig = playerRigs.get(p.id);
          if (rig) syncCharacterRig(rig, p, rf.time);
        }
        syncBallRig(ballRig, rf.ball, false, false, rf.time);
        if (arenaRig) {
          syncJellyGoalPosts(arenaRig, rf.goalPosts);
          syncArenaGoalNets(arenaRig, { ...rf.ball, vy: 0, vz: rf.ball.vz, radius: sim.ball.radius }, dt, rf.time);
          syncArenaSpectators(arenaRig, rf.time, rf.ball.isClashedFire ? 0.75 : 0.35);
          syncArenaWeather(arenaRig, sim.weather, rf.time);
        }

        // Banteng ikut bergerak saat replay
        const replayBulls = rf.bulls ?? [];
        const replayBullIds = new Set(replayBulls.map((b) => b.id));
        for (const [bid, rig] of bullRigs) {
          if (!replayBullIds.has(bid)) {
            disposeBullRig(rig);
            bullRigs.delete(bid);
          }
        }
        for (const b of replayBulls) {
          let rig = bullRigs.get(b.id);
          if (!rig) {
            rig = buildBullMesh();
            scene.add(rig.group);
            bullRigs.set(b.id, rig);
          }
          syncBullRig(rig, b, rf.time);
        }

        const activePropIds = new Set(rf.props.map((pr) => pr.id));
        for (const [pid, rig] of propRigs) {
          if (!activePropIds.has(pid)) {
            disposePropRig(rig);
            propRigs.delete(pid);
          }
        }
        for (const pr of rf.props) {
          let rig = propRigs.get(pr.id);
          if (!rig) {
            rig = buildPropMesh(pr.kind, shadowTex);
            scene.add(rig.group);
            propRigs.set(pr.id, rig);
          }
          syncPropRig(rig, pr, rf.time);
        }
      } else {
        for (const p of sim.players) {
          const rig = playerRigs.get(p.id);
          if (rig) {
            syncCharacterRig(rig, p, sim.elapsedTime);
            rig.root.scale.setScalar(p.sizeScale ?? 1);
          }
        }

        // Banteng dari telur burung unta
        const activeBullIds = new Set(sim.bulls.map((b) => b.id));
        for (const [bid, rig] of bullRigs) {
          if (!activeBullIds.has(bid)) {
            disposeBullRig(rig);
            bullRigs.delete(bid);
          }
        }
        for (const b of sim.bulls) {
          let rig = bullRigs.get(b.id);
          if (!rig) {
            rig = buildBullMesh();
            scene.add(rig.group);
            bullRigs.set(b.id, rig);
          }
          syncBullRig(rig, b, sim.elapsedTime);
        }

        const fireActive = sim.activeItems.some((i) => i.type === 'fire_power');
        const windActive = sim.activeItems.some((i) => i.type === 'updraft_wind');
        syncBallRig(ballRig, sim.ball, fireActive, windActive, sim.elapsedTime);

        if (arenaRig) {
          syncJellyGoalPosts(arenaRig, sim.goalPosts);
          syncArenaGoalNets(arenaRig, sim.ball, dt, sim.elapsedTime);
          const crowdExcitement = sim.goalCelebrationTimer > 0 ? 1.0 : sim.ball.isClashedFire ? 0.65 : 0.15;
          syncArenaSpectators(arenaRig, sim.elapsedTime, crowdExcitement);
          syncArenaWeather(arenaRig, sim.weather, sim.elapsedTime);
        }

        const activePropIds = new Set(sim.props.map((pr) => pr.id));
        for (const [pid, rig] of propRigs) {
          if (!activePropIds.has(pid)) {
            disposePropRig(rig);
            propRigs.delete(pid);
          }
        }
        for (const pr of sim.props) {
          let rig = propRigs.get(pr.id);
          if (!rig) {
            rig = buildPropMesh(pr.kind, shadowTex);
            scene.add(rig.group);
            propRigs.set(pr.id, rig);
          }
          syncPropRig(rig, pr, sim.elapsedTime);
        }
      }

      // Falling Rain Streaks (Zero-GC InstancedMesh)
      rainMesh.visible = sim.weather.isRaining;
      if (sim.weather.isRaining) {
        for (let i = 0; i < MAX_RAIN_DROPS; i++) {
          const drop = rainDrops[i];
          drop.y -= drop.speed * dt;
          drop.x -= 2.2 * dt;
          if (drop.y < 0.05) {
            drop.y = 12 + Math.random() * 4;
            drop.x = (Math.random() - 0.5) * (PITCH_HALF_X * 2 + 12);
            drop.z = (Math.random() - 0.5) * (PITCH_HALF_Z * 2 + 10);
          }
          _rainDummy.position.set(drop.x, drop.y, drop.z);
          _rainDummy.rotation.set(0, 0, -0.14);
          _rainDummy.scale.setScalar(1);
          _rainDummy.updateMatrix();
          rainMesh.setMatrixAt(i, _rainDummy.matrix);
        }
        rainMesh.instanceMatrix.needsUpdate = true;
      }

      // Falling Snow Flakes (Zero-GC InstancedMesh)
      const isSnow = Boolean(sim.weather.isSnowing);
      snowMesh.visible = isSnow;
      if (isSnow) {
        for (let i = 0; i < MAX_SNOW_FLAKES; i++) {
          const f = snowFlakes[i];
          f.y -= f.speed * dt;
          f.x += Math.sin(sim.elapsedTime * 1.4 + f.phase) * 0.85 * dt;
          if (f.y < 0.05) {
            f.y = 12.5 + Math.random() * 3.5;
            f.x = (Math.random() - 0.5) * (PITCH_HALF_X * 2 + 12);
            f.z = (Math.random() - 0.5) * (PITCH_HALF_Z * 2 + 10);
          }
          _snowDummy.position.set(f.x, f.y, f.z);
          _snowDummy.rotation.set(sim.elapsedTime + f.phase, sim.elapsedTime * 0.7, 0);
          _snowDummy.updateMatrix();
          snowMesh.setMatrixAt(i, _snowDummy.matrix);
        }
        snowMesh.instanceMatrix.needsUpdate = true;
      }

      // Sculpted Center Pickup Item Display
      orbGroup.visible = !useReplay && sim.pickupOrb.active;
      if (orbGroup.visible) {
        (Object.keys(itemModels) as CenterItemType[]).forEach((k) => {
          itemModels[k].visible = k === sim.pickupOrb.type;
        });
        orbGroup.position.set(sim.pickupOrb.x, sim.pickupOrb.y, sim.pickupOrb.z);
        orbGroup.rotation.y += dt * 2.0;
      }

      // Meteors
      for (let i = 0; i < meteorMeshes.length; i++) {
        const mSim = sim.meteors[i];
        const mMesh = meteorMeshes[i];
        if (!useReplay && mSim && mSim.active && !mSim.impacted) {
          mMesh.visible = true;
          mMesh.position.set(mSim.x, mSim.y, mSim.z);
          mMesh.children[0].rotation.x += dt * 6;
          mMesh.children[0].rotation.z += dt * 4;
        } else {
          mMesh.visible = false;
        }
      }

      // Update Pooled Particles (Zero GC!)
      for (let i = 0; i < MAX_PARTICLES; i++) {
        const slot = particles[i];
        if (!slot.active) {
          _dummy.position.set(0, -50, 0);
          _dummy.scale.setScalar(0.001);
          _dummy.updateMatrix();
          particleMesh.setMatrixAt(i, _dummy.matrix);
          continue;
        }
        slot.life -= dt;
        if (slot.life <= 0) {
          slot.active = false;
          continue;
        }
        slot.vy -= 14 * dt;
        slot.x += slot.vx * dt;
        slot.y = Math.max(0.05, slot.y + slot.vy * dt);
        slot.z += slot.vz * dt;

        const frac = slot.life / slot.maxLife;
        _dummy.position.set(slot.x, slot.y, slot.z);
        _dummy.scale.setScalar(slot.size * frac);
        _dummy.rotation.set(slot.life * 6, slot.life * 4, 0);
        _dummy.updateMatrix();
        particleMesh.setMatrixAt(i, _dummy.matrix);
        particleMesh.setColorAt(i, slot.color);
      }
      particleMesh.instanceMatrix.needsUpdate = true;
      if (particleMesh.instanceColor) particleMesh.instanceColor.needsUpdate = true;

      (arenaRig as ArenaRig | null)?.tickScenery(sim.elapsedTime);
      (arenaRig as ArenaRig | null)?.tickStaff(
        sim.elapsedTime,
        sim.goalCelebrationTimer > 0 ? sim.lastScoringTeam : null,
        sim.goalCelebrationTimer > 0 ? 1 : sim.ball.isClashedFire ? 0.5 : 0.1,
        camera.position
      );

      // Update partikel permukaan (rumput / debu)
      for (let i = 0; i < MAX_DUST; i++) {
        const d = dustSlots[i];
        if (d.active) {
          d.life -= dt;
          if (d.life <= 0) d.active = false;
        }
        if (!d.active) {
          _dummy.position.set(0, -50, 0);
          _dummy.scale.setScalar(0.001);
          _dummy.rotation.set(0, 0, 0);
        } else {
          const f = d.life / d.maxLife;
          if (isBlade) {
            d.vy -= 11 * dt;
            d.rot += d.rotV * dt;
          }
          d.x += d.vx * dt;
          d.y = Math.max(0.03, d.y + d.vy * dt);
          d.z += d.vz * dt;
          if (isBlade && d.y <= 0.03) {
            d.vx *= 0.6;
            d.vz *= 0.6;
            d.vy = 0;
          }
          _dummy.position.set(d.x, d.y, d.z);
          _dummy.rotation.set(d.rot, d.rot * 0.7, d.rot * 0.4);
          _dummy.scale.setScalar(isBlade ? d.size * Math.min(1, f * 3) : d.size * (1.4 - f * 0.7) * (0.3 + f));
        }
        _dummy.updateMatrix();
        dustMesh.setMatrixAt(i, _dummy.matrix);
      }
      dustMesh.instanceMatrix.needsUpdate = true;

      for (let i = 0; i < MAX_DASH_PUFF; i++) {
        const d = dashSlots[i];
        if (d.active) {
          d.life -= dt;
          if (d.life <= 0) d.active = false;
        }
        if (!d.active) {
          _dummy.position.set(0, -50, 0);
          _dummy.scale.setScalar(0.001);
        } else {
          const f = d.life / d.maxLife;
          d.x += d.vx * dt;
          d.z += d.vz * dt;
          d.y += 0.5 * dt;
          _dummy.position.set(d.x, d.y, d.z);
          _dummy.scale.setScalar((1.5 - f * 0.8) * (0.3 + f));
        }
        _dummy.rotation.set(0, 0, 0);
        _dummy.updateMatrix();
        dashMesh.setMatrixAt(i, _dummy.matrix);
      }
      dashMesh.instanceMatrix.needsUpdate = true;

      // Update percikan cahaya pantulan pembatas
      for (let i = 0; i < MAX_SPARKS; i++) {
        const sp = sparkSlots[i];
        if (sp.active) {
          sp.life -= dt;
          if (sp.life <= 0) sp.active = false;
        }
        if (!sp.active) {
          _sparkDummy.position.set(0, -50, 0);
          _sparkDummy.scale.setScalar(0.001);
          _sparkDummy.quaternion.identity();
        } else {
          const f = sp.life / sp.maxLife;
          sp.vy -= 7 * dt;
          const drag = Math.max(0, 1 - 2.2 * dt);
          sp.vx *= drag;
          sp.vz *= drag;
          sp.x += sp.vx * dt;
          sp.y = Math.max(0.03, sp.y + sp.vy * dt);
          sp.z += sp.vz * dt;
          _sparkDir.set(sp.vx, sp.vy, sp.vz);
          const spd = _sparkDir.length();
          if (spd > 0.001) _sparkDir.multiplyScalar(1 / spd);
          else _sparkDir.set(0, 1, 0);
          _sparkQuat.setFromUnitVectors(_sparkZ, _sparkDir);
          _sparkDummy.position.set(sp.x, sp.y, sp.z);
          _sparkDummy.quaternion.copy(_sparkQuat);
          _sparkDummy.scale.set(1, 1, (0.5 + Math.min(2.2, spd * 0.22)) * (0.35 + f * 0.65));
        }
        _sparkDummy.updateMatrix();
        sparkMesh.setMatrixAt(i, _sparkDummy.matrix);
        // redup lewat warna (blending additif): makin kecil makin transparan
        const fade = sp.active ? Math.min(1, (sp.life / sp.maxLife) * 1.6) : 0;
        _sparkColor.copy(sp.color).multiplyScalar(fade);
        sparkMesh.setColorAt(i, _sparkColor);
      }
      sparkMesh.instanceMatrix.needsUpdate = true;
      if (sparkMesh.instanceColor) sparkMesh.instanceColor.needsUpdate = true;
      for (let i = 0; i < MAX_FLASHES; i++) {
        const fl = flashSlots[i];
        if (fl.active) {
          fl.life -= dt;
          if (fl.life <= 0) fl.active = false;
        }
        if (!fl.active) {
          _sparkDummy.position.set(0, -50, 0);
          _sparkDummy.scale.setScalar(0.001);
          _sparkColor.setRGB(0, 0, 0);
        } else {
          const f = fl.life / fl.maxLife; // 1 -> 0
          _sparkDummy.position.set(fl.x, fl.y, fl.z);
          _sparkDummy.scale.setScalar(fl.size * (1.35 - f * 0.75));
          _sparkColor.setRGB(f, f, f);
        }
        _sparkDummy.quaternion.copy(camera.quaternion);
        _sparkDummy.updateMatrix();
        flashMesh.setMatrixAt(i, _sparkDummy.matrix);
        flashMesh.setColorAt(i, _sparkColor);
      }
      flashMesh.instanceMatrix.needsUpdate = true;
      if (flashMesh.instanceColor) flashMesh.instanceColor.needsUpdate = true;

      // Camera Rig
      const aspect = (container.clientWidth || 1440) / Math.max(1, container.clientHeight || 900);
      const narrowBoost = aspect < 1.35 ? (1.35 - aspect) * 7.2 : 0;

      if (useReplay && activeReplayFrame) {
        const angle = rState.active ? rState.cameraAngle : autoGoalReplay?.angle ?? 'goal_cam';
        const focus = rState.active ? rState.focusTeam : autoGoalReplay?.focusTeam ?? null;
        const pose = computeReplayCameraPose(angle, activeReplayFrame, focus);
        camTargetPos.set(pose.pos[0], pose.pos[1], pose.pos[2]);
        camLookTarget.set(pose.lookAt[0], pose.lookAt[1], pose.lookAt[2]);
      } else if (isMenuScreen(st)) {
        const panAngle = sim.elapsedTime * 0.22;
        camTargetPos.set(Math.sin(panAngle) * 6.5 - 1.5, 12.6, 17.4 + Math.cos(panAngle) * 2.2);
        camLookTarget.set(-1.8, 0.4, -0.4);
      } else {
        const zoomIn = sim.cameraZoomPulse * 1.9;
        const baseY = 16.0 + narrowBoost - zoomIn * 0.6;
        const baseZ = 18.2 + narrowBoost - zoomIn * 0.8;
        camTargetPos.set(sim.ball.x * 0.1, baseY, baseZ + sim.ball.z * 0.08);
        camLookTarget.set(sim.ball.x * 0.11, 0.2, sim.ball.z * 0.1);
      }

      const dampAlpha = 1 - Math.exp(-(useReplay ? 8.5 : 6.5) * dt);
      camera.position.lerp(camTargetPos, dampAlpha);
      camera.lookAt(camLookTarget);

      // Decaying Trauma Camera Shake (Suppressed while Rubber Ball 10x or Replay is active!)
      if (!useReplay && !sim.ball.isJelly10x && sim.cameraTrauma > 0.005) {
        const shake = sim.cameraTrauma * sim.cameraTrauma * 0.35;
        camera.position.x += (Math.random() - 0.5) * shake;
        camera.position.y += (Math.random() - 0.5) * shake;
      }

      renderer.render(scene, camera);

      hudTimer += dt;
      if (hudTimer >= 0.1 && st === 'playing') {
        hudTimer = 0;
        pushHudNow();
      }

      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };

    if (isSoftwareGl) {
      renderer.render(scene, camera);
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    return () => {
      disposed = true;
      gameAudio.stopBgm();
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearInputs);
      document.removeEventListener('visibilitychange', clearInputs);
      window.removeEventListener('resize', handleResize);
      lanChannel?.close();
      shadowTex.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      dustGeo.dispose();
      dustMat.dispose();
      dashGeo.dispose();
      dashMat.dispose();
      sparkGeo.dispose();
      sparkMat.dispose();
      flashGeo.dispose();
      flashMat.dispose();
      flashTex.dispose();
      bullRigs.forEach(disposeBullRig);
      rainGeo.dispose();
      rainMat.dispose();
      snowGeo.dispose();
      snowMat.dispose();
      propRigs.forEach(disposePropRig);
      propRigs.clear();
      if (arenaRig) arenaRig.disposables.forEach((d) => d.dispose());
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} data-testid="game-canvas-mount" className="w-full h-full" />;
}
