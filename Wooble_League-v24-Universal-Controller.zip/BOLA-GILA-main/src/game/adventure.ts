import {
  AnimalId,
  ArenaId,
  BallTypeId,
  BossAiStyle,
  MatchConfig,
  PlayerCustomization,
  StatMods,
  WeatherMode,
} from './types';
import { ANIMALS, CAPES, DEFAULT_CUSTOMIZATION, HATS, MASKS, createDefaultMatchConfig } from './catalog';

/* =====================================================================
 *  WOBBLE LEAGUE — OPEN WORLD STORY MODE (data + logika, tanpa UI)
 *  - Tanpa level karakter: perkembangan = statistik, pengalaman (TP), rekrutmen, perlengkapan
 *  - 10 stadion x 10 pertandingan = 10 trofi -> World Championship
 * ===================================================================== */

export const STAT_KEYS = [
  'speed',
  'accel',
  'strength',
  'jump',
  'balance',
  'stamina',
  'accuracy',
  'power',
  'control',
  'reaction',
] as const;
export type StatKey = (typeof STAT_KEYS)[number];
export type AthleteStats = Record<StatKey, number>;

export const STAT_LABELS: Record<StatKey, { name: string; desc: string }> = {
  speed: { name: 'Speed', desc: 'Kecepatan berlari' },
  accel: { name: 'Acceleration', desc: 'Cepat mencapai kecepatan maksimum' },
  strength: { name: 'Strength', desc: 'Dorongan, duel fisik, dan pukulan' },
  jump: { name: 'Jump', desc: 'Tinggi lompatan' },
  balance: { name: 'Balance', desc: 'Tahan jatuh, cepat bangun' },
  stamina: { name: 'Stamina', desc: 'Daya tahan lari sepanjang laga' },
  accuracy: { name: 'Accuracy', desc: 'Akurasi arah tendangan' },
  power: { name: 'Power', desc: 'Kekuatan tendangan' },
  control: { name: 'Control', desc: 'Jangkauan kontrol bola' },
  reaction: { name: 'Reaction', desc: 'Kecepatan berbelok & merespons' },
};

export type Position = 'FWD' | 'MID' | 'DEF' | 'GK';
export const POSITION_LABEL: Record<Position, string> = {
  FWD: 'Penyerang',
  MID: 'Gelandang',
  DEF: 'Bek',
  GK: 'Kiper',
};

export const ROSTER_LIMIT = 15;
export const LINEUP_LIMIT = 3;
export const STAT_CAP = 95;

/* ------------------------------ Perlengkapan ------------------------------ */
export interface GearSpec {
  id: string;
  name: string;
  desc: string;
  price: number;
  bonus: Partial<Record<StatKey, number>>;
}

export const GEARS: GearSpec[] = [
  { id: 'gear_cleats', name: 'Turbo Cleats', desc: '+8 Speed, +4 Accel', price: 150, bonus: { speed: 8, accel: 4 } },
  { id: 'gear_boots', name: 'Cannon Boots', desc: '+10 Power', price: 180, bonus: { power: 10 } },
  { id: 'gear_gloves', name: 'Magnet Gloves', desc: '+8 Control, +4 Accuracy', price: 170, bonus: { control: 8, accuracy: 4 } },
  { id: 'gear_belt', name: 'Iron Belt', desc: '+10 Balance', price: 160, bonus: { balance: 10 } },
  { id: 'gear_band', name: 'Sprint Band', desc: '+10 Stamina', price: 160, bonus: { stamina: 10 } },
  { id: 'gear_focus', name: 'Focus Headband', desc: '+8 Reaction, +4 Accuracy', price: 200, bonus: { reaction: 8, accuracy: 4 } },
  { id: 'gear_pads', name: 'Titan Pads', desc: '+10 Strength', price: 220, bonus: { strength: 10 } },
  { id: 'gear_springs', name: 'Spring Soles', desc: '+10 Jump', price: 190, bonus: { jump: 10 } },
];
export const gearById = (id: string | null | undefined) => GEARS.find((g) => g.id === id) ?? null;

/* -------------------------------- Atlet --------------------------------- */
export interface Athlete {
  id: string;
  name: string;
  animal: AnimalId;
  position: Position;
  stats: AthleteStats;
  skill: string;
  skillDesc: string;
  hat: string;
  mask: string;
  cape: string;
  gear: string | null;
  wins: number;
  tp: number; // training points (pengalaman bertanding), bukan level
}

export function totalStat(a: Athlete): number {
  return STAT_KEYS.reduce((s, k) => s + a.stats[k], 0);
}

export function effectiveStats(a: Athlete): AthleteStats {
  const gear = gearById(a.gear);
  const out = { ...a.stats };
  if (gear) {
    for (const k of STAT_KEYS) out[k] = Math.min(99, out[k] + (gear.bonus[k] ?? 0));
  }
  return out;
}

const clampMod = (v: number) => Math.max(0.75, Math.min(1.3, 0.75 + (v / 100) * 0.55));

export function statsToMods(stats: AthleteStats): StatMods {
  return {
    speed: clampMod(stats.speed),
    accel: clampMod(stats.accel),
    strength: clampMod(stats.strength),
    jump: clampMod(stats.jump),
    balance: clampMod(stats.balance),
    stamina: clampMod(stats.stamina),
    accuracy: clampMod(stats.accuracy),
    power: clampMod(stats.power),
    control: clampMod(stats.control),
    reaction: clampMod(stats.reaction),
  };
}

function mk(
  id: string,
  name: string,
  animal: AnimalId,
  position: Position,
  stats: Partial<AthleteStats>,
  base: number,
  skill: string,
  skillDesc: string,
  look: { hat?: string; mask?: string; cape?: string } = {}
): Athlete {
  const full = {} as AthleteStats;
  for (const k of STAT_KEYS) full[k] = Math.min(STAT_CAP, Math.max(5, stats[k] ?? base));
  return {
    id,
    name,
    animal,
    position,
    stats: full,
    skill,
    skillDesc,
    hat: look.hat ?? 'none',
    mask: look.mask ?? 'none',
    cape: look.cape ?? 'none',
    gear: null,
    wins: 0,
    tp: 0,
  };
}

/* ------------------------------ Perekrutan ------------------------------ */
export type RecruitMethod =
  | { type: 'coin'; hall: 'hall_start' | 'hall_mid' | 'hall_neon'; price: number }
  | { type: 'found'; spot: string; hint: string }
  | { type: 'challenge'; text: string; stadium: number; wins: number }
  | { type: 'defeat'; text: string; stadium: number; match: number };

export interface RecruitDef {
  athlete: Athlete;
  method: RecruitMethod;
}

export const RECRUITS: RecruitDef[] = [
  // --- Aula Rekrut: Wobble Town (hall_start) ---
  { athlete: mk('r_cheetah', 'Dash', 'tiger', 'FWD', { speed: 78, accel: 70, stamina: 40, strength: 35 }, 42, 'Sprint Burst', 'Sangat cepat berlari (Speed tinggi)'), method: { type: 'coin', hall: 'hall_start', price: 260 } },
  { athlete: mk('r_rhino', 'Crusher', 'hippo', 'DEF', { strength: 82, balance: 66, speed: 30, jump: 28 }, 42, 'Bulldoze', 'Mendorong lawan dengan kuat (Strength tinggi)'), method: { type: 'coin', hall: 'hall_start', price: 260 } },
  { athlete: mk('r_bunny', 'Hop', 'rabbit', 'MID', { jump: 84, reaction: 62, strength: 28, balance: 40 }, 42, 'Sky Hop', 'Lompatan sangat tinggi (Jump tinggi)'), method: { type: 'coin', hall: 'hall_start', price: 240 } },
  { athlete: mk('r_cat', 'Miso', 'red_panda', 'MID', { balance: 82, control: 66, reaction: 58, power: 32 }, 42, 'Nine Lives', 'Sulit jatuh & cepat bangun (Balance tinggi)'), method: { type: 'coin', hall: 'hall_start', price: 240 } },
  // --- Aula Rekrut: tengah (hall_mid) ---
  { athlete: mk('r_dog', 'Rex', 'shiba', 'MID', { stamina: 86, speed: 54, control: 52, power: 38 }, 42, 'Endless Run', 'Stamina sangat tinggi, tidak cepat lelah'), method: { type: 'coin', hall: 'hall_mid', price: 420 } },
  { athlete: mk('r_gorilla', 'Kong', 'gorilla', 'DEF', { strength: 88, power: 70, speed: 32, accel: 30 }, 45, 'Iron Fist', 'Pukulan dan benturan sangat kuat'), method: { type: 'coin', hall: 'hall_mid', price: 520 } },
  { athlete: mk('r_owl', 'Hoot', 'owl', 'GK', { reaction: 88, accuracy: 62, balance: 60, speed: 34 }, 44, 'Night Eyes', 'Reaksi sangat cepat — kiper andalan'), method: { type: 'coin', hall: 'hall_mid', price: 480 } },
  { athlete: mk('r_flamingo', 'Flora', 'flamingo', 'FWD', { accuracy: 84, control: 70, power: 56, strength: 25 }, 44, 'Pin Point', 'Tendangan sangat akurat'), method: { type: 'coin', hall: 'hall_mid', price: 460 } },
  // --- Aula Rekrut: Neon City (hall_neon) ---
  { athlete: mk('r_wolf', 'Fang', 'wolf', 'FWD', { power: 86, speed: 72, accuracy: 60, balance: 40 }, 50, 'Alpha Strike', 'Tendangan keras dan lari cepat'), method: { type: 'coin', hall: 'hall_neon', price: 780 } },
  { athlete: mk('r_giraffe', 'Tall', 'giraffe', 'DEF', { jump: 80, reaction: 68, control: 62, speed: 44 }, 50, 'Long Reach', 'Jangkauan tinggi, lompatan unggul'), method: { type: 'coin', hall: 'hall_neon', price: 720 } },
  { athlete: mk('r_lion', 'Leo', 'lion', 'FWD', { power: 80, strength: 76, accuracy: 66, speed: 60 }, 55, 'Roar Shot', 'Penyerang serba bisa'), method: { type: 'coin', hall: 'hall_neon', price: 900 } },
  { athlete: mk('r_bear', 'Bruno', 'bear', 'DEF', { strength: 80, balance: 78, stamina: 70, speed: 40 }, 50, 'Bear Wall', 'Bek tangguh, sulit dijatuhkan'), method: { type: 'coin', hall: 'hall_neon', price: 760 } },
  // --- Ditemukan di perjalanan ---
  { athlete: mk('r_penguin', 'Pip', 'penguin', 'MID', { balance: 74, control: 70, stamina: 62, speed: 36 }, 44, 'Ice Slide', 'Atlet salju: stabil dan lincah'), method: { type: 'found', spot: 'found_snow', hint: 'Bersembunyi di dataran bersalju' } },
  { athlete: mk('r_croc', 'Snap', 'crocodile', 'DEF', { strength: 78, power: 64, speed: 36, accuracy: 30 }, 44, 'Jaw Clamp', 'Penjaga rawa yang kuat'), method: { type: 'found', spot: 'found_jungle', hint: 'Menunggu di pinggir sungai hutan' } },
  { athlete: mk('r_koala', 'Kobi', 'koala', 'MID', { stamina: 70, control: 76, balance: 64, power: 30 }, 44, 'Eucalyptus Calm', 'Tenang & kontrol bola bagus'), method: { type: 'found', spot: 'found_beach', hint: 'Bersantai di pantai' } },
  { athlete: mk('r_kangaroo', 'Joey', 'kangaroo', 'FWD', { jump: 78, power: 72, speed: 56, balance: 38 }, 46, 'Kangaroo Kick', 'Tendangan melompat'), method: { type: 'found', spot: 'found_secret', hint: 'Di jalan rahasia gunung' } },
  { athlete: mk('r_alpaca', 'Alma', 'alpaca', 'GK', { balance: 70, reaction: 72, control: 66, power: 28 }, 42, 'Fluffy Wall', 'Kiper berbulu tebal'), method: { type: 'found', spot: 'found_desert', hint: 'Di oasis gurun' } },
  // --- Tantangan ---
  { athlete: mk('r_capy', 'Chill', 'capybara', 'MID', { stamina: 80, balance: 76, control: 60, speed: 38 }, 46, 'Zen Mode', 'Santai tapi sulit dikalahkan'), method: { type: 'challenge', text: 'Menangkan 5 pertandingan di Desert Arena', stadium: 1, wins: 5 } },
  { athlete: mk('r_elephant', 'Tusk', 'elephant', 'DEF', { strength: 90, balance: 80, power: 66, speed: 22, accel: 24 }, 40, 'Trunk Slam', 'Raksasa yang sulit digeser'), method: { type: 'challenge', text: 'Menangkan 6 pertandingan di Mountain Stadium', stadium: 6, wins: 6 } },
  { athlete: mk('r_axolotl', 'Axel', 'axolotl', 'MID', { reaction: 78, control: 78, accuracy: 70, strength: 24 }, 46, 'Regenerate', 'Pemain teknis yang licin'), method: { type: 'challenge', text: 'Menangkan 4 pertandingan di Coastal Stadium', stadium: 4, wins: 4 } },
  // --- Mengalahkan tim tertentu ---
  { athlete: mk('r_rival_a', 'Blaze', 'tiger', 'FWD', { power: 80, speed: 70, accuracy: 68, strength: 52 }, 52, 'Blaze Shot', 'Rival jago tembakan'), method: { type: 'defeat', text: 'Kalahkan final Jungle Stadium', stadium: 3, match: 9 } },
  { athlete: mk('r_rival_b', 'Volt', 'wolf', 'MID', { speed: 82, accel: 80, reaction: 74, stamina: 70 }, 50, 'Volt Dash', 'Rival tercepat dari kota'), method: { type: 'defeat', text: 'Kalahkan final Industrial Stadium', stadium: 5, match: 9 } },
  { athlete: mk('r_rival_c', 'Queen B', 'lion', 'FWD', { power: 90, accuracy: 84, control: 78, strength: 70, speed: 66 }, 62, 'Royal Decree', 'Bintang Royal Championship'), method: { type: 'defeat', text: 'Kalahkan final Royal Championship', stadium: 8, match: 9 } },
];

export const START_ATHLETES = (heroAnimal: AnimalId): Athlete[] => [
  mk('hero', 'Hero', heroAnimal, 'FWD', {}, 40, 'All-Rounder', 'Atlet pemula serba bisa'),
  mk('buddy', 'Buddy', 'shiba', 'MID', { stamina: 46, speed: 44 }, 36, 'Loyal Pal', 'Sahabat setia yang siap membantu'),
];

export function fillerAthlete(i: number): Athlete {
  return mk(`filler_${i}`, `Rookie ${i + 1}`, ANIMALS[(i * 3 + 2) % ANIMALS.length].id, 'MID', {}, 26, 'Helper', 'Pemain bantuan sementara');
}

export function customOf(a: Athlete, fallback?: PlayerCustomization): PlayerCustomization {
  const base = fallback ?? DEFAULT_CUSTOMIZATION;
  return {
    ...base,
    animal: a.animal,
    hat: a.hat !== 'none' || !fallback ? a.hat : base.hat,
    mask: a.mask !== 'none' || !fallback ? a.mask : base.mask,
    cape: a.cape !== 'none' || !fallback ? a.cape : base.cape,
  };
}

/* ------------------------------ 10 Stadion ------------------------------ */
export interface StadiumSpec {
  index: number;
  name: string;
  subtitle: string;
  arena: ArenaId;
  ball: BallTypeId;
  weather: WeatherMode;
  color: string;
  icon: string;
  trophyName: string;
  teamNames: string[]; // 10 nama lawan
}

export const STADIUMS: StadiumSpec[] = [
  { index: 0, name: 'Green Valley Stadium', subtitle: 'Lapangan rumput hijau — lawan pemula', arena: 'meadow_park', ball: 'soccer', weather: 'sunny', color: '#4ade80', icon: '🌿', trophyName: 'Valley Cup', teamNames: ['Meadow Mice', 'Clover FC', 'Daisy Dribblers', 'Hay Bales', 'Brook Bunnies', 'Hilltop Hares', 'Farmland FC', 'Windmill United', 'Barn Stormers', 'Valley Kings'] },
  { index: 1, name: 'Desert Arena', subtitle: 'Lapangan pasir — bola & pemain berat', arena: 'desert_oasis', ball: 'pro_yellow', weather: 'sunny', color: '#fbbf24', icon: '🏜️', trophyName: 'Dune Cup', teamNames: ['Cactus Kids', 'Sandstorm FC', 'Scorpion Squad', 'Mirage United', 'Oasis Owls', 'Camel Corps', 'Dune Riders', 'Pyramid Stars', 'Sphinx Guard', 'Sultans of Sand'] },
  { index: 2, name: 'Snowfield Stadium', subtitle: 'Lapangan es — permukaan licin', arena: 'glacier_rink', ball: 'pro_blue', weather: 'snow', color: '#7dd3fc', icon: '❄️', trophyName: 'Frost Cup', teamNames: ['Snowballers', 'Icicle FC', 'Penguin Patrol', 'Blizzard Boys', 'Frostbite United', 'Yeti Squad', 'Polar Pals', 'Glacier Guard', 'Avalanche FC', 'Ice Kings'] },
  { index: 3, name: 'Jungle Stadium', subtitle: 'Stadion di tengah hutan', arena: 'jungle_temple', ball: 'rubber', weather: 'rain', color: '#22c55e', icon: '🌴', trophyName: 'Jungle Cup', teamNames: ['Vine Swingers', 'Parrot Posse', 'Monkey Business', 'Fern Fighters', 'Liana FC', 'Tiger Trail', 'Temple Guard', 'Canopy Crew', 'Jaguar Squad', 'Jungle Lords'] },
  { index: 4, name: 'Coastal Stadium', subtitle: 'Pantai — pasir & dekorasi laut', arena: 'tropical_beach', ball: 'beach_volleyball', weather: 'sunny', color: '#38bdf8', icon: '🏖️', trophyName: 'Coast Cup', teamNames: ['Seashell FC', 'Crab Claws', 'Tide Turners', 'Surf Squad', 'Palm Patrol', 'Dolphin Dash', 'Lighthouse FC', 'Pirate Crew', 'Wave Riders', 'Captains of the Coast'] },
  { index: 5, name: 'Industrial Stadium', subtitle: 'Kawasan industri — lapangan beton', arena: 'rooftop_skyline', ball: 'metal', weather: 'auto', color: '#94a3b8', icon: '🏭', trophyName: 'Steel Cup', teamNames: ['Rivet Rats', 'Gear Grinders', 'Forge FC', 'Conveyor Crew', 'Piston Pals', 'Crane Squad', 'Furnace United', 'Smokestack FC', 'Iron Foremen', 'Steel Titans'] },
  { index: 6, name: 'Mountain Stadium', subtitle: 'Dataran tinggi pegunungan', arena: 'volcano_caldera', ball: 'star_gbc', weather: 'auto', color: '#f97316', icon: '⛰️', trophyName: 'Summit Cup', teamNames: ['Pebble Pups', 'Goat Gang', 'Cliff Climbers', 'Eagle Eyes', 'Rockslide FC', 'Peak Patrol', 'Magma Mob', 'Crag Crushers', 'Summit Guard', 'Mountain Kings'] },
  { index: 7, name: 'Neon City Stadium', subtitle: 'Kota futuristik penuh lampu neon', arena: 'neon_dome', ball: 'crystal', weather: 'auto', color: '#a855f7', icon: '🌃', trophyName: 'Neon Cup', teamNames: ['Pixel Pack', 'Glow Gang', 'Circuit Breakers', 'Laser Lynx', 'Hologram FC', 'Synth Squad', 'Cyber Cats', 'Neon Knights', 'Data Dragons', 'Neon Overlords'] },
  { index: 8, name: 'Royal Championship Stadium', subtitle: 'Stadion mewah — lawan profesional', arena: 'grand_championship', ball: 'pro_gold', weather: 'sunny', color: '#facc15', icon: '👑', trophyName: 'Royal Crown', teamNames: ['Duke’s Dribblers', 'Baron FC', 'Count’s Crew', 'Knight Strikers', 'Royal Guard', 'Marquis United', 'Prince’s Pride', 'Crown Chasers', 'Queen’s Own', 'Royal Majesties'] },
  { index: 9, name: 'World Final Stadium', subtitle: 'Stadion terbesar — lawan terkuat', arena: 'floating_isles', ball: 'pro_gold', weather: 'auto', color: '#f43f5e', icon: '🌍', trophyName: 'World Trophy', teamNames: ['Challenger Zero', 'Rank Breakers', 'Elite Eleven', 'Planet Pros', 'Galaxy Guard', 'Cosmic Crew', 'Titan Tamers', 'Legends United', 'World Wonders', 'The Champions'] },
];

export const CHAMPIONSHIP_TEAMS = ['World Champions: Vanguard', 'World Champions: Eclipse', 'World Champions: Wobble Gods'];

export const BOSS_STYLES: BossAiStyle[] = [
  'power_shot',
  'rubber_header',
  'curve_master',
  'elastic_reach',
  'aerial_flip',
  'balanced_titan',
];

export const WIN_REQUIRED_MATCHES = 10;

/* ------------------------------- Save data ------------------------------ */
export interface AdventureSave {
  version: 1;
  started: boolean;
  coins: number;
  roster: Athlete[];
  lineup: string[]; // id atlet (maks 3); pertama = kapten (dikendalikan pemain)
  inventory: string[]; // id perlengkapan yang dimiliki (bisa duplikat)
  wins: number[]; // jumlah pertandingan menang berurutan per stadion (0..10)
  trophies: boolean[]; // 10 trofi
  discovered: boolean[]; // stadion yang sudah ditemukan
  championshipWins: number;
  championshipCleared: boolean;
  pos: { x: number; y: number };
  openedChests: string[];
  foundRecruits: string[]; // id atlet yang sudah bergabung
  talked: string[];
  settings: { autosave: boolean; minimap: boolean };
  savedAt: number;
  manualSaves: number;
  heroCustom: PlayerCustomization;
}

export const ADVENTURE_STORAGE_KEY = 'wobble_openworld_story_v1';

export function createNewAdventure(heroCustom?: PlayerCustomization): AdventureSave {
  const hc = heroCustom ?? DEFAULT_CUSTOMIZATION;
  const roster = START_ATHLETES(hc.animal);
  roster[0].hat = hc.hat;
  roster[0].mask = hc.mask;
  roster[0].cape = hc.cape;
  return {
    version: 1,
    started: false,
    coins: 300,
    roster,
    lineup: roster.map((r) => r.id),
    inventory: [],
    wins: Array(10).fill(0),
    trophies: Array(10).fill(false),
    discovered: Array(10).fill(false),
    championshipWins: 0,
    championshipCleared: false,
    pos: { x: -1, y: -1 }, // -1 = pakai posisi awal peta
    openedChests: [],
    foundRecruits: [],
    talked: [],
    settings: { autosave: true, minimap: true },
    savedAt: 0,
    manualSaves: 0,
    heroCustom: { ...hc },
  };
}

export function loadAdventure(): AdventureSave {
  try {
    const raw = localStorage.getItem(ADVENTURE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AdventureSave;
      if (parsed && parsed.version === 1 && Array.isArray(parsed.roster)) {
        const fresh = createNewAdventure();
        return { ...fresh, ...parsed, settings: { ...fresh.settings, ...(parsed.settings ?? {}) } };
      }
    }
  } catch {
    // abaikan
  }
  return createNewAdventure();
}

export function persistAdventure(save: AdventureSave): void {
  try {
    localStorage.setItem(ADVENTURE_STORAGE_KEY, JSON.stringify({ ...save, savedAt: Date.now() }));
  } catch {
    // abaikan
  }
}

export function hasAdventureSave(): boolean {
  try {
    const raw = localStorage.getItem(ADVENTURE_STORAGE_KEY);
    if (!raw) return false;
    const p = JSON.parse(raw) as AdventureSave;
    return Boolean(p && p.started);
  } catch {
    return false;
  }
}

export function clearAdventure(): void {
  try {
    localStorage.removeItem(ADVENTURE_STORAGE_KEY);
  } catch {
    // abaikan
  }
}

export const trophyCount = (s: AdventureSave) => s.trophies.filter(Boolean).length;

/** World Final Stadium terkunci sampai 9 trofi lainnya terkumpul */
export function stadiumLockReason(s: AdventureSave, stadium: number): string | null {
  if (stadium === 9) {
    const others = s.trophies.slice(0, 9).filter(Boolean).length;
    if (others < 9) return `Kumpulkan 9 trofi dari stadion lain dulu (${others}/9)`;
  }
  return null;
}

export const championshipUnlocked = (s: AdventureSave) => trophyCount(s) >= 10 && !s.championshipCleared;

/* ---------------------------- Lawan & pertandingan ---------------------------- */
function rng(seed: number) {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6d2b79f5) >>> 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export const teamSizeFor = (match: number) => (match < 3 ? 1 : match < 7 ? 2 : 3);

export function matchGlobalIndex(stadium: number, match: number) {
  return stadium * 10 + match;
}

export function opponentDifficulty(g: number) {
  return Math.min(1, 0.35 + 0.65 * (g / 99));
}

export function makeOpponentAthlete(g: number, slot: number, isChamp = false): Athlete {
  const r = rng(g * 977 + slot * 131 + 7);
  const base = isChamp ? 92 : 26 + g * 0.58;
  const animal = ANIMALS[Math.floor(r() * ANIMALS.length)].id;
  const stats = {} as AthleteStats;
  for (const k of STAT_KEYS) stats[k] = Math.round(Math.min(99, Math.max(10, base + (r() - 0.5) * 16 + (slot === 0 ? 4 : 0))));
  // 2 atribut unggulan
  const fav = [STAT_KEYS[Math.floor(r() * 10)], STAT_KEYS[Math.floor(r() * 10)]];
  for (const k of fav) stats[k] = Math.min(99, stats[k] + 12);
  const hats = HATS.filter((h) => h.id !== 'none');
  const masks = MASKS.filter((m) => m.id !== 'none');
  const capes = CAPES.filter((c) => c.id !== 'none');
  return {
    id: `opp_${g}_${slot}`,
    name: `Opp ${g}-${slot}`,
    animal,
    position: 'MID',
    stats,
    skill: '',
    skillDesc: '',
    hat: r() < 0.7 ? hats[Math.floor(r() * hats.length)]?.id ?? 'none' : 'none',
    mask: r() < 0.3 ? masks[Math.floor(r() * masks.length)]?.id ?? 'none' : 'none',
    cape: r() < 0.5 ? capes[Math.floor(r() * capes.length)]?.id ?? 'none' : 'none',
    gear: null,
    wins: 0,
    tp: 0,
  };
}

export interface AdventureMatchInfo {
  stadium: number;
  match: number;
  title: string;
  opponentName: string;
  teamSize: number;
  difficulty: number;
  isFinal: boolean;
  isChampionship: boolean;
  bossStyle?: BossAiStyle;
  durationMinutes: 2 | 3;
  avgOpponentStat: number;
}

export function describeMatch(stadium: number, match: number): AdventureMatchInfo {
  if (stadium === 10) {
    return {
      stadium,
      match,
      title: `World Championship — Match ${match + 1}/3`,
      opponentName: CHAMPIONSHIP_TEAMS[match] ?? CHAMPIONSHIP_TEAMS[0],
      teamSize: 3,
      difficulty: 1,
      isFinal: match === 2,
      isChampionship: true,
      bossStyle: 'balanced_titan',
      durationMinutes: 3,
      avgOpponentStat: 92,
    };
  }
  const st = STADIUMS[stadium];
  const g = matchGlobalIndex(stadium, match);
  return {
    stadium,
    match,
    title: match === 9 ? `${st.name} — FINAL` : `${st.name} — Match ${match + 1}/10`,
    opponentName: st.teamNames[match],
    teamSize: teamSizeFor(match),
    difficulty: opponentDifficulty(g),
    isFinal: match === 9,
    isChampionship: false,
    bossStyle: match === 9 ? BOSS_STYLES[stadium % BOSS_STYLES.length] : undefined,
    durationMinutes: match === 9 ? 3 : 2,
    avgOpponentStat: Math.round(26 + g * 0.58),
  };
}

/** Atlet yang akan dimainkan (urut: kapten dulu), dilengkapi pemain bantuan bila kurang */
export function resolveLineup(save: AdventureSave, size: number): Athlete[] {
  const picked: Athlete[] = [];
  for (const id of save.lineup) {
    const a = save.roster.find((r) => r.id === id);
    if (a && !picked.includes(a)) picked.push(a);
  }
  if (picked.length === 0 && save.roster[0]) picked.push(save.roster[0]);
  const out = picked.slice(0, size);
  let f = 0;
  while (out.length < size) out.push(fillerAthlete(f++));
  return out;
}

export function createAdventureMatchConfig(
  save: AdventureSave,
  stadium: number,
  match: number,
  base?: MatchConfig
): MatchConfig {
  const info = describeMatch(stadium, match);
  const st = STADIUMS[Math.min(9, stadium)];
  const def = base ?? createDefaultMatchConfig();
  const lineup = resolveLineup(save, info.teamSize);
  const g = info.isChampionship ? 99 : matchGlobalIndex(stadium, match);

  const playerStats: Record<string, StatMods> = {};
  const teamCustoms: Record<string, PlayerCustomization> = {};
  lineup.forEach((a, i) => {
    playerStats[`red_${i}`] = statsToMods(effectiveStats(a));
    if (i > 0) teamCustoms[`red_${i}`] = customOf(a);
  });
  let oppCustom0: PlayerCustomization = { ...DEFAULT_CUSTOMIZATION };
  for (let i = 0; i < info.teamSize; i++) {
    const o = makeOpponentAthlete(g, i, info.isChampionship);
    playerStats[`blue_${i}`] = statsToMods(o.stats);
    const c = customOf(o);
    teamCustoms[`blue_${i}`] = c;
    if (i === 0) oppCustom0 = c;
  }
  const captain = lineup[0];

  return {
    ...def,
    mode: 'story',
    matchSubMode: 'quick',
    localPlayerCount: 1,
    redCount: info.teamSize,
    blueCount: info.teamSize,
    p1Team: 'red',
    p2Team: 'blue',
    p1Custom: customOf(captain, save.heroCustom),
    durationMinutes: info.durationMinutes,
    halves: 1,
    scoreLimit: null,
    arena: st.arena,
    arenaRandom: false,
    ballType: info.isChampionship ? 'pro_gold' : st.ball,
    weatherMode: st.weather,
    aiDifficulty: info.difficulty > 0.8 ? 'hard' : info.difficulty > 0.5 ? 'normal' : 'easy',
    itemSpawnMode: stadium === 0 && match < 3 ? 'off' : 'on',
    storyStageIndex: g,
    storyWorldIndex: stadium,
    storyMatchIndex: match,
    storyAi: { difficulty: info.difficulty, bossStyle: info.bossStyle, opponentName: info.opponentName },
    storyOpponentCustom: oppCustom0,
    playerStats,
    teamCustoms,
    adventure: { stadium, match },
  };
}

/* ---------------------------- Hasil pertandingan ---------------------------- */
export interface AdventureResult {
  won: boolean;
  redScore: number;
  blueScore: number;
  stadium: number;
  match: number;
  coins: number;
  tp: number;
  trophyEarned: boolean;
  stadiumCleared: boolean;
  championshipCleared: boolean;
  recruits: Athlete[];
  allTrophies: boolean;
  info: AdventureMatchInfo;
}

export function evaluateRecruitUnlocks(save: AdventureSave): Athlete[] {
  const joined: Athlete[] = [];
  for (const def of RECRUITS) {
    const id = def.athlete.id;
    if (save.foundRecruits.includes(id)) continue;
    const m = def.method;
    let ok = false;
    if (m.type === 'challenge') ok = save.wins[m.stadium] >= m.wins;
    if (m.type === 'defeat') ok = save.wins[m.stadium] > m.match;
    if (ok && save.roster.length < ROSTER_LIMIT) {
      save.roster.push({ ...def.athlete, stats: { ...def.athlete.stats } });
      save.foundRecruits.push(id);
      joined.push(def.athlete);
    }
  }
  return joined;
}

export function completeAdventureMatch(
  prev: AdventureSave,
  stadium: number,
  match: number,
  redScore: number,
  blueScore: number
): { save: AdventureSave; result: AdventureResult } {
  const save: AdventureSave = JSON.parse(JSON.stringify(prev));
  const info = describeMatch(stadium, match);
  const won = redScore > blueScore;
  let coins = 0;
  let tp = 0;
  let trophyEarned = false;
  let stadiumCleared = false;
  let championshipCleared = false;

  if (won) {
    const g = info.isChampionship ? 100 : matchGlobalIndex(stadium, match);
    coins = 40 + Math.round(g * 3.2) + (info.isFinal ? 220 : 0);
    tp = 3 + (info.isFinal ? 8 : 0);
    if (info.isChampionship) {
      save.championshipWins = Math.max(save.championshipWins, match + 1);
      if (match === 2) {
        save.championshipCleared = true;
        championshipCleared = true;
      }
    } else if (save.wins[stadium] === match) {
      save.wins[stadium] = match + 1;
      if (match === 9 && !save.trophies[stadium]) {
        save.trophies[stadium] = true;
        trophyEarned = true;
        stadiumCleared = true;
      }
    }
  } else {
    coins = 10;
    tp = 1;
  }
  save.coins += coins;
  // Pengalaman bertanding: seluruh atlet yang main mendapat TP
  const players = resolveLineup(save, info.teamSize);
  for (const p of players) {
    const a = save.roster.find((r) => r.id === p.id);
    if (a) {
      a.tp += tp;
      if (won) a.wins += 1;
    }
  }
  const recruits = evaluateRecruitUnlocks(save);
  const result: AdventureResult = {
    won,
    redScore,
    blueScore,
    stadium,
    match,
    coins,
    tp,
    trophyEarned,
    stadiumCleared,
    championshipCleared,
    recruits,
    allTrophies: trophyCount(save) >= 10,
    info,
  };
  return { save, result };
}

/* --------------------------- Aksi: toko & tim --------------------------- */
export function buyGear(save: AdventureSave, gearId: string): AdventureSave | string {
  const g = gearById(gearId);
  if (!g) return 'Perlengkapan tidak ditemukan';
  if (save.coins < g.price) return 'Koin tidak cukup';
  return { ...save, coins: save.coins - g.price, inventory: [...save.inventory, g.id] };
}

export function equipGear(save: AdventureSave, athleteId: string, gearId: string | null): AdventureSave | string {
  const roster = save.roster.map((a) => ({ ...a }));
  const a = roster.find((r) => r.id === athleteId);
  if (!a) return 'Atlet tidak ditemukan';
  let inventory = [...save.inventory];
  if (a.gear) inventory.push(a.gear); // kembalikan yang lama
  a.gear = null;
  if (gearId) {
    const idx = inventory.indexOf(gearId);
    if (idx < 0) return 'Perlengkapan tidak dimiliki';
    inventory.splice(idx, 1);
    a.gear = gearId;
  }
  inventory = inventory.filter(Boolean);
  return { ...save, roster, inventory };
}

export function recruitWithCoins(save: AdventureSave, athleteId: string): AdventureSave | string {
  const def = RECRUITS.find((r) => r.athlete.id === athleteId);
  if (!def || def.method.type !== 'coin') return 'Atlet tidak bisa dibeli';
  if (save.foundRecruits.includes(athleteId)) return 'Sudah bergabung';
  if (save.roster.length >= ROSTER_LIMIT) return `Roster penuh (maks ${ROSTER_LIMIT})`;
  if (save.coins < def.method.price) return 'Koin tidak cukup';
  return {
    ...save,
    coins: save.coins - def.method.price,
    roster: [...save.roster, { ...def.athlete, stats: { ...def.athlete.stats } }],
    foundRecruits: [...save.foundRecruits, athleteId],
  };
}

export function recruitFound(save: AdventureSave, spot: string): { save: AdventureSave; athlete: Athlete | null; msg: string } {
  const def = RECRUITS.find((r) => r.method.type === 'found' && r.method.spot === spot);
  if (!def) return { save, athlete: null, msg: 'Tidak ada siapa-siapa di sini.' };
  if (save.foundRecruits.includes(def.athlete.id)) return { save, athlete: null, msg: `${def.athlete.name} sudah bergabung di timmu.` };
  if (save.roster.length >= ROSTER_LIMIT) return { save, athlete: null, msg: `Roster penuh (maks ${ROSTER_LIMIT}). Keluarkan atlet dulu.` };
  return {
    save: { ...save, roster: [...save.roster, { ...def.athlete, stats: { ...def.athlete.stats } }], foundRecruits: [...save.foundRecruits, def.athlete.id] },
    athlete: def.athlete,
    msg: `${def.athlete.name} bergabung ke timmu!`,
  };
}

export function releaseAthlete(save: AdventureSave, athleteId: string): AdventureSave | string {
  if (athleteId === 'hero') return 'Hero tidak bisa dikeluarkan';
  if (save.roster.length <= 1) return 'Roster minimal 1 atlet';
  const a = save.roster.find((r) => r.id === athleteId);
  if (!a) return 'Atlet tidak ditemukan';
  return {
    ...save,
    roster: save.roster.filter((r) => r.id !== athleteId),
    lineup: save.lineup.filter((l) => l !== athleteId),
    inventory: a.gear ? [...save.inventory, a.gear] : save.inventory,
    foundRecruits: save.foundRecruits.filter((f) => f !== athleteId),
  };
}

export function setLineup(save: AdventureSave, lineup: string[]): AdventureSave {
  return { ...save, lineup: lineup.slice(0, LINEUP_LIMIT) };
}

export function trainStat(save: AdventureSave, athleteId: string, key: StatKey): AdventureSave | string {
  const roster = save.roster.map((a) => ({ ...a, stats: { ...a.stats } }));
  const a = roster.find((r) => r.id === athleteId);
  if (!a) return 'Atlet tidak ditemukan';
  if (a.tp < 1) return 'Pengalaman (TP) tidak cukup — menangkan pertandingan!';
  if (a.stats[key] >= STAT_CAP) return 'Statistik sudah maksimal';
  a.tp -= 1;
  a.stats[key] += 1;
  return { ...save, roster };
}
