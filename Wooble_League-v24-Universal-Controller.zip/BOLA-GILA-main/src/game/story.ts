import {
  AnimalId,
  ArenaId,
  BallTypeId,
  BossAiStyle,
  MatchConfig,
  PlayerCustomization,
  StoryAiProfile,
  TeamId,
} from './types';
import { createDefaultMatchConfig } from './catalog';

export type DialogueEmotion = 'neutral' | 'happy' | 'angry' | 'surprised' | 'confident';

export interface DialogueChoice {
  key: 'A' | 'B' | 'C';
  label: string;
  replyLine: string;
  replyEmotion: DialogueEmotion;
  heroFollowUp?: string;
}

export interface DialogueLine {
  speaker: 'hero' | 'opponent' | 'narrator';
  speakerName: string;
  emotion: DialogueEmotion;
  text: string;
  choices?: DialogueChoice[];
}

export type StoryRankLabel =
  | 'Rookie'
  | 'Challenger'
  | 'Skilled Player'
  | 'Elite Player'
  | 'Boss Champion';

export interface StoryRewardSpec {
  coins: number;
  unlockAnimal?: AnimalId;
  unlockHat?: string;
  unlockMask?: string;
  unlockCape?: string;
  trophyId?: string;
  trophyName?: string;
  titleBadge?: string;
}

export interface StoryMatchSpec {
  matchIndex: number; // 0..4
  rank: StoryRankLabel;
  isBoss: boolean;
  opponentName: string;
  opponentTeam: TeamId;
  opponentCustom: PlayerCustomization;
  ball: BallTypeId;
  durationMinutes: 2 | 5;
  halves: 1 | 2;
  difficulty: number;
  bossStyle?: BossAiStyle;
  bossStyleLabel?: string;
  reward: StoryRewardSpec;
  preMatchDialogue: DialogueLine[];
  postWinDialogue: DialogueLine[];
  postLoseLine: string;
}

export interface StoryWorldSpec {
  worldIndex: number; // 0..9
  worldNumber: number; // 1..10
  name: string;
  subtitle: string;
  arena: ArenaId;
  themeColor: string;
  accentColor: string;
  mapX: number; // SVG 0..1000 coordinate
  mapY: number; // SVG 0..460 coordinate
  trophyId: string;
  trophyName: string;
  trophyColor: string;
  worldTitle: string;
  matches: StoryMatchSpec[];
}

export interface StoryProgressState {
  coins: number;
  highestWorldUnlocked: number; // 0..9
  highestMatchPerWorld: number[]; // 0..5 (5 means world boss cleared)
  completedMatches: string[]; // "worldIdx-matchIdx"
  unlockedTrophies: string[];
  unlockedTitles: string[];
  unlockedAnimals: AnimalId[];
  unlockedHats: string[];
  unlockedMasks: string[];
  unlockedCapes: string[];
  championEndingCleared: boolean;
  lastSelectedWorld: number;
  lastSelectedMatch: number;
}

export const STORY_STORAGE_KEY = 'rubber_pitch_world_tour_v1';

export const BOSS_STYLE_LABELS: Record<BossAiStyle, string> = {
  power_shot: 'Power Cannon Shot',
  rubber_header: 'Rubber Neck Header',
  curve_master: '180° Curve Master',
  elastic_reach: 'Elastic Blitz Dash',
  aerial_flip: 'Aerial Fire Backflip',
  balanced_titan: 'All-Round Grand Titan',
};

const RANK_LABELS: StoryRankLabel[] = [
  'Rookie',
  'Challenger',
  'Skilled Player',
  'Elite Player',
  'Boss Champion',
];

function makeMatch(
  worldIndex: number,
  matchIndex: number,
  worldName: string,
  opponentName: string,
  opponentCustom: PlayerCustomization,
  ball: BallTypeId,
  difficulty: number,
  coins: number,
  extraReward: Omit<StoryRewardSpec, 'coins'>,
  introSpeech: string,
  choices: DialogueChoice[],
  bossSpeech: string,
  winSpeech: string,
  loseSpeech: string,
  bossStyle?: BossAiStyle
): StoryMatchSpec {
  const isBoss = matchIndex === 4;
  const rank = RANK_LABELS[matchIndex];
  const preMatchDialogue: DialogueLine[] = isBoss
    ? [
        {
          speaker: 'narrator',
          speakerName: 'Tournament Herald',
          emotion: 'confident',
          text: `${worldName} Finale! Boss Champion ${opponentName} steps onto the pitch!`,
        },
        {
          speaker: 'opponent',
          speakerName: opponentName,
          emotion: 'confident',
          text: introSpeech,
          choices,
        },
        {
          speaker: 'opponent',
          speakerName: opponentName,
          emotion: 'angry',
          text: bossSpeech,
        },
      ]
    : [
        {
          speaker: 'opponent',
          speakerName: opponentName,
          emotion: 'confident',
          text: introSpeech,
          choices,
        },
        {
          speaker: 'hero',
          speakerName: 'You',
          emotion: 'happy',
          text: bossSpeech,
        },
      ];

  const postWinDialogue: DialogueLine[] = [
    {
      speaker: 'opponent',
      speakerName: opponentName,
      emotion: 'surprised',
      text: winSpeech,
    },
    {
      speaker: 'hero',
      speakerName: 'You',
      emotion: 'happy',
      text: isBoss
        ? `Victory! ${worldName} Champion Trophy is ours!`
        : `Great match! Onward to the next challenger in ${worldName}!`,
    },
  ];

  return {
    matchIndex,
    rank,
    isBoss,
    opponentName,
    opponentTeam: 'blue',
    opponentCustom,
    ball,
    durationMinutes: 2,
    halves: 2,
    difficulty,
    bossStyle,
    bossStyleLabel: bossStyle ? BOSS_STYLE_LABELS[bossStyle] : undefined,
    reward: {
      coins,
      ...extraReward,
    },
    preMatchDialogue,
    postWinDialogue,
    postLoseLine: loseSpeech,
  };
}

export const STORY_WORLDS: StoryWorldSpec[] = [
  // WORLD 1 — Green Valley
  {
    worldIndex: 0,
    worldNumber: 1,
    name: 'Green Valley',
    subtitle: 'Lush starter meadows & sunny turf',
    arena: 'meadow_park',
    themeColor: '#22c55e',
    accentColor: '#bbf7d0',
    mapX: 84,
    mapY: 365,
    trophyId: 'trophy_green_valley',
    trophyName: 'Emerald Meadow Cup',
    trophyColor: '#4ade80',
    worldTitle: 'Valley Kickoff Star',
    matches: [
      makeMatch(
        0, 0, 'Green Valley', 'Pip the Sprout',
        { animal: 'alpaca', hat: 'flower_pot', mask: 'none', cape: 'none' },
        'soccer', 0.36, 45, { unlockHat: 'flower_pot' },
        'Welcome to Green Valley! Ready for your very first World Tour match?',
        [
          { key: 'A', label: 'A. Let us have a fun match!', replyLine: 'That is the spirit! Watch my rubber pass!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Watch out for my spin kick!', replyLine: 'Whoa, eager rookie! Let us see what you got!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. I am taking the trophy!', replyLine: 'Big talk! First get past me on the meadow!', replyEmotion: 'confident' },
        ],
        'Let us warm up those rubber legs and chase that ball!',
        'Whoa! That spin kick nearly blew my sprout pot right off!',
        'Nice try! Keep charging your kicks and challenge me again!'
      ),
      makeMatch(
        0, 1, 'Green Valley', 'Biscuit Shiba',
        { animal: 'shiba', hat: 'propeller', mask: 'none', cape: 'bath_towel' },
        'soccer', 0.42, 55, { unlockAnimal: 'shiba' },
        'I zoom around this meadow every morning! Think you can keep up?',
        [
          { key: 'A', label: 'A. Speed versus power!', replyLine: 'Haha! Catch my propeller tail if you can!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. My dash is faster!', replyLine: 'Oh yeah? Race you straight to kickoff!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Stay sharp in goal!', replyLine: 'Bark! I never let a slow shot slip by!', replyEmotion: 'angry' },
        ],
        'Dash timing wins possession—watch my flank!',
        'You out-dashed even me! What a slick strike!',
        'Too slow on the turn! Time your dash when the ball rolls free.'
      ),
      makeMatch(
        0, 2, 'Green Valley', 'Milo Capy',
        { animal: 'capybara', hat: 'cheese_wedge', mask: 'googly', cape: 'none' },
        'rubber', 0.48, 65, { unlockMask: 'googly' },
        'I swapped in a hyper-bouncy Rubber Ball. Ready for crazy rebounds?',
        [
          { key: 'A', label: 'A. Love chaotic bounces!', replyLine: 'Chill vibes and wild ricochets—my favorite!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I read every bounce!', replyLine: 'Ooh, a physics wizard? Prove it on the pitch!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. One clean shot ends it.', replyLine: 'Good luck aiming when it rockets off every post!', replyEmotion: 'confident' },
        ],
        'Stay calm and time that rubber rebound!',
        'Even my googly glasses could not track that angle!',
        'Haha, the bouncy ball fooled you! Aim lower off the wall.'
      ),
      makeMatch(
        0, 3, 'Green Valley', 'Chef Barnaby',
        { animal: 'red_panda', hat: 'chef_toque', mask: 'mustache', cape: 'pizza_slice' },
        'soccer', 0.54, 75, { unlockHat: 'chef_toque' },
        'Only one hurdle left before Boss Sir Wooly! Care for a spicy volley?',
        [
          { key: 'A', label: 'A. Serve up your best shot!', replyLine: 'Magnifique! One flaming header coming right up!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I will block every dish!', replyLine: 'Hmph! My pizza cape brings top-shelf speed!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Show me your secret move!', replyLine: 'Hold your kick button to unleash Super Kicks!', replyEmotion: 'confident' },
        ],
        'Time to cook up a crisp Super Kick!',
        'Order up—one well-deserved victory for you!',
        'Overcooked that shot! Hold A a beat longer for extra power.'
      ),
      makeMatch(
        0, 4, 'Green Valley', 'Sir Wooly',
        { animal: 'alpaca', hat: 'royal_crown', mask: 'none', cape: 'royal_velvet' },
        'soccer', 0.6, 150,
        { unlockHat: 'royal_crown', unlockCape: 'royal_velvet', trophyId: 'trophy_green_valley', trophyName: 'Emerald Meadow Cup', titleBadge: 'Valley Kickoff Star' },
        'I am Sir Wooly, Guardian of Green Valley! Every traveler must prove their kick against my Power Cannon!',
        [
          { key: 'A', label: 'A. Your crown looks great—mind if I earn a cup?', replyLine: 'A courteous rival! Then let us clash with full honor!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Your Power Shot will not break my defense!', replyLine: 'Bold words! Brace yourself when my Super Kick ignites!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Show me what a Boss Champion plays like!', replyLine: 'Gladly! Watch the turf tremble under my hooves!', replyEmotion: 'confident' },
        ],
        'Feel the thunder of Green Valley’s Power Cannon Shot!',
        'Bravo! Your rubber technique shattered my defense. Green Valley salutes its new champion!',
        'A noble attempt! Jump + A fire backflips can counter my cannon shots.',
        'power_shot'
      ),
    ],
  },

  // WORLD 2 — Tropical Beach
  {
    worldIndex: 1,
    worldNumber: 2,
    name: 'Tropical Beach',
    subtitle: 'Sunlit golden sands & ocean breezes',
    arena: 'tropical_beach',
    themeColor: '#06b6d4',
    accentColor: '#bae6fd',
    mapX: 182,
    mapY: 230,
    trophyId: 'trophy_tropical_beach',
    trophyName: 'Coral Wave Trophy',
    trophyColor: '#38bdf8',
    worldTitle: 'Coastal Volley Ace',
    matches: [
      makeMatch(
        1, 0, 'Tropical Beach', 'Sunny Flippers',
        { animal: 'penguin', hat: 'duck_float', mask: 'snorkel', cape: 'bath_towel' },
        'beach_volleyball', 0.44, 55, { unlockMask: 'snorkel' },
        'Aloha! Out here the giant Beach Ball floats on every ocean gust!',
        [
          { key: 'A', label: 'A. Floaty balls are fun!', replyLine: 'Right?! Jump high and spike it into the net!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Watch my aerial lob!', replyLine: 'Ooh, Jump+X lob tricks? I have my snorkel ready!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Sand will not slow me down!', replyLine: 'Let us splash into action then!', replyEmotion: 'confident' },
        ],
        'Jump + X lobs soar sky-high with this giant Beach Ball!',
        'Splash-tastic goal! Even with my duck float I could not reach!',
        'Wait for the slow drop, then strike cleanly!'
      ),
      makeMatch(
        1, 1, 'Tropical Beach', 'Coco Roo',
        { animal: 'kangaroo', hat: 'banana_bunch', mask: 'none', cape: 'none' },
        'beach_volleyball', 0.5, 65, { unlockHat: 'banana_bunch' },
        'Boing! Nobody leaps higher over beach waves than a Kangaroo!',
        [
          { key: 'A', label: 'A. Let us see who jumps higher!', replyLine: 'Challenge accepted! Watch these spring heels fly!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Ground shots beat high hops!', replyLine: 'Clever! Let us see if your low spin sneaks past!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Nice banana crown!', replyLine: 'Hands off my potassium power-up!', replyEmotion: 'angry' },
        ],
        'Time my hops and meet the ball mid-air!',
        'Crikey! You grounded my best bounce!',
        'Keep the ball low against high jumpers!'
      ),
      makeMatch(
        1, 2, 'Tropical Beach', 'Coral Axolotl',
        { animal: 'axolotl', hat: 'cactus', mask: 'none', cape: 'rainbow_ribbon' },
        'ostrich_egg', 0.55, 75, { unlockAnimal: 'axolotl' },
        'Found an Ostrich Egg near the tide pools! Its oval roll curves unexpectedly!',
        [
          { key: 'A', label: 'A. Oval physics? Bring it on!', replyLine: 'Wheee! Nobody knows where it bounces next!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I will tame that egg!', replyLine: 'Confident, aren’t we? Try curving it past me!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Smooth rainbow footwork wins.', replyLine: 'Let us test your footwork on warm sand!', replyEmotion: 'confident' },
        ],
        'Watch the wild wobble of the Ostrich Egg!',
        'Bubble-pop! You mastered the egg bounce!',
        'Those uneven oval rebounds are tricky—aim straight through center!'
      ),
      makeMatch(
        1, 3, 'Tropical Beach', 'Tiki Flamingo',
        { animal: 'flamingo', hat: 'sombrero', mask: 'pixel_shades', cape: 'none' },
        'soccer', 0.62, 85, { unlockMask: 'pixel_shades' },
        'Cool shades, cooler kicks! Beat me and you earn your shot at Captain Reef!',
        [
          { key: 'A', label: 'A. Love the beach style!', replyLine: 'Style plus precision equals unstoppable goals!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. My shades would look sharper!', replyLine: 'Earn them by scoring past my one-leg stance!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Prepare for blazing shots!', replyLine: 'Whoa, bring the heat—this beach can handle it!', replyEmotion: 'angry' },
        ],
        'One last warm-up before the Tide Boss!',
        'Too cool! My shades slid right off my beak!',
        'Keep pressure on the sidelines—Captain Reef curves shots hard!'
      ),
      makeMatch(
        1, 4, 'Tropical Beach', 'Captain Reef',
        { animal: 'crocodile', hat: 'octopus', mask: 'none', cape: 'leaf_cloak' },
        'beach_volleyball', 0.68, 180,
        { unlockAnimal: 'crocodile', unlockHat: 'octopus', trophyId: 'trophy_tropical_beach', trophyName: 'Coral Wave Trophy', titleBadge: 'Coastal Volley Ace' },
        'Ahoy, challenger! I am Captain Reef! My 180° Curve Master spin bends every shot like a riptide!',
        [
          { key: 'A', label: 'A. Ready to ride your tidal wave!', replyLine: 'Ha! Hope your sea legs are steady!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I will curve one right back!', replyLine: 'Try out-spinning an old sea croc? Show me!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. That octopus hat is awesome!', replyLine: 'Eight tentacles help me spot every angle—en garde!', replyEmotion: 'surprised' },
        ],
        'Brace for my twisting 180° Riptide Spin!',
        'Blimey! You sliced straight through my tidal spin! Take the Coral Wave Trophy!',
        'Caught in my undertow! Watch which side my spin curls from.' ,
        'curve_master'
      ),
    ],
  },

  // WORLD 3 — Snow Mountain
  {
    worldIndex: 2,
    worldNumber: 3,
    name: 'Snow Mountain',
    subtitle: 'Frozen alpine peaks & slick hockey rinks',
    arena: 'glacier_rink',
    themeColor: '#38bdf8',
    accentColor: '#e0f2fe',
    mapX: 295,
    mapY: 135,
    trophyId: 'trophy_snow_mountain',
    trophyName: 'Glacier Crest Cup',
    trophyColor: '#7dd3fc',
    worldTitle: 'Sub-Zero Striker',
    matches: [
      makeMatch(
        2, 0, 'Snow Mountain', 'Chilly Pip',
        { animal: 'penguin', hat: 'propeller', mask: 'none', cape: 'none' },
        'hockey', 0.5, 65, { unlockAnimal: 'penguin' },
        'Brrr! Up here on Glacier Rink, the Hockey Puck glides across the pitch at lightning speed!',
        [
          { key: 'A', label: 'A. Slide-tackle time!', replyLine: 'Waddle and slide! Mind those sharp corners!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Fast pucks suit me!', replyLine: 'Then watch how fast it rockets off the ice wall!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Hope it is not too cold!', replyLine: 'A fierce match warms everyone right up!', replyEmotion: 'surprised' },
        ],
        'Low flat shots glide fastest with the Hockey Puck!',
        'Brrr-illiant! You thawed my frozen defense!',
        'The puck slides fast—intercept early before it reaches the box!'
      ),
      makeMatch(
        2, 1, 'Snow Mountain', 'Yeti Kong',
        { animal: 'gorilla', hat: 'viking', mask: 'none', cape: 'bat_tattered' },
        'soccer', 0.56, 75, { unlockHat: 'viking' },
        'Heavy shoulder charges! Nobody moves Yeti Kong off the snowy center circle!',
        [
          { key: 'A', label: 'A. Might vs agility!', replyLine: 'GRRR! Let us see your nimble footwork!', replyEmotion: 'angry' },
          { key: 'B', label: 'B. Try catching my punch charge!', replyLine: 'Haha! A worthy brawler! Hold X and swing!', replyEmotion: 'happy' },
          { key: 'C', label: 'C. I only focus on goals.', replyLine: 'Smart—just do not blink when I wind up!', replyEmotion: 'confident' },
        ],
        'Stay nimble and use objects or charged strikes!',
        'Ooof! Even this big ape got outmaneuvered!',
        'Do not trade head-on hits with big Gorilla power—flank him!'
      ),
      makeMatch(
        2, 2, 'Snow Mountain', 'Powder Capy',
        { animal: 'capybara', hat: 'traffic_cone', mask: 'phantom', cape: 'none' },
        'flat_disc', 0.6, 85, { unlockMask: 'phantom' },
        'A low Flat Disc glides like a curling stone across frost!',
        [
          { key: 'A', label: 'A. Smooth curling passes!', replyLine: 'So satisfying when it hugs the turf!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I will loft it with a backflip!', replyLine: 'Jump + X can pop even a flat disc airborne!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Cone hat defense?', replyLine: 'Hey, it improves my aerodynamics!', replyEmotion: 'confident' },
        ],
        'Control the disc slide before it kisses the post!',
        'Clean sweep! My traffic cone tipped right over!',
        'Wait half a beat before kicking sliding discs so you do not whiff.'
      ),
      makeMatch(
        2, 3, 'Snow Mountain', 'Alpine Fox',
        { animal: 'shiba', hat: 'wizard', mask: 'kitsune', cape: 'dragon_wings' },
        'crystal', 0.66, 95, { unlockCape: 'dragon_wings' },
        'One step from the summit! Can you read the shimmer of a Crystal Ball in snow?',
        [
          { key: 'A', label: 'A. Bring on the magic!', replyLine: 'Sparkling volleys incoming—stay sharp!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Pure skill beats snow magic!', replyLine: 'Let us test that conviction right now!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. See you at the Boss peak!', replyLine: 'You still have to get past my wings first!', replyEmotion: 'angry' },
        ],
        'One crisp win unlocks the Glacier Boss!',
        'Crystal clear victory! Frostbite Emperor awaits at the summit!',
        'Do not chase shadows—stay between the ball and your net!'
      ),
      makeMatch(
        2, 4, 'Snow Mountain', 'Frostbite Emperor',
        { animal: 'penguin', hat: 'royal_crown', mask: 'oni', cape: 'royal_velvet' },
        'hockey', 0.72, 210,
        { unlockMask: 'oni', trophyId: 'trophy_snow_mountain', trophyName: 'Glacier Crest Cup', titleBadge: 'Sub-Zero Striker' },
        'I am the Frostbite Emperor! My Rubber Neck Header strikes from impossible backward angles!',
        [
          { key: 'A', label: 'A. Ready for an icy duel, Your Majesty!', replyLine: 'Honorable challenger! Let ice and rubber collide!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. My aerial kicks top your headers!', replyLine: 'Insolent! Feel my 360° whip-neck strike!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Show me your best header!', replyLine: 'Eyes on the puck—my neck reaches farther than you think!', replyEmotion: 'confident' },
        ],
        'Witness the Rubber Neck Header of the Glacier Throne!',
        'Astonishing! You melted my frozen streak and claimed the Glacier Crest Cup!',
        'A chilly defeat! Watch my whip-neck reach behind me on rebounds.',
        'rubber_header'
      ),
    ],
  },

  // WORLD 4 — Desert Canyon
  {
    worldIndex: 3,
    worldNumber: 4,
    name: 'Desert Canyon',
    subtitle: 'Sun-baked sandstone walls & fiery oasis',
    arena: 'desert_oasis',
    themeColor: '#f59e0b',
    accentColor: '#fde68a',
    mapX: 410,
    mapY: 255,
    trophyId: 'trophy_desert_canyon',
    trophyName: 'Sunstone Oasis Cup',
    trophyColor: '#fbbf24',
    worldTitle: 'Canyon Mirage Runner',
    matches: [
      makeMatch(
        3, 0, 'Desert Canyon', 'Dune Hopper',
        { animal: 'kangaroo', hat: 'sombrero', mask: 'none', cape: 'none' },
        'nfl', 0.56, 75, { unlockHat: 'sombrero' },
        'Howdy! Out in Desert Canyon we break out the chaotic Oval Ball!',
        [
          { key: 'A', label: 'A. Oval chaos is awesome!', replyLine: 'Yeehaw! Nobody predicts that pointy hop!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Aiming center strikes solves it!', replyLine: 'Smart traveler! Let us see it in action!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Sandstone walls help my rebounds.', replyLine: 'Careful—the wall kicks back just as hard!', replyEmotion: 'surprised' },
        ],
        'Hold steady against unpredictable Oval bounces!',
        'Woo-wee! You tamed the wild desert oval!',
        'Wait for the second bounce when the Oval Ball tumbles fast.'
      ),
      makeMatch(
        3, 1, 'Desert Canyon', 'Scorpion Croc',
        { animal: 'crocodile', hat: 'plunger', mask: 'luchador', cape: 'none' },
        'dice', 0.62, 85, { unlockMask: 'luchador' },
        'Roll the Dice Cube! Six flat faces mean crazy lucky bank shots!',
        [
          { key: 'A', label: 'A. Roll snake eyes on your defense!', replyLine: 'Hahaha! My luchador mask brings double sixes!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Skill beats luck every time!', replyLine: 'Prove it against my canyon cross-shots!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Nice plunger hat!', replyLine: 'It sticks to victory—literally!', replyEmotion: 'confident' },
        ],
        'Dice Cube kicks fly true—even if bounces roll wild!',
        'Boxcars! You rolled right past my canyon wall!',
        'Watch the square corners of the Dice Cube when it hits posts!'
      ),
      makeMatch(
        3, 2, 'Desert Canyon', 'Mirage Shiba',
        { animal: 'shiba', hat: 'frying_pan', mask: 'paper_bag', cape: 'newspaper' },
        'tennis', 0.66, 95, { unlockHat: 'frying_pan' },
        'Tiny, blazing-fast Tennis Ball! Blink in the desert heat and it is in your net!',
        [
          { key: 'A', label: 'A. High-speed reflexes ready!', replyLine: 'Zoom! Let us trade supersonic volleys!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Can you even see through that bag?', replyLine: 'I sense the ball with pure desert instinct!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Hold A Super Kicks will rocket it!', replyLine: 'Careful not to blast it straight back off the wall!', replyEmotion: 'confident' },
        ],
        'Track the tiny green blur across the oasis turf!',
        'Bullseye! Even my desert ears could not trace that speed!',
        'Small balls demand tight positioning—use shorter taps to steer!'
      ),
      makeMatch(
        3, 3, 'Desert Canyon', 'Oasis Guard',
        { animal: 'gorilla', hat: 'cactus', mask: 'mustache', cape: 'leaf_cloak' },
        'metal', 0.7, 105, { unlockHat: 'cactus' },
        'Heavy Metal Ball! Only true Super Kicks and props can launch this iron boulder!',
        [
          { key: 'A', label: 'A. Time to flex heavy kicks!', replyLine: 'Ooh! Hope your ankles are made of iron too!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Fire Backflips move anything!', replyLine: 'Smart! Jump + A melts even heavy metal!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Grabbing a box beats brute force!', replyLine: 'Watch your toes—throw props smartly!', replyEmotion: 'angry' },
        ],
        'Charge Hold-A or Jump+A to blast the heavy Metal Ball!',
        'Clang! You launched that iron sphere clean through my posts!',
        'Light taps barely nudge Metal Balls—always charge your kicks!'
      ),
      makeMatch(
        3, 4, 'Desert Canyon', 'Mirage Pharaoh',
        { animal: 'flamingo', hat: 'wizard', mask: 'phantom', cape: 'royal_velvet' },
        'soccer', 0.76, 240,
        { unlockAnimal: 'flamingo', unlockCape: 'newspaper', trophyId: 'trophy_desert_canyon', trophyName: 'Sunstone Oasis Cup', titleBadge: 'Canyon Mirage Runner' },
        'Traveler! I am Mirage Pharaoh! My Elastic Blitz Dash closes every gap in a golden flash!',
        [
          { key: 'A', label: 'A. Dash against dash—let us go!', replyLine: 'Marvelous! Watch me blink across the oasis!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Mirage tricks will not rattle me!', replyLine: 'Foolish! My elastic stride strikes before you blink!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Claiming Sunstone Oasis Cup now!', replyLine: 'Only if you outpace the desert wind itself!', replyEmotion: 'confident' },
        ],
        'Witness the Elastic Blitz Dash of Desert Canyon!',
        'The mirage parts before your brilliance! Claim the Sunstone Oasis Cup!',
        'Too swift in transition—conserve your dash for clear breakaways!',
        'elastic_reach'
      ),
    ],
  },

  // WORLD 5 — Sakura Village
  {
    worldIndex: 4,
    worldNumber: 5,
    name: 'Sakura Village',
    subtitle: 'Blossom shrines & serene torii gates',
    arena: 'sakura_shrine',
    themeColor: '#f43f5e',
    accentColor: '#fecdd3',
    mapX: 520,
    mapY: 130,
    trophyId: 'trophy_sakura_village',
    trophyName: 'Blossom Torii Cup',
    trophyColor: '#fb7185',
    worldTitle: 'Petal Acrobat',
    matches: [
      makeMatch(
        4, 0, 'Sakura Village', 'Petal Panda',
        { animal: 'red_panda', hat: 'none', mask: 'kitsune', cape: 'none' },
        'soccer', 0.62, 85, { unlockAnimal: 'red_panda' },
        'Peaceful blossoms drift here, yet every shrine match demands razor-sharp form!',
        [
          { key: 'A', label: 'A. Respectful duel under the petals!', replyLine: 'Honor first! May our footwork flow like wind!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. My kicks stir a blossom storm!', replyLine: 'Ooh, poetic and fierce! Show me!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Ready for a fast pace!', replyLine: 'Then let us begin at the first chime!', replyEmotion: 'confident' },
        ],
        'Flow like drifting petals across the shrine pitch!',
        'Such grace! Your strikes dance past every blossom!',
        'Stay centered beneath the torii posts on clearances.'
      ),
      makeMatch(
        4, 1, 'Sakura Village', 'Mochi Alpaca',
        { animal: 'alpaca', hat: 'chef_toque', mask: 'googly', cape: 'rainbow_ribbon' },
        'honey_ball', 0.66, 95, { unlockCape: 'rainbow_ribbon' },
        'Beware our sweet Honey Ball—touch it softly and it sticks right to your fur!',
        [
          { key: 'A', label: 'A. Sticky dribble challenge! Fun!', replyLine: 'Haha! Carry it near goal, then blast it in!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. A strong kick breaks the honey!', replyLine: 'Yes! Power kicks tear it loose immediately!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Sticky balls will not trap me!', replyLine: 'Careful—one soft bump and you are carrying mochi!', replyEmotion: 'surprised' },
        ],
        'Use sticky honey control or rip free with a fast spin kick!',
        'Sweet! You dribbled that sticky honey right into the net!',
        'If the Honey Ball sticks to you, kick quickly toward goal!'
      ),
      makeMatch(
        4, 2, 'Sakura Village', 'Tanuki Chef',
        { animal: 'capybara', hat: 'plunger', mask: 'oni', cape: 'leaf_cloak' },
        'rubber', 0.7, 105, { unlockCape: 'leaf_cloak' },
        'Leaf-cloak stealth and bouncy Rubber Shots—can you keep your cool?',
        [
          { key: 'A', label: 'A. Always cool under pressure!', replyLine: 'Excellent! Keep your eyes on my leaf cape!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Let us see who reads walls better!', replyLine: 'Torii walls bounce sharp—brace yourself!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Oni mask looks fierce!', replyLine: 'Wait until you see my full-speed spin!', replyEmotion: 'angry' },
        ],
        'Read the torii post angles cleanly!',
        'Poof! My leaf illusions vanished before your strike!',
        'Play defense first when a bouncy rubber ball enters your half.'
      ),
      makeMatch(
        4, 3, 'Sakura Village', 'Kaze Shiba',
        { animal: 'shiba', hat: 'alien_antenna', mask: 'kitsune', cape: 'dragon_wings' },
        'star_gbc', 0.74, 115, { unlockMask: 'kitsune' },
        'Defeat me with the Star Arena Ball and Kitsune Master awaits!',
        [
          { key: 'A', label: 'A. Let our stars collide!', replyLine: 'Swift and bright! Here comes a comet pass!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I am climbing straight to Boss 5!', replyLine: 'Earn every inch of shrine turf first!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Any tip for Kitsune Master?', replyLine: 'Watch her aerial fire backflips when the ball pops up!', replyEmotion: 'surprised' },
        ],
        'One sharp victory away from the Sakura Shrine Boss!',
        'You shine brighter than the shrine lanterns! Good luck!',
        'Stay light on your feet against Star Arena speed.'
      ),
      makeMatch(
        4, 4, 'Sakura Village', 'Kitsune Master',
        { animal: 'red_panda', hat: 'wizard', mask: 'kitsune', cape: 'royal_velvet' },
        'soccer', 0.78, 270,
        { unlockHat: 'wizard', trophyId: 'trophy_sakura_village', trophyName: 'Blossom Torii Cup', titleBadge: 'Petal Acrobat' },
        'I am Kitsune Master! Above these blossoms, my Aerial Fire Backflip ignites every high ball!',
        [
          { key: 'A', label: 'A. Teach me your skyward form!', replyLine: 'Then leap with me among the sakura clouds!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I can fire backflip too!', replyLine: 'Oh?! Let two flames clash mid-air!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Ground discipline defeats aerial flair!', replyLine: 'Bold! Let us see if ground tackles stop blazing comets!', replyEmotion: 'confident' },
        ],
        'Ascend with Aerial Fire Backflips!',
        'Magnificent mid-air mastery! The Blossom Torii Cup belongs to you!',
        'Never let high rebounds hang undefended—leap early to contest!',
        'aerial_flip'
      ),
    ],
  },

  // WORLD 6 — Lost Jungle
  {
    worldIndex: 5,
    worldNumber: 6,
    name: 'Lost Jungle',
    subtitle: 'Ancient moss ruins & wild temple drums',
    arena: 'jungle_temple',
    themeColor: '#16a34a',
    accentColor: '#bbf7d0',
    mapX: 615,
    mapY: 280,
    trophyId: 'trophy_lost_jungle',
    trophyName: 'Jade Idol Trophy',
    trophyColor: '#22c55e',
    worldTitle: 'Temple Crusher',
    matches: [
      makeMatch(
        5, 0, 'Lost Jungle', 'Vine Roo',
        { animal: 'kangaroo', hat: 'dino_hood', mask: 'none', cape: 'leaf_cloak' },
        'soccer', 0.68, 95, { unlockAnimal: 'kangaroo' },
        'Welcome deep inside Lost Jungle! Ancient ruins echo every heavy strike!',
        [
          { key: 'A', label: 'A. What an epic temple pitch!', replyLine: 'Right?! Wait until you hear the drums roll!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. No jungle trap scares me!', replyLine: 'Watch those falling wooden boxes mid-match!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Ready to kick off!', replyLine: 'Hop to it—temple rules, full intensity!', replyEmotion: 'confident' },
        ],
        'Keep moving around temple ruins and crates!',
        'Crikey—you smashed clean out of the vines!',
        'Use dash bursts across midfield when props drop near center.'
      ),
      makeMatch(
        5, 1, 'Lost Jungle', 'Moss Kong',
        { animal: 'gorilla', hat: 'burger', mask: 'paper_bag', cape: 'none' },
        'ostrich_egg', 0.72, 105, { unlockAnimal: 'gorilla' },
        'Gorilla found giant temple egg! Guard your net before Kong smashes it home!',
        [
          { key: 'A', label: 'A. Gentle pass or mega smash?', replyLine: 'KONG ALWAYS CHOOSES MEGA SMASH!', replyEmotion: 'angry' },
          { key: 'B', label: 'B. Let us trade power kicks!', replyLine: 'Haha! Tiny feet got thunder? Show Kong!', replyEmotion: 'happy' },
          { key: 'C', label: 'C. Nice burger hat, Kong.', replyLine: 'Thanks! Snack for after Kong scores!', replyEmotion: 'confident' },
        ],
        'Do not get flattened by Gorilla power charges!',
        'Whoa! Tiny challenger hit harder than Kong expected!',
        'Watch out for charged punches and fast power balls—dodge sideways!'
      ),
      makeMatch(
        5, 2, 'Lost Jungle', 'Amber Axolotl',
        { animal: 'axolotl', hat: 'flower_pot', mask: 'visor', cape: 'none' },
        'honey_ball', 0.75, 115, { unlockHat: 'burger' },
        'Wild jungle hives dropped a fresh Honey Ball! Outsmart the sticky dribble!',
        [
          { key: 'A', label: 'A. Sticky jungle duel!', replyLine: 'Let us see who controls that golden dribble best!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Power shots break every trap!', replyLine: 'Careful—missing leaves you wide open!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Grabbing a drum could help too!', replyLine: 'Yikes, dodge the oil drums!', replyEmotion: 'surprised' },
        ],
        'Watch your footing with the Sticky Honey Ball!',
        'Buzz-tastic! You broke clean through my honey guard!',
        'Hold A briefly when honey slows your dribble to rip a shot free.'
      ),
      makeMatch(
        5, 3, 'Lost Jungle', 'Temple Stalker',
        { animal: 'crocodile', hat: 'traffic_cone', mask: 'luchador', cape: 'bat_tattered' },
        'timer_bomb', 0.78, 125, { unlockCape: 'bat_tattered' },
        'Hear that ticking? The 15s Bomb Ball blasts everyone nearby every 15 seconds!',
        [
          { key: 'A', label: 'A. Explosive soccer? Love it!', replyLine: 'Just make sure it explodes on MY half—wait, YOUR half!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Keep it in your zone at zero!', replyLine: 'Clever tactic! Watch the countdown!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Bomb blasts send players flying!', replyLine: 'Tick... tick... BOOM! Here we go!', replyEmotion: 'angry' },
        ],
        'Watch the 15s Bomb timer and launch it before blast!',
        'Kaboom! You timed the blast and scored cleanly!',
        'Kick the Bomb Ball away when the timer drops under 3 seconds!'
      ),
      makeMatch(
        5, 4, 'Lost Jungle', 'Rex Croc',
        { animal: 'crocodile', hat: 'dino_hood', mask: 'oni', cape: 'dragon_wings' },
        'metal', 0.82, 300,
        { unlockHat: 'dino_hood', trophyId: 'trophy_lost_jungle', trophyName: 'Jade Idol Trophy', titleBadge: 'Temple Crusher' },
        'ROAR! I am Rex Croc, Apex Champion of Lost Jungle! My Power Cannon launches Metal Balls like meteors!',
        [
          { key: 'A', label: 'A. Let the temple shake!', replyLine: 'HAHA! A challenger with fire in their eyes!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Even heavy armor cracks against my kicks!', replyLine: 'No one cracks Jade Scales! Face my wrath!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Show me Apex power!', replyLine: 'Hold nothing back—here comes Rex Cannon!', replyEmotion: 'confident' },
        ],
        'Survive the Jungle Titan’s Power Cannon Shot!',
        'Grrr-eat match! You proved fiercer than the jungle king. Take the Jade Idol Trophy!',
        'Do not challenge a Metal Ball half-heartedly—charge full kicks!',
        'power_shot'
      ),
    ],
  },

  // WORLD 7 — Candy Kingdom
  {
    worldIndex: 6,
    worldNumber: 7,
    name: 'Candy Kingdom',
    subtitle: 'Pastel sugar turf & lollipop barriers',
    arena: 'candy_kingdom',
    themeColor: '#ec4899',
    accentColor: '#fbcfe8',
    mapX: 705,
    mapY: 165,
    trophyId: 'trophy_candy_kingdom',
    trophyName: 'Sugar Crown Cup',
    trophyColor: '#f472b6',
    worldTitle: 'Sugar Rush Champion',
    matches: [
      makeMatch(
        6, 0, 'Candy Kingdom', 'Fizz Flamingo',
        { animal: 'flamingo', hat: 'duck_float', mask: 'none', cape: 'rainbow_ribbon' },
        'rubber', 0.72, 105, { unlockHat: 'duck_float' },
        'Welcome to Candy Kingdom! Everything here is sweet, pastel, and bouncy!',
        [
          { key: 'A', label: 'A. This candy pitch looks delicious!', replyLine: 'Hands off the lollipop posts—focus on the ball!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Sweet turf, serious goals!', replyLine: 'Ooh! Do not let the cute colors fool you!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Ready for rubber bounces!', replyLine: 'Bounce high and shoot fast!', replyEmotion: 'confident' },
        ],
        'Sugar-coated rebounds fly fast on pastel turf!',
        'Sweet shot! You glazed right past my reach!',
        'Track the high bounce over the candy wall!'
      ),
      makeMatch(
        6, 1, 'Candy Kingdom', 'Caramel Panda',
        { animal: 'red_panda', hat: 'cheese_wedge', mask: 'googly', cape: 'pizza_slice' },
        'honey_ball', 0.76, 115, { unlockCape: 'pizza_slice' },
        'Golden Caramel-Honey Ball! Sticky sweet chaos across Candy Kingdom!',
        [
          { key: 'A', label: 'A. Sugar & honey combo!', replyLine: 'Careful—it clings to your boots if you tap lightly!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I will blast it clean!', replyLine: 'Hold A or spin-kick hard to break the glaze!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Love the pizza cape!', replyLine: 'Sweet and savory—best combo on tour!', replyEmotion: 'surprised' },
        ],
        'Outplay the Caramel Honey glaze!',
        'Sugar rush! You caramelized my goal net!',
        'Dash right before kicking to unstick the Honey Ball smoothly.'
      ),
      makeMatch(
        6, 2, 'Candy Kingdom', 'Gumball Capy',
        { animal: 'capybara', hat: 'tv_box', mask: 'pixel_shades', cape: 'disco_prism' },
        'dice', 0.8, 125, { unlockCape: 'disco_prism' },
        'Disco shimmer, sugar cube Dice Ball—welcome to the Candy Arcade!',
        [
          { key: 'A', label: 'A. Time to roll some sweet sixes!', replyLine: 'Groovy! Catch my sparkling cross-field pass!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Stay focused, win clean!', replyLine: 'All business on candy turf? Respect!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. That disco cape sparkles!', replyLine: 'Win this round and rock your own shimmer!', replyEmotion: 'surprised' },
        ],
        'Keep rhythm with the Candy Cube bounces!',
        'Sweet victory! That was pure arcade perfection!',
        'Do not get distracted by corner rebounds—stay goal-side.'
      ),
      makeMatch(
        6, 3, 'Candy Kingdom', 'Sprinkle Axolotl',
        { animal: 'axolotl', hat: 'ufo_dish', mask: 'none', cape: 'rainbow_ribbon' },
        'beach_volleyball', 0.84, 135, { unlockHat: 'ufo_dish' },
        'Float like cotton candy! Beat me to earn an audience with Duchess Macaron!',
        [
          { key: 'A', label: 'A. Cotton candy spikes coming up!', replyLine: 'Wheee! Jump-A fire spikes look awesome here!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Tell the Duchess I am coming!', replyLine: 'First get past my floating saucer defense!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Any secret about her play?', replyLine: 'Her curve shots bend like ribbon candy!', replyEmotion: 'surprised' },
        ],
        'Reach the Candy Throne by clearing one more star!',
        'Sugar-coated win! Duchess Macaron awaits!',
        'Watch high balls carefully—Jump+A sends them blazing down!'
      ),
      makeMatch(
        6, 4, 'Candy Kingdom', 'Duchess Macaron',
        { animal: 'axolotl', hat: 'royal_crown', mask: 'phantom', cape: 'disco_prism' },
        'star_gbc', 0.86, 330,
        { unlockHat: 'cheese_wedge', trophyId: 'trophy_candy_kingdom', trophyName: 'Sugar Crown Cup', titleBadge: 'Sugar Rush Champion' },
        'Welcome to my sweet court! I am Duchess Macaron—every curve shot I bend swirls like spun sugar!',
        [
          { key: 'A', label: 'A. Honored to challenge the Duchess!', replyLine: 'How charming! Let our sweetest match begin!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. My straight fire shots beat fancy curves!', replyLine: 'My word! Then let us see if fire melts spun sugar!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Show me your finest Ribbon Curve!', replyLine: 'Observe closely—it bends past posts when least expected!', replyEmotion: 'confident' },
        ],
        'Dance through the Candy Duchess’s 180° Curve Master strikes!',
        'Magnifique! Sweeter victory I have never seen. Take the Sugar Crown Cup!',
        'Stepping toward her far post blocks her curled finishes!',
        'curve_master'
      ),
    ],
  },

  // WORLD 8 — Neon City
  {
    worldIndex: 7,
    worldNumber: 8,
    name: 'Neon City',
    subtitle: 'Cybernetic floodlights & gravity walls',
    arena: 'neon_dome',
    themeColor: '#6366f1',
    accentColor: '#c7d2fe',
    mapX: 800,
    mapY: 330,
    trophyId: 'trophy_neon_city',
    trophyName: 'Cyber Core Trophy',
    trophyColor: '#818cf8',
    worldTitle: 'Neon Blitz Legend',
    matches: [
      makeMatch(
        7, 0, 'Neon City', 'Pixel Byte',
        { animal: 'penguin', hat: 'tv_box', mask: 'cyber_visor', cape: 'rocket_pack' },
        'soccer', 0.78, 115, { unlockHat: 'tv_box' },
        'SYSTEM ONLINE! Welcome to Neon City’s Gravity Wall Arena—zero mercy in the cyber league!',
        [
          { key: 'A', label: 'A. Ready to light up the scoreboard!', replyLine: 'INITIATING HIGH-TEMPO KICKOFF!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. My footwork crashes your system!', replyLine: 'ERROR: OVERCONFIDENCE DETECTED. ENGAGING!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Cool visor and jetpack!', replyLine: 'Win the match and upgrade your cyber gear!', replyEmotion: 'confident' },
        ],
        'Neon floodlights engaged—keep pace!',
        'SYSTEM OVERLOAD! What a blazing goal!',
        'Neon gravity walls keep rebounds live—stay ready!'
      ),
      makeMatch(
        7, 1, 'Neon City', 'Laser Roo',
        { animal: 'kangaroo', hat: 'alien_antenna', mask: 'pixel_shades', cape: 'rocket_pack' },
        'timer_bomb', 0.82, 125, { unlockCape: 'rocket_pack' },
        '15s Cyber Bomb Ball active! Time your dashes around blast radiuses!',
        [
          { key: 'A', label: 'A. Explosive cyber action!', replyLine: 'Boosters ready! Watch the red bomb ring!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I will detonate it in your goal box!', replyLine: 'Try it—my rocket pack kicks back double!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Hold steady under pressure.', replyLine: 'Countdown ticking... 15 seconds!', replyEmotion: 'surprised' },
        ],
        'Handle the Neon Bomb Ball under city floodlights!',
        'BOOM! Clean cyber finish before detonation!',
        'Never stand still when the Bomb timer hits red!'
      ),
      makeMatch(
        7, 2, 'Neon City', 'Volt Croc',
        { animal: 'crocodile', hat: 'propeller', mask: 'cyber_visor', cape: 'dragon_wings' },
        'hockey', 0.85, 135, { unlockMask: 'cyber_visor' },
        'Hyper-glide Hockey Puck under neon laser beams! Fast, flat, and unforgiving!',
        [
          { key: 'A', label: 'A. Lightning puck reflexes ready!', replyLine: 'Good! One blink and it slams the crossbar!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. I block high-speed shots daily!', replyLine: 'Then test those blocks right now!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Watch out for my charged punch!', replyLine: 'Careful—my visor locks onto counter-attacks!', replyEmotion: 'angry' },
        ],
        'Track hyper-velocity passes across the Neon Dome!',
        'Short-circuit! My cyber visor cracked!',
        'Predict rebounds off the endwall next to goal!'
      ),
      makeMatch(
        7, 3, 'Neon City', 'Synth Gorilla',
        { animal: 'gorilla', hat: 'ufo_dish', mask: 'oni', cape: 'bat_tattered' },
        'metal', 0.88, 145, { unlockHat: 'alien_antenna' },
        'Neon heavyweight division! Lift this cyber-metal ball with sheer technique!',
        [
          { key: 'A', label: 'A. Bring the heavy thunder!', replyLine: 'Metal meets muscle under neon skies!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Jump+A fire flips break heavy metal!', replyLine: 'Impressive data—let us see you execute!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Cyber Hound is next!', replyLine: 'Only if you clear my iron wall first!', replyEmotion: 'angry' },
        ],
        'One step from Neon City’s Boss Champion!',
        'Power grid offline! Proceed to Cyber Hound!',
        'Use Super Kicks (hold A) to crack heavy Metal defenses.'
      ),
      makeMatch(
        7, 4, 'Neon City', 'Cyber Hound',
        { animal: 'shiba', hat: 'tv_box', mask: 'cyber_visor', cape: 'dragon_wings' },
        'star_gbc', 0.9, 380,
        { unlockHat: 'plunger', trophyId: 'trophy_neon_city', trophyName: 'Cyber Core Trophy', titleBadge: 'Neon Blitz Legend' },
        'I am Cyber Hound, Neon City Overclock Champion! My Elastic Blitz Dash computes your every step!',
        [
          { key: 'A', label: 'A. Overclock versus instinct—let us play!', replyLine: 'TARGET LOCKED! EXECUTING FULL-SPEED BLITZ!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. You cannot calculate heart and hustle!', replyLine: 'HEART IS UNTESTED CODE. PROVE YOUR DATA!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Bring maximum overclock!', replyLine: '100% THRUSTERS ENGAGED!', replyEmotion: 'confident' },
        ],
        'Outpace Cyber Hound’s Elastic Blitz Dash!',
        'FIREWALL BREACHED! Unbelievable speed—the Cyber Core Trophy is yours!',
        'Cyber Hound predicts straight runs—mix directional spin kicks!',
        'elastic_reach'
      ),
    ],
  },

  // WORLD 9 — Sky Islands
  {
    worldIndex: 8,
    worldNumber: 9,
    name: 'Sky Islands',
    subtitle: 'Floating cloud citadel & forcefield skies',
    arena: 'sky_citadel',
    themeColor: '#0ea5e9',
    accentColor: '#e0f2fe',
    mapX: 880,
    mapY: 165,
    trophyId: 'trophy_sky_islands',
    trophyName: 'Aether Halo Trophy',
    trophyColor: '#38bdf8',
    worldTitle: 'Sky Citadel Ace',
    matches: [
      makeMatch(
        8, 0, 'Sky Islands', 'Cloud Alpaca',
        { animal: 'alpaca', hat: 'ufo_dish', mask: 'none', cape: 'bath_towel' },
        'crystal', 0.84, 130, { unlockCape: 'bath_towel' },
        'Welcome above the clouds! Sky Forcefields bounce shots skyward—watch the Crystal Ball gleam!',
        [
          { key: 'A', label: 'A. What a breathtaking view!', replyLine: 'Do not stare too long—this match flies fast!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Ready for high-altitude strikes!', replyLine: 'Good! Up here every lob travels miles!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Only two worlds left to the Crown!', replyLine: 'Reach the clouds cleanly if you can!', replyEmotion: 'surprised' },
        ],
        'Ride sky updrafts and crisp Crystal volleys!',
        'Sky-high style! You floated straight past my defense!',
        'Use Jump + A when floating balls bounce near the box!'
      ),
      makeMatch(
        8, 1, 'Sky Islands', 'Wind Red Panda',
        { animal: 'red_panda', hat: 'propeller', mask: 'phantom', cape: 'rainbow_ribbon' },
        'beach_volleyball', 0.88, 140, { unlockHat: 'propeller' },
        'Jet-stream Volleyball at 10,000 feet! Aerial timing decides everything!',
        [
          { key: 'A', label: 'A. Meet me at the cloud ceiling!', replyLine: 'Propeller spun up—let us duel mid-air!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Jump+X lob tricks coming up!', replyLine: 'Careful, I spike back just as quick!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. Nothing grounds me today!', replyLine: 'Bold words on Sky Citadel Deck!', replyEmotion: 'confident' },
        ],
        'Win the mid-air battle above Sky Islands!',
        'Out-flown and out-kicked! Clear skies ahead for you!',
        'Stay patient—wait under the shadow ring before leaping!'
      ),
      makeMatch(
        8, 2, 'Sky Islands', 'Thunder Penguin',
        { animal: 'penguin', hat: 'viking', mask: 'luchador', cape: 'dragon_wings' },
        'timer_bomb', 0.9, 150, { unlockMask: 'mustache' },
        'Storm clouds! 15s Bomb Ball crackling across the forcefield!',
        [
          { key: 'A', label: 'A. Lightning and explosions—epic!', replyLine: 'Bring thunder! Keep that bomb off your goal line!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Timed blasts are my specialty!', replyLine: 'Then let us see who blinks when it beeps!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Viking Penguin looks unstoppable!', replyLine: 'No storm holds me back—kick off!', replyEmotion: 'angry' },
        ],
        'Thunderclap countdown—keep pressure high!',
        'Thunder-struck! You rode the storm to victory!',
        'Keep the Bomb Ball moving forward with quick spin taps!'
      ),
      makeMatch(
        8, 3, 'Sky Islands', 'Nimbus Gorilla',
        { animal: 'gorilla', hat: 'chef_toque', mask: 'oni', cape: 'royal_velvet' },
        'nfl', 0.92, 160, { unlockHat: 'traffic_cone' },
        'Only Aether Flamingo stands beyond me! Survive my storming Oval Cannon!',
        [
          { key: 'A', label: 'A. One last gatekeeper before Sky Boss!', replyLine: 'Earn your wings right here on deck!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Let us clash at maximum power!', replyLine: 'HAHA! Sky Island trembles beneath us!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Watch my Super Kicks!', replyLine: 'Give everything you have learned on tour!', replyEmotion: 'confident' },
        ],
        'Final climb to the Sky Islands Boss!',
        'Unbelievable grit! Step forward to face Aether Flamingo!',
        'Combine Dash + Super Kick to punch past elite defenders.'
      ),
      makeMatch(
        8, 4, 'Sky Islands', 'Aether Flamingo',
        { animal: 'flamingo', hat: 'royal_crown', mask: 'phantom', cape: 'dragon_wings' },
        'crystal', 0.94, 430,
        { unlockMask: 'bag', trophyId: 'trophy_sky_islands', trophyName: 'Aether Halo Trophy', titleBadge: 'Sky Citadel Ace' },
        'I am Aether Flamingo, Sovereign of the Clouds! Above the forcefield, my Aerial Fire Backflip scorches the sky!',
        [
          { key: 'A', label: 'A. Let us paint the sky with fire goals!', replyLine: 'Splendid! Spread your wings and rise!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Next stop after you is Grand Championship!', replyLine: 'Presumptuous! Touch the clouds first if you dare!', replyEmotion: 'angry' },
          { key: 'C', label: 'C. Show me true skyward mastery!', replyLine: 'Witness blazing feather-weight perfection!', replyEmotion: 'confident' },
        ],
        'Soar against Aether Flamingo’s Aerial Fire Backflip!',
        'Dazzling! You conquered the clouds and earned the Aether Halo Trophy. The Grand Championship awaits!',
        'Do not surrender midfield air—contest every bounce above waist height!',
        'aerial_flip'
      ),
    ],
  },

  // WORLD 10 — Grand Championship
  {
    worldIndex: 9,
    worldNumber: 10,
    name: 'Grand Championship',
    subtitle: 'Royal golden stadium of the world finals',
    arena: 'grand_championship',
    themeColor: '#facc15',
    accentColor: '#fef08a',
    mapX: 925,
    mapY: 365,
    trophyId: 'trophy_world_champion',
    trophyName: 'Grand World Champion Crown',
    trophyColor: '#fde047',
    worldTitle: 'WORLD CHAMPION',
    matches: [
      makeMatch(
        9, 0, 'Grand Championship', 'Knight Capybara',
        { animal: 'capybara', hat: 'viking', mask: 'phantom', cape: 'royal_velvet' },
        'soccer', 0.88, 150, { unlockCape: 'royal_velvet' },
        'Welcome to the Grand Royal Stadium! Only World Tour finalists step onto this golden pitch!',
        [
          { key: 'A', label: 'A. Everything I trained for starts now!', replyLine: 'Let us give the stadium crowd an unforgettable opener!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. No knight blocks my path!', replyLine: 'Steady shield, sharp hooves—show me your best!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Grand King Alpaca will see me soon!', replyLine: 'Clear all four guardians first, hero!', replyEmotion: 'angry' },
        ],
        'Opening round of the Grand Championship Finals!',
        'A championship-caliber opener! Crowd is roaring for you!',
        'Stay composed—Finals opponents punish careless lunges.'
      ),
      makeMatch(
        9, 1, 'Grand Championship', 'Baron Kangaroo',
        { animal: 'kangaroo', hat: 'sombrero', mask: 'oni', cape: 'dragon_wings' },
        'ostrich_egg', 0.91, 165, { unlockHat: 'banana_bunch' },
        'Quarterfinals! Even an unpredictable Ostrich Egg becomes a missile under royal floodlights!',
        [
          { key: 'A', label: 'A. High stakes, wild bounces—let us go!', replyLine: 'That is why you made World 10! Full power!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Watch my spin curves!', replyLine: 'Let us trade top-spin cannons!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Nothing stops my streak!', replyLine: 'Big confidence—prove it on the golden pitch!', replyEmotion: 'angry' },
        ],
        'Grand Championship Quarterfinal!',
        'What a knockout strike! Semifinals await!',
        'Keep your goalkeeper angles tight when the Oval egg tips!'
      ),
      makeMatch(
        9, 2, 'Grand Championship', 'Oracle Axolotl',
        { animal: 'axolotl', hat: 'wizard', mask: 'cyber_visor', cape: 'disco_prism' },
        'rubber', 0.94, 180, { unlockMask: 'googly' },
        'Semifinal! High-speed Rubber chaos under championship spotlights—read every bounce!',
        [
          { key: 'A', label: 'A. Ready for semifinal intensity!', replyLine: 'My visor reads speed—can your spirit match it?', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Fire shots crack any prediction!', replyLine: 'Jump + A sparks light up the whole stadium!', replyEmotion: 'surprised' },
          { key: 'C', label: 'C. See you in the trophy ceremony!', replyLine: 'Beat me here first, challenger!', replyEmotion: 'confident' },
        ],
        'Grand Championship Semifinal!',
        'Unbelievable reflexes! Only the Elite Guard and Grand King remain!',
        'Use wall passes to pull aggressive defenders out of goal.'
      ),
      makeMatch(
        9, 3, 'Grand Championship', 'Royal Guard Rex',
        { animal: 'gorilla', hat: 'royal_crown', mask: 'luchador', cape: 'dragon_wings' },
        'metal', 0.96, 200, { unlockHat: 'royal_crown' },
        'Final Gatekeeper before Grand King Alpaca! Prove your strength against the Royal Metal Ball!',
        [
          { key: 'A', label: 'A. Time to earn the Finals stage!', replyLine: 'Stand tall and strike true, challenger!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Heavy metal bends to Super Kicks!', replyLine: 'Show this heavy guard what fire looks like!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Tell the King I am ready!', replyLine: 'Pass through me and the throne pitch is yours!', replyEmotion: 'angry' },
        ],
        'Last step before the Grand World Champion Boss!',
        'The Royal Gate opens! Grand King Alpaca awaits for the World Crown!',
        'Use full charged A kicks or props to stun heavy guardians!'
      ),
      makeMatch(
        9, 4, 'Grand Championship', 'Grand King Alpaca',
        { animal: 'alpaca', hat: 'royal_crown', mask: 'phantom', cape: 'royal_velvet' },
        'soccer', 1.0, 500,
        {
          unlockCape: 'disco_prism',
          trophyId: 'trophy_world_champion',
          trophyName: 'Grand World Champion Crown',
          titleBadge: 'WORLD CHAMPION',
        },
        'So you conquered all nine worlds to stand before me! I am Grand King Alpaca—undefeated World Champion!',
        [
          { key: 'A', label: 'A. Every rival taught me something—let us have the greatest match ever!', replyLine: 'Spoken like a true star! All the world watches us now!', replyEmotion: 'happy' },
          { key: 'B', label: 'B. Your crown is coming home with me today!', replyLine: 'Haha! Then pry it from my golden hoofwork, challenger!', replyEmotion: 'confident' },
          { key: 'C', label: 'C. Give me your absolute full power!', replyLine: 'GLADLY! Power, curve, headers, and fire—ALL AT ONCE!', replyEmotion: 'angry' },
        ],
        'THE GRAND FINALE! Face the All-Round Titan of Rubber Pitch!',
        'MAGNIFICENT! Across ten worlds you outkicked, outthought, and outshone every champion. Long live the new WORLD CHAMPION!',
        'What a fierce duel! Study the bounce, stay patient in defense, and reclaim the Crown!',
        'balanced_titan'
      ),
    ],
  },
];

export interface EndingCreditCastItem {
  worldName: string;
  bossName: string;
  custom: PlayerCustomization;
  cheerLine: string;
}

export const WORLD_10_CELEBRATION_CAST: EndingCreditCastItem[] = STORY_WORLDS.map((w) => {
  const boss = w.matches[4];
  return {
    worldName: w.name,
    bossName: boss.opponentName,
    custom: boss.opponentCustom,
    cheerLine:
      w.worldIndex === 9
        ? 'All hail the new World Champion!'
        : `Cheers from ${w.name}! What an unforgettable World Tour!`,
  };
});

export const WORLD_10_ENDING_DIALOGUE: DialogueLine[] = [
  {
    speaker: 'narrator',
    speakerName: 'Grand Royal Announcer',
    emotion: 'happy',
    text: 'THE FINAL WHISTLE SOUNDS! Confetti rains across the Grand Royal Stadium—we have a new WORLD CHAMPION!',
  },
  {
    speaker: 'opponent',
    speakerName: 'Grand King Alpaca',
    emotion: 'happy',
    text: 'I bow to your mastery! From Green Valley to the Sky Citadel, you united every arena with pure skill and heart!',
  },
  {
    speaker: 'hero',
    speakerName: 'You (World Champion)',
    emotion: 'happy',
    text: 'Thank you, everyone! Every rival and arena made this World Tour unforgettable!',
  },
  {
    speaker: 'narrator',
    speakerName: 'All-Rivals Celebration',
    emotion: 'confident',
    text: 'Sir Wooly, Captain Reef, Frostbite Emperor, Mirage Pharaoh, Kitsune Master, Rex Croc, Duchess Macaron, Cyber Hound, and Aether Flamingo raise the trophy together!',
  },
];

export function createInitialStoryProgress(): StoryProgressState {
  return {
    coins: 0,
    highestWorldUnlocked: 0,
    highestMatchPerWorld: STORY_WORLDS.map(() => 0),
    completedMatches: [],
    unlockedTrophies: [],
    unlockedTitles: [],
    unlockedAnimals: ['alpaca', 'capybara'],
    unlockedHats: ['none'],
    unlockedMasks: ['none'],
    unlockedCapes: ['none'],
    championEndingCleared: false,
    lastSelectedWorld: 0,
    lastSelectedMatch: 0,
  };
}

export function normalizeStoryProgress(raw: Partial<StoryProgressState> | null | undefined): StoryProgressState {
  const base = createInitialStoryProgress();
  if (!raw || typeof raw !== 'object') return base;
  const highestMatchPerWorld = STORY_WORLDS.map((_, idx) => {
    const val = Array.isArray(raw.highestMatchPerWorld) ? Number(raw.highestMatchPerWorld[idx] ?? 0) : 0;
    return Number.isFinite(val) ? Math.max(0, Math.min(5, Math.floor(val))) : 0;
  });
  return {
    coins: typeof raw.coins === 'number' && Number.isFinite(raw.coins) ? Math.max(0, Math.floor(raw.coins)) : 0,
    highestWorldUnlocked:
      typeof raw.highestWorldUnlocked === 'number' && Number.isFinite(raw.highestWorldUnlocked)
        ? Math.max(0, Math.min(STORY_WORLDS.length - 1, Math.floor(raw.highestWorldUnlocked)))
        : 0,
    highestMatchPerWorld,
    completedMatches: Array.isArray(raw.completedMatches) ? Array.from(new Set(raw.completedMatches.filter((s) => typeof s === 'string'))) : [],
    unlockedTrophies: Array.isArray(raw.unlockedTrophies) ? Array.from(new Set(raw.unlockedTrophies.filter((s) => typeof s === 'string'))) : [],
    unlockedTitles: Array.isArray(raw.unlockedTitles) ? Array.from(new Set(raw.unlockedTitles.filter((s) => typeof s === 'string'))) : [],
    unlockedAnimals: Array.isArray(raw.unlockedAnimals)
      ? (Array.from(new Set([...base.unlockedAnimals, ...raw.unlockedAnimals])) as AnimalId[])
      : base.unlockedAnimals,
    unlockedHats: Array.isArray(raw.unlockedHats) ? Array.from(new Set([...base.unlockedHats, ...raw.unlockedHats])) : base.unlockedHats,
    unlockedMasks: Array.isArray(raw.unlockedMasks) ? Array.from(new Set([...base.unlockedMasks, ...raw.unlockedMasks])) : base.unlockedMasks,
    unlockedCapes: Array.isArray(raw.unlockedCapes) ? Array.from(new Set([...base.unlockedCapes, ...raw.unlockedCapes])) : base.unlockedCapes,
    championEndingCleared: Boolean(raw.championEndingCleared),
    lastSelectedWorld:
      typeof raw.lastSelectedWorld === 'number' && Number.isFinite(raw.lastSelectedWorld)
        ? Math.max(0, Math.min(STORY_WORLDS.length - 1, Math.floor(raw.lastSelectedWorld)))
        : 0,
    lastSelectedMatch:
      typeof raw.lastSelectedMatch === 'number' && Number.isFinite(raw.lastSelectedMatch)
        ? Math.max(0, Math.min(4, Math.floor(raw.lastSelectedMatch)))
        : 0,
  };
}

export function loadStoryProgress(): StoryProgressState {
  try {
    const raw = localStorage.getItem(STORY_STORAGE_KEY);
    if (!raw) return createInitialStoryProgress();
    return normalizeStoryProgress(JSON.parse(raw) as Partial<StoryProgressState>);
  } catch {
    return createInitialStoryProgress();
  }
}

export function saveStoryProgress(state: StoryProgressState): void {
  try {
    localStorage.setItem(STORY_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore storage errors
  }
}

export function matchKey(worldIdx: number, matchIdx: number): string {
  return `${worldIdx}-${matchIdx}`;
}

export function isWorldUnlocked(state: StoryProgressState, worldIdx: number): boolean {
  return worldIdx >= 0 && worldIdx <= state.highestWorldUnlocked;
}

export function isMatchUnlocked(state: StoryProgressState, worldIdx: number, matchIdx: number): boolean {
  if (!isWorldUnlocked(state, worldIdx)) return false;
  return matchIdx >= 0 && matchIdx <= (state.highestMatchPerWorld[worldIdx] ?? 0);
}

export function isMatchCompleted(state: StoryProgressState, worldIdx: number, matchIdx: number): boolean {
  return state.completedMatches.includes(matchKey(worldIdx, matchIdx));
}

export function isWorldCleared(state: StoryProgressState, worldIdx: number): boolean {
  return isMatchCompleted(state, worldIdx, 4);
}

export interface StoryCompletionOutcome {
  nextState: StoryProgressState;
  coinsEarned: number;
  firstTimeClear: boolean;
  unlockedNextWorld: number | null;
  completedStoryEnding: boolean;
  newlyUnlockedItems: string[];
}

export function completeStoryMatch(
  prev: StoryProgressState,
  worldIdx: number,
  matchIdx: number
): StoryCompletionOutcome {
  const world = STORY_WORLDS[worldIdx];
  const match = world?.matches[matchIdx];
  if (!world || !match) {
    return {
      nextState: prev,
      coinsEarned: 0,
      firstTimeClear: false,
      unlockedNextWorld: null,
      completedStoryEnding: false,
      newlyUnlockedItems: [],
    };
  }

  const key = matchKey(worldIdx, matchIdx);
  const firstTimeClear = !prev.completedMatches.includes(key);
  const coinsEarned = firstTimeClear ? match.reward.coins : Math.max(20, Math.round(match.reward.coins * 0.35));

  const nextHighestMatch = [...prev.highestMatchPerWorld];
  nextHighestMatch[worldIdx] = Math.max(nextHighestMatch[worldIdx] ?? 0, Math.min(5, matchIdx + 1));

  let nextHighestWorld = prev.highestWorldUnlocked;
  let unlockedNextWorld: number | null = null;
  if (match.isBoss && worldIdx + 1 < STORY_WORLDS.length && nextHighestWorld < worldIdx + 1) {
    nextHighestWorld = worldIdx + 1;
    unlockedNextWorld = worldIdx + 1;
  }

  const newlyUnlockedItems: string[] = [];
  const nextAnimals = [...prev.unlockedAnimals];
  const nextHats = [...prev.unlockedHats];
  const nextMasks = [...prev.unlockedMasks];
  const nextCapes = [...prev.unlockedCapes];
  const nextTrophies = [...prev.unlockedTrophies];
  const nextTitles = [...prev.unlockedTitles];

  if (match.reward.unlockAnimal && !nextAnimals.includes(match.reward.unlockAnimal)) {
    nextAnimals.push(match.reward.unlockAnimal);
    newlyUnlockedItems.push(`Animal: ${match.reward.unlockAnimal}`);
  }
  if (match.reward.unlockHat && !nextHats.includes(match.reward.unlockHat)) {
    nextHats.push(match.reward.unlockHat);
    newlyUnlockedItems.push(`Hat: ${match.reward.unlockHat}`);
  }
  if (match.reward.unlockMask && !nextMasks.includes(match.reward.unlockMask)) {
    nextMasks.push(match.reward.unlockMask);
    newlyUnlockedItems.push(`Mask: ${match.reward.unlockMask}`);
  }
  if (match.reward.unlockCape && !nextCapes.includes(match.reward.unlockCape)) {
    nextCapes.push(match.reward.unlockCape);
    newlyUnlockedItems.push(`Cape: ${match.reward.unlockCape}`);
  }
  if (match.reward.trophyId && !nextTrophies.includes(match.reward.trophyId)) {
    nextTrophies.push(match.reward.trophyId);
    newlyUnlockedItems.push(`Trophy: ${match.reward.trophyName ?? match.reward.trophyId}`);
  }
  if (match.reward.titleBadge && !nextTitles.includes(match.reward.titleBadge)) {
    nextTitles.push(match.reward.titleBadge);
    newlyUnlockedItems.push(`Title: ${match.reward.titleBadge}`);
  }

  const completedStoryEnding = worldIdx === STORY_WORLDS.length - 1 && match.isBoss;
  const nextSelectedWorld = unlockedNextWorld !== null ? unlockedNextWorld : worldIdx;
  const nextSelectedMatch = unlockedNextWorld !== null ? 0 : Math.min(4, matchIdx + 1);

  const nextState: StoryProgressState = {
    coins: prev.coins + coinsEarned,
    highestWorldUnlocked: nextHighestWorld,
    highestMatchPerWorld: nextHighestMatch,
    completedMatches: firstTimeClear ? [...prev.completedMatches, key] : prev.completedMatches,
    unlockedTrophies: nextTrophies,
    unlockedTitles: nextTitles,
    unlockedAnimals: nextAnimals,
    unlockedHats: nextHats,
    unlockedMasks: nextMasks,
    unlockedCapes: nextCapes,
    championEndingCleared: prev.championEndingCleared || completedStoryEnding,
    lastSelectedWorld: nextSelectedWorld,
    lastSelectedMatch: nextSelectedMatch,
  };

  return {
    nextState,
    coinsEarned,
    firstTimeClear,
    unlockedNextWorld,
    completedStoryEnding,
    newlyUnlockedItems,
  };
}

export function createStoryMatchConfig(
  worldIdx: number,
  matchIdx: number,
  heroCustom: PlayerCustomization,
  baseConfig?: MatchConfig
): MatchConfig {
  const world = STORY_WORLDS[worldIdx] ?? STORY_WORLDS[0];
  const match = world.matches[matchIdx] ?? world.matches[0];
  const def = baseConfig ?? createDefaultMatchConfig();

  const storyAi: StoryAiProfile = {
    difficulty: match.difficulty,
    bossStyle: match.bossStyle,
    opponentName: match.opponentName,
  };

  return {
    ...def,
    mode: 'story',
    redCount: 1,
    blueCount: 1,
    p1Team: 'red',
    p2Team: 'blue',
    p1Custom: { ...heroCustom },
    durationMinutes: match.durationMinutes,
    halves: match.halves,
    arena: world.arena,
    ballType: match.ball,
    itemSpawnMode: worldIdx === 0 && matchIdx === 0 ? 'off' : 'on',
    storyStageIndex: worldIdx * 5 + matchIdx,
    storyWorldIndex: worldIdx,
    storyMatchIndex: matchIdx,
    storyAi,
    storyOpponentCustom: { ...match.opponentCustom },
  };
}
