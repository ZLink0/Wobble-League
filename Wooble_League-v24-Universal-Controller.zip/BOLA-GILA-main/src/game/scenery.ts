import * as THREE from 'three';

/** Latar sekeliling lapangan: gunung, gedung tinggi, pantai, jalan raya, istana permen, dll. */
export interface SceneryRig {
  group: THREE.Group;
  disposables: Array<{ dispose: () => void }>;
  /** Animasi ringan (mobil di jalan raya, awan, asap, ombak) */
  update: (t: number) => void;
}

type Theme = 'mountain' | 'city' | 'beach' | 'candy' | 'volcano' | 'ice' | 'sky' | 'desert' | 'floating' | 'rooftop';

const THEME_BY_ARENA: Record<string, { theme: Theme; highway: boolean }> = {
  meadow_park: { theme: 'mountain', highway: true },
  sakura_shrine: { theme: 'mountain', highway: false },
  jungle_temple: { theme: 'mountain', highway: false },
  grand_championship: { theme: 'city', highway: true },
  gbc_pixel_bowl: { theme: 'city', highway: true },
  futsal_court_blue: { theme: 'city', highway: true },
  futsal_court_orange: { theme: 'city', highway: true },
  neon_dome: { theme: 'city', highway: true },
  tropical_beach: { theme: 'beach', highway: true },
  desert_oasis: { theme: 'desert', highway: true },
  glacier_rink: { theme: 'ice', highway: false },
  volcano_caldera: { theme: 'volcano', highway: false },
  sky_citadel: { theme: 'sky', highway: false },
  candy_kingdom: { theme: 'candy', highway: false },
  floating_isles: { theme: 'floating', highway: false },
  rooftop_skyline: { theme: 'rooftop', highway: false },
};

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function windowTexture(lit: string[], repeatX: number, repeatY: number, bg = '#1e293b'): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 128;
  const g = c.getContext('2d')!;
  g.fillStyle = bg;
  g.fillRect(0, 0, 64, 128);
  const r = rng(11);
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 4; x++) {
      g.fillStyle = r() < 0.55 ? lit[Math.floor(r() * lit.length)] : '#0f172a';
      g.fillRect(x * 16 + 3, y * 16 + 3, 10, 10);
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function roadTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 64;
  const g = c.getContext('2d')!;
  g.fillStyle = '#2b2f36';
  g.fillRect(0, 0, 256, 64);
  g.fillStyle = '#f8fafc';
  g.fillRect(0, 2, 256, 3);
  g.fillRect(0, 59, 256, 3);
  g.fillStyle = '#facc15';
  for (let i = 0; i < 4; i++) g.fillRect(i * 64 + 8, 30, 36, 4);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.repeat.set(10, 1);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function buildScenery(arenaId: string): SceneryRig {
  const cfg = THEME_BY_ARENA[arenaId] ?? { theme: 'mountain' as Theme, highway: true };
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];
  const animators: Array<(t: number) => void> = [];
  const r = rng(arenaId.length * 977 + 13);

  const mat = (color: string, opts: Partial<THREE.MeshStandardMaterialParameters> = {}) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: 0.85, flatShading: true, ...opts });
    disposables.push(m);
    return m;
  };
  const geo = <T extends THREE.BufferGeometry>(g: T): T => {
    disposables.push(g);
    return g;
  };
  const add = (m: THREE.Object3D, x: number, y: number, z: number) => {
    m.position.set(x, y, z);
    group.add(m);
    return m;
  };

  // Tanah luas di luar lapangan
  const groundColor: Record<Theme, string> = {
    mountain: '#4d7c0f',
    city: '#475569',
    beach: '#e7c98f',
    candy: '#fbcfe8',
    volcano: '#44403c',
    ice: '#e0f2fe',
    sky: '#bfdbfe',
    desert: '#e0b36a',
    floating: '#86efac',
    rooftop: '#475569',
  };
  const ground = new THREE.Mesh(geo(new THREE.CircleGeometry(170, 40)), mat(groundColor[cfg.theme], { flatShading: false }));
  ground.rotation.x = -Math.PI / 2;
  add(ground, 0, -0.08, 0);
  // Pulau melayang & atap gedung tidak punya tanah luas (diganti pulau/atap sendiri)
  if (cfg.theme === 'floating' || cfg.theme === 'rooftop') ground.visible = false;

  // ---------- Elemen umum ----------
  const mountains = (base: string, mid: string, snow: string | null, count: number, zMin: number, zMax: number) => {
    const baseMat = mat(base);
    const midMat = mat(mid);
    const snowMat = snow ? mat(snow) : null;
    for (let i = 0; i < count; i++) {
      const x = -95 + (i / (count - 1)) * 190 + (r() - 0.5) * 8;
      const z = -(zMin + r() * (zMax - zMin));
      const h = 16 + r() * 26;
      const rad = 10 + r() * 12;
      const m = new THREE.Mesh(geo(new THREE.ConeGeometry(rad, h, 7)), i % 2 ? baseMat : midMat);
      add(m, x, h / 2 - 0.1, z);
      if (snowMat && h > 24) {
        const cap = new THREE.Mesh(geo(new THREE.ConeGeometry(rad * 0.38, h * 0.34, 7)), snowMat);
        add(cap, x, h - h * 0.17 - 0.1, z);
      }
    }
    // Sisi timur dan barat
    for (const side of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const h = 12 + r() * 16;
        const rad = 8 + r() * 8;
        const m = new THREE.Mesh(geo(new THREE.ConeGeometry(rad, h, 7)), i % 2 ? baseMat : midMat);
        add(m, side * (62 + r() * 22), h / 2 - 0.1, -28 + i * 24);
      }
    }
  };

  const trees = (count: number, trunk: string, leaf: string, leaf2: string) => {
    const trunkMat = mat(trunk);
    const l1 = mat(leaf);
    const l2 = mat(leaf2);
    const trunkG = geo(new THREE.CylinderGeometry(0.2, 0.28, 1.6, 6));
    const crownG = geo(new THREE.ConeGeometry(1.3, 3.2, 7));
    for (let i = 0; i < count; i++) {
      const a = r() * Math.PI * 2;
      const rad = 26 + r() * 14;
      const x = Math.cos(a) * rad * 1.4;
      const z = Math.sin(a) * rad * 0.9;
      if (z > 14) continue;
      const s = 0.8 + r() * 0.9;
      const tr = new THREE.Mesh(trunkG, trunkMat);
      const cr = new THREE.Mesh(crownG, i % 2 ? l1 : l2);
      tr.scale.setScalar(s);
      cr.scale.setScalar(s);
      add(tr, x, 0.8 * s, z);
      add(cr, x, 1.6 * s + 1.6 * s, z);
    }
  };

  const highwayStrip = (z: number, width: number) => {
    const tex = roadTexture();
    disposables.push(tex);
    const road = new THREE.Mesh(geo(new THREE.PlaneGeometry(260, width)), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 }));
    disposables.push(road.material as THREE.Material);
    road.rotation.x = -Math.PI / 2;
    add(road, 0, 0.03, z);
    const carColors = ['#ef4444', '#3b82f6', '#facc15', '#22c55e', '#f8fafc', '#a855f7', '#f97316'];
    const bodyG = geo(new THREE.BoxGeometry(2.2, 0.7, 1.05));
    const cabG = geo(new THREE.BoxGeometry(1.1, 0.5, 0.95));
    const cabMat = mat('#0f172a', { flatShading: false });
    const cars: Array<{ obj: THREE.Group; speed: number; lane: number; off: number }> = [];
    for (let i = 0; i < 10; i++) {
      const car = new THREE.Group();
      const body = new THREE.Mesh(bodyG, mat(carColors[i % carColors.length], { flatShading: false, roughness: 0.4 }));
      body.position.y = 0.45;
      const cab = new THREE.Mesh(cabG, cabMat);
      cab.position.set(-0.1, 0.95, 0);
      car.add(body, cab);
      const lane = i % 2 === 0 ? -1 : 1;
      car.position.set(0, 0, z + lane * width * 0.22);
      if (lane > 0) car.rotation.y = Math.PI;
      group.add(car);
      cars.push({ obj: car, speed: 9 + r() * 8, lane, off: r() * 260 });
    }
    animators.push((t) => {
      for (const c of cars) {
        const x = ((c.off + t * c.speed * (c.lane < 0 ? 1 : -1)) % 260 + 260) % 260 - 130;
        c.obj.position.x = x;
      }
    });
  };

  const skyscrapers = (count: number, palette: string[], lit: string[], zMin: number, zMax: number) => {
    const texes = [windowTexture(lit, 2, 5), windowTexture(lit, 3, 6), windowTexture(lit, 4, 8)];
    texes.forEach((t) => disposables.push(t));
    const mats = texes.flatMap((tx) =>
      palette.map((p) => {
        const m = new THREE.MeshStandardMaterial({ color: p, map: tx, roughness: 0.6, emissive: '#1e293b', emissiveIntensity: 0.4, emissiveMap: tx });
        disposables.push(m);
        return m;
      })
    );
    for (let i = 0; i < count; i++) {
      const x = -100 + (i / (count - 1)) * 200 + (r() - 0.5) * 6;
      const z = -(zMin + r() * (zMax - zMin));
      const w = 6 + r() * 7;
      const d = 6 + r() * 6;
      const h = 18 + r() * 40;
      const b = new THREE.Mesh(geo(new THREE.BoxGeometry(w, h, d)), mats[Math.floor(r() * mats.length)]);
      add(b, x, h / 2, z);
      if (r() < 0.4) {
        const ant = new THREE.Mesh(geo(new THREE.CylinderGeometry(0.1, 0.1, 5, 5)), mat('#e2e8f0', { flatShading: false }));
        add(ant, x, h + 2.5, z);
      }
    }
    for (const side of [-1, 1]) {
      for (let i = 0; i < 5; i++) {
        const w = 6 + r() * 6;
        const h = 14 + r() * 30;
        const b = new THREE.Mesh(geo(new THREE.BoxGeometry(w, h, 7 + r() * 5)), mats[Math.floor(r() * mats.length)]);
        add(b, side * (46 + r() * 20), h / 2, -34 + i * 17);
      }
    }
  };

  const palms = (count: number) => {
    const trunkMat = mat('#a16207');
    const leafMat = mat('#16a34a', { side: THREE.DoubleSide });
    const trunkG = geo(new THREE.CylinderGeometry(0.16, 0.26, 4.4, 6));
    const leafG = geo(new THREE.ConeGeometry(0.5, 3.2, 4));
    for (let i = 0; i < count; i++) {
      const x = -60 + (i / (count - 1)) * 120 + (r() - 0.5) * 4;
      const z = -(15 + r() * 6);
      const trunk = new THREE.Mesh(trunkG, trunkMat);
      trunk.rotation.z = (r() - 0.5) * 0.3;
      add(trunk, x, 2.2, z);
      for (let k = 0; k < 6; k++) {
        const leaf = new THREE.Mesh(leafG, leafMat);
        const a = (k / 6) * Math.PI * 2;
        leaf.rotation.set(Math.PI / 2 - 0.5, 0, 0);
        const holder = new THREE.Group();
        holder.add(leaf);
        leaf.position.set(0, 0, 1.4);
        holder.rotation.y = a;
        add(holder, x, 4.4, z);
      }
    }
  };

  switch (cfg.theme) {
    case 'mountain':
      mountains('#4b6b3a', '#5f7f4a', '#f8fafc', 11, 52, 78);
      trees(46, '#7c4a1e', '#166534', '#15803d');
      if (cfg.highway) highwayStrip(-26, 6);
      break;
    case 'desert': {
      mountains('#c58a3d', '#d9a35a', null, 11, 52, 78);
      const pyr = mat('#e8c27a');
      for (let i = 0; i < 3; i++) {
        const p = new THREE.Mesh(geo(new THREE.ConeGeometry(13 - i * 2, 14 - i * 2, 4)), pyr);
        p.rotation.y = Math.PI / 4;
        add(p, -22 + i * 24, (14 - i * 2) / 2, -46 - i * 5);
      }
      if (cfg.highway) highwayStrip(-26, 6);
      break;
    }
    case 'city':
      skyscrapers(24, ['#94a3b8', '#64748b', '#a8b4c4', '#7c8aa0'], ['#fde68a', '#fef9c3', '#bae6fd'], 32, 62);
      if (cfg.highway) highwayStrip(-24, 7);
      for (let i = 0; i < 10; i++) {
        const lampG = geo(new THREE.CylinderGeometry(0.08, 0.1, 4.5, 6));
        const lamp = new THREE.Mesh(lampG, mat('#cbd5e1', { flatShading: false }));
        add(lamp, -54 + i * 12, 2.25, -20.2);
      }
      break;
    case 'beach': {
      const sea = new THREE.Mesh(geo(new THREE.PlaneGeometry(320, 120, 1, 1)), new THREE.MeshStandardMaterial({ color: '#0ea5e9', roughness: 0.25, metalness: 0.15, transparent: true, opacity: 0.95 }));
      disposables.push(sea.material as THREE.Material);
      sea.rotation.x = -Math.PI / 2;
      add(sea, 0, -0.04, -92);
      const foam = new THREE.Mesh(geo(new THREE.PlaneGeometry(320, 1.6)), new THREE.MeshBasicMaterial({ color: '#f0f9ff', transparent: true, opacity: 0.8 }));
      disposables.push(foam.material as THREE.Material);
      foam.rotation.x = -Math.PI / 2;
      add(foam, 0, -0.02, -32);
      animators.push((t) => {
        foam.position.z = -32 + Math.sin(t * 0.8) * 0.9;
      });
      palms(16);
      mountains('#7aa0b8', '#93b4c8', null, 7, 120, 135);
      if (cfg.highway) highwayStrip(-14.5, 5);
      break;
    }
    case 'ice':
      mountains('#93c5fd', '#bfdbfe', '#ffffff', 11, 52, 78);
      break;
    case 'volcano': {
      mountains('#292524', '#44403c', null, 9, 56, 80);
      const vol = new THREE.Mesh(geo(new THREE.ConeGeometry(26, 34, 9)), mat('#3f3a36'));
      add(vol, 0, 16.9, -72);
      const lava = new THREE.Mesh(geo(new THREE.CylinderGeometry(6.5, 6.5, 1.2, 9)), new THREE.MeshBasicMaterial({ color: '#f97316' }));
      disposables.push(lava.material as THREE.Material);
      add(lava, 0, 34, -72);
      const smokeMat = new THREE.MeshBasicMaterial({ color: '#78716c', transparent: true, opacity: 0.55 });
      disposables.push(smokeMat);
      const smokes: THREE.Mesh[] = [];
      for (let i = 0; i < 5; i++) {
        const sm = new THREE.Mesh(geo(new THREE.SphereGeometry(5, 8, 6)), smokeMat);
        smokes.push(sm);
        add(sm, 0, 38 + i * 6, -72);
      }
      animators.push((t) => {
        smokes.forEach((sm, i) => {
          sm.position.x = Math.sin(t * 0.3 + i) * 3 + i * 1.5;
          sm.scale.setScalar(1 + i * 0.25 + Math.sin(t + i) * 0.05);
        });
      });
      break;
    }
    case 'sky': {
      const cloudMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1, transparent: true, opacity: 0.95 });
      disposables.push(cloudMat);
      const clouds: THREE.Group[] = [];
      for (let i = 0; i < 16; i++) {
        const cl = new THREE.Group();
        for (let k = 0; k < 4; k++) {
          const s = new THREE.Mesh(geo(new THREE.SphereGeometry(4 + r() * 3, 10, 8)), cloudMat);
          s.position.set(k * 5 - 8, r() * 2, r() * 3);
          cl.add(s);
        }
        cl.position.set(-90 + (i / 15) * 180, -6 + r() * 6, -30 - r() * 40);
        group.add(cl);
        clouds.push(cl);
      }
      animators.push((t) => clouds.forEach((c, i) => (c.position.y += Math.sin(t * 0.4 + i) * 0.003)));
      mountains('#a5b4fc', '#c7d2fe', '#ffffff', 7, 70, 90);
      break;
    }
    case 'floating': {
      // ===== Pulau melayang fantasi =====
      const rockA = mat('#6b4f3a');
      const rockB = mat('#7c5d86');
      const grassTop = mat('#58c76f', { flatShading: false });
      const stone = mat('#cbd5e1');
      const cloudMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1, transparent: true, opacity: 0.92 });
      disposables.push(cloudMat);
      const glowBlue = new THREE.MeshBasicMaterial({ color: '#7dd3fc', transparent: true, opacity: 0.55, side: THREE.DoubleSide });
      const glowPink = new THREE.MeshBasicMaterial({ color: '#f0abfc', transparent: true, opacity: 0.85 });
      disposables.push(glowBlue, glowPink);

      // Pulau utama (tempat lapangan berada)
      const main = new THREE.Group();
      const top = new THREE.Mesh(geo(new THREE.CylinderGeometry(46, 46, 0.3, 48)), grassTop);
      top.position.y = -0.2;
      const rim = new THREE.Mesh(geo(new THREE.CylinderGeometry(46.6, 45, 1.6, 48)), stone);
      rim.position.y = -1.1;
      const under = new THREE.Mesh(geo(new THREE.ConeGeometry(45, 44, 14)), rockA);
      under.rotation.x = Math.PI;
      under.position.y = -24;
      const under2 = new THREE.Mesh(geo(new THREE.ConeGeometry(26, 30, 10)), rockB);
      under2.rotation.x = Math.PI;
      under2.position.set(10, -50, -4);
      main.add(top, rim, under, under2);
      main.scale.z = 0.82;
      group.add(main);
      // Kristal menggantung di bawah pulau
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * Math.PI * 2;
        const cr = new THREE.Mesh(geo(new THREE.OctahedronGeometry(1.4 + r() * 1.4)), i % 2 ? glowBlue : glowPink);
        cr.scale.y = 2.2;
        cr.position.set(Math.cos(a) * 30, -16 - r() * 10, Math.sin(a) * 24);
        group.add(cr);
      }
      // Air terjun dari tepi pulau
      const falls: THREE.Mesh[] = [];
      for (const [fx, fz] of [[-40, -8], [41, 6], [6, -39]] as Array<[number, number]>) {
        const fall = new THREE.Mesh(geo(new THREE.PlaneGeometry(4, 40)), glowBlue);
        fall.position.set(fx, -22, fz * 0.82);
        fall.rotation.y = Math.atan2(fx, fz) + Math.PI / 2 * 0;
        group.add(fall);
        falls.push(fall);
      }
      // Pohon sihir & batu rune di sekeliling pulau
      const trunkM = mat('#7c4a1e');
      const crownM = [mat('#c084fc', { flatShading: false }), mat('#f9a8d4', { flatShading: false }), mat('#67e8f9', { flatShading: false })];
      for (let i = 0; i < 26; i++) {
        const a = (i / 26) * Math.PI * 2 + r() * 0.2;
        const rad = 27 + r() * 14;
        const x = Math.cos(a) * rad;
        const z = Math.sin(a) * rad * 0.8;
        if (z > 14) continue;
        const s = 0.9 + r() * 0.9;
        const tr = new THREE.Mesh(geo(new THREE.CylinderGeometry(0.18, 0.26, 1.6, 6)), trunkM);
        tr.scale.setScalar(s);
        add(tr, x, 0.8 * s, z);
        const cr = new THREE.Mesh(geo(new THREE.IcosahedronGeometry(1.3, 0)), crownM[i % 3]);
        cr.scale.setScalar(s);
        add(cr, x, 2.4 * s, z);
      }
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + 0.3;
        const rune = new THREE.Mesh(geo(new THREE.BoxGeometry(0.8, 2.6, 0.6)), stone);
        add(rune, Math.cos(a) * 24, 1.3, Math.sin(a) * 19 - 4);
        const glow = new THREE.Mesh(geo(new THREE.BoxGeometry(0.3, 0.9, 0.12)), glowBlue);
        add(glow, Math.cos(a) * 24, 1.7, Math.sin(a) * 19 - 4 + 0.36);
      }

      // Pulau-pulau kecil melayang (bergoyang naik-turun)
      const isles: Array<{ g: THREE.Group; y0: number; ph: number }> = [];
      const spots: Array<[number, number, number, number]> = [
        [-78, 12, -46, 11], [82, 20, -52, 13], [-52, 30, -105, 9], [48, 26, -112, 10], [-112, 6, -20, 8], [112, 10, -24, 9], [0, 34, -150, 14],
      ];
      spots.forEach(([x, y, z, rad], i) => {
        const g = new THREE.Group();
        const t2 = new THREE.Mesh(geo(new THREE.CylinderGeometry(rad, rad, 0.5, 18)), grassTop);
        const u = new THREE.Mesh(geo(new THREE.ConeGeometry(rad * 0.98, rad * 1.5, 9)), i % 2 ? rockA : rockB);
        u.rotation.x = Math.PI;
        u.position.y = -rad * 0.78;
        g.add(t2, u);
        if (i % 3 === 0) {
          const tw = new THREE.Mesh(geo(new THREE.CylinderGeometry(rad * 0.22, rad * 0.26, rad * 1.4, 10)), stone);
          tw.position.y = rad * 0.7;
          const rf = new THREE.Mesh(geo(new THREE.ConeGeometry(rad * 0.3, rad * 0.6, 10)), mat('#a855f7', { flatShading: false }));
          rf.position.y = rad * 1.7;
          g.add(tw, rf);
        } else if (i % 3 === 1) {
          const cr = new THREE.Mesh(geo(new THREE.OctahedronGeometry(rad * 0.3)), glowBlue);
          cr.scale.y = 2;
          cr.position.y = rad * 0.8;
          g.add(cr);
        } else {
          for (let k = 0; k < 3; k++) {
            const tr = new THREE.Mesh(geo(new THREE.ConeGeometry(1.2, 3.4, 7)), mat('#15803d'));
            tr.position.set((k - 1) * rad * 0.4, 2, (k % 2) * 2);
            g.add(tr);
          }
        }
        g.position.set(x, y, z);
        group.add(g);
        isles.push({ g, y0: y, ph: i * 1.3 });
      });

      // Lautan awan di bawah
      const cloudG = geo(new THREE.SphereGeometry(1, 9, 7));
      const sea: THREE.Mesh[] = [];
      for (let i = 0; i < 90; i++) {
        const c = new THREE.Mesh(cloudG, cloudMat);
        const s = 8 + r() * 12;
        c.scale.set(s * 1.6, s * 0.45, s);
        c.position.set(-190 + r() * 380, -58 - r() * 14, -170 + r() * 300);
        group.add(c);
        sea.push(c);
      }

      // Naga terbang mengitari pulau
      const dragon = new THREE.Group();
      const dBody = mat('#7c3aed', { flatShading: false });
      const dWing = new THREE.MeshStandardMaterial({ color: '#f472b6', side: THREE.DoubleSide, roughness: 0.6 });
      disposables.push(dWing);
      const torso = new THREE.Mesh(geo(new THREE.SphereGeometry(1.5, 10, 8)), dBody);
      torso.scale.set(1.9, 0.9, 0.9);
      const head = new THREE.Mesh(geo(new THREE.SphereGeometry(0.9, 8, 6)), dBody);
      head.position.set(3, 0.5, 0);
      const tail = new THREE.Mesh(geo(new THREE.ConeGeometry(0.7, 5, 6)), dBody);
      tail.rotation.z = Math.PI / 2;
      tail.position.set(-4.6, 0, 0);
      const wingGeo = geo(new THREE.PlaneGeometry(4.5, 2.6));
      const wingL = new THREE.Group();
      const wL = new THREE.Mesh(wingGeo, dWing);
      wL.rotation.x = -Math.PI / 2;
      wL.position.z = 2.2;
      wingL.add(wL);
      const wingR = new THREE.Group();
      const wR = new THREE.Mesh(wingGeo, dWing);
      wR.rotation.x = -Math.PI / 2;
      wR.position.z = -2.2;
      wingR.add(wR);
      dragon.add(torso, head, tail, wingL, wingR);
      dragon.scale.setScalar(1.5);
      group.add(dragon);

      // Kerlip sihir melayang
      const SP = 160;
      const sp = new Float32Array(SP * 3);
      for (let i = 0; i < SP; i++) {
        sp[i * 3] = -90 + r() * 180;
        sp[i * 3 + 1] = -4 + r() * 40;
        sp[i * 3 + 2] = -100 + r() * 90;
      }
      const spGeo = geo(new THREE.BufferGeometry());
      spGeo.setAttribute('position', new THREE.BufferAttribute(sp, 3));
      const spMat = new THREE.PointsMaterial({ color: '#fef9c3', size: 0.7, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending });
      disposables.push(spMat);
      const sparkles = new THREE.Points(spGeo, spMat);
      group.add(sparkles);

      animators.push((t) => {
        isles.forEach((o) => (o.g.position.y = o.y0 + Math.sin(t * 0.5 + o.ph) * 1.4));
        falls.forEach((f, i) => ((f.material as THREE.MeshBasicMaterial).opacity = 0.45 + Math.sin(t * 3 + i) * 0.08));
        sea.forEach((c, i) => (c.position.x += Math.sin(t * 0.2 + i) * 0.004));
        const a = t * 0.12;
        dragon.position.set(Math.cos(a) * 95, 24 + Math.sin(t * 0.6) * 3, -62 + Math.sin(a) * 50);
        dragon.rotation.y = -a - Math.PI / 2 + Math.PI;
        const flap = Math.sin(t * 5) * 0.7;
        wingL.rotation.x = flap;
        wingR.rotation.x = -flap;
        sparkles.rotation.y = Math.sin(t * 0.05) * 0.3;
        sparkles.position.y = Math.sin(t * 0.4) * 1.2;
      });
      break;
    }
    case 'rooftop': {
      // ===== Atap gedung pencakar langit, pesawat melintas =====
      const concrete = mat('#6b7280', { flatShading: false, roughness: 0.95 });
      const roof = new THREE.Mesh(geo(new THREE.BoxGeometry(104, 4, 72)), concrete);
      add(roof, 0, -2.1, -4);
      // Pagar pembatas atap (rendah di selatan agar kamera tidak terhalang)
      const parapet = mat('#94a3b8', { flatShading: false });
      for (const [w, d, x, z, h] of [[104, 1.2, 0, -40, 1.6], [1.2, 72, -52, -4, 1.6], [1.2, 72, 52, -4, 1.6], [104, 1.2, 0, 32, 0.5]] as Array<[number, number, number, number, number]>) {
        add(new THREE.Mesh(geo(new THREE.BoxGeometry(w, h, d)), parapet), x, h / 2, z);
      }
      // Lingkaran helipad & garis atap
      const padTex = (() => {
        const c = document.createElement('canvas');
        c.width = c.height = 128;
        const g2 = c.getContext('2d')!;
        g2.clearRect(0, 0, 128, 128);
        g2.strokeStyle = '#fde047';
        g2.lineWidth = 6;
        g2.beginPath();
        g2.arc(64, 64, 54, 0, Math.PI * 2);
        g2.stroke();
        g2.fillStyle = '#fde047';
        g2.font = 'bold 70px sans-serif';
        g2.textAlign = 'center';
        g2.textBaseline = 'middle';
        g2.fillText('H', 64, 68);
        const t = new THREE.CanvasTexture(c);
        t.colorSpace = THREE.SRGBColorSpace;
        return t;
      })();
      disposables.push(padTex);
      const padMat = new THREE.MeshBasicMaterial({ map: padTex, transparent: true });
      disposables.push(padMat);
      const pad = new THREE.Mesh(geo(new THREE.PlaneGeometry(10, 10)), padMat);
      pad.rotation.x = -Math.PI / 2;
      add(pad, -42, 0.02, -28);
      // Tangki air, unit AC, antena berkedip
      const tankM = mat('#b45309', { flatShading: false });
      const tank = new THREE.Mesh(geo(new THREE.CylinderGeometry(2.2, 2.2, 3.4, 14)), tankM);
      add(tank, 40, 3.4, -30);
      for (const lx of [-1.4, 1.4]) add(new THREE.Mesh(geo(new THREE.CylinderGeometry(0.12, 0.12, 1.8, 5)), mat('#475569')), 40 + lx, 0.9, -30 + 0.5);
      add(new THREE.Mesh(geo(new THREE.ConeGeometry(2.4, 1.1, 14)), tankM), 40, 5.6, -30);
      const acM = mat('#cbd5e1', { flatShading: false });
      for (let i = 0; i < 5; i++) {
        const ac = new THREE.Mesh(geo(new THREE.BoxGeometry(3, 1.6, 2)), acM);
        add(ac, -30 + i * 6.5, 0.8, -36.5);
        add(new THREE.Mesh(geo(new THREE.CylinderGeometry(0.7, 0.7, 0.1, 10)), mat('#1e293b')), -30 + i * 6.5, 1.65, -36.5);
      }
      const mast = new THREE.Mesh(geo(new THREE.CylinderGeometry(0.1, 0.16, 16, 6)), mat('#e2e8f0'));
      add(mast, 46, 8, -34);
      const beaconMat = new THREE.MeshBasicMaterial({ color: '#ef4444' });
      disposables.push(beaconMat);
      const beacon = new THREE.Mesh(geo(new THREE.SphereGeometry(0.4, 8, 6)), beaconMat);
      add(beacon, 46, 16.2, -34);

      // Papan iklan neon di belakang
      const bbTex = (() => {
        const c = document.createElement('canvas');
        c.width = 256;
        c.height = 96;
        const g2 = c.getContext('2d')!;
        g2.fillStyle = '#0f172a';
        g2.fillRect(0, 0, 256, 96);
        g2.strokeStyle = '#22d3ee';
        g2.lineWidth = 5;
        g2.strokeRect(5, 5, 246, 86);
        g2.fillStyle = '#f472b6';
        g2.font = 'bold 44px sans-serif';
        g2.textAlign = 'center';
        g2.textBaseline = 'middle';
        g2.fillText('BOLA GILA', 128, 50);
        const t = new THREE.CanvasTexture(c);
        t.colorSpace = THREE.SRGBColorSpace;
        return t;
      })();
      disposables.push(bbTex);
      const bbMat = new THREE.MeshBasicMaterial({ map: bbTex });
      disposables.push(bbMat);
      const bb = new THREE.Mesh(geo(new THREE.PlaneGeometry(28, 10.5)), bbMat);
      add(bb, 0, 11, -43);
      for (const sx of [-10, 10]) add(new THREE.Mesh(geo(new THREE.CylinderGeometry(0.2, 0.2, 6, 6)), mat('#475569')), sx, 3, -42.8);

      // Cakrawala kota di bawah & jauh (atap gedung lain lebih rendah, sebagian lebih tinggi di kejauhan)
      const litTex = [windowTexture(['#fde68a', '#fef9c3', '#bae6fd'], 2, 6), windowTexture(['#fda4af', '#fde68a'], 3, 8)];
      litTex.forEach((tx) => disposables.push(tx));
      const bMats = litTex.flatMap((tx) =>
        ['#64748b', '#475569', '#7c8aa0', '#94a3b8'].map((p) => {
          const m = new THREE.MeshStandardMaterial({ color: p, map: tx, emissive: '#1e293b', emissiveIntensity: 0.5, emissiveMap: tx, roughness: 0.7 });
          disposables.push(m);
          return m;
        })
      );
      for (let i = 0; i < 70; i++) {
        const a = (r() * 2 - 1) * Math.PI * 0.95; // sebaran melingkar (tanpa tepat di selatan kamera)
        const dist = 62 + r() * 120;
        const x = Math.sin(a) * dist * 1.1;
        const z = -Math.cos(a) * dist * 0.9 - 4;
        if (Math.abs(x) < 58 && z > -42) continue; // jangan menimpa atap
        const w = 9 + r() * 12;
        const d = 9 + r() * 12;
        const topY = -6 - r() * 26 + (dist > 110 ? r() * 55 : 0);
        const h = 60 + r() * 50;
        const b = new THREE.Mesh(geo(new THREE.BoxGeometry(w, h, d)), bMats[Math.floor(r() * bMats.length)]);
        add(b, x, topY - h / 2, z);
      }
      const street = new THREE.Mesh(geo(new THREE.PlaneGeometry(600, 600)), mat('#0b1220', { flatShading: false }));
      street.rotation.x = -Math.PI / 2;
      add(street, 0, -110, -60);

      // Pesawat yang melintas
      const makePlane = (body: string, accent: string, scale: number) => {
        const p = new THREE.Group();
        const bodyM = new THREE.MeshStandardMaterial({ color: body, roughness: 0.35, metalness: 0.2 });
        const accM = new THREE.MeshStandardMaterial({ color: accent, roughness: 0.4 });
        disposables.push(bodyM, accM);
        const fus = new THREE.Mesh(geo(new THREE.CylinderGeometry(0.9, 0.9, 10, 12)), bodyM);
        fus.rotation.z = Math.PI / 2;
        const nose = new THREE.Mesh(geo(new THREE.ConeGeometry(0.9, 2.2, 12)), bodyM);
        nose.rotation.z = -Math.PI / 2;
        nose.position.x = 6.1;
        const wing = new THREE.Mesh(geo(new THREE.BoxGeometry(3.2, 0.2, 13)), accM);
        wing.position.set(0.5, -0.1, 0);
        wing.rotation.y = 0;
        const tailFin = new THREE.Mesh(geo(new THREE.BoxGeometry(2, 2.6, 0.2)), accM);
        tailFin.position.set(-4.6, 1.5, 0);
        tailFin.rotation.z = -0.35;
        const tailWing = new THREE.Mesh(geo(new THREE.BoxGeometry(1.6, 0.15, 4.6)), accM);
        tailWing.position.set(-4.8, 0.4, 0);
        const redM = new THREE.MeshBasicMaterial({ color: '#ef4444' });
        const grnM = new THREE.MeshBasicMaterial({ color: '#22c55e' });
        const whtM = new THREE.MeshBasicMaterial({ color: '#ffffff' });
        disposables.push(redM, grnM, whtM);
        const lr = new THREE.Mesh(geo(new THREE.SphereGeometry(0.28, 6, 5)), redM);
        lr.position.set(0.5, 0, 6.5);
        const lg = new THREE.Mesh(geo(new THREE.SphereGeometry(0.28, 6, 5)), grnM);
        lg.position.set(0.5, 0, -6.5);
        const lw = new THREE.Mesh(geo(new THREE.SphereGeometry(0.3, 6, 5)), whtM);
        lw.position.set(-5.2, 0.3, 0);
        const trailM = new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.28, depthWrite: false, side: THREE.DoubleSide });
        disposables.push(trailM);
        const trail = new THREE.Mesh(geo(new THREE.PlaneGeometry(60, 0.9)), trailM);
        trail.position.set(-36, 0, 0);
        p.add(fus, nose, wing, tailFin, tailWing, lr, lg, lw, trail);
        p.scale.setScalar(scale);
        group.add(p);
        return { p, lights: [lr, lg, lw] };
      };
      const jet = makePlane('#f8fafc', '#ef4444', 2.6);
      const prop = makePlane('#fde68a', '#2563eb', 1.4);
      animators.push((t) => {
        // pesawat besar: kiri -> kanan tiap ±26 detik
        const jx = ((t * 15) % 400) - 200;
        jet.p.position.set(jx, 34 + Math.sin(t * 0.3) * 1.2, -82);
        jet.p.rotation.set(0, 0, Math.sin(t * 0.5) * 0.03);
        // pesawat kecil: kanan -> kiri, lebih rendah
        const px = 190 - ((t * 9 + 120) % 380);
        prop.p.position.set(px, 20 + Math.sin(t * 0.7) * 0.8, -58);
        prop.p.rotation.set(0, Math.PI, 0);
        const blink = Math.sin(t * 7) > 0;
        for (const pl of [jet, prop]) {
          pl.lights[0].visible = blink;
          pl.lights[1].visible = blink;
          pl.lights[2].visible = !blink;
        }
        beacon.visible = Math.sin(t * 3) > -0.2;
      });
      break;
    }
    case 'candy': {
      const pastel = ['#f9a8d4', '#a5f3fc', '#fde68a', '#c4b5fd', '#bbf7d0', '#fda4af'];
      // Gumdrop hills
      for (let i = 0; i < 12; i++) {
        const s = 9 + r() * 10;
        const hill = new THREE.Mesh(geo(new THREE.SphereGeometry(s, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2)), mat(pastel[i % pastel.length], { flatShading: false, roughness: 0.5 }));
        add(hill, -85 + i * 15.5, -0.1, -70 - r() * 18);
      }
      // ISTANA permen
      const wallMat = mat('#fbcfe8', { flatShading: false, roughness: 0.5 });
      const roofPink = mat('#ec4899', { flatShading: false, roughness: 0.35 });
      const roofBlue = mat('#38bdf8', { flatShading: false, roughness: 0.35 });
      const gold = mat('#facc15', { flatShading: false, metalness: 0.4, roughness: 0.3 });
      const castleZ = -58;
      const keep = new THREE.Mesh(geo(new THREE.CylinderGeometry(6, 6.6, 22, 16)), wallMat);
      add(keep, 0, 11, castleZ);
      add(new THREE.Mesh(geo(new THREE.ConeGeometry(7.6, 12, 16)), roofPink), 0, 28, castleZ);
      add(new THREE.Mesh(geo(new THREE.SphereGeometry(0.9, 10, 8)), gold), 0, 34.6, castleZ);
      const wall = new THREE.Mesh(geo(new THREE.BoxGeometry(46, 10, 3)), wallMat);
      add(wall, 0, 5, castleZ + 8);
      for (const sx of [-23, -14, 14, 23]) {
        const tw = new THREE.Mesh(geo(new THREE.CylinderGeometry(3, 3.3, 16, 12)), wallMat);
        add(tw, sx, 8, castleZ + 8);
        add(new THREE.Mesh(geo(new THREE.ConeGeometry(4, 8, 12)), sx < 0 ? roofBlue : roofPink), sx, 20, castleZ + 8);
      }
      for (let i = 0; i < 9; i++) {
        const cren = new THREE.Mesh(geo(new THREE.BoxGeometry(2, 1.6, 3.2)), wallMat);
        add(cren, -16 + i * 4, 10.8, castleZ + 8);
      }
      const gate = new THREE.Mesh(geo(new THREE.BoxGeometry(6, 7, 3.4)), mat('#7c3aed', { flatShading: false }));
      add(gate, 0, 3.5, castleZ + 8.1);
      // KOTA permen: rumah cupcake / permen
      for (let i = 0; i < 16; i++) {
        const x = -70 + i * 9.3 + (r() - 0.5) * 2;
        const z = -34 - r() * 10;
        const w = 5 + r() * 3;
        const h = 5 + r() * 4;
        const house = new THREE.Mesh(geo(new THREE.BoxGeometry(w, h, w)), mat(pastel[i % pastel.length], { flatShading: false, roughness: 0.5 }));
        add(house, x, h / 2, z);
        const roof = new THREE.Mesh(geo(new THREE.SphereGeometry(w * 0.62, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2)), mat(pastel[(i + 3) % pastel.length], { flatShading: false, roughness: 0.3 }));
        add(roof, x, h, z);
        const cherry = new THREE.Mesh(geo(new THREE.SphereGeometry(0.5, 8, 6)), mat('#dc2626', { flatShading: false }));
        add(cherry, x, h + w * 0.62 + 0.3, z);
      }
      // Lollipop & tongkat permen
      const stickG = geo(new THREE.CylinderGeometry(0.15, 0.15, 5, 6));
      const stickMat = mat('#ffffff', { flatShading: false });
      const lolG = geo(new THREE.SphereGeometry(1.6, 12, 8));
      for (let i = 0; i < 20; i++) {
        const x = -60 + i * 6.2 + r() * 2;
        const z = -22 - r() * 6;
        add(new THREE.Mesh(stickG, stickMat), x, 2.5, z);
        const lol = new THREE.Mesh(lolG, mat(pastel[i % pastel.length], { flatShading: false, roughness: 0.3 }));
        lol.scale.set(1, 1, 0.35);
        add(lol, x, 5.6, z);
      }
      break;
    }
  }

  return {
    group,
    disposables,
    update: (t: number) => animators.forEach((a) => a(t)),
  };
}
