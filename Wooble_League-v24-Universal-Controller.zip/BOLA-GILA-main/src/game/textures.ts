import * as THREE from 'three';
import { ArenaSpec, BallTypeId, ClothesStyleId } from './types';

export function createGrassTexture(arena: ArenaSpec, maxAnisotropy: number, pattern: 'stripes' | 'checker' | 'diamond' | 'rings' = 'stripes'): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  if (pattern === 'checker') {
    const n = 8;
    const cw = size / n;
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        ctx.fillStyle = (x + y) % 2 === 0 ? arena.grassA : arena.grassB;
        ctx.fillRect(x * cw, y * cw, cw, cw);
      }
    }
  } else if (pattern === 'diamond') {
    ctx.fillStyle = arena.grassA;
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = arena.grassB;
    const d = size / 4;
    for (let y = 0; y < 4; y++) {
      for (let x = 0; x < 4; x++) {
        const cx = x * d + d / 2;
        const cy = y * d + d / 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy - d / 2);
        ctx.lineTo(cx + d / 2, cy);
        ctx.lineTo(cx, cy + d / 2);
        ctx.lineTo(cx - d / 2, cy);
        ctx.closePath();
        ctx.fill();
      }
    }
  } else if (pattern === 'rings') {
    const rings = 8;
    for (let i = rings; i >= 1; i--) {
      ctx.fillStyle = i % 2 === 0 ? arena.grassA : arena.grassB;
      ctx.beginPath();
      ctx.arc(size / 2, size / 2, (i / rings) * size * 0.72, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalCompositeOperation = 'destination-over';
    ctx.fillStyle = arena.grassA;
    ctx.fillRect(0, 0, size, size);
    ctx.globalCompositeOperation = 'source-over';
  } else {
    const stripeCount = 8;
    const stripeW = size / stripeCount;
    for (let i = 0; i < stripeCount; i++) {
      ctx.fillStyle = i % 2 === 0 ? arena.grassA : arena.grassB;
      ctx.fillRect(i * stripeW, 0, stripeW, size);
    }
  }

  for (let y = 0; y < size; y += 4) {
    for (let x = 0; x < size; x += 4) {
      const h = ((x * 73 + y * 139) % 17) / 17;
      if (h > 0.68) {
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
        ctx.fillRect(x, y, 2, 2);
      } else if (h < 0.22) {
        ctx.fillStyle = 'rgba(0,0,0,0.08)';
        ctx.fillRect(x, y, 2, 2);
      }
    }
  }

  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  // Mirrored repeat (jumlah tile genap) => corak rumput simetris persis kiri-kanan dan atas-bawah
  map.wrapS = THREE.MirroredRepeatWrapping;
  map.wrapT = THREE.MirroredRepeatWrapping;
  map.repeat.set(4, 2);
  map.anisotropy = maxAnisotropy;

  const bCanvas = document.createElement('canvas');
  bCanvas.width = 128;
  bCanvas.height = 128;
  const bCtx = bCanvas.getContext('2d')!;
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 128, 128);
  for (let y = 0; y < 128; y += 2) {
    for (let x = 0; x < 128; x += 2) {
      const v = 100 + ((x * 37 + y * 91) % 60);
      bCtx.fillStyle = `rgb(${v},${v},${v})`;
      bCtx.fillRect(x, y, 2, 2);
    }
  }
  const bumpMap = new THREE.CanvasTexture(bCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(10, 6);

  return { map, bumpMap };
}

/** Pseudo-random deterministik agar corak bola selalu sama */
function seededRand(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

interface ProBallStyle {
  base: string;
  panelLine: string;
  accent: string;
  accent2: string;
  dark: string;
  speckle: string;
  seed: number;
  darkBase: boolean;
  /** Jumlah serpihan corak (default 26) */
  shards?: number;
}

/**
 * Corak bola pro: panel segi lima/enam, serpihan "petir" tajam berlapis, dan titik halftone,
 * digambar seamless (wrap horizontal) untuk dipetakan ke bola.
 */
function drawProBall(ctx: CanvasRenderingContext2D, size: number, st: ProBallStyle) {
  const rand = seededRand(st.seed);
  ctx.fillStyle = st.base;
  ctx.fillRect(0, 0, size, size);

  // Panel segi lima/enam
  ctx.lineWidth = 3;
  ctx.strokeStyle = st.panelLine;
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 6; c++) {
      const cx = ((c + (r % 2) * 0.5) / 6) * size;
      const cy = ((r + 0.5) / 4) * size;
      const n = (r + c) % 2 === 0 ? 5 : 6;
      for (const dx of [-size, 0, size]) {
        ctx.beginPath();
        for (let k = 0; k < n; k++) {
          const a = (k / n) * Math.PI * 2 - Math.PI / 2;
          const px = cx + dx + Math.cos(a) * 52;
          const py = cy + Math.sin(a) * 52;
          if (k === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        if (st.darkBase && n === 5) {
          ctx.fillStyle = 'rgba(0,0,0,0.35)';
          ctx.fill();
        }
        ctx.stroke();
      }
    }
  }

  // Serpihan petir tajam
  const shard = (x: number, y: number, len: number, w: number, ang: number, fill: string) => {
    for (const dx of [-size, 0, size]) {
      ctx.save();
      ctx.translate(x + dx, y);
      ctx.rotate(ang);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(len * 0.45, -w);
      ctx.lineTo(len * 0.38, -w * 0.15);
      ctx.lineTo(len, w * 0.2);
      ctx.lineTo(len * 0.5, w * 0.55);
      ctx.lineTo(len * 0.55, w * 1.1);
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.restore();
    }
  };
  const palette = [st.accent, st.dark, st.accent2, st.dark, st.accent];
  for (let i = 0; i < (st.shards ?? 26); i++) {
    const x = rand() * size;
    const y = rand() * size;
    const len = 90 + rand() * 170;
    const w = 20 + rand() * 38;
    const ang = -0.9 + rand() * 1.5;
    shard(x, y, len, w, ang, palette[i % palette.length]);
  }
  // Goresan tipis kontras
  ctx.lineCap = 'round';
  for (let i = 0; i < 14; i++) {
    ctx.strokeStyle = i % 2 === 0 ? st.dark : st.accent2;
    ctx.lineWidth = 2 + rand() * 4;
    const x = rand() * size;
    const y = rand() * size;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 40 + rand() * 90, y - 20 - rand() * 60);
    ctx.stroke();
  }
  // Titik halftone
  ctx.fillStyle = st.speckle;
  for (let i = 0; i < 520; i++) {
    const x = rand() * size;
    const y = rand() * size;
    const r = 0.8 + rand() * 2.4;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function createBallTexture(type: BallTypeId, maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  if (type === 'pro_blue') {
    drawProBall(ctx, size, {
      base: '#f8fafc', panelLine: 'rgba(100,116,139,0.55)', accent: '#1d6fe0', accent2: '#60a5fa',
      dark: '#0b1220', speckle: 'rgba(15,23,42,0.75)', seed: 7, darkBase: false,
    });
  } else if (type === 'pro_yellow') {
    drawProBall(ctx, size, {
      base: '#fcd920', panelLine: 'rgba(161,98,7,0.5)', accent: '#f8fafc', accent2: '#fde047',
      dark: '#0b0f19', speckle: 'rgba(15,23,42,0.55)', seed: 19, darkBase: false, shards: 7,
    });
  } else if (type === 'pro_gold') {
    drawProBall(ctx, size, {
      base: '#0b0d12', panelLine: 'rgba(212,160,23,0.75)', accent: '#d4a017', accent2: '#f5d060',
      dark: '#05060a', speckle: 'rgba(224,176,40,0.8)', seed: 31, darkBase: true,
    });
  } else if (type === 'soccer') {
    // Corak Tango: panel putih dengan segitiga melengkung (tri-lobe) berlapis abu-abu
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, size, size);
    const tri = (cx: number, cy: number, rad: number, rot: number, fill: string, stroke: string, lw: number) => {
      const pts = [0, 1, 2].map((k) => {
        const a = rot + (k / 3) * Math.PI * 2;
        return [cx + Math.cos(a) * rad, cy + Math.sin(a) * rad];
      });
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      for (let k = 0; k < 3; k++) {
        const p1 = pts[(k + 1) % 3];
        const a = rot + ((k + 0.5) / 3) * Math.PI * 2;
        const bx = cx + Math.cos(a) * rad * 1.05;
        const by = cy + Math.sin(a) * rad * 1.05;
        ctx.quadraticCurveTo(bx, by, p1[0], p1[1]);
      }
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.strokeStyle = stroke;
      ctx.lineWidth = lw;
      ctx.stroke();
    };
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 6; c++) {
        const cx = ((c + (r % 2) * 0.5) / 6) * size;
        const cy = ((r + 0.5) / 4) * size;
        const rot = (r + c) % 2 === 0 ? -Math.PI / 2 : Math.PI / 2;
        tri(cx, cy, 58, rot, '#f1f5f9', '#475569', 4);
        tri(cx, cy, 36, rot, '#cbd5e1', '#64748b', 3);
        tri(cx, cy, 15, rot, '#334155', '#0f172a', 2);
      }
    }
  } else if (type === 'soccer_telstar') {
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 3;
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 6; c++) {
        const cx = ((c + (r % 2) * 0.5) / 6) * size;
        const cy = ((r + 0.5) / 4) * size;
        ctx.beginPath();
        for (let k = 0; k < 5; k++) {
          const ang = (k / 5) * Math.PI * 2 - Math.PI / 2;
          const px = cx + Math.cos(ang) * 34;
          const py = cy + Math.sin(ang) * 34;
          if (k === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fillStyle = '#0f172a';
        ctx.fill();
        ctx.stroke();
      }
    }
  } else if (type === 'hockey') {
    // Black vulcanized rubber puck with cyan/white hockey emblem & edge grooves
    const cx = size / 2;
    const cy = size / 2;
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, size, size);
    // Grooved side rubber bands
    ctx.strokeStyle = '#1f2937';
    ctx.lineWidth = 8;
    for (let y = 16; y < size; y += 24) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(size, y);
      ctx.stroke();
    }
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.arc(cx, cy, 180, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.arc(cx, cy, 62, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(cx - 8, cy - 88, 16, 176);
  } else if (type === 'rubber') {
    // High-visibility glossy elastic rubber swirl stripes
    ctx.fillStyle = '#ec4899';
    ctx.fillRect(0, 0, size, size);
    const cols = ['#f472b6', '#fde047', '#f97316', '#f43f5e'];
    for (let i = 0; i < 8; i++) {
      ctx.fillStyle = cols[i % cols.length];
      ctx.fillRect(0, i * 64, size, 28);
    }
    ctx.fillStyle = 'rgba(255,255,255,0.28)';
    ctx.beginPath();
    ctx.arc(size * 0.35, size * 0.32, 68, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 'metal') {
    // Brushed chrome steel texture with dark machined seam lines so rotation is readable
    const grad = ctx.createLinearGradient(0, 0, size, size);
    grad.addColorStop(0, '#f1f5f9');
    grad.addColorStop(0.35, '#94a3b8');
    grad.addColorStop(0.65, '#e2e8f0');
    grad.addColorStop(1, '#475569');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.35)';
    ctx.lineWidth = 3;
    for (let y = 8; y < size; y += 12) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(size, y);
      ctx.stroke();
    }
    // Steel bolts & seam ring
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(0, size / 2);
    ctx.lineTo(size, size / 2);
    ctx.stroke();
    for (let i = 0; i < 6; i++) {
      const bx = (i + 0.5) * (size / 6);
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.arc(bx, size * 0.25, 14, 0, Math.PI * 2);
      ctx.arc(bx, size * 0.75, 14, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (type === 'beach_volleyball') {
    const colors = ['#ef4444', '#f8fafc', '#2563eb', '#facc15', '#f8fafc', '#16a34a'];
    const stripe = size / colors.length;
    colors.forEach((col, i) => {
      ctx.fillStyle = col;
      ctx.fillRect(i * stripe, 0, stripe + 2, size);
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 4;
      ctx.strokeRect(i * stripe, 0, stripe, size);
    });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, 48);
    ctx.fillRect(0, size - 48, size, 48);
  } else if (type === 'crystal') {
    // Faceted glowing crystal polygons so 3D rotation sparkles cleanly
    const grad = ctx.createLinearGradient(0, 0, size, size);
    grad.addColorStop(0, '#a5f3fc');
    grad.addColorStop(0.5, '#67e8f9');
    grad.addColorStop(1, '#c084fc');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    const facetCols = ['rgba(255,255,255,0.45)', 'rgba(168,85,247,0.35)', 'rgba(56,189,248,0.4)'];
    for (let r = 0; r < 6; r++) {
      for (let c = 0; c < 6; c++) {
        const x = (c / 6) * size;
        const y = (r / 6) * size;
        const w = size / 6;
        ctx.fillStyle = facetCols[(r + c) % facetCols.length];
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + w, y);
        ctx.lineTo(x + w * 0.5, y + w);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.65)';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }
  } else if (type === 'nfl') {
    const grad = ctx.createLinearGradient(0, 0, 0, size);
    grad.addColorStop(0, '#6b3410');
    grad.addColorStop(0.5, '#964b19');
    grad.addColorStop(1, '#5c2c0c');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    for (let y = 0; y < size; y += 8) {
      for (let x = 0; x < size; x += 8) {
        if ((x + y) % 16 === 0) {
          ctx.fillStyle = 'rgba(0,0,0,0.18)';
          ctx.beginPath();
          ctx.arc(x + 2, y + 2, 2.4, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 52, size, 28);
    ctx.fillRect(0, size - 80, size, 28);
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(size * 0.46, 140, 26, size - 280);
    ctx.fillStyle = '#ffffff';
    for (let y = 160; y < size - 155; y += 30) {
      ctx.fillRect(size * 0.38, y, size * 0.24, 12);
    }
  } else if (type === 'flat_disc') {
    // Aerodynamic Sport Flying Disc concentric radial rings + directional marker
    const cx = size / 2;
    const cy = size / 2;
    ctx.fillStyle = '#f97316';
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 22;
    ctx.beginPath();
    ctx.arc(cx, cy, 195, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = '#0ea5e9';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.arc(cx, cy, 130, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(cx, cy, 56, 0, Math.PI * 2);
    ctx.fill();
    // Wedge accent so vertical Y spin is clearly visible!
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(cx - 12, 20, 24, 150);
  } else if (type === 'tennis') {
    ctx.fillStyle = '#bef264';
    ctx.fillRect(0, 0, size, size);
    for (let y = 0; y < size; y += 6) {
      for (let x = 0; x < size; x += 6) {
        if ((x * 7 + y * 13) % 5 === 0) {
          ctx.fillStyle = 'rgba(255,255,255,0.2)';
          ctx.fillRect(x, y, 3, 3);
        }
      }
    }
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 22;
    ctx.beginPath();
    ctx.moveTo(0, size * 0.3);
    ctx.bezierCurveTo(size * 0.35, size * 0.82, size * 0.65, size * 0.18, size, size * 0.7);
    ctx.stroke();
  } else if (type === 'dice') {
    ctx.fillStyle = '#fefce8';
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 18;
    ctx.strokeRect(12, 12, size - 24, size - 24);
    const pips = [
      [0.28, 0.28],
      [0.72, 0.28],
      [0.5, 0.5],
      [0.28, 0.72],
      [0.72, 0.72],
    ];
    pips.forEach(([px, py], idx) => {
      ctx.fillStyle = idx === 2 ? '#dc2626' : '#0f172a';
      ctx.beginPath();
      ctx.arc(size * px, size * py, 36, 0, Math.PI * 2);
      ctx.fill();
    });
  } else if (type === 'ostrich_egg') {
    const grad = ctx.createLinearGradient(0, 0, 0, size);
    grad.addColorStop(0, '#fef9ef');
    grad.addColorStop(0.55, '#f6ebd5');
    grad.addColorStop(1, '#e6d3b3');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    // Natural ostrich egg pores & warm tan speckles
    for (let i = 0; i < 190; i++) {
      const sx = ((i * 97 + 31) % 499) / 499 * size;
      const sy = ((i * 151 + 67) % 499) / 499 * size;
      const r = 2.2 + (i % 5) * 1.1;
      ctx.fillStyle = i % 4 === 0 ? 'rgba(146, 108, 68, 0.48)' : 'rgba(180, 145, 102, 0.36)';
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (type === 'timer_bomb') {
    const grad = ctx.createLinearGradient(0, 0, 0, size);
    grad.addColorStop(0, '#334155');
    grad.addColorStop(0.5, '#1e293b');
    grad.addColorStop(1, '#090d16');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    // Hazard stripes band + 15s red countdown warning band
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(0, size * 0.42, size, 84);
    ctx.fillStyle = '#facc15';
    for (let x = -40; x < size + 40; x += 64) {
      ctx.beginPath();
      ctx.moveTo(x, size * 0.42);
      ctx.lineTo(x + 28, size * 0.42);
      ctx.lineTo(x + 6, size * 0.42 + 84);
      ctx.lineTo(x - 22, size * 0.42 + 84);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(size * 0.25, size * 0.44, size * 0.5, 64);
    ctx.fillStyle = '#fef08a';
    ctx.font = 'bold 42px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('15s BOOM', size * 0.5, size * 0.5);
  } else if (type === 'honey_ball') {
    const grad = ctx.createLinearGradient(0, 0, 0, size);
    grad.addColorStop(0, '#fef08a');
    grad.addColorStop(0.42, '#f59e0b');
    grad.addColorStop(1, '#b45309');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    // Honeycomb hex hints + thick glossy honey drip waves
    ctx.strokeStyle = 'rgba(120, 53, 15, 0.28)';
    ctx.lineWidth = 4;
    for (let r = 0; r < 6; r++) {
      for (let c = 0; c < 6; c++) {
        const cx = (c + (r % 2) * 0.5) * (size / 5);
        const cy = r * (size / 5);
        ctx.beginPath();
        for (let k = 0; k < 6; k++) {
          const a = (k / 6) * Math.PI * 2;
          const px = cx + Math.cos(a) * 32;
          const py = cy + Math.sin(a) * 32;
          if (k === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();
      }
    }
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(size, 0);
    ctx.lineTo(size, 150);
    for (let x = size; x >= 0; x -= 64) {
      ctx.quadraticCurveTo(x - 16, 225 + Math.sin(x) * 35, x - 64, 150);
    }
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillStyle = '#facc15';
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(0, size * 0.42, size, 72);
    ctx.fillStyle = '#ffffff';
    for (let i = 0; i < 4; i++) {
      const cx = (i + 0.5) * (size / 4);
      const cy = size / 2;
      ctx.beginPath();
      for (let k = 0; k < 10; k++) {
        const r = k % 2 === 0 ? 36 : 16;
        const a = (k / 10) * Math.PI * 2 - Math.PI / 2;
        if (k === 0) ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
        else ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.closePath();
      ctx.fill();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createDiceFaceTextures(maxAnisotropy: number): THREE.CanvasTexture[] {
  const layouts: Record<number, Array<[number, number]>> = {
    1: [[0.5, 0.5]],
    2: [[0.28, 0.28], [0.72, 0.72]],
    3: [[0.26, 0.26], [0.5, 0.5], [0.74, 0.74]],
    4: [[0.28, 0.28], [0.72, 0.28], [0.28, 0.72], [0.72, 0.72]],
    5: [[0.26, 0.26], [0.74, 0.26], [0.5, 0.5], [0.26, 0.74], [0.74, 0.74]],
    6: [[0.28, 0.24], [0.72, 0.24], [0.28, 0.5], [0.72, 0.5], [0.28, 0.76], [0.72, 0.76]],
  };

  return [1, 2, 3, 4, 5, 6].map((face) => {
    const size = 256;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#fefce8';
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 14;
    ctx.strokeRect(8, 8, size - 16, size - 16);

    const pips = layouts[face];
    pips.forEach(([px, py]) => {
      ctx.fillStyle = face === 1 ? '#dc2626' : '#0f172a';
      ctx.beginPath();
      ctx.arc(size * px, size * py, face === 1 ? 38 : 24, 0, Math.PI * 2);
      ctx.fill();
    });

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = maxAnisotropy;
    return tex;
  });
}

export function createFireAuraTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, size, 0, 0);
  grad.addColorStop(0, '#fef08a');
  grad.addColorStop(0.45, '#f97316');
  grad.addColorStop(1, '#dc2626');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(0,0,0,0.62)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0.28)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Tekstur kain jersey: rajutan halus (rib), anyaman diagonal, bintik serat, dan bayangan lipatan lembut.
 * Dipanggil di akhir setiap tekstur jersey supaya semua model jersey terlihat seperti kain sungguhan.
 */
function applyJerseyFabric(ctx: CanvasRenderingContext2D, w: number, h: number): void {
  // 1. Rib rajutan vertikal tipis
  for (let x = 0; x < w; x += 3) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.07)';
    ctx.fillRect(x, 0, 1, h);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.fillRect(x + 1, 0, 1, h);
  }
  // 2. Anyaman diagonal (twill)
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.06)';
  ctx.lineWidth = 1;
  for (let d = -h; d < w; d += 4) {
    ctx.beginPath();
    ctx.moveTo(d, 0);
    ctx.lineTo(d + h, h);
    ctx.stroke();
  }
  // 3. Bintik serat acak (deterministik agar tidak berkedip antar render)
  let seed = (w * 73856093) ^ (h * 19349663);
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  for (let i = 0; i < Math.floor((w * h) / 28); i++) {
    const x = Math.floor(rnd() * w);
    const y = Math.floor(rnd() * h);
    ctx.fillStyle = rnd() > 0.5 ? 'rgba(255, 255, 255, 0.10)' : 'rgba(0, 0, 0, 0.10)';
    ctx.fillRect(x, y, 1, 1);
  }
  // 4. Bayangan lipatan kain lembut
  const fold = ctx.createLinearGradient(0, 0, w, 0);
  fold.addColorStop(0, 'rgba(0,0,0,0.14)');
  fold.addColorStop(0.2, 'rgba(0,0,0,0)');
  fold.addColorStop(0.5, 'rgba(255,255,255,0.06)');
  fold.addColorStop(0.8, 'rgba(0,0,0,0)');
  fold.addColorStop(1, 'rgba(0,0,0,0.14)');
  ctx.fillStyle = fold;
  ctx.fillRect(0, 0, w, h);
}

export function createPixelJerseyTexture(
  teamColor: string,
  accentColor: string,
  style: ClothesStyleId = 'solid',
  trimColor?: string
): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const isRed = teamColor.toLowerCase().includes('dc2626') || teamColor.toLowerCase().includes('ef4444');
  const darkBase = isRed ? '#991b1b' : '#1e3a8a';
  const midBase = isRed ? '#dc2626' : '#2563eb';
  const brightTone = isRed ? '#ef4444' : '#3b82f6';
  const whiteStripe = '#ffffff';
  const secondaryTrim = trimColor && trimColor.length > 0 ? trimColor : isRed ? '#fde047' : '#bae6fd';

  // Crisp Red or Blue base jersey gradient
  const baseGrad = ctx.createLinearGradient(0, 0, 0, size);
  baseGrad.addColorStop(0, brightTone);
  baseGrad.addColorStop(0.55, midBase);
  baseGrad.addColorStop(1, darkBase);
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, size, size);

  if (style === 'solid') {
    // Pure plain solid Red or Blue jersey (subtle tonal shading + fabric weave only)
    ctx.fillStyle = darkBase;
    ctx.fillRect(0, 0, 8, size);
    ctx.fillRect(size - 8, 0, 8, size);
    ctx.fillRect(0, 0, size, 8);
    ctx.fillRect(0, size - 10, size, 10);

    // Subtle breathable micro-hex fabric weave
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    for (let y = 14; y < size - 14; y += 6) {
      for (let x = 14; x < size - 14; x += 6) {
        if ((x + y) % 12 === 0) ctx.fillRect(x, y, 2, 2);
      }
    }

    // Matching tonal V-collar without white stripes
    ctx.fillStyle = darkBase;
    ctx.beginPath();
    ctx.moveTo(46, 0);
    ctx.lineTo(82, 0);
    ctx.lineTo(64, 20);
    ctx.closePath();
    ctx.fill();

    // Garis tebal di tengah badan (di bawah ujung kerah V)
    ctx.fillStyle = darkBase;
    ctx.fillRect(52, 20, 24, size - 30);
    ctx.fillStyle = whiteStripe;
    ctx.fillRect(55, 20, 18, size - 30);
    ctx.fillStyle = secondaryTrim;
    ctx.fillRect(62, 20, 4, size - 30);

    applyJerseyFabric(ctx, size, size);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  }

  if (style === 'stripe_horizontal') {
    // 2 Bold Horizontal White Stripes across chest & abdomen (Red/White or Blue/White)
    ctx.fillStyle = whiteStripe;
    ctx.fillRect(10, 34, size - 20, 17);
    ctx.fillRect(10, 66, size - 20, 17);
    ctx.fillStyle = darkBase;
    ctx.fillRect(10, 32, size - 20, 2);
    ctx.fillRect(10, 51, size - 20, 2);
    ctx.fillRect(10, 64, size - 20, 2);
    ctx.fillRect(10, 83, size - 20, 2);
  } else if (style === 'classic_sash') {
    // Crisp White Diagonal Sash across Red or Blue kit
    ctx.fillStyle = whiteStripe;
    ctx.beginPath();
    ctx.moveTo(0, 82);
    ctx.lineTo(size, 18);
    ctx.lineTo(size, 44);
    ctx.lineTo(0, 108);
    ctx.closePath();
    ctx.fill();
  } else if (style === 'split_hoop') {
    // Wide White Center Band with Team Trim Accent
    ctx.fillStyle = whiteStripe;
    ctx.fillRect(10, 40, size - 20, 38);
    ctx.fillStyle = secondaryTrim;
    ctx.fillRect(10, 36, size - 20, 4);
    ctx.fillRect(10, 78, size - 20, 4);
  } else if (style === 'pro_vneck') {
    // Twin Angled White V-Chevrons
    ctx.fillStyle = whiteStripe;
    ctx.beginPath();
    ctx.moveTo(14, 28);
    ctx.lineTo(64, 62);
    ctx.lineTo(114, 28);
    ctx.lineTo(114, 44);
    ctx.lineTo(64, 78);
    ctx.lineTo(14, 44);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = secondaryTrim;
    ctx.beginPath();
    ctx.moveTo(14, 54);
    ctx.lineTo(64, 88);
    ctx.lineTo(114, 54);
    ctx.lineTo(114, 64);
    ctx.lineTo(64, 98);
    ctx.lineTo(14, 64);
    ctx.closePath();
    ctx.fill();
  } else {
    // 'stripe_vertical': 2 Bold Vertical White Stripes down torso (Red/White or Blue/White)
    ctx.fillStyle = whiteStripe;
    ctx.fillRect(32, 12, 18, size - 26);
    ctx.fillRect(size - 50, 12, 18, size - 26);
    ctx.fillStyle = darkBase;
    ctx.fillRect(30, 12, 2, size - 26);
    ctx.fillRect(50, 12, 2, size - 26);
    ctx.fillRect(size - 52, 12, 2, size - 26);
    ctx.fillRect(size - 32, 12, 2, size - 26);
  }

  // Breathable white & dark athletic side panels
  ctx.fillStyle = darkBase;
  ctx.fillRect(0, 0, 10, size);
  ctx.fillRect(size - 10, 0, 10, size);
  ctx.fillStyle = whiteStripe;
  ctx.fillRect(9, 10, 3, size - 24);
  ctx.fillRect(size - 12, 10, 3, size - 24);

  // Subtle breathable micro-hex fabric weave
  ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
  for (let y = 16; y < size - 16; y += 6) {
    for (let x = 16; x < size - 16; x += 6) {
      if ((x + y) % 12 === 0) ctx.fillRect(x, y, 2, 2);
    }
  }

  // Modern Crisp White Collar & Shoulder Piping
  ctx.fillStyle = accentColor || whiteStripe;
  ctx.fillRect(0, 0, size, 10);
  ctx.fillStyle = secondaryTrim;
  ctx.fillRect(0, 10, size, 3);

  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.moveTo(44, 0);
  ctx.lineTo(84, 0);
  ctx.lineTo(64, 24);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = whiteStripe;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(44, 2);
  ctx.lineTo(64, 24);
  ctx.lineTo(84, 2);
  ctx.stroke();

  // Pro Club Shield Crest on upper chest
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.moveTo(80, 24);
  ctx.lineTo(100, 24);
  ctx.lineTo(100, 38);
  ctx.lineTo(90, 47);
  ctx.lineTo(80, 38);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = whiteStripe;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  ctx.fillStyle = secondaryTrim;
  ctx.beginPath();
  ctx.arc(90, 34, 3.8, 0, Math.PI * 2);
  ctx.fill();

  // Crisp White & Dark Bottom Waistband Trim
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, size - 14, size, 14);
  ctx.fillStyle = whiteStripe;
  ctx.fillRect(0, size - 14, size, 5);
  ctx.fillStyle = secondaryTrim;
  ctx.fillRect(0, size - 5, size, 3);

  applyJerseyFabric(ctx, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

export function createJerseyFaceTextures(
  teamColor: string,
  accentColor: string,
  style: ClothesStyleId = 'solid',
  trimColor?: string
): {
  frontTex: THREE.CanvasTexture;
  backTex: THREE.CanvasTexture;
  sideTex: THREE.CanvasTexture;
  sleeveTex: THREE.CanvasTexture;
} {
  const frontTex = createPixelJerseyTexture(teamColor, accentColor, style, trimColor);

  const isRed = teamColor.toLowerCase().includes('dc2626') || teamColor.toLowerCase().includes('ef4444');
  const darkBase = isRed ? '#991b1b' : '#1e3a8a';
  const midBase = isRed ? '#dc2626' : '#2563eb';
  const brightTone = isRed ? '#ef4444' : '#3b82f6';
  const whiteStripe = '#ffffff';
  const secondaryTrim = trimColor && trimColor.length > 0 ? trimColor : isRed ? '#fde047' : '#bae6fd';
  const size = 128;

  // 1. Back of Jersey: continues stripes cleanly without front V-collar or front club badge
  const backCanvas = document.createElement('canvas');
  backCanvas.width = size;
  backCanvas.height = size;
  const bCtx = backCanvas.getContext('2d')!;
  const backGrad = bCtx.createLinearGradient(0, 0, 0, size);
  backGrad.addColorStop(0, brightTone);
  backGrad.addColorStop(0.55, midBase);
  backGrad.addColorStop(1, darkBase);
  bCtx.fillStyle = backGrad;
  bCtx.fillRect(0, 0, size, size);

  if (style === 'stripe_horizontal') {
    bCtx.fillStyle = whiteStripe;
    bCtx.fillRect(8, 34, size - 16, 17);
    bCtx.fillRect(8, 66, size - 16, 17);
  } else if (style === 'stripe_vertical') {
    bCtx.fillStyle = whiteStripe;
    bCtx.fillRect(32, 12, 18, size - 26);
    bCtx.fillRect(size - 50, 12, 18, size - 26);
  } else if (style === 'classic_sash') {
    bCtx.fillStyle = whiteStripe;
    bCtx.beginPath();
    bCtx.moveTo(0, 18);
    bCtx.lineTo(size, 82);
    bCtx.lineTo(size, 108);
    bCtx.lineTo(0, 44);
    bCtx.closePath();
    bCtx.fill();
  } else if (style === 'split_hoop') {
    bCtx.fillStyle = whiteStripe;
    bCtx.fillRect(8, 40, size - 16, 38);
    bCtx.fillStyle = secondaryTrim;
    bCtx.fillRect(8, 36, size - 16, 4);
    bCtx.fillRect(8, 78, size - 16, 4);
  } else if (style === 'pro_vneck') {
    bCtx.fillStyle = whiteStripe;
    bCtx.fillRect(14, 18, size - 28, 12);
    bCtx.fillStyle = secondaryTrim;
    bCtx.fillRect(14, 30, size - 28, 5);
  }

  // Subtle fabric weave & waistband on back
  bCtx.fillStyle = 'rgba(255, 255, 255, 0.05)';
  for (let y = 14; y < size - 14; y += 6) {
    for (let x = 14; x < size - 14; x += 6) {
      if ((x + y) % 12 === 0) bCtx.fillRect(x, y, 2, 2);
    }
  }
  bCtx.fillStyle = darkBase;
  bCtx.fillRect(0, 0, size, 8);
  bCtx.fillRect(0, size - 12, size, 12);
  if (style !== 'solid') {
    bCtx.fillStyle = whiteStripe;
    bCtx.fillRect(0, size - 12, size, 4);
  }

  if (style === 'solid') {
    bCtx.fillStyle = darkBase;
    bCtx.fillRect(52, 8, 24, size - 20);
    bCtx.fillStyle = whiteStripe;
    bCtx.fillRect(55, 8, 18, size - 20);
    bCtx.fillStyle = secondaryTrim;
    bCtx.fillRect(62, 8, 4, size - 20);
  }
  applyJerseyFabric(bCtx, size, size);
  const backTex = new THREE.CanvasTexture(backCanvas);
  backTex.colorSpace = THREE.SRGBColorSpace;
  backTex.anisotropy = 4;

  // 2. Side Flank & Top/Bottom Fabric: clean uniform breathable team mesh (zero chest graphics!)
  const sideCanvas = document.createElement('canvas');
  sideCanvas.width = 64;
  sideCanvas.height = 64;
  const sCtx = sideCanvas.getContext('2d')!;
  const sGrad = sCtx.createLinearGradient(0, 0, 0, 64);
  sGrad.addColorStop(0, brightTone);
  sGrad.addColorStop(0.55, midBase);
  sGrad.addColorStop(1, darkBase);
  sCtx.fillStyle = sGrad;
  sCtx.fillRect(0, 0, 64, 64);
  sCtx.fillStyle = 'rgba(255,255,255,0.05)';
  for (let y = 4; y < 60; y += 6) {
    for (let x = 4; x < 60; x += 6) {
      if ((x + y) % 12 === 0) sCtx.fillRect(x, y, 2, 2);
    }
  }
  if (style !== 'solid') {
    sCtx.fillStyle = darkBase;
    sCtx.fillRect(24, 0, 16, 64);
    sCtx.fillStyle = whiteStripe;
    sCtx.fillRect(29, 4, 6, 54);
  }
  applyJerseyFabric(sCtx, 64, 64);
  const sideTex = new THREE.CanvasTexture(sideCanvas);
  sideTex.colorSpace = THREE.SRGBColorSpace;
  sideTex.anisotropy = 4;

  // 3. Dedicated Sleeve Texture for Shoulders: clean team sleeve with crisp cuff stripe
  const sleeveCanvas = document.createElement('canvas');
  sleeveCanvas.width = 64;
  sleeveCanvas.height = 64;
  const slCtx = sleeveCanvas.getContext('2d')!;
  const slGrad = slCtx.createLinearGradient(0, 0, 0, 64);
  slGrad.addColorStop(0, brightTone);
  slGrad.addColorStop(0.7, midBase);
  slGrad.addColorStop(1, darkBase);
  slCtx.fillStyle = slGrad;
  slCtx.fillRect(0, 0, 64, 64);
  if (style !== 'solid') {
    slCtx.fillStyle = whiteStripe;
    slCtx.fillRect(0, 50, 64, 8);
    slCtx.fillStyle = secondaryTrim;
    slCtx.fillRect(0, 46, 64, 4);
  } else {
    slCtx.fillStyle = darkBase;
    slCtx.fillRect(0, 52, 64, 12);
  }
  applyJerseyFabric(slCtx, 64, 64);
  const sleeveTex = new THREE.CanvasTexture(sleeveCanvas);
  sleeveTex.colorSpace = THREE.SRGBColorSpace;
  sleeveTex.anisotropy = 4;

  return { frontTex, backTex, sideTex, sleeveTex };
}

export function createSpectatorTexture(variantIndex: number): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, size, size);

  const variants = [
    { fur: '#f8f2e4', ear: '#e2c799', snout: '#d9b589', shirt: '#dc2626', stripe: '#ffffff', type: 'alpaca' },
    { fur: '#e69138', ear: '#c2410c', snout: '#fef3c7', shirt: '#2563eb', stripe: '#facc15', type: 'shiba' },
    { fur: '#f8fafc', ear: '#1e293b', snout: '#e2e8f0', shirt: '#eab308', stripe: '#1e293b', type: 'panda' },
    { fur: '#4ade80', ear: '#16a34a', snout: '#bbf7d0', shirt: '#ec4899', stripe: '#ffffff', type: 'frog' },
  ];
  const v = variants[variantIndex % variants.length];

  // Outline silhouette helper
  const box = (x: number, y: number, w: number, h: number, color: string) => {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
  };

  // Raised cheering animal-human arms!
  box(14, 42, 16, 40, '#0f172a');
  box(18, 46, 8, 32, v.fur);
  box(14, 38, 16, 12, v.fur); // raised paw L

  box(98, 42, 16, 40, '#0f172a');
  box(102, 46, 8, 32, v.fur);
  box(98, 38, 16, 12, v.fur); // raised paw R

  // Humanoid Jersey Torso + Shorts
  box(32, 68, 64, 54, '#0f172a');
  box(36, 72, 56, 36, v.shirt);
  box(36, 84, 56, 10, v.stripe); // Team chest stripe
  box(36, 108, 26, 12, '#1e293b');
  box(66, 108, 26, 12, '#1e293b');

  // Animal Ears / Froggy Eyes on top
  if (v.type === 'alpaca') {
    box(36, 6, 14, 24, '#0f172a');
    box(40, 10, 6, 18, v.ear);
    box(78, 6, 14, 24, '#0f172a');
    box(82, 10, 6, 18, v.ear);
  } else if (v.type === 'shiba') {
    box(34, 10, 18, 18, '#0f172a');
    box(38, 14, 10, 12, v.ear);
    box(76, 10, 18, 18, '#0f172a');
    box(80, 14, 10, 12, v.ear);
  } else if (v.type === 'panda') {
    box(32, 12, 18, 18, '#0f172a');
    box(78, 12, 18, 18, '#0f172a');
  } else {
    box(34, 12, 18, 16, '#0f172a');
    box(38, 16, 10, 8, '#ffffff');
    box(42, 18, 4, 4, '#0f172a');
    box(76, 12, 18, 16, '#0f172a');
    box(80, 16, 10, 8, '#ffffff');
    box(84, 18, 4, 4, '#0f172a');
  }

  // Distinct Pixel Animal Head
  box(32, 24, 64, 48, '#0f172a');
  box(36, 28, 56, 40, v.fur);

  if (v.type === 'panda') {
    box(42, 36, 14, 14, '#0f172a');
    box(72, 36, 14, 14, '#0f172a');
    box(47, 40, 5, 5, '#ffffff');
    box(76, 40, 5, 5, '#ffffff');
  } else if (v.type !== 'frog') {
    box(44, 38, 8, 10, '#ffffff');
    box(47, 40, 5, 6, '#0f172a');
    box(76, 38, 8, 10, '#ffffff');
    box(77, 40, 5, 6, '#0f172a');
  }

  // Cheerful Snout & Open Cheering Mouth
  box(46, 50, 36, 16, v.snout);
  box(60, 50, 8, 5, '#0f172a');
  box(54, 57, 20, 7, '#ef4444'); // open cheer mouth!

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createBrickWallTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Mortar background
  ctx.fillStyle = '#cbd5e1';
  ctx.fillRect(0, 0, size, size);

  const rows = 8;
  const cols = 4;
  const bh = size / rows;
  const bw = size / cols;
  const tones = ['#b45309', '#9a3412', '#c2410c', '#a16207'];

  for (let r = 0; r < rows; r++) {
    const offset = (r % 2) * (bw * 0.5);
    for (let c = -1; c <= cols; c++) {
      const col = tones[(r * 3 + c + 4) % tones.length];
      ctx.fillStyle = col;
      ctx.fillRect(c * bw + offset + 3, r * bh + 3, bw - 6, bh - 6);
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(c * bw + offset + 3, r * bh + 3, bw - 6, 4);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(14, 1);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createSponsorBoardTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 512;
  const h = 64;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const panels = [
    { bg: '#dc2626', text: '#ffffff', label: 'ALPACA CUP', icon: 'trophy' as const },
    { bg: '#facc15', text: '#0f172a', label: 'SPORTS', icon: 'ball' as const },
    { bg: '#2563eb', text: '#ffffff', label: 'STAR PITCH', icon: 'star' as const },
    { bg: '#16a34a', text: '#ffffff', label: 'ALLSTARS', icon: 'ball' as const },
  ];
  const pw = w / panels.length;
  panels.forEach((p, idx) => {
    const x0 = idx * pw;
    ctx.fillStyle = p.bg;
    ctx.fillRect(x0, 0, pw, h);
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 4;
    ctx.strokeRect(x0 + 2, 2, pw - 4, h - 4);

    // Small crisp sport icon emblem on left of each panel
    const icx = x0 + 18;
    const icy = h / 2;
    if (p.icon === 'ball') {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(icx, icy, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(icx - 3, icy - 3, 6, 6);
    } else if (p.icon === 'star') {
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      for (let k = 0; k < 10; k++) {
        const r = k % 2 === 0 ? 11 : 5;
        const a = (k / 10) * Math.PI * 2 - Math.PI / 2;
        if (k === 0) ctx.moveTo(icx + Math.cos(a) * r, icy + Math.sin(a) * r);
        else ctx.lineTo(icx + Math.cos(a) * r, icy + Math.sin(a) * r);
      }
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillStyle = '#fde047';
      ctx.fillRect(icx - 7, icy - 9, 14, 10);
      ctx.fillRect(icx - 3, icy + 1, 6, 6);
      ctx.fillRect(icx - 6, icy + 7, 12, 3);
    }

    ctx.fillStyle = p.text;
    ctx.font = 'bold 16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(p.label, x0 + pw * 0.58, h / 2 + 1);
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.repeat.set(3, 1);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createPuddleTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size * 0.45, size * 0.45, 6, size / 2, size / 2, size * 0.48);
  grad.addColorStop(0, 'rgba(186, 230, 253, 0.78)');
  grad.addColorStop(0.55, 'rgba(56, 189, 248, 0.56)');
  grad.addColorStop(0.85, 'rgba(14, 165, 233, 0.34)');
  grad.addColorStop(1, 'rgba(14, 165, 233, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.ellipse(size * 0.5, size * 0.5, 34, 24, 0.2, 0, Math.PI * 2);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createWoodenCrateTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Base horizontal timber planks
  const plankCount = 5;
  const ph = size / plankCount;
  const plankColors = ['#c98c4b', '#b97837', '#d29755', '#be7d3c', '#c78846'];
  for (let i = 0; i < plankCount; i++) {
    const y0 = i * ph;
    ctx.fillStyle = plankColors[i % plankColors.length];
    ctx.fillRect(0, y0, size, ph);

    // Subtle wood grain streaks
    ctx.fillStyle = 'rgba(92, 51, 23, 0.16)';
    for (let g = 0; g < 6; g++) {
      const gy = y0 + 6 + g * 7;
      ctx.fillRect((i * 37 + g * 19) % 40, gy, size - 24, 2);
    }
    ctx.fillStyle = 'rgba(255, 237, 213, 0.15)';
    ctx.fillRect(0, y0 + 2, size, 3);

    // Dark plank seam
    ctx.fillStyle = '#4a2710';
    ctx.fillRect(0, y0 + ph - 3, size, 3);
  }

  // Diagonal X-brace slats
  const drawDiagonalBrace = (x1: number, y1: number, x2: number, y2: number) => {
    ctx.save();
    ctx.lineCap = 'butt';
    ctx.strokeStyle = '#3b1e0b';
    ctx.lineWidth = 34;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    ctx.strokeStyle = '#9e5e26';
    ctx.lineWidth = 28;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(253, 224, 178, 0.22)';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(x1 - 4, y1 - 4);
    ctx.lineTo(x2 - 4, y2 - 4);
    ctx.stroke();
    ctx.restore();
  };

  drawDiagonalBrace(24, 24, size - 24, size - 24);
  drawDiagonalBrace(size - 24, 24, 24, size - 24);

  // Outer frame beams (border around crate face)
  const fw = 30;
  const drawFrameBeam = (x: number, y: number, w: number, h: number) => {
    ctx.fillStyle = '#a8672c';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = '#3b1e0b';
    ctx.lineWidth = 4;
    ctx.strokeRect(x + 2, y + 2, w - 4, h - 4);
    ctx.fillStyle = 'rgba(255, 237, 213, 0.2)';
    ctx.fillRect(x + 4, y + 4, w - 8, 4);
  };
  drawFrameBeam(0, 0, size, fw);
  drawFrameBeam(0, size - fw, size, fw);
  drawFrameBeam(0, fw, fw, size - fw * 2);
  drawFrameBeam(size - fw, fw, fw, size - fw * 2);

  // Dark iron rivets / nails on corners
  const nailPts = [
    [15, 15],
    [size - 15, 15],
    [15, size - 15],
    [size - 15, size - 15],
    [size / 2, 15],
    [size / 2, size - 15],
    [15, size / 2],
    [size - 15, size / 2],
  ];
  for (const [nx, ny] of nailPts) {
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(nx, ny, 5.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#94a3b8';
    ctx.beginPath();
    ctx.arc(nx - 1.5, ny - 1.5, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}



export type StaffSpriteKind = 'coach_red' | 'coach_blue' | 'guard_bear' | 'guard_wolf';

/**
 * Sprite 2D manusia-hewan berdiri (gaya piksel sama seperti penonton) untuk pelatih & petugas keamanan.
 * Kanvas 128x192, kaki di dasar.
 */
export function createStaffSpriteTexture(kind: StaffSpriteKind): THREE.CanvasTexture {
  const W = 128;
  const H = 192;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, W, H);
  const OUT = '#0f172a';
  const box = (x: number, y: number, w: number, h: number, color: string) => {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
  };
  // kotak berkontur (kontur 4px)
  const obox = (x: number, y: number, w: number, h: number, color: string) => {
    box(x - 4, y - 4, w + 8, h + 8, OUT);
    box(x, y, w, h, color);
  };

  const cfg = {
    coach_red: { fur: '#e69138', ear: '#c2410c', snout: '#fef3c7', top: '#dc2626', trim: '#ffffff', pants: '#7f1d1d', ears: 'point', cap: '#7f1d1d' },
    coach_blue: { fur: '#f8fafc', ear: '#1e293b', snout: '#e2e8f0', top: '#2563eb', trim: '#facc15', pants: '#1e3a8a', ears: 'round', cap: '#1e3a8a' },
    guard_bear: { fur: '#8b5a2b', ear: '#5b3a1a', snout: '#d9b589', top: '#1f2937', trim: '#facc15', pants: '#0b0f14', ears: 'round', cap: '#0b0f14' },
    guard_wolf: { fur: '#9ca3af', ear: '#4b5563', snout: '#e5e7eb', top: '#1f2937', trim: '#facc15', pants: '#0b0f14', ears: 'point', cap: '#0b0f14' },
  }[kind];
  const isGuard = kind.startsWith('guard');

  // kaki + sepatu
  obox(40, 150, 18, 30, cfg.pants);
  obox(70, 150, 18, 30, cfg.pants);
  box(36, 176, 26, 10, '#111827');
  box(66, 176, 26, 10, '#111827');

  // badan
  obox(34, 92, 60, 62, cfg.top);
  if (isGuard) {
    // rompi kuning + garis reflektif
    box(38, 96, 14, 54, cfg.trim);
    box(76, 96, 14, 54, cfg.trim);
    box(38, 120, 52, 8, '#e5e7eb');
  } else {
    // jaket pelatih: garis tengah + strip lengan
    box(60, 96, 8, 54, cfg.trim);
    box(38, 96, 52, 6, cfg.trim);
  }

  // lengan
  if (isGuard) {
    // bersedekap
    obox(18, 98, 24, 20, cfg.fur);
    obox(86, 98, 24, 20, cfg.fur);
    box(40, 104, 48, 14, '#0f172a');
    box(42, 106, 44, 10, cfg.top);
  } else {
    obox(14, 98, 18, 44, cfg.top);
    obox(96, 98, 18, 44, cfg.top);
    box(14, 138, 18, 10, cfg.fur);
    box(96, 138, 18, 10, cfg.fur);
    // papan catatan
    box(100, 128, 22, 26, OUT);
    box(103, 131, 16, 20, '#f8fafc');
    box(105, 136, 12, 2, '#64748b');
    box(105, 141, 12, 2, '#64748b');
  }

  // telinga
  if (cfg.ears === 'point') {
    obox(34, 14, 16, 26, cfg.fur);
    box(40, 20, 6, 16, cfg.ear);
    obox(78, 14, 16, 26, cfg.fur);
    box(82, 20, 6, 16, cfg.ear);
  } else {
    obox(32, 18, 20, 20, cfg.ear);
    obox(76, 18, 20, 20, cfg.ear);
  }

  // kepala
  obox(34, 30, 60, 56, cfg.fur);
  // topi (security & pelatih)
  obox(30, 22, 68, 16, cfg.cap);
  box(34, 38, 60, 6, cfg.cap);
  box(66, 36, 38, 8, cfg.cap); // lidah topi
  if (isGuard) {
    // kacamata hitam
    box(40, 52, 48, 12, OUT);
    box(44, 54, 16, 8, '#334155');
    box(68, 54, 16, 8, '#334155');
    box(46, 55, 5, 2, '#94a3b8');
    box(70, 55, 5, 2, '#94a3b8');
  } else {
    box(44, 50, 10, 12, '#ffffff');
    box(48, 53, 6, 8, OUT);
    box(76, 50, 10, 12, '#ffffff');
    box(80, 53, 6, 8, OUT);
  }
  // moncong
  obox(46, 66, 36, 16, cfg.snout);
  box(60, 66, 8, 5, OUT);
  if (isGuard) {
    box(54, 76, 20, 3, OUT); // mulut datar, serius
  } else {
    box(52, 74, 24, 8, '#ef4444'); // berteriak semangat
    box(56, 74, 16, 3, '#ffffff');
    // peluit
    box(86, 84, 8, 8, '#e5e7eb');
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export type FantasyCapeStyle =
  | 'starry'
  | 'arcane'
  | 'dragonscale'
  | 'galaxy'
  | 'phoenixcape'
  | 'frost'
  | 'vine'
  | 'royalmage'
  | 'raggedcape'
  | 'shadow';

/**
 * Tekstur jubah fantasi bergaya lukisan (kanvas 256x320, latar transparan).
 * Bentuk jubah (trapesium + ujung bawah khas tiap jubah) dipotong lewat clip, sehingga
 * tepi jubah robek/bergelombang/berapi terbentuk langsung dari alpha tekstur.
 */
export function createFantasyCapeTexture(style: FantasyCapeStyle, c1: string, c2: string): THREE.CanvasTexture {
  const W = 256;
  const H = 320;
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const g = cv.getContext('2d')!;
  g.clearRect(0, 0, W, H);

  let seed = style.length * 7919 + 17;
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };

  // --- Siluet: atas sempit, bawah lebar, ujung bawah tergantung gaya ---
  const topL = 52;
  const topR = W - 52;
  const botL = 6;
  const botR = W - 6;
  const hemY = H - 10;
  const silhouette = () => {
    g.beginPath();
    g.moveTo(topL, 4);
    g.lineTo(topR, 4);
    g.lineTo(botR, hemY - 26);
    // sisi kanan -> hem (kanan ke kiri)
    const steps = 14;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = botR + (botL - botR) * t;
      let y = hemY;
      if (style === 'phoenixcape') {
        // lidah api
        y = hemY + (i % 2 === 0 ? 8 : -34 - rnd() * 14);
      } else if (style === 'raggedcape') {
        y = hemY - 6 - rnd() * 36 + (i % 3 === 0 ? 14 : 0);
      } else if (style === 'vine') {
        y = hemY - (i % 2 === 0 ? 4 : 22) - rnd() * 8;
      } else if (style === 'shadow') {
        y = hemY - (i % 2 === 0 ? 0 : 30) - rnd() * 14;
      } else if (style === 'dragonscale' || style === 'frost') {
        y = hemY - (i % 2 === 0 ? 0 : 16);
      } else {
        y = hemY + Math.sin(t * Math.PI * 4) * 6;
      }
      g.lineTo(x, y);
    }
    g.lineTo(botL, hemY - 26);
    g.closePath();
  };

  g.save();
  silhouette();
  g.clip();

  // --- Warna dasar & gradien ---
  const base = g.createLinearGradient(0, 0, 0, H);
  const paint = (stops: Array<[number, string]>) => {
    stops.forEach(([o, c]) => base.addColorStop(o, c));
    g.fillStyle = base;
    g.fillRect(0, 0, W, H);
  };
  const star = (x: number, y: number, r: number, color: string) => {
    g.fillStyle = color;
    g.beginPath();
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2;
      const rr = k % 2 === 0 ? r : r * 0.35;
      g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    g.closePath();
    g.fill();
  };
  const glow = (x: number, y: number, r: number, color: string, alpha = 0.55) => {
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, color);
    gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.globalAlpha = alpha;
    g.fillStyle = gr;
    g.fillRect(x - r, y - r, r * 2, r * 2);
    g.globalAlpha = 1;
  };

  if (style === 'starry') {
    paint([[0, '#0b1033'], [0.5, c1], [1, '#312e81']]);
    for (let i = 0; i < 70; i++) star(rnd() * W, rnd() * H, 1 + rnd() * 2.2, rnd() < 0.5 ? '#fff7c2' : '#ffffff');
    for (let i = 0; i < 6; i++) star(20 + rnd() * 216, 40 + rnd() * 240, 5 + rnd() * 4, c2);
    // bulan sabit (digambar di kanvas terpisah agar tidak melubangi kain)
    const moon = document.createElement('canvas');
    moon.width = 100;
    moon.height = 100;
    const mg = moon.getContext('2d')!;
    mg.fillStyle = c2;
    mg.beginPath();
    mg.arc(50, 50, 34, 0, Math.PI * 2);
    mg.fill();
    mg.globalCompositeOperation = 'destination-out';
    mg.beginPath();
    mg.arc(64, 42, 30, 0, Math.PI * 2);
    mg.fill();
    g.drawImage(moon, 78, 80);
    glow(128, 130, 70, '#fde68a', 0.25);
  } else if (style === 'arcane') {
    paint([[0, '#1e1048'], [0.6, c1], [1, '#4c1d95']]);
    glow(128, 170, 120, c2, 0.28);
    g.strokeStyle = c2;
    g.lineWidth = 3;
    for (const rr of [70, 54]) {
      g.beginPath();
      g.arc(128, 170, rr, 0, Math.PI * 2);
      g.stroke();
    }
    g.lineWidth = 2;
    // bintang segi lima
    g.beginPath();
    for (let k = 0; k < 6; k++) {
      const a = -Math.PI / 2 + ((k * 2) % 5) * ((Math.PI * 2) / 5);
      const x = 128 + Math.cos(a) * 54;
      const y = 170 + Math.sin(a) * 54;
      if (k === 0) g.moveTo(x, y);
      else g.lineTo(x, y);
    }
    g.stroke();
    // rune di sekeliling
    g.fillStyle = c2;
    for (let k = 0; k < 12; k++) {
      const a = (k / 12) * Math.PI * 2;
      const x = 128 + Math.cos(a) * 62;
      const y = 170 + Math.sin(a) * 62;
      g.save();
      g.translate(x, y);
      g.rotate(a + Math.PI / 2);
      g.fillRect(-1.5, -6, 3, 12);
      g.fillRect(-5, -2, 10, 3);
      if (k % 3 === 0) g.fillRect(-4, 3, 8, 2);
      g.restore();
    }
    for (let i = 0; i < 26; i++) star(rnd() * W, rnd() * H, 1 + rnd() * 1.6, '#e9d5ff');
  } else if (style === 'dragonscale') {
    paint([[0, c1], [1, '#450a0a']]);
    const sw = 26;
    const sh = 22;
    for (let row = 0; row < H / sh + 1; row++) {
      for (let col = -1; col < W / sw + 1; col++) {
        const x = col * sw + (row % 2) * (sw / 2);
        const y = row * sh;
        const grd = g.createRadialGradient(x, y + 6, 2, x, y + 8, sw * 0.8);
        grd.addColorStop(0, c1);
        grd.addColorStop(1, '#3f0a0a');
        g.fillStyle = grd;
        g.beginPath();
        g.moveTo(x - sw / 2, y);
        g.quadraticCurveTo(x - sw / 2, y + sh * 1.15, x, y + sh * 1.2);
        g.quadraticCurveTo(x + sw / 2, y + sh * 1.15, x + sw / 2, y);
        g.closePath();
        g.fill();
        g.strokeStyle = 'rgba(253,224,71,0.55)';
        g.lineWidth = 1.5;
        g.stroke();
        g.strokeStyle = 'rgba(255,255,255,0.18)';
        g.beginPath();
        g.moveTo(x - sw * 0.28, y + 4);
        g.quadraticCurveTo(x, y + sh * 0.7, x + sw * 0.1, y + 5);
        g.stroke();
      }
    }
  } else if (style === 'galaxy') {
    paint([[0, '#05010f'], [1, '#12043a']]);
    const cols = [c1, c2, '#22d3ee', '#a855f7'];
    for (let i = 0; i < 9; i++) glow(rnd() * W, rnd() * H, 70 + rnd() * 70, cols[i % cols.length], 0.4);
    for (let i = 0; i < 160; i++) {
      g.fillStyle = `rgba(255,255,255,${0.4 + rnd() * 0.6})`;
      const s = rnd() < 0.1 ? 2.4 : 1.1;
      g.fillRect(rnd() * W, rnd() * H, s, s);
    }
    for (let i = 0; i < 5; i++) star(rnd() * W, rnd() * H, 5 + rnd() * 5, '#ffffff');
  } else if (style === 'phoenixcape') {
    paint([[0, '#7f1d1d'], [0.35, c1], [0.75, '#facc15'], [1, '#fff7ae']]);
    // plume bulu api
    g.lineCap = 'round';
    for (let i = 0; i < 18; i++) {
      const x = 14 + (i / 17) * (W - 28);
      g.strokeStyle = i % 2 ? 'rgba(254,240,138,0.55)' : 'rgba(234,88,12,0.5)';
      g.lineWidth = 7 + rnd() * 5;
      g.beginPath();
      g.moveTo(128 + (x - 128) * 0.35, 20);
      g.quadraticCurveTo(x + (rnd() - 0.5) * 30, H * 0.55, x + (rnd() - 0.5) * 24, H - 24);
      g.stroke();
    }
    glow(128, 120, 90, '#fde047', 0.35);
  } else if (style === 'frost') {
    paint([[0, '#e0f2fe'], [0.5, c1], [1, '#1d4ed8']]);
    glow(128, 90, 100, '#ffffff', 0.45);
    g.strokeStyle = 'rgba(255,255,255,0.85)';
    g.lineWidth = 2;
    const flake = (x: number, y: number, r: number) => {
      for (let k = 0; k < 6; k++) {
        const a = (k / 6) * Math.PI * 2;
        g.beginPath();
        g.moveTo(x, y);
        g.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
        g.moveTo(x + Math.cos(a) * r * 0.6, y + Math.sin(a) * r * 0.6);
        g.lineTo(x + Math.cos(a + 0.5) * r * 0.85, y + Math.sin(a + 0.5) * r * 0.85);
        g.moveTo(x + Math.cos(a) * r * 0.6, y + Math.sin(a) * r * 0.6);
        g.lineTo(x + Math.cos(a - 0.5) * r * 0.85, y + Math.sin(a - 0.5) * r * 0.85);
        g.stroke();
      }
    };
    flake(128, 160, 34);
    for (let i = 0; i < 8; i++) flake(20 + rnd() * 216, 60 + rnd() * 230, 7 + rnd() * 9);
    // kristal es di tepi bawah
    g.fillStyle = 'rgba(255,255,255,0.7)';
    for (let i = 0; i < 12; i++) {
      const x = 12 + i * 20;
      g.beginPath();
      g.moveTo(x, hemY - 20);
      g.lineTo(x + 8, hemY - 20);
      g.lineTo(x + 4, hemY + 2);
      g.closePath();
      g.fill();
    }
  } else if (style === 'vine') {
    paint([[0, '#14532d'], [0.6, c1], [1, '#365314']]);
    g.lineCap = 'round';
    for (let v = 0; v < 6; v++) {
      let x = 40 + v * 34;
      g.strokeStyle = 'rgba(190,242,100,0.75)';
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(x, 10);
      for (let y = 10; y < H; y += 20) {
        x += Math.sin(y * 0.05 + v) * 7;
        g.lineTo(x, y);
        if (y % 40 === 10) {
          g.save();
          g.fillStyle = v % 2 ? c2 : '#86efac';
          g.translate(x, y);
          g.rotate(v % 2 ? 0.8 : -0.8);
          g.beginPath();
          g.ellipse(9, 0, 10, 4.5, 0, 0, Math.PI * 2);
          g.fill();
          g.restore();
        }
      }
      g.stroke();
    }
    for (let i = 0; i < 7; i++) {
      const x = 30 + rnd() * 196;
      const y = 40 + rnd() * 240;
      g.fillStyle = '#fde68a';
      g.beginPath();
      g.arc(x, y, 4.5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#f472b6';
      g.beginPath();
      g.arc(x, y, 2.2, 0, Math.PI * 2);
      g.fill();
    }
  } else if (style === 'royalmage') {
    paint([[0, '#7f1d1d'], [0.55, c1], [1, '#450a0a']]);
    // beludru: garis halus
    g.strokeStyle = 'rgba(0,0,0,0.12)';
    for (let x = 0; x < W; x += 5) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x + 20, H);
      g.stroke();
    }
    // sulaman emas: bingkai + motif
    g.strokeStyle = c2;
    g.lineWidth = 4;
    g.beginPath();
    g.moveTo(topL + 12, 22);
    g.lineTo(topR - 12, 22);
    g.lineTo(botR - 18, hemY - 40);
    g.lineTo(botL + 18, hemY - 40);
    g.closePath();
    g.stroke();
    g.lineWidth = 2;
    for (let k = 0; k < 4; k++) {
      const y = 70 + k * 52;
      g.beginPath();
      g.arc(128, y, 16, 0, Math.PI * 2);
      g.stroke();
      star(128, y, 9, c2);
      for (const sx of [-1, 1]) {
        g.beginPath();
        g.moveTo(128 + sx * 20, y);
        g.quadraticCurveTo(128 + sx * 50, y - 16, 128 + sx * 70, y);
        g.stroke();
      }
    }
    // bulu ermine di atas
    g.fillStyle = '#fafafa';
    g.fillRect(0, 0, W, 34);
    g.fillStyle = '#111827';
    for (let i = 0; i < 9; i++) {
      g.beginPath();
      g.ellipse(18 + i * 28, 18 + (i % 2) * 6, 2.6, 6, 0, 0, Math.PI * 2);
      g.fill();
    }
  } else if (style === 'raggedcape') {
    paint([[0, '#57534e'], [0.6, c1], [1, '#292524']]);
    // serat kain & noda
    for (let i = 0; i < 260; i++) {
      g.fillStyle = `rgba(${rnd() < 0.5 ? '0,0,0' : '255,255,255'},${0.03 + rnd() * 0.07})`;
      g.fillRect(rnd() * W, rnd() * H, 1 + rnd() * 2, 6 + rnd() * 24);
    }
    // tambalan berjahit
    const patch = (x: number, y: number, w: number, h: number, col: string) => {
      g.fillStyle = col;
      g.fillRect(x, y, w, h);
      g.strokeStyle = '#1c1917';
      g.setLineDash([4, 3]);
      g.lineWidth = 1.6;
      g.strokeRect(x + 3, y + 3, w - 6, h - 6);
      g.setLineDash([]);
    };
    patch(70, 90, 50, 42, c2);
    patch(150, 170, 44, 54, '#78716c');
    patch(60, 220, 40, 36, '#a16207');
    // lubang-lubang robek (transparan)
    g.globalCompositeOperation = 'destination-out';
    for (const [x, y, rx, ry] of [[170, 80, 14, 9], [100, 180, 10, 14], [200, 250, 16, 10], [46, 140, 9, 12]] as Array<[number, number, number, number]>) {
      g.beginPath();
      g.ellipse(x, y, rx, ry, rnd(), 0, Math.PI * 2);
      g.fill();
    }
    g.globalCompositeOperation = 'source-over';
  } else {
    // shadow
    paint([[0, '#020617'], [0.6, c1], [1, '#042f2e']]);
    for (let i = 0; i < 9; i++) {
      const x = 20 + rnd() * 216;
      g.strokeStyle = `rgba(45,212,191,${0.18 + rnd() * 0.25})`;
      g.lineWidth = 6 + rnd() * 8;
      g.lineCap = 'round';
      g.beginPath();
      g.moveTo(x, 10);
      g.bezierCurveTo(x + 40, 90, x - 40, 190, x + (rnd() - 0.5) * 60, H - 20);
      g.stroke();
    }
    glow(128, 110, 80, c2, 0.35);
    // mata menyala
    for (const ex of [108, 148]) {
      g.fillStyle = '#5eead4';
      g.beginPath();
      g.ellipse(ex, 118, 10, 5, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#ccfbf1';
      g.beginPath();
      g.ellipse(ex, 118, 4, 2.4, 0, 0, Math.PI * 2);
      g.fill();
    }
  }

  // Bayangan lipatan vertikal (membuat kain terasa bergelombang)
  const folds = g.createLinearGradient(0, 0, W, 0);
  for (let i = 0; i <= 8; i++) folds.addColorStop(i / 8, i % 2 === 0 ? 'rgba(0,0,0,0.18)' : 'rgba(255,255,255,0.07)');
  g.fillStyle = folds;
  g.fillRect(0, 0, W, H);
  // Gelap di dekat bahu
  const shade = g.createLinearGradient(0, 0, 0, 90);
  shade.addColorStop(0, 'rgba(0,0,0,0.35)');
  shade.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = shade;
  g.fillRect(0, 0, W, 90);
  g.restore();

  // Garis tepi jubah (tidak untuk yang berapi/robek agar tetap lembut)
  g.save();
  silhouette();
  g.lineJoin = 'round';
  g.lineWidth = style === 'raggedcape' || style === 'shadow' ? 2 : 5;
  g.strokeStyle = style === 'royalmage' || style === 'dragonscale' || style === 'starry' ? c2 : 'rgba(15,23,42,0.85)';
  if (style !== 'phoenixcape') g.stroke();
  g.restore();

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/**
 * Permukaan lapangan yang HANYA menutupi area di dalam garis putih (tidak masuk ke gawang/luar garis).
 * Corak simetris kiri-kanan. `wood` = lantai kayu futsal (papan memanjang) seperti desain referensi.
 */
export function createPitchSurfaceTexture(
  arena: ArenaSpec,
  maxAnisotropy: number,
  pattern: 'stripes' | 'checker' | 'diamond' | 'rings',
  wood: boolean
): THREE.CanvasTexture {
  const W = 1024;
  const H = 680; // rasio mendekati lapangan 22.4 : 14.8
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;
  let seed = 90210;
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };

  if (wood) {
    const rows = 22;
    const rh = H / rows;
    const base = arena.grassA;
    for (let r = 0; r < rows; r++) {
      let x = -rnd() * 200;
      while (x < W) {
        const len = 180 + rnd() * 260;
        const tone = (rnd() - 0.5) * 0.18;
        ctx.fillStyle = base;
        ctx.fillRect(x, r * rh, len, rh);
        ctx.fillStyle = tone > 0 ? `rgba(255,235,190,${tone})` : `rgba(60,25,0,${-tone})`;
        ctx.fillRect(x, r * rh, len, rh);
        // serat kayu
        ctx.strokeStyle = 'rgba(80,40,10,0.18)';
        ctx.lineWidth = 1;
        for (let g = 0; g < 3; g++) {
          const gy = r * rh + rh * (0.2 + rnd() * 0.6);
          ctx.beginPath();
          ctx.moveTo(x, gy);
          ctx.lineTo(x + len, gy + (rnd() - 0.5) * 3);
          ctx.stroke();
        }
        // sambungan papan
        ctx.fillStyle = 'rgba(60,30,5,0.45)';
        ctx.fillRect(x, r * rh, 2, rh);
        x += len;
      }
      ctx.fillStyle = 'rgba(50,25,5,0.5)';
      ctx.fillRect(0, r * rh, W, 2);
    }
    // kilau lampu halus
    const sheen = ctx.createLinearGradient(0, 0, W, 0);
    sheen.addColorStop(0, 'rgba(255,255,255,0)');
    sheen.addColorStop(0.5, 'rgba(255,240,200,0.12)');
    sheen.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sheen;
    ctx.fillRect(0, 0, W, H);
  } else {
    const A = arena.grassA;
    const B = arena.grassB;
    ctx.fillStyle = A;
    ctx.fillRect(0, 0, W, H);
    if (pattern === 'rings') {
      // Lingkaran konsentris dari titik tengah lapangan (seperti desain referensi)
      const step = 62;
      const maxR = Math.hypot(W / 2, H / 2) + step;
      for (let i = Math.ceil(maxR / step); i >= 1; i--) {
        ctx.fillStyle = i % 2 === 0 ? A : B;
        ctx.beginPath();
        ctx.arc(W / 2, H / 2, i * step, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (pattern === 'checker') {
      const nx = 13; // ganjil => simetris
      const ny = 9;
      const cw = W / nx;
      const ch = H / ny;
      for (let y = 0; y < ny; y++)
        for (let x = 0; x < nx; x++) {
          ctx.fillStyle = (x + y) % 2 === 0 ? A : B;
          ctx.fillRect(x * cw, y * ch, cw + 1, ch + 1);
        }
    } else if (pattern === 'diamond') {
      ctx.fillStyle = B;
      const d = 128;
      for (let cy = H / 2 - d * 4; cy < H + d; cy += d) {
        for (let cx = W / 2 - d * 8; cx < W + d; cx += d) {
          ctx.beginPath();
          ctx.moveTo(cx, cy - d / 2);
          ctx.lineTo(cx + d / 2, cy);
          ctx.lineTo(cx, cy + d / 2);
          ctx.lineTo(cx - d / 2, cy);
          ctx.closePath();
          ctx.fill();
        }
      }
    } else {
      const n = 11; // ganjil => simetris kiri-kanan
      const sw = W / n;
      for (let i = 0; i < n; i++) {
        ctx.fillStyle = i % 2 === 0 ? A : B;
        ctx.fillRect(i * sw, 0, sw + 1, H);
      }
    }
    // tekstur rumput halus
    for (let i = 0; i < 9000; i++) {
      ctx.fillStyle = rnd() > 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.07)';
      ctx.fillRect(rnd() * W, rnd() * H, 2, 4);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}
