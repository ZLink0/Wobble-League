/**
 * Ragdoll fisik sungguhan untuk karakter BOLA GILA.
 *
 * Rangka berupa 12 partikel (position-based dynamics) yang dihubungkan constraint jarak:
 * badan kaku (6 partikel), leher 2 ruas, 2 lengan, 2 kaki. Setiap partikel kena gravitasi,
 * tumbukan lantai (pantulan + gesekan), dinding lapangan, dan saling tolak antar anggota badan.
 *
 * Modul ini murni matematika (tanpa three.js) supaya bisa dites di Node.
 */

export const RAGDOLL_PARTICLE_COUNT = 13;

export const RD = {
  HIP_L: 0,
  HIP_R: 1,
  SH_L: 2,
  SH_R: 3,
  BELLY: 4,
  NECK_BASE: 5,
  NECK_MID: 6,
  HEAD: 7,
  HAND_L: 8,
  HAND_R: 9,
  FOOT_L: 10,
  FOOT_R: 11,
  BACK: 12,
} as const;

const TORSO_IDX = [0, 1, 2, 3, 4, 5, 12];
const IS_TORSO: boolean[] = Array.from({ length: 13 }, (_, i) => TORSO_IDX.includes(i));

/** Posisi istirahat tiap partikel di ruang badan (x kiri+, y atas, z depan) – cocok dengan rig di models.ts */
export const RAGDOLL_REST: ReadonlyArray<readonly [number, number, number]> = [
  [0.15, 0.38, 0], // HIP_L
  [-0.15, 0.38, 0], // HIP_R
  [0.36, 0.86, 0], // SH_L
  [-0.36, 0.86, 0], // SH_R
  [0, 0.68, 0.21], // BELLY (permukaan depan badan)
  [0, 0.96, 0], // NECK_BASE
  [0, 1.14, 0], // NECK_MID
  [0, 1.32, 0], // HEAD
  [0.36, 0.5, 0], // HAND_L (menggantung)
  [-0.36, 0.5, 0], // HAND_R
  [0.15, 0.04, 0], // FOOT_L
  [-0.15, 0.04, 0], // FOOT_R
  [0, 0.68, -0.21], // BACK (permukaan belakang badan)
];

/** Radius tumbukan lantai tiap partikel */
const RADIUS: ReadonlyArray<number> = [0.21, 0.21, 0.21, 0.21, 0.0, 0.17, 0.1, 0.27, 0.07, 0.07, 0.07, 0.07, 0.0];
/** Gesekan lantai tiap partikel (kaki/tangan lebih licin dari badan) */
const FRICTION: ReadonlyArray<number> = [6.5, 6.5, 6.0, 6.0, 6.5, 5, 5, 5.5, 5.0, 5.0, 4.5, 4.5, 6.5];

export interface RagdollBounds {
  halfX: number;
  halfZ: number;
  goalHalfZ: number;
}

export interface RagdollState {
  /** x,y,z berurutan per partikel (panjang 36) */
  pos: number[];
  vel: number[];
  /** constraint jarak [a, b, panjangIstirahat, rope] – rope=1 hanya menahan saat meregang (sendi teleskopik karet) */
  links: Array<[number, number, number, number]>;
  /** jarak minimum [a, b, min] – mencegah anggota badan menembus */
  mins: Array<[number, number, number]>;
  age: number;
  /** jumlah tumbukan lantai keras sejak mulai (untuk SFX/efek) */
  thumps: number;
  /** posisi terakhir yang disinkronkan ke PlayerSim (x,z) – untuk mendeteksi pergeseran dari luar */
  lastX: number;
  lastZ: number;
  /** true setelah arah bangun (facing) dihitung – terjadi sekali saat fase bangun dimulai */
  getUpFacingSet: boolean;
}

function dist3(p: number[], a: number, b: number): number {
  const dx = p[a * 3] - p[b * 3];
  const dy = p[a * 3 + 1] - p[b * 3 + 1];
  const dz = p[a * 3 + 2] - p[b * 3 + 2];
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function buildLinks(): { links: RagdollState['links']; mins: RagdollState['mins'] } {
  const links: RagdollState['links'] = [];
  const rest = (a: number, b: number): number => {
    const ra = RAGDOLL_REST[a];
    const rb = RAGDOLL_REST[b];
    return Math.hypot(ra[0] - rb[0], ra[1] - rb[1], ra[2] - rb[2]);
  };
  // Badan kaku: semua pasangan di antara 6 partikel torso
  const torso = TORSO_IDX;
  for (let i = 0; i < torso.length; i++) {
    for (let j = i + 1; j < torso.length; j++) {
      links.push([torso[i], torso[j], rest(torso[i], torso[j]), 0]);
    }
  }
  // Leher 2 ruas + kepala
  links.push([RD.NECK_BASE, RD.NECK_MID, rest(RD.NECK_BASE, RD.NECK_MID), 1]);
  links.push([RD.NECK_MID, RD.HEAD, rest(RD.NECK_MID, RD.HEAD), 1]);
  // Lengan & kaki (sendi bahu / pinggul) – karet: bisa memendek tapi tidak memanjang
  links.push([RD.SH_L, RD.HAND_L, rest(RD.SH_L, RD.HAND_L), 1]);
  links.push([RD.SH_R, RD.HAND_R, rest(RD.SH_R, RD.HAND_R), 1]);
  links.push([RD.HIP_L, RD.FOOT_L, rest(RD.HIP_L, RD.FOOT_L), 1]);
  links.push([RD.HIP_R, RD.FOOT_R, rest(RD.HIP_R, RD.FOOT_R), 1]);

  const mins: RagdollState['mins'] = [
    // leher tidak boleh dilipat total
    [RD.NECK_BASE, RD.HEAD, 0.22],
    // lengan & kaki memendek banyak (rubber squash) tapi tidak sampai nol
    [RD.SH_L, RD.HAND_L, 0.1],
    [RD.SH_R, RD.HAND_R, 0.1],
    [RD.HIP_L, RD.FOOT_L, 0.1],
    [RD.HIP_R, RD.FOOT_R, 0.1],
    // kepala tidak menembus bahu
    [RD.HEAD, RD.SH_L, 0.3],
    [RD.HEAD, RD.SH_R, 0.3],
    // kaki & tangan tidak menembus badan
    [RD.FOOT_L, RD.BELLY, 0.2],
    [RD.FOOT_R, RD.BELLY, 0.2],
    [RD.FOOT_L, RD.BACK, 0.2],
    [RD.FOOT_R, RD.BACK, 0.2],
    [RD.HAND_L, RD.BACK, 0.2],
    [RD.HAND_R, RD.BACK, 0.2],
    [RD.FOOT_L, RD.HIP_R, 0.17],
    [RD.FOOT_R, RD.HIP_L, 0.17],
    [RD.HAND_L, RD.BELLY, 0.2],
    [RD.HAND_R, RD.BELLY, 0.2],
    [RD.HAND_L, RD.HIP_L, 0.16],
    [RD.HAND_R, RD.HIP_R, 0.16],
    // antar anggota badan
    [RD.FOOT_L, RD.FOOT_R, 0.15],
    [RD.HAND_L, RD.HAND_R, 0.12],
    [RD.HAND_L, RD.HEAD, 0.28],
    [RD.HAND_R, RD.HEAD, 0.28],
  ];
  return { links, mins };
}

const LINK_CACHE = buildLinks();

/** Bangun ragdoll dari pose berdiri pada posisi/hadap karakter, lalu beri dorongan awal. */
export function createRagdoll(
  x: number,
  y: number,
  z: number,
  facing: number,
  knockVx: number,
  knockVy: number,
  knockVz: number,
  rand: () => number = Math.random
): RagdollState {
  const pos: number[] = [];
  const vel: number[] = [];
  const s = Math.sin(facing);
  const c = Math.cos(facing);

  const knockLen = Math.hypot(knockVx, knockVz);
  for (let i = 0; i < RAGDOLL_PARTICLE_COUNT; i++) {
    const [lx, ly, lz] = RAGDOLL_REST[i];
    // rotasi Y: x' = x cos + z sin ; z' = -x sin + z cos
    pos.push(x + lx * c + lz * s, y + ly, z - lx * s + lz * c);

    // Bagian atas terdorong lebih jauh daripada kaki yang menapak -> badan terjungkal alami
    const h = ly / 1.32; // 0 (kaki) .. 1 (kepala)
    const horizontalGain = 0.55 + 0.75 * h;
    const upGain = 0.7 + 0.5 * h;
    const jitter = i >= RD.HAND_L && i <= RD.HAND_R ? 1.6 : 0.5;
    vel.push(
      knockVx * horizontalGain + (rand() - 0.5) * jitter + (knockLen > 0 ? 0 : 0),
      knockVy * upGain + rand() * 0.4,
      knockVz * horizontalGain + (rand() - 0.5) * jitter
    );
  }

  return {
    pos,
    vel,
    links: LINK_CACHE.links,
    mins: LINK_CACHE.mins,
    age: 0,
    thumps: 0,
    lastX: x,
    lastZ: z,
    getUpFacingSet: false,
  };
}

/** Tambah impuls (m/s) ke seluruh partikel; bobot lebih besar ke partikel tinggi bila `topHeavy`. */
export function addRagdollImpulse(rd: RagdollState, ix: number, iy: number, iz: number, topHeavy = true) {
  for (let i = 0; i < RAGDOLL_PARTICLE_COUNT; i++) {
    const g = topHeavy ? 0.6 + 0.5 * (RAGDOLL_REST[i][1] / 1.32) : 1;
    rd.vel[i * 3] += ix * g;
    rd.vel[i * 3 + 1] += iy * g;
    rd.vel[i * 3 + 2] += iz * g;
  }
}

/** Geser seluruh ragdoll (mis. akibat separasi antar pemain di luar ragdoll). */
export function shiftRagdoll(rd: RagdollState, dx: number, dz: number) {
  if (dx === 0 && dz === 0) return;
  for (let i = 0; i < RAGDOLL_PARTICLE_COUNT; i++) {
    rd.pos[i * 3] += dx;
    rd.pos[i * 3 + 2] += dz;
  }
}

export interface RagdollStepOptions {
  gravity: number;
  bounds: RagdollBounds;
}

const SUBSTEP = 1 / 120;
const ITERATIONS = 5;

/** Satu langkah fisika (dibagi menjadi substep tetap 1/120 detik agar stabil). */
export function stepRagdoll(rd: RagdollState, dt: number, opts: RagdollStepOptions): void {
  const steps = Math.max(1, Math.min(8, Math.ceil(dt / SUBSTEP)));
  const h = dt / steps;
  for (let s = 0; s < steps; s++) substep(rd, h, opts);
  rd.age += dt;
}

function substep(rd: RagdollState, h: number, opts: RagdollStepOptions) {
  const { pos, vel } = rd;
  const n = RAGDOLL_PARTICLE_COUNT;
  const pred: number[] = new Array(n * 3);
  const preVy: number[] = new Array(n);

  // Pusat massa torso untuk redaman relatif (sendi "berat" agar tidak jitter)
  let cvx = 0;
  let cvy = 0;
  let cvz = 0;
  const torsoIdx = TORSO_IDX;
  for (const t of torsoIdx) {
    cvx += vel[t * 3];
    cvy += vel[t * 3 + 1];
    cvz += vel[t * 3 + 2];
  }
  cvx /= torsoIdx.length;
  cvy /= torsoIdx.length;
  cvz /= torsoIdx.length;

  for (let i = 0; i < n; i++) {
    const o = i * 3;
    const isLimb = !IS_TORSO[i];
    if (isLimb) {
      // redaman gerak relatif terhadap badan (gesekan sendi)
      const k = Math.min(1, 0.55 * h); // sendi sangat longgar = tubuh lemas
      vel[o] += (cvx - vel[o]) * k;
      vel[o + 1] += (cvy - vel[o + 1]) * k;
      vel[o + 2] += (cvz - vel[o + 2]) * k;
    }
    vel[o + 1] -= opts.gravity * h;
    // hambatan udara ringan
    const drag = Math.max(0, 1 - 0.35 * h);
    vel[o] *= drag;
    vel[o + 1] *= drag;
    vel[o + 2] *= drag;
    preVy[i] = vel[o + 1];
    pred[o] = pos[o] + vel[o] * h;
    pred[o + 1] = pos[o + 1] + vel[o + 1] * h;
    pred[o + 2] = pos[o + 2] + vel[o + 2] * h;
  }

  const contact: boolean[] = new Array(n).fill(false);

  for (let it = 0; it < ITERATIONS; it++) {
    // Constraint jarak tetap
    for (const [a, b, len, rope] of rd.links) {
      const ax = a * 3;
      const bx = b * 3;
      const dx = pred[bx] - pred[ax];
      const dy = pred[bx + 1] - pred[ax + 1];
      const dz = pred[bx + 2] - pred[ax + 2];
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-6;
      if (rope && d <= len) continue;
      const diff = (d - len) / d;
      // massa: torso lebih berat dari anggota badan
      const wa = massInv(a);
      const wb = massInv(b);
      const wsum = wa + wb;
      const ca = (wa / wsum) * diff;
      const cb = (wb / wsum) * diff;
      pred[ax] += dx * ca;
      pred[ax + 1] += dy * ca;
      pred[ax + 2] += dz * ca;
      pred[bx] -= dx * cb;
      pred[bx + 1] -= dy * cb;
      pred[bx + 2] -= dz * cb;
    }
    // Jarak minimum (tumbukan antar anggota badan)
    for (const [a, b, min] of rd.mins) {
      const ax = a * 3;
      const bx = b * 3;
      const dx = pred[bx] - pred[ax];
      const dy = pred[bx + 1] - pred[ax + 1];
      const dz = pred[bx + 2] - pred[ax + 2];
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-6;
      if (d >= min) continue;
      const diff = (d - min) / d;
      const wa = massInv(a);
      const wb = massInv(b);
      const wsum = wa + wb;
      const ca = (wa / wsum) * diff;
      const cb = (wb / wsum) * diff;
      pred[ax] += dx * ca;
      pred[ax + 1] += dy * ca;
      pred[ax + 2] += dz * ca;
      pred[bx] -= dx * cb;
      pred[bx + 1] -= dy * cb;
      pred[bx + 2] -= dz * cb;
    }
    // Lantai
    for (let i = 0; i < n; i++) {
      const o = i * 3;
      if (pred[o + 1] < RADIUS[i]) {
        pred[o + 1] = RADIUS[i];
        contact[i] = true;
      }
    }
  }

  // Dinding lapangan
  const { halfX, halfZ, goalHalfZ } = opts.bounds;
  for (let i = 0; i < n; i++) {
    const o = i * 3;
    const inGoalMouth = Math.abs(pred[o + 2]) < goalHalfZ - 0.35;
    const mx = inGoalMouth ? halfX + 0.65 : halfX - 0.35;
    if (pred[o] > mx) pred[o] = mx;
    else if (pred[o] < -mx) pred[o] = -mx;
    const mz = halfZ - 0.35;
    if (pred[o + 2] > mz) pred[o + 2] = mz;
    else if (pred[o + 2] < -mz) pred[o + 2] = -mz;
  }

  // Kecepatan baru dari selisih posisi
  for (let i = 0; i < n; i++) {
    const o = i * 3;
    let vx = (pred[o] - pos[o]) / h;
    let vy = (pred[o + 1] - pos[o + 1]) / h;
    let vz = (pred[o + 2] - pos[o + 2]) / h;

    if (contact[i]) {
      // gesekan lantai
      const f = Math.exp(-FRICTION[i] * h);
      vx *= f;
      vz *= f;
      // pantulan kecil saat jatuh keras
      const impact = -preVy[i];
      if (impact > 2.2) {
        vy = Math.max(vy, impact * (i === RD.HEAD ? 0.1 : 0.13));
        if (impact > 4.5 && (i === RD.BELLY || i === RD.BACK || i === RD.HIP_L || i === RD.HIP_R)) rd.thumps++;
      } else if (vy < 0) {
        vy = 0;
      }
    }
    // batas kecepatan agar tidak meledak
    const sp = Math.hypot(vx, vy, vz);
    if (sp > 28) {
      const k = 28 / sp;
      vx *= k;
      vy *= k;
      vz *= k;
    }
    vel[o] = vx;
    vel[o + 1] = vy;
    vel[o + 2] = vz;
    pos[o] = pred[o];
    pos[o + 1] = pred[o + 1];
    pos[o + 2] = pred[o + 2];
  }
}

function massInv(i: number): number {
  if (IS_TORSO[i]) return 1 / 1.6; // torso berat
  if (i === RD.HEAD) return 1 / 1.1;
  return 1; // leher tengah, tangan, kaki
}

export interface RagdollFrame {
  /** titik asal badan (setara posisi bodyGroup di rig, tinggi 0 = telapak kaki) */
  ox: number;
  oy: number;
  oz: number;
  /** sumbu lokal badan di dunia */
  xAxis: [number, number, number];
  yAxis: [number, number, number];
  zAxis: [number, number, number];
}

function norm(v: [number, number, number]): [number, number, number] {
  const l = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / l, v[1] / l, v[2] / l];
}

function cross(a: number[], b: number[]): [number, number, number] {
  return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
}

/** Kerangka (basis) badan dari partikel torso; dipakai render untuk memutar bodyGroup. */
export function getRagdollFrame(pts: ArrayLike<number>): RagdollFrame {
  const g = (i: number, k: number) => pts[i * 3 + k];
  const hipMid = [
    (g(RD.HIP_L, 0) + g(RD.HIP_R, 0)) / 2,
    (g(RD.HIP_L, 1) + g(RD.HIP_R, 1)) / 2,
    (g(RD.HIP_L, 2) + g(RD.HIP_R, 2)) / 2,
  ];
  const up = norm([g(RD.NECK_BASE, 0) - hipMid[0], g(RD.NECK_BASE, 1) - hipMid[1], g(RD.NECK_BASE, 2) - hipMid[2]]);
  let x: [number, number, number] = [
    g(RD.SH_L, 0) - g(RD.SH_R, 0) + g(RD.HIP_L, 0) - g(RD.HIP_R, 0),
    g(RD.SH_L, 1) - g(RD.SH_R, 1) + g(RD.HIP_L, 1) - g(RD.HIP_R, 1),
    g(RD.SH_L, 2) - g(RD.SH_R, 2) + g(RD.HIP_L, 2) - g(RD.HIP_R, 2),
  ];
  const d = x[0] * up[0] + x[1] * up[1] + x[2] * up[2];
  x = norm([x[0] - up[0] * d, x[1] - up[1] * d, x[2] - up[2] * d]);
  const z = norm(cross(x, up));
  return {
    ox: hipMid[0] - up[0] * 0.38,
    oy: hipMid[1] - up[1] * 0.38,
    oz: hipMid[2] - up[2] * 0.38,
    xAxis: x,
    yAxis: up,
    zAxis: z,
  };
}

/** Titik tengah pinggul (dipakai sebagai posisi sim PlayerSim x/z). */
export function getRagdollHip(pts: ArrayLike<number>): { x: number; y: number; z: number } {
  return {
    x: (pts[RD.HIP_L * 3] + pts[RD.HIP_R * 3]) / 2,
    y: (pts[RD.HIP_L * 3 + 1] + pts[RD.HIP_R * 3 + 1]) / 2,
    z: (pts[RD.HIP_L * 3 + 2] + pts[RD.HIP_R * 3 + 2]) / 2,
  };
}

/**
 * Arah hadap (yaw) saat bangun lagi: telungkup -> menghadap arah kepala,
 * telentang -> menghadap arah kaki, miring -> mengikuti arah dada.
 */
export function getRagdollGetUpFacing(pts: ArrayLike<number>): number {
  const f = getRagdollFrame(pts);
  let hx: number;
  let hz: number;
  if (Math.abs(f.zAxis[1]) < 0.65) {
    hx = f.zAxis[0];
    hz = f.zAxis[2];
  } else if (f.zAxis[1] < 0) {
    hx = f.yAxis[0];
    hz = f.yAxis[2];
  } else {
    hx = -f.yAxis[0];
    hz = -f.yAxis[2];
  }
  if (Math.hypot(hx, hz) < 1e-4) {
    hx = f.zAxis[0];
    hz = f.zAxis[2];
  }
  return Math.atan2(hx, hz);
}

/** Ukuran kerja total: berapa cepat ragdoll bergerak (untuk mendeteksi sudah diam). */
export function getRagdollEnergy(rd: RagdollState): number {
  let e = 0;
  for (let i = 0; i < rd.vel.length; i++) e += Math.abs(rd.vel[i]);
  return e / RAGDOLL_PARTICLE_COUNT;
}

/** Cek integritas constraint (dipakai tes): selisih maksimum dari panjang istirahat. */
export function ragdollMaxLinkError(rd: RagdollState): number {
  let m = 0;
  for (const [a, b, len, rope] of rd.links) {
    const d = dist3(rd.pos, a, b);
    m = Math.max(m, rope ? Math.max(0, d - len) : Math.abs(d - len));
  }
  return m;
}

export function ragdollMinHeight(rd: RagdollState): number {
  let m = Infinity;
  for (let i = 0; i < RAGDOLL_PARTICLE_COUNT; i++) m = Math.min(m, rd.pos[i * 3 + 1] - RADIUS[i]);
  return m;
}

/** Radius tumbukan partikel terhadap bola. */
export function getRagdollParticleRadius(i: number): number {
  return Math.max(0.11, RADIUS[i]);
}

/** Dorong satu partikel (misal ditendang bola). */
export function pokeRagdollParticle(rd: RagdollState, i: number, ix: number, iy: number, iz: number) {
  rd.vel[i * 3] += ix;
  rd.vel[i * 3 + 1] += iy;
  rd.vel[i * 3 + 2] += iz;
  // sebagian impuls menjalar ke badan agar tubuh ikut terseret
  if (!IS_TORSO[i]) {
    for (const t of TORSO_IDX) {
      rd.vel[t * 3] += ix * 0.12;
      rd.vel[t * 3 + 1] += iy * 0.08;
      rd.vel[t * 3 + 2] += iz * 0.12;
    }
  }
}

/** Kecepatan rata-rata badan (m/s) – dipakai sim untuk membaca p.vx/p.vz pemain yang sedang ragdoll. */
export function getRagdollTorsoVelocity(rd: RagdollState): { vx: number; vy: number; vz: number } {
  let vx = 0;
  let vy = 0;
  let vz = 0;
  for (const t of TORSO_IDX) {
    vx += rd.vel[t * 3];
    vy += rd.vel[t * 3 + 1];
    vz += rd.vel[t * 3 + 2];
  }
  const k = 1 / TORSO_IDX.length;
  return { vx: vx * k, vy: vy * k, vz: vz * k };
}
