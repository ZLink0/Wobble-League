import assert from 'node:assert/strict';
import test from 'node:test';
import {
  completeAdventureMatch,
  createAdventureMatchConfig,
  createNewAdventure,
  describeMatch,
  recruitWithCoins,
  stadiumLockReason,
  trainStat,
  trophyCount,
} from './adventure';
import { buildWorld, WORLD_H, WORLD_W } from './openWorldMap';

test('menang 10 pertandingan berurutan di satu stadion = 1 trofi', () => {
  let s = createNewAdventure();
  for (let m = 0; m < 9; m++) {
    const r = completeAdventureMatch(s, 0, m, 1, 0);
    assert.equal(r.result.trophyEarned, false);
    s = r.save;
  }
  assert.equal(trophyCount(s), 0);
  const last = completeAdventureMatch(s, 0, 9, 3, 1);
  assert.equal(last.result.trophyEarned, true);
  assert.equal(trophyCount(last.save), 1);
});

test('kalah atau melompati pertandingan tidak memajukan turnamen', () => {
  const s = createNewAdventure();
  assert.equal(completeAdventureMatch(s, 1, 0, 0, 2).save.wins[1], 0);
  assert.equal(completeAdventureMatch(s, 1, 5, 2, 0).save.wins[1], 0);
});

test('World Final terkunci sampai 9 trofi lain', () => {
  const s = createNewAdventure();
  assert.notEqual(stadiumLockReason(s, 9), null);
  s.trophies = s.trophies.map((_, i) => i < 9);
  assert.equal(stadiumLockReason(s, 9), null);
});

test('konfigurasi pertandingan membawa statistik atlet dan penanda adventure', () => {
  const s = createNewAdventure();
  const cfg = createAdventureMatchConfig(s, 0, 4);
  assert.deepEqual(cfg.adventure, { stadium: 0, match: 4 });
  assert.equal(cfg.redCount, 2);
  assert.ok((cfg.playerStats?.red_0.speed ?? 0) > 0.7);
  assert.equal(describeMatch(0, 9).isFinal, true);
});

test('rekrut dengan koin dan latihan memakai TP', () => {
  let s = createNewAdventure();
  s.coins = 5000;
  const r = recruitWithCoins(s, 'r_cheetah');
  assert.notEqual(typeof r, 'string');
  if (typeof r !== 'string') s = r;
  assert.equal(s.roster.length, 3);
  assert.equal(typeof trainStat(s, 'hero', 'speed'), 'string');
  s.roster[0].tp = 2;
  assert.notEqual(typeof trainStat(s, 'hero', 'speed'), 'string');
});

test('semua stadion dan POI dapat dijangkau dengan berjalan dari titik awal', () => {
  const w = buildWorld();
  const seen = new Uint8Array(WORLD_W * WORLD_H);
  const stack: Array<[number, number]> = [[w.spawn.x, w.spawn.y]];
  seen[w.spawn.y * WORLD_W + w.spawn.x] = 1;
  while (stack.length) {
    const [x, y] = stack.pop()!;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= WORLD_W || ny >= WORLD_H) continue;
      const k = ny * WORLD_W + nx;
      if (seen[k] || w.solid[k]) continue;
      seen[k] = 1;
      stack.push([nx, ny]);
    }
  }
  for (const p of w.pois) assert.equal(seen[p.y * WORLD_W + p.x], 1, p.id);
  assert.equal(w.stadiums.length, 10);
});
