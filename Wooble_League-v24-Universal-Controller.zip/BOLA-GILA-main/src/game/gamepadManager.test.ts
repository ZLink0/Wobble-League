import assert from 'node:assert/strict';
import test from 'node:test';

// Tiruan lingkungan browser minimal untuk menguji gamepadManager
const store: Record<string, string> = {};
(globalThis as any).localStorage = {
  getItem: (k: string) => store[k] ?? null,
  setItem: (k: string, v: string) => {
    store[k] = v;
  },
};
(globalThis as any).window = { addEventListener() {}, dispatchEvent: () => true, setInterval: () => 0 };
let pads: any[] = [];
Object.defineProperty(globalThis, 'navigator', { value: { getGamepads: () => pads }, configurable: true });
let clock = 0;
(globalThis as any).performance = { now: () => (clock += 50) };

const XBOX = 'Xbox 360 Controller (STANDARD GAMEPAD Vendor: 045e Product: 028e)';
const PS = 'Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 09cc)';
const NSW = 'Pro Controller (STANDARD GAMEPAD Vendor: 057e Product: 2009)';

function pad(index: number, id: string, mapping = 'standard', o: { btn?: Record<number, boolean>; axes?: number[]; ts?: number } = {}) {
  const buttons = Array.from({ length: 17 }, () => ({ pressed: false, value: 0 }));
  const axes = [0, 0, 0, 0];
  for (const [i, v] of Object.entries(o.btn ?? {})) buttons[Number(i)] = { pressed: v, value: v ? 1 : 0 };
  (o.axes ?? []).forEach((v, i) => (axes[i] = v));
  return { index, id, mapping, connected: true, buttons, axes, timestamp: o.ts ?? index };
}

test('1 controller = 1 player, analog terpisah, tidak bergantung gamepad index 0', async () => {
  const { gamepadManager: gm } = await import('./gamepadManager');
  pads = [null, null, pad(2, XBOX, 'standard', { axes: [1, 0] }), pad(3, PS, 'standard', { axes: [-1, 0] })];
  gm.scan(true);
  const p1 = gm.readSlot(1, 't')!;
  const p2 = gm.readSlot(2, 't')!;
  assert.equal(p1.moveX, 1);
  assert.equal(p2.moveX, -1);
  assert.equal(gm.readSlot(3, 't'), null);
});

test('deadzone radial: drift diabaikan, diagonal tidak lebih cepat', async () => {
  const { gamepadManager: gm } = await import('./gamepadManager');
  pads = [pad(0, XBOX, 'standard', { axes: [0.1, -0.12] })];
  gm.scan(true);
  const drift = gm.readSlot(1, 'dz')!;
  assert.equal(drift.moveX, 0);
  assert.equal(drift.moveZ, 0);
  pads = [pad(0, XBOX, 'standard', { axes: [1, 1] })];
  const d = gm.readSlot(1, 'dz')!;
  assert.ok(Math.hypot(d.moveX, d.moveZ) <= 1.0001);
});

test('Nintendo & PlayStation mengikuti posisi fisik Xbox', async () => {
  const { gamepadManager: gm } = await import('./gamepadManager');
  pads = [pad(0, NSW, 'standard', { btn: { 0: true, 1: true, 2: true, 3: true, 4: true, 5: true, 9: true } })];
  gm.scan(true);
  const slot = gm.getStatus().find((s) => s.pad?.kind === 'nintendo')!.slot;
  const n = gm.readSlot(slot, 'nsw')!;
  assert.deepEqual(
    [n.kickPressed, n.jumpPressed, n.kickRightPressed, n.grabPressed, n.headPressed, n.dashPressed, n.startPressed],
    [true, true, true, true, true, true, true]
  );
  // PlayStation tanpa mapping standar: Cross (index 1) = tombol bawah = Kick 1
  pads = [pad(0, PS, '', { btn: { 1: true } })];
  gm.scan(true);
  const ps = gm.getStatus().find((s) => s.pad?.kind === 'playstation')!.slot;
  const r = gm.readSlot(ps, 'ps')!;
  assert.equal(r.kickPressed, true);
  assert.equal(r.kickRightPressed, false);
});
