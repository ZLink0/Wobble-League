import {
  AnimationState,
  ArenaPropSim,
  GoalPostsState,
  HeadVariant,
  JellyPostSpring,
  KickVariant,
  MatchSimulation,
  PlayerSim,
  PropKind,
  TeamId,
} from './types';

export const REPLAY_BUFFER_SECONDS = 15.0;
export const REPLAY_SAMPLE_INTERVAL = 1 / 24; // 24 fps lightweight snapshots

export type ReplayCameraAngle = 'broadcast' | 'goal_cam' | 'follow_ball' | 'overhead';

export interface ReplayPlayerPose {
  id: string;
  x: number;
  y: number;
  z: number;
  facing: number;
  turnRateVisual: number;
  animState: AnimationState;
  walkCycle: number;
  squashX: number;
  squashY: number;
  kickPhase: PlayerSim['kickPhase'];
  kickVariant: KickVariant;
  kickLeg: 'left' | 'right';
  kickStretch: number;
  kickSpinAngle: number;
  kickSpinDir: -1 | 0 | 1;
  kickCharge: number;
  backflipAngle: number;
  kickTargetDirX: number;
  kickTargetDirZ: number;
  headPhase: PlayerSim['headPhase'];
  headVariant: HeadVariant;
  neckStretch: number;
  neckCurve: number;
  headSpinAngle: number;
  headSpinDir: -1 | 0 | 1;
  saltoAngle: number;
  headTargetDirX: number;
  headTargetDirY: number;
  headTargetDirZ: number;
  fallTimer: number;
  ragdollBlend: number;
  ragdollPitch: number;
  ragdollRoll: number;
  ragdollArmL: number;
  ragdollArmR: number;
  ragdollLegL: number;
  ragdollLegR: number;
  ragdollNeck: number;
  ragdollHeadRoll: number;
  /** posisi partikel ragdoll fisik (flat x,y,z) atau null */
  ragdoll?: { pos: number[] } | null;
  ghostAttachedTimer: number;
  carryingPropId: string | null;
  punchPhase: PlayerSim['punchPhase'];
  punchTimer: number;
  punchCharge: number;
  dashTimer?: number;
}

export interface ReplayPropPose {
  id: string;
  kind: PropKind;
  x: number;
  y: number;
  z: number;
  rotY: number;
  usesRemaining: number;
  carriedByPlayerId: string | null;
  flashTimer: number;
}

export interface ReplayBullPose {
  id: string;
  x: number;
  z: number;
  vx: number;
  vz: number;
  facing: number;
  stun: number;
}

export interface ReplayFrame {
  time: number;
  redScore: number;
  blueScore: number;
  ball: {
    x: number;
    y: number;
    z: number;
    vx: number;
    vz: number;
    rotX: number;
    rotY: number;
    rotZ: number;
    scaleMultiplier: number;
    isClashedFire: boolean;
    isBombArmed: boolean;
    isJelly10x: boolean;
    hitFlashTimer: number;
    bombCountdown: number;
    stickyTargetPlayerId: string | null;
  };
  players: ReplayPlayerPose[];
  props: ReplayPropPose[];
  /** Banteng dari telur burung unta (opsional agar rekaman lama tetap valid) */
  bulls?: ReplayBullPose[];
  goalPosts: GoalPostsState;
}

export interface ReplayGoalBookmark {
  id: string;
  time: number;
  team: TeamId;
  redScore: number;
  blueScore: number;
  clipFrames?: ReplayFrame[];
}

export interface ReplayBundle {
  tailFrames: ReplayFrame[];
  goals: ReplayGoalBookmark[];
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function lerpAngle(a: number, b: number, t: number): number {
  let diff = b - a;
  while (diff > Math.PI) diff -= Math.PI * 2;
  while (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}

function cloneSpring(s: JellyPostSpring): JellyPostSpring {
  return { ...s };
}

function cloneGoalPosts(gp: GoalPostsState): GoalPostsState {
  return {
    leftGoal: {
      leftPost: cloneSpring(gp.leftGoal.leftPost),
      rightPost: cloneSpring(gp.leftGoal.rightPost),
      crossbar: cloneSpring(gp.leftGoal.crossbar),
    },
    rightGoal: {
      leftPost: cloneSpring(gp.rightGoal.leftPost),
      rightPost: cloneSpring(gp.rightGoal.rightPost),
      crossbar: cloneSpring(gp.rightGoal.crossbar),
    },
  };
}

export function captureReplayFrame(sim: MatchSimulation): ReplayFrame {
  return {
    time: sim.elapsedTime,
    redScore: sim.redScore,
    blueScore: sim.blueScore,
    ball: {
      x: sim.ball.x,
      y: sim.ball.y,
      z: sim.ball.z,
      vx: sim.ball.vx,
      vz: sim.ball.vz,
      rotX: sim.ball.rotX,
      rotY: sim.ball.rotY,
      rotZ: sim.ball.rotZ,
      scaleMultiplier: sim.ball.scaleMultiplier,
      isClashedFire: sim.ball.isClashedFire,
      isBombArmed: sim.ball.isBombArmed,
      isJelly10x: sim.ball.isJelly10x,
      hitFlashTimer: sim.ball.hitFlashTimer,
      bombCountdown: sim.ball.bombCountdown,
      stickyTargetPlayerId: sim.ball.stickyTargetPlayerId,
    },
    players: sim.players.map((p) => ({
      id: p.id,
      x: p.x,
      y: p.y,
      z: p.z,
      facing: p.facing,
      turnRateVisual: p.turnRateVisual,
      animState: p.animState,
      walkCycle: p.walkCycle,
      squashX: p.squashX,
      squashY: p.squashY,
      kickPhase: p.kickPhase,
      kickVariant: p.kickVariant,
      kickLeg: p.kickLeg,
      kickStretch: p.kickStretch,
      kickSpinAngle: p.kickSpinAngle,
      kickSpinDir: p.kickSpinDir,
      kickCharge: p.kickCharge,
      backflipAngle: p.backflipAngle,
      kickTargetDirX: p.kickTargetDirX,
      kickTargetDirZ: p.kickTargetDirZ,
      headPhase: p.headPhase,
      headVariant: p.headVariant,
      neckStretch: p.neckStretch,
      neckCurve: p.neckCurve,
      headSpinAngle: p.headSpinAngle,
      headSpinDir: p.headSpinDir,
      saltoAngle: p.saltoAngle,
      headTargetDirX: p.headTargetDirX,
      headTargetDirY: p.headTargetDirY,
      headTargetDirZ: p.headTargetDirZ,
      fallTimer: p.fallTimer,
      ragdollBlend: p.ragdollBlend,
      ragdollPitch: p.ragdollPitch,
      ragdollRoll: p.ragdollRoll,
      ragdollArmL: p.ragdollArmL,
      ragdollArmR: p.ragdollArmR,
      ragdollLegL: p.ragdollLegL,
      ragdollLegR: p.ragdollLegR,
      ragdollNeck: p.ragdollNeck,
      ragdollHeadRoll: p.ragdollHeadRoll,
      ragdoll: p.ragdoll ? { pos: p.ragdoll.pos.slice() } : null,
      ghostAttachedTimer: p.ghostAttachedTimer,
      carryingPropId: p.carryingPropId,
      punchPhase: p.punchPhase,
      punchTimer: p.punchTimer,
      punchCharge: p.punchCharge,
      dashTimer: p.dashTimer,
    })),
    props: sim.props.map((pr: ArenaPropSim) => ({
      id: pr.id,
      kind: pr.kind,
      x: pr.x,
      y: pr.y,
      z: pr.z,
      rotY: pr.rotY,
      usesRemaining: pr.usesRemaining,
      carriedByPlayerId: pr.carriedByPlayerId,
      flashTimer: pr.flashTimer,
    })),
    bulls: (sim.bulls ?? []).map((b) => ({
      id: b.id,
      x: b.x,
      z: b.z,
      vx: b.vx,
      vz: b.vz,
      facing: b.facing,
      stun: b.stun,
    })),
    goalPosts: cloneGoalPosts(sim.goalPosts),
  };
}

export class ReplayRecorder {
  private frames: ReplayFrame[] = [];
  private goals: ReplayGoalBookmark[] = [];
  private pendingGoalSaves: Array<{ bookmark: ReplayGoalBookmark; endAt: number }> = [];
  private accum = 0;

  public reset() {
    this.frames = [];
    this.goals = [];
    this.pendingGoalSaves = [];
    this.accum = 0;
  }

  public recordStep(sim: MatchSimulation, dt: number, force = false) {
    this.accum += dt;
    if (!force && this.accum < REPLAY_SAMPLE_INTERVAL && this.frames.length > 0) {
      // Still detect goal event immediately so we never miss a goal bookmark
      for (const ev of sim.events) {
        if (ev.type === 'goal' && ev.team) {
          this.registerGoal(sim, ev.team);
        }
      }
      return;
    }
    this.accum = 0;

    const frame = captureReplayFrame(sim);
    this.frames.push(frame);

    const cutoff = frame.time - REPLAY_BUFFER_SECONDS;
    while (this.frames.length > 2 && this.frames[0].time < cutoff) {
      this.frames.shift();
    }

    for (const ev of sim.events) {
      if (ev.type === 'goal' && ev.team) {
        this.registerGoal(sim, ev.team);
      }
    }

    // Finalize any goal clip 2.0s after the goal so celebration is included
    for (let i = this.pendingGoalSaves.length - 1; i >= 0; i--) {
      const pending = this.pendingGoalSaves[i];
      if (frame.time >= pending.endAt) {
        const startCut = pending.bookmark.time - 8.5;
        pending.bookmark.clipFrames = this.frames.filter((f) => f.time >= startCut);
        this.pendingGoalSaves.splice(i, 1);
      }
    }
  }

  private registerGoal(sim: MatchSimulation, team: TeamId) {
    const bookmark: ReplayGoalBookmark = {
      id: `goal_${this.goals.length + 1}_${Math.round(sim.elapsedTime * 100)}`,
      time: sim.elapsedTime,
      team,
      redScore: sim.redScore,
      blueScore: sim.blueScore,
      clipFrames: [...this.frames],
    };
    this.goals.push(bookmark);
    this.pendingGoalSaves.push({ bookmark, endAt: sim.elapsedTime + 2.0 });
  }

  public getRecentClip(windowSeconds = 4.2): ReplayFrame[] {
    if (this.frames.length === 0) return [];
    const latestTime = this.frames[this.frames.length - 1].time;
    const cutoff = latestTime - windowSeconds;
    return this.frames.filter((f) => f.time >= cutoff);
  }

  public getBundle(): ReplayBundle {
    return {
      tailFrames: this.frames,
      goals: this.goals.map((g) => ({
        ...g,
        clipFrames: g.clipFrames && g.clipFrames.length > 0 ? g.clipFrames : this.frames,
      })),
    };
  }
}

export function sampleReplayFrame(frames: ReplayFrame[], targetTime: number): ReplayFrame | null {
  if (frames.length === 0) return null;
  if (targetTime <= frames[0].time) return frames[0];
  const last = frames[frames.length - 1];
  if (targetTime >= last.time) return last;

  let lo = 0;
  let hi = frames.length - 1;
  while (lo + 1 < hi) {
    const mid = (lo + hi) >> 1;
    if (frames[mid].time <= targetTime) lo = mid;
    else hi = mid;
  }

  const a = frames[lo];
  const b = frames[hi];
  const span = b.time - a.time;
  const t = span > 0.0001 ? Math.max(0, Math.min(1, (targetTime - a.time) / span)) : 0;

  const interpPlayers: ReplayPlayerPose[] = a.players.map((pa, idx) => {
    const pb = b.players[idx] ?? pa;
    return {
      ...pa,
      x: lerp(pa.x, pb.x, t),
      y: lerp(pa.y, pb.y, t),
      z: lerp(pa.z, pb.z, t),
      facing: lerpAngle(pa.facing, pb.facing, t),
      squashX: lerp(pa.squashX, pb.squashX, t),
      squashY: lerp(pa.squashY, pb.squashY, t),
      kickStretch: lerp(pa.kickStretch, pb.kickStretch, t),
      kickSpinAngle:
        pa.kickPhase === pb.kickPhase ? lerp(pa.kickSpinAngle, pb.kickSpinAngle, t) : pb.kickSpinAngle,
      kickCharge: lerp(pa.kickCharge, pb.kickCharge, t),
      backflipAngle:
        pa.kickPhase === pb.kickPhase ? lerp(pa.backflipAngle, pb.backflipAngle, t) : pb.backflipAngle,
      neckStretch: lerp(pa.neckStretch, pb.neckStretch, t),
      headSpinAngle:
        pa.headPhase === pb.headPhase ? lerp(pa.headSpinAngle, pb.headSpinAngle, t) : pb.headSpinAngle,
      saltoAngle:
        pa.headPhase === pb.headPhase ? lerp(pa.saltoAngle, pb.saltoAngle, t) : pb.saltoAngle,
      ragdollBlend: lerp(pa.ragdollBlend, pb.ragdollBlend, t),
      ragdollPitch: lerp(pa.ragdollPitch, pb.ragdollPitch, t),
      ragdollRoll: lerp(pa.ragdollRoll, pb.ragdollRoll, t),
      ragdoll:
        pa.ragdoll && pb.ragdoll
          ? { pos: pa.ragdoll.pos.map((v, i) => lerp(v, pb.ragdoll!.pos[i] ?? v, t)) }
          : pa.ragdoll ?? null,
      punchCharge: lerp(pa.punchCharge, pb.punchCharge, t),
      walkCycle: lerp(pa.walkCycle, pb.walkCycle, t),
    };
  });

  const interpProps: ReplayPropPose[] = a.props.map((pra) => {
    const prb = b.props.find((p) => p.id === pra.id);
    if (!prb) return pra;
    return {
      ...pra,
      x: lerp(pra.x, prb.x, t),
      y: lerp(pra.y, prb.y, t),
      z: lerp(pra.z, prb.z, t),
      rotY: lerpAngle(pra.rotY, prb.rotY, t),
    };
  });

  const interpSpring = (sa: JellyPostSpring, sb: JellyPostSpring): JellyPostSpring => ({
    dispX: lerp(sa.dispX, sb.dispX, t),
    dispY: lerp(sa.dispY, sb.dispY, t),
    dispZ: lerp(sa.dispZ, sb.dispZ, t),
    velX: lerp(sa.velX, sb.velX, t),
    velY: lerp(sa.velY, sb.velY, t),
    velZ: lerp(sa.velZ, sb.velZ, t),
  });

  return {
    time: lerp(a.time, b.time, t),
    redScore: a.redScore,
    blueScore: a.blueScore,
    ball: {
      ...a.ball,
      x: lerp(a.ball.x, b.ball.x, t),
      y: lerp(a.ball.y, b.ball.y, t),
      z: lerp(a.ball.z, b.ball.z, t),
      vx: lerp(a.ball.vx, b.ball.vx, t),
      vz: lerp(a.ball.vz, b.ball.vz, t),
      rotX: lerp(a.ball.rotX, b.ball.rotX, t),
      rotY: lerp(a.ball.rotY, b.ball.rotY, t),
      rotZ: lerp(a.ball.rotZ, b.ball.rotZ, t),
      scaleMultiplier: lerp(a.ball.scaleMultiplier, b.ball.scaleMultiplier, t),
    },
    players: interpPlayers,
    props: interpProps,
    bulls: (a.bulls ?? []).map((ba) => {
      const bb = (b.bulls ?? []).find((x) => x.id === ba.id);
      if (!bb) return ba;
      return {
        ...ba,
        x: lerp(ba.x, bb.x, t),
        z: lerp(ba.z, bb.z, t),
        vx: lerp(ba.vx, bb.vx, t),
        vz: lerp(ba.vz, bb.vz, t),
        facing: lerpAngle(ba.facing, bb.facing, t),
      };
    }),
    goalPosts: {
      leftGoal: {
        leftPost: interpSpring(a.goalPosts.leftGoal.leftPost, b.goalPosts.leftGoal.leftPost),
        rightPost: interpSpring(a.goalPosts.leftGoal.rightPost, b.goalPosts.leftGoal.rightPost),
        crossbar: interpSpring(a.goalPosts.leftGoal.crossbar, b.goalPosts.leftGoal.crossbar),
      },
      rightGoal: {
        leftPost: interpSpring(a.goalPosts.rightGoal.leftPost, b.goalPosts.rightGoal.leftPost),
        rightPost: interpSpring(a.goalPosts.rightGoal.rightPost, b.goalPosts.rightGoal.rightPost),
        crossbar: interpSpring(a.goalPosts.rightGoal.crossbar, b.goalPosts.rightGoal.crossbar),
      },
    },
  };
}

/**
 * Semua sudut replay berada di PINGGIR lapangan (sisi touchline) dengan jarak lebar tetap.
 * Saat replay gol (focusGoalTeam diberikan) kamera selalu membingkai bola DAN gawang
 * sekaligus: titik pandang berada di antara bola dan gawang yang dibobol.
 */
export function computeReplayCameraPose(
  angle: ReplayCameraAngle,
  frame: ReplayFrame,
  focusGoalTeam?: TeamId | null
): { pos: [number, number, number]; lookAt: [number, number, number] } {
  const GOAL_X = 11.2;
  const bx = frame.ball.x;
  const bz = frame.ball.z;
  const t = frame.time;
  const sway = Math.sin(t * 0.9) * 0.2;
  const side = focusGoalTeam ? (focusGoalTeam === 'red' ? 1 : -1) : bx >= 0 ? 1 : -1;
  // Bobot gawang: penuh saat replay gol, bertahap saat bola mendekati gawang pada replay biasa
  const nearGoal = Math.max(0, Math.min(1, (Math.abs(bx) - 4) / 6));
  const goalW = focusGoalTeam ? 0.6 : nearGoal * 0.6;
  const gx = side * GOAL_X;
  const focusX = bx * (1 - goalW) + gx * goalW;
  const focusZ = bz * 0.25;
  const camX = Math.max(-10, Math.min(10, focusX * 0.8)) + sway;
  const sideZ = 19;

  if (angle === 'goal_cam') {
    return { pos: [camX, 6.8, sideZ], lookAt: [focusX, 1.0, focusZ] };
  }
  if (angle === 'follow_ball') {
    return { pos: [camX, 4.6, sideZ + 1.5], lookAt: [focusX, 1.0, focusZ] };
  }
  if (angle === 'overhead') {
    return { pos: [camX * 0.7, 14, sideZ + 3.5], lookAt: [focusX, 0, focusZ] };
  }
  return { pos: [camX, 9, sideZ + 1.5], lookAt: [focusX, 0.8, focusZ] };
}
