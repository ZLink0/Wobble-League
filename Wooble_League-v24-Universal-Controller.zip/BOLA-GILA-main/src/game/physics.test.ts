import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultMatchConfig, createTrainingConfig } from './catalog';
import {
  BALL_RESPAWN_IDLE_SECONDS,
  computeNeckPose,
  computeNpcInput,
  createMatchSimulation,
  spawnRandomPropPair,
  DASH_COOLDOWN,
  DASH_DURATION,
  DASH_SPEED,
  getExtendedFootPosition,
  getExtendedHeadPosition,
  getKickingLegSamplePoints,
  GOAL_HALF_Z,
  GOAL_HEIGHT,
  ITEM_EFFECT_DURATION,
  ITEM_RESPAWN_COOLDOWN,
  KICK_SPIN_REACH,
  PITCH_HALF_X,
  RAIN_DURATION_SECONDS,
  RAIN_PROBABILITY,
  RUN_SPEED,
  stepSimulation,
  triggerHeadAttack,
  triggerKick,
  WALK_SPEED,
} from './physics';
import { InputFrame } from './types';

function idleInput(): InputFrame {
  return {
    moveX: 0,
    moveZ: 0,
    runHeld: false,
    kickPressed: false,
    kickHeld: false,
    kickRightSpinPressed: false,
    kickRightHeld: false,
    grabPressed: false,
    jumpPressed: false,
    headSpinLeftPressed: false,
    dashPressed: false,
  };
}

test('movement accelerates gradually, respects walk/run/dash caps, and unlimited R dash has 1.0s cooldown', () => {
  assert.equal(DASH_COOLDOWN, 1.0);

  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  p1.x = -8;
  p1.z = -3;
  p1.facing = Math.PI / 2;
  npc.x = 12;
  npc.z = 5;
  sim.ball.x = 11;
  sim.ball.z = 5;

  const walkIn: InputFrame = { ...idleInput(), moveX: 1, moveZ: 0, runHeld: false };
  stepSimulation(sim, 0.04, { p1: walkIn });
  const speedAfter1Frame = Math.hypot(p1.vx, p1.vz);
  assert.ok(speedAfter1Frame > 0 && speedAfter1Frame < WALK_SPEED, `Expected gradual acceleration, got ${speedAfter1Frame}`);

  for (let i = 0; i < 40; i++) {
    stepSimulation(sim, 0.04, { p1: walkIn });
  }
  const steadyWalk = Math.hypot(p1.vx, p1.vz);
  assert.ok(Math.abs(steadyWalk - WALK_SPEED) < 0.25, `Expected walk speed ~${WALK_SPEED}, got ${steadyWalk}`);

  const runIn: InputFrame = { ...idleInput(), moveX: 1, moveZ: 0, runHeld: true };
  for (let i = 0; i < 40; i++) {
    stepSimulation(sim, 0.04, { p1: runIn });
  }
  const steadyRun = Math.hypot(p1.vx, p1.vz);
  assert.ok(Math.abs(steadyRun - RUN_SPEED) < 0.4, `Expected run speed ~${RUN_SPEED}, got ${steadyRun}`);

  for (let i = 0; i < 15; i++) {
    stepSimulation(sim, 0.04, { p1: idleInput() });
  }
  const stoppedSpeed = Math.hypot(p1.vx, p1.vz);
  assert.ok(stoppedSpeed < 0.05, `Expected stop without sliding, got ${stoppedSpeed}`);

  // First dash on R
  sim.hitstopTimer = 0;
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), dashPressed: true } });
  const dashSpeed = Math.hypot(p1.vx, p1.vz);
  assert.ok(Math.abs(dashSpeed - DASH_SPEED) < 0.4, `Expected dash speed ~${DASH_SPEED}, got ${dashSpeed}`);

  // Wait 1.05s -> should be able to dash again immediately (unlimited dash, 1s cooldown)
  for (let i = 0; i < 36; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  sim.hitstopTimer = 0;
  assert.equal(p1.dashCooldown, 0);
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), dashPressed: true } });
  assert.ok(p1.dashTimer > 0, 'Expected unlimited second dash after 1.0s cooldown');
});

test('A (right-leg 180° spin left) & X (left-leg 180° spin right) sweep -PI/2 -> +PI/2 with hard kick power', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  npc.x = 9;
  npc.z = 5;

  assert.ok(KICK_SPIN_REACH < 1.0, `Expected moderate kick spin reach, got ${KICK_SPIN_REACH}`);

  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2; // Facing +X -> character's LEFT is -Z
  sim.ball.x = 0.25;
  sim.ball.y = 0.45;
  sim.ball.z = -1.2;
  sim.ball.vx = 0;
  sim.ball.vz = 0;

  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickPressed: true } });
  assert.equal(p1.kickVariant, 'spin_left');
  assert.equal(p1.kickSpinDir, 1, 'A button spin kick left must rotate +1 CCW');
  assert.equal(p1.kickLeg, 'right', 'A button spin kick left must use the right leg');
  assert.ok(p1.kickSpinAngle < 0, `Expected 180° sweep starting near -PI/2, got ${p1.kickSpinAngle}`);
  assert.equal(computeNeckPose(p1).bodyYaw, 0, 'Body torso must NOT rotate when kicking');

  let minSpinA = p1.kickSpinAngle;
  let maxSpinA = p1.kickSpinAngle;
  let minVz = 0;
  for (let i = 0; i < 18; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
    assert.equal(computeNeckPose(p1).bodyYaw, 0, 'Body torso yaw must stay 0 throughout spin kick');
    if (p1.kickSpinAngle < minSpinA) minSpinA = p1.kickSpinAngle;
    if (p1.kickSpinAngle > maxSpinA) maxSpinA = p1.kickSpinAngle;
    if (sim.ball.vz < minVz) minVz = sim.ball.vz;
  }
  assert.ok(
    minSpinA <= -Math.PI * 0.4 && maxSpinA >= Math.PI * 0.4 && maxSpinA <= Math.PI * 0.56,
    `Expected 180° sweep (-PI/2..+PI/2), got ${minSpinA}..${maxSpinA}`
  );
  assert.ok(minVz < -10.0, `Expected hard A spin kick to strike left-side ball -Z strongly, got minVz=${minVz}`);

  // X button -> Left-leg 360° spin RIGHT (back -> front)
  const simX = createMatchSimulation(cfg, { forceRain: false });
  const pX = simX.players.find((p) => p.humanSlot === 1)!;
  const npcX = simX.players.find((p) => !p.isHuman)!;
  npcX.x = -9;
  npcX.z = -5;
  pX.x = 0;
  pX.z = 0;
  pX.facing = Math.PI / 2; // Facing +X -> character's RIGHT is +Z
  simX.ball.x = 0.25;
  simX.ball.y = 0.45;
  simX.ball.z = 1.2;

  stepSimulation(simX, 0.02, { p1: { ...idleInput(), kickRightSpinPressed: true } });
  assert.equal(pX.kickVariant, 'spin_right');
  assert.equal(pX.kickSpinDir, -1, 'X button spin kick right must rotate -1 CW');
  assert.equal(pX.kickLeg, 'left', 'X button spin kick right must use the left leg');

  let maxVz = 0;
  for (let i = 0; i < 18; i++) {
    stepSimulation(simX, 0.03, { p1: idleInput() });
    if (simX.ball.vz > maxVz) maxVz = simX.ball.vz;
  }
  assert.ok(maxVz > 5.0, `Expected X left-leg spin kick right to strike ball +Z, got maxVz=${maxVz}`);

  // Verify out-of-range distant ball is NOT magically hit without foot contact
  const simFar = createMatchSimulation(cfg, { forceRain: false });
  const pFar = simFar.players.find((p) => p.humanSlot === 1)!;
  const npcFar = simFar.players.find((p) => !p.isHuman)!;
  npcFar.x = 9;
  npcFar.z = 5;
  pFar.x = 0;
  pFar.z = 0;
  pFar.facing = Math.PI / 2;
  simFar.ball.x = 2.6;
  simFar.ball.y = 0.45;
  simFar.ball.z = 0;
  simFar.ball.vx = 0;
  simFar.ball.vz = 0;
  stepSimulation(simFar, 0.02, { p1: { ...idleInput(), kickPressed: true } });
  for (let i = 0; i < 16; i++) {
    const foot = getExtendedFootPosition(pFar);
    assert.ok(Math.hypot(foot.x - simFar.ball.x, foot.z - simFar.ball.z) > 0.9);
    stepSimulation(simFar, 0.03, { p1: idleInput() });
  }
  assert.equal(simFar.ball.vx, 0, 'Kick must never apply force without physical leg/foot contact');
});

test('every leg segment including calf (betis) kicks the ball on contact', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  npc.x = -9;
  npc.z = -5;

  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;

  const samples = getKickingLegSamplePoints(p1);
  assert.ok(samples.length >= 4, 'Expected thigh, calf (betis), ankle, and foot kick sample points');

  // Place ball directly at mid-calf distance (~0.62m ahead of player, too close for foot tip alone)
  sim.ball.x = 0.65;
  sim.ball.y = 0.35;
  sim.ball.z = 0;
  sim.ball.vx = 0;
  sim.ball.vz = 0;

  triggerKick(p1, 'forward', sim.ball);
  for (let i = 0; i < 15; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  assert.ok(sim.ball.vx > 5.0, `Expected calf (betis) / leg contact to launch ball forward, got vx=${sim.ball.vx}`);
});

test('directional forward rubber kick aligns along body without sideways drift', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  npc.x = -9;
  npc.z = -5;

  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  sim.ball.x = 1.65;
  sim.ball.y = 0.42;
  sim.ball.z = 0.25;

  triggerKick(p1, 'forward', sim.ball);
  assert.equal(p1.kickPhase, 'prep');
  for (let i = 0; i < 24; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  assert.ok(sim.ball.vx > 6.0, `Expected forward kick along +X, got vx=${sim.ball.vx}`);
  assert.ok(Math.abs(sim.ball.vz) < 0.05, `Expected straight ball trajectory, got vz=${sim.ball.vz}`);
});

test('L button rotates extended rubber neck + head 360° LEFT', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const simL = createMatchSimulation(cfg, { forceRain: false });
  const pL = simL.players.find((p) => p.humanSlot === 1)!;
  const npcL = simL.players.find((p) => !p.isHuman)!;
  npcL.x = 9;
  npcL.z = 5;

  pL.x = 0;
  pL.z = 0;
  pL.facing = Math.PI / 2; // Facing +X -> Left is -Z
  simL.ball.x = 0;
  simL.ball.y = 0.65;
  simL.ball.z = -1.65;

  stepSimulation(simL, 0.02, { p1: { ...idleInput(), headSpinLeftPressed: true } });
  assert.equal(pL.headVariant, 'spin_left');
  assert.equal(pL.headSpinDir, 1);
  assert.equal(pL.animState, 'head_spin_360');

  let maxHeadSpinL = 0;
  let maxNeckStretchL = 0;
  let minBallVz = 0;
  for (let i = 0; i < 18; i++) {
    stepSimulation(simL, 0.03, { p1: idleInput() });
    if (pL.headSpinAngle > maxHeadSpinL) maxHeadSpinL = pL.headSpinAngle;
    if (pL.neckStretch > maxNeckStretchL) maxNeckStretchL = pL.neckStretch;
    if (simL.ball.vz < minBallVz) minBallVz = simL.ball.vz;
  }
  assert.ok(maxHeadSpinL > Math.PI * 1.5, `Expected 360° head spin left, got ${maxHeadSpinL}`);
  assert.ok(maxNeckStretchL > 0.7, `Expected long rubber neck stretch on L, got ${maxNeckStretchL}`);
  assert.ok(minBallVz < -5.0, `Expected L 360° left head spin to strike ball -Z, got vz=${minBallVz}`);
});

test('Y Jump + A = front-leg Fire Backflip; Y Jump + X = backward high Lob Backflip', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;

  // 1. Y Jump triggers airborne state cleanly
  const simJump = createMatchSimulation(cfg, { forceRain: false });
  const pj = simJump.players.find((p) => p.humanSlot === 1)!;
  stepSimulation(simJump, 0.02, { p1: { ...idleInput(), jumpPressed: true } });
  assert.ok(pj.vy > 5.0, 'Y button must trigger jump');
  stepSimulation(simJump, 0.03, { p1: idleInput() });
  assert.equal(pj.animState, 'jump');

  // 2. Jump + A -> Front-leg backflip that ignites the ball on fire and shoots fast!
  const simFireFlip = createMatchSimulation(cfg, { forceRain: false });
  const pf = simFireFlip.players.find((p) => p.humanSlot === 1)!;
  const npcF = simFireFlip.players.find((p) => !p.isHuman)!;
  npcF.x = -9;
  npcF.z = -5;
  pf.x = 0;
  pf.y = 0.7;
  pf.vy = 4.2;
  pf.z = 0;
  pf.facing = Math.PI / 2;
  simFireFlip.ball.x = 1.25;
  simFireFlip.ball.y = 1.35;
  simFireFlip.ball.z = 0;

  stepSimulation(simFireFlip, 0.02, { p1: { ...idleInput(), kickPressed: true, kickHeld: true } });
  assert.equal(pf.kickVariant, 'backflip_front_fire');
  assert.equal(pf.animState, 'backflip_front');

  let maxBallVx = 0;
  let maxFlipAngle = 0;
  for (let i = 0; i < 16; i++) {
    stepSimulation(simFireFlip, 0.03, { p1: idleInput() });
    if (simFireFlip.ball.vx > maxBallVx) maxBallVx = simFireFlip.ball.vx;
    if (pf.backflipAngle > maxFlipAngle) maxFlipAngle = pf.backflipAngle;
  }
  assert.ok(maxFlipAngle > Math.PI, `Expected front backflip rotation, got ${maxFlipAngle}`);
  assert.equal(simFireFlip.ball.isClashedFire, true, 'Jump+A front-leg backflip must ignite ball on fire');
  assert.ok(maxBallVx > 15.0, `Jump+A fire backflip must fire ball fast forward, got ${maxBallVx}`);

  // 3. Jump + X -> Backward backflip that lobs the ball high into the air!
  const simLob = createMatchSimulation(cfg, { forceRain: false });
  const pl = simLob.players.find((p) => p.humanSlot === 1)!;
  const npcL = simLob.players.find((p) => !p.isHuman)!;
  npcL.x = -9;
  npcL.z = -5;
  pl.x = 0;
  pl.y = 0.7;
  pl.vy = 4.2;
  pl.z = 0;
  pl.facing = Math.PI / 2;
  simLob.ball.x = 1.2;
  simLob.ball.y = 1.35;
  simLob.ball.z = 0;

  stepSimulation(simLob, 0.02, { p1: { ...idleInput(), kickRightSpinPressed: true, kickRightHeld: true } });
  assert.equal(pl.kickVariant, 'backflip_lob');
  assert.equal(pl.animState, 'backflip_back');

  let maxBallVy = 0;
  let maxBallY = 0;
  for (let i = 0; i < 20; i++) {
    stepSimulation(simLob, 0.03, { p1: idleInput() });
    if (simLob.ball.vy > maxBallVy) maxBallVy = simLob.ball.vy;
    if (simLob.ball.y > maxBallY) maxBallY = simLob.ball.y;
  }
  assert.ok(maxBallVy >= 11.0 && maxBallY >= 3.2, `Jump+X backward backflip must lob ball high, got vy=${maxBallVy}, y=${maxBallY}`);
});

test('directional headings (left/right/backward turn-first) differentiate directions cleanly', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  npc.x = 9;
  npc.z = 5;

  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  sim.ball.x = -1.6;
  sim.ball.y = 0.65;
  sim.ball.z = 0;

  triggerHeadAttack(p1, 'backward', sim.ball);
  assert.equal(p1.headPhase, 'turn_first', 'Backward heading must turn body first before extending');
  for (let i = 0; i < 28; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  assert.ok(sim.ball.vx < -5.0, `Expected backward heading after turn-first to launch ball -X, got vx=${sim.ball.vx}`);
});

test('ordinary slow ball never knocks player down; fast/fire ball triggers instant limp ragdoll', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;

  // 1. Ordinary slow/medium ball contact -> zero knockdown / stun
  const simOrd = createMatchSimulation(cfg, { forceRain: false });
  const pOrd = simOrd.players.find((p) => p.humanSlot === 1)!;
  pOrd.x = 0;
  pOrd.z = 0;
  simOrd.ball.x = 0.7;
  simOrd.ball.y = 0.55;
  simOrd.ball.z = 0;
  simOrd.ball.vx = -5.5;
  simOrd.ball.vy = 0;
  simOrd.ball.vz = 0;

  stepSimulation(simOrd, 0.02, { p1: idleInput() });
  assert.equal(pOrd.fallTimer, 0, 'Ordinary ball touch must NEVER knock player down');
  assert.equal(pOrd.collisionStunTimer, 0, 'Ordinary ball touch must NEVER stun player');

  // 1b. Medium-fast non-fire ball (-12.5 m/s) still must NOT knock player down easily
  const simMed = createMatchSimulation(cfg, { forceRain: false });
  const pMed = simMed.players.find((p) => p.humanSlot === 1)!;
  pMed.x = 0;
  pMed.z = 0;
  simMed.ball.x = 0.7;
  simMed.ball.y = 0.6;
  simMed.ball.z = 0;
  simMed.ball.vx = -12.5;
  simMed.ball.vy = 0;
  simMed.ball.vz = 0;
  stepSimulation(simMed, 0.02, { p1: idleInput() });
  assert.equal(pMed.fallTimer, 0, 'Moderate speed ordinary ball (-12.5 m/s) should not trigger ragdoll knockdown');

  // 2. Very fast power ball hit (-18 m/s) -> INSTANT limp ragdoll (ragdollBlend >= 0.8 immediately)
  const simFast = createMatchSimulation(cfg, { forceRain: false });
  const pFast = simFast.players.find((p) => p.humanSlot === 1)!;
  pFast.x = 0;
  pFast.z = 0;
  simFast.ball.x = 0.7;
  simFast.ball.y = 0.65;
  simFast.ball.z = 0;
  simFast.ball.vx = -24.0;
  simFast.ball.vy = 0;
  simFast.ball.vz = 0;

  stepSimulation(simFast, 0.02, { p1: idleInput() });
  assert.ok(pFast.fallTimer > 0.8, 'Very fast power ball hit (>=22 m/s) should trigger ragdoll fall');
  assert.ok(pFast.ragdollBlend >= 0.8, `Expected instant limp ragdoll (blend >= 0.8), got ${pFast.ragdollBlend}`);
  assert.ok(Math.abs(pFast.ragdollArmL) > 0.3 && Math.abs(pFast.ragdollLegL) > 0.2, 'Expected floppy ragdoll limbs on impact');

  // 3. Fire ball even at moderate speed triggers ragdoll
  const simFire = createMatchSimulation(cfg, { forceRain: false });
  const pFire = simFire.players.find((p) => p.humanSlot === 1)!;
  pFire.x = 0;
  pFire.z = 0;
  simFire.ball.isClashedFire = true;
  simFire.ball.clashFireTimer = 5;
  simFire.ball.x = 0.7;
  simFire.ball.y = 0.55;
  simFire.ball.z = 0;
  simFire.ball.vx = -15.0;
  stepSimulation(simFire, 0.02, { p1: idleInput() });
  assert.ok(pFire.fallTimer > 0.8, 'Fire ball hit should trigger ragdoll fall');

  for (let i = 0; i < 190; i++) {
    // ragdoll lemas total 3 detik (bola dijauhkan agar tidak memicu jatuh lagi)
    simFast.ball.x = -8;
    simFast.ball.z = 5;
    simFast.ball.vx = 0;
    simFast.ball.vz = 0;
    stepSimulation(simFast, 0.03, { p1: idleInput() });
  }
  assert.equal(pFast.fallTimer <= 0, true, 'Player should finish getting up');
  assert.equal(pFast.ragdollBlend, 0);
  assert.equal(pFast.ragdollPitch, 0);
});

test('enlarged goals fit Giant Ball (2.1x) and jelly posts wobble cleanly', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });

  assert.ok(GOAL_HALF_Z >= 3.0 && GOAL_HEIGHT >= 3.3, 'Goals should be enlarged for giant balls');

  sim.ball.x = PITCH_HALF_X - 0.6;
  sim.ball.y = 1.0;
  sim.ball.z = -GOAL_HALF_Z;
  sim.ball.vx = 10.0;
  sim.ball.vy = 0;
  sim.ball.vz = 0;

  for (let i = 0; i < 4; i++) {
    stepSimulation(sim, 0.03, {});
  }
  assert.ok(sim.ball.vx < 0, `Expected post rebound vx < 0, got ${sim.ball.vx}`);
  assert.ok(Math.abs(sim.goalPosts.rightGoal.leftPost.dispX) > 0.001, 'Expected jelly goalpost displacement');

  sim.activeItems.push({ type: 'giant_ball', remaining: 15, targetPlayerId: null });
  sim.ball.x = PITCH_HALF_X + 0.85;
  sim.ball.y = GOAL_HEIGHT * 0.55;
  sim.ball.z = 1.2;
  sim.ball.vx = 8.0;
  sim.ball.vz = 0;
  stepSimulation(sim, 0.03, {});
  assert.equal(sim.redScore, 1, 'Giant Ball must fit and score cleanly in enlarged goal');
});

test('center item spawns once every 60 seconds and Rubber Ball 10x does not shake camera', () => {
  const cfg = createDefaultMatchConfig();
  cfg.enabledItems = ['jelly_10x'];
  const sim = createMatchSimulation(cfg, { forceRain: false });
  assert.equal(ITEM_RESPAWN_COOLDOWN, 60.0);
  assert.equal(sim.pickupOrb.respawnTimer, 60.0);

  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  sim.pickupOrb.active = true;
  sim.pickupOrb.type = 'jelly_10x';
  p1.x = 0;
  p1.z = 0;

  stepSimulation(sim, 0.03, {});
  assert.equal(sim.ball.isJelly10x, true);
  assert.equal(sim.pickupOrb.respawnTimer, 60.0);

  p1.x = -5;
  p1.z = -5;
  sim.ball.y = 0.2;
  sim.ball.vy = -12;
  stepSimulation(sim, 0.03, {});
  assert.equal(sim.cameraTrauma, 0, 'Rubber Ball 10x must never shake the camera screen');
  assert.ok(sim.ball.vy > 4.0 && sim.ball.vy <= 13.0, `Expected lively controlled rubber bounce, got vy=${sim.ball.vy}`);
});

test('shape-specific ball physics: Hockey Puck / Flat Disc slide flat & Y-spin only; Oval hops asymmetrically; Metal heavy vs Rubber extra bounce', () => {
  const puckCfg = createDefaultMatchConfig();
  puckCfg.ballType = 'hockey';
  const puckSim = createMatchSimulation(puckCfg, { forceRain: false });
  assert.equal(puckSim.ball.colliderType, 'cylinder');
  assert.equal(puckSim.ball.sliding, true);
  puckSim.ball.vx = 6.0;
  puckSim.ball.vz = 2.0;
  puckSim.ball.spinY = 8.0;
  for (let i = 0; i < 15; i++) {
    stepSimulation(puckSim, 0.03, {});
  }
  assert.equal(puckSim.ball.rotX, 0, 'Hockey puck must stay flat without tumbling on X');
  assert.equal(puckSim.ball.rotZ, 0, 'Hockey puck must stay flat without tumbling on Z');
  assert.ok(Math.abs(puckSim.ball.rotY) > 0.5, 'Hockey puck must spin on Y axis');
  assert.ok(puckSim.ball.vx > 3.5, 'Hockey puck should glide smoothly with low friction');

  const discCfg = createDefaultMatchConfig();
  discCfg.ballType = 'flat_disc';
  const discSim = createMatchSimulation(discCfg, { forceRain: false });
  assert.equal(discSim.ball.colliderType, 'cylinder');
  discSim.ball.vx = 7.0;
  discSim.ball.spinY = 10.0;
  for (let i = 0; i < 12; i++) {
    stepSimulation(discSim, 0.03, {});
  }
  assert.equal(discSim.ball.rotX, 0);
  assert.equal(discSim.ball.rotZ, 0);

  const nflCfg = createDefaultMatchConfig();
  nflCfg.ballType = 'nfl';
  const nflSim = createMatchSimulation(nflCfg, { forceRain: false });
  assert.equal(nflSim.ball.colliderType, 'ellipsoid');
  nflSim.ball.x = 0;
  nflSim.ball.y = 0.35;
  nflSim.ball.z = 0;
  nflSim.ball.vx = 0;
  nflSim.ball.vz = 0;
  nflSim.ball.vy = -9.0;
  nflSim.ball.rotX = 0.9;
  nflSim.ball.rotY = 0.8;
  stepSimulation(nflSim, 0.03, {});
  const nflHorizHop = Math.hypot(nflSim.ball.vx, nflSim.ball.vz);
  assert.ok(nflHorizHop > 0.5, `NFL oval should produce irregular horizontal hop on bounce, got ${nflHorizHop}`);
  assert.ok(nflSim.events.some((e) => e.type === 'ball_bounce'), 'Expected ball_bounce event');

  const metalCfg = createDefaultMatchConfig();
  metalCfg.ballType = 'metal';
  const metalSim = createMatchSimulation(metalCfg, { forceRain: false });
  metalSim.ball.y = 0.35;
  metalSim.ball.vy = -9.0;
  stepSimulation(metalSim, 0.03, {});
  assert.ok(metalSim.ball.vy < 3.5, `Metal ball should have heavy low bounce, got vy=${metalSim.ball.vy}`);

  const rubberCfg = createDefaultMatchConfig();
  rubberCfg.ballType = 'rubber';
  const rubberSim = createMatchSimulation(rubberCfg, { forceRain: false });
  rubberSim.ball.y = 0.35;
  rubberSim.ball.vy = -9.0;
  stepSimulation(rubberSim, 0.03, {});
  assert.ok(rubberSim.ball.vy > 7.5, `Rubber ball should bounce very high, got vy=${rubberSim.ball.vy}`);

  const soccerCfg = createDefaultMatchConfig();
  soccerCfg.ballType = 'soccer';
  const soccerSim = createMatchSimulation(soccerCfg, { forceRain: false });
  soccerSim.ball.y = soccerSim.ball.radius;
  soccerSim.ball.vx = 0;
  soccerSim.ball.vz = 0;
  stepSimulation(soccerSim, 0.05, {});
  assert.equal(soccerSim.ball.spinX, 0);
  assert.equal(soccerSim.ball.spinZ, 0);
});

test('rain weather occurs at 30% probability, lasts 2 minutes (120s), and triggers puddle splashes', () => {
  assert.equal(RAIN_PROBABILITY, 0.3);
  assert.equal(RAIN_DURATION_SECONDS, 120.0);

  const cfg = createDefaultMatchConfig();
  const drySim = createMatchSimulation(cfg, { rainRoll: 0.35 });
  assert.equal(drySim.weather.isRaining, false);
  assert.equal(drySim.weather.rainTimer, 0);

  const rainSim = createMatchSimulation(cfg, { rainRoll: 0.25 });
  assert.equal(rainSim.weather.isRaining, true);
  assert.equal(rainSim.weather.rainTimer, 120.0);
  assert.ok(rainSim.weather.puddles.length >= 4, 'Rainy match should have pitch puddles');

  const pud = rainSim.weather.puddles[0];
  rainSim.ball.x = pud.x;
  rainSim.ball.z = pud.z;
  rainSim.ball.y = 0.35;
  rainSim.ball.vy = -6.0;
  stepSimulation(rainSim, 0.03, {});
  assert.ok(rainSim.events.some((e) => e.type === 'water_splash'), 'Expected water_splash event on rainy puddle bounce');

  for (let i = 0; i < 4000 && rainSim.weather.isRaining && rainSim.elapsedTime < 125; i++) {
    stepSimulation(rainSim, 0.05, {});
  }
  assert.equal(rainSim.weather.isRaining, false, 'Rain should stop after 2 minutes (120s)');
});

test('ball 15s idle respawn & 20s item expiration remain intact', () => {
  const cfg = createDefaultMatchConfig();
  cfg.enabledItems = ['giant_ball'];
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  p1.x = -8;
  p1.z = -5;

  sim.ball.x = 4.0;
  sim.ball.z = 3.0;
  sim.ball.untouchedTimer = BALL_RESPAWN_IDLE_SECONDS - 0.05;
  stepSimulation(sim, 0.05, {});
  stepSimulation(sim, 0.03, {});
  assert.equal(sim.ball.x, 0);
  assert.equal(sim.ball.z, 0);

  sim.pickupOrb.active = true;
  sim.pickupOrb.type = 'giant_ball';
  p1.x = 0;
  p1.z = 0;
  stepSimulation(sim, 0.03, {});
  assert.equal(sim.ball.scaleMultiplier, 2.1);
  assert.ok(sim.activeItems[0].remaining <= ITEM_EFFECT_DURATION);
  sim.config.itemSpawnMode = 'off';

  const startElapsed = sim.elapsedTime;
  for (let i = 0; i < 600 && sim.elapsedTime < startElapsed + 20.1; i++) {
    stepSimulation(sim, 0.05, {});
  }
  assert.equal(sim.ball.scaleMultiplier, 1.0);
});

test('triggerHeadAttack salto_curved ignites the ball on fire and launches it fast', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  npc.x = -9;
  npc.z = -5;

  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  sim.ball.x = 1.85;
  sim.ball.y = 1.25;
  sim.ball.z = 0;

  triggerHeadAttack(p1, 'salto_curved', sim.ball);
  let maxSaltoVx = 0;
  let maxHeadExtendX = 0;
  for (let i = 0; i < 20; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
    if (sim.ball.vx > maxSaltoVx) maxSaltoVx = sim.ball.vx;
    const hp = getExtendedHeadPosition(p1);
    if (hp.x - p1.x > maxHeadExtendX) maxHeadExtendX = hp.x - p1.x;
  }
  assert.ok(maxHeadExtendX > 1.1, `Expected curved neck tip ahead, got ${maxHeadExtendX}`);
  assert.equal(sim.ball.isClashedFire, true, 'Salto hit must ignite the ball on fire');
  assert.ok(sim.ball.clashFireTimer > 3.5, 'Salto fire timer should last several seconds');
  assert.ok(maxSaltoVx > 15.0, `Salto hit should fire the ball very fast, got maxSaltoVx=${maxSaltoVx}`);
});

test('4 new ball shapes: Dice cube, Ostrich Egg ellipsoid, 15s Timer Bomb, and sticky Honey Ball', () => {
  // 1. Dice
  const diceCfg = createDefaultMatchConfig();
  diceCfg.ballType = 'dice';
  const diceSim = createMatchSimulation(diceCfg, { forceRain: false });
  assert.equal(diceSim.ball.colliderType, 'box');

  // 2. Ostrich Egg
  const eggCfg = createDefaultMatchConfig();
  eggCfg.ballType = 'ostrich_egg';
  const eggSim = createMatchSimulation(eggCfg, { forceRain: false });
  assert.equal(eggSim.ball.colliderType, 'ellipsoid');

  // 3. Timer Bomb explodes every 15s
  const bombCfg = createDefaultMatchConfig();
  bombCfg.redCount = 1;
  bombCfg.blueCount = 1;
  bombCfg.ballType = 'timer_bomb';
  const bombSim = createMatchSimulation(bombCfg, { forceRain: false });
  assert.equal(bombSim.ball.bombCountdown, 15.0);
  const pBomb = bombSim.players.find((p) => p.humanSlot === 1)!;
  pBomb.x = 1.2;
  pBomb.z = 0;
  bombSim.ball.x = 0;
  bombSim.ball.z = 0;
  bombSim.ball.bombCountdown = 0.04;
  stepSimulation(bombSim, 0.05, { p1: idleInput() });
  assert.ok(bombSim.events.some((e) => e.type === 'bomb_explode'), 'Expected 15s timer bomb explosion event');
  assert.ok(pBomb.fallTimer > 0.5, '15s bomb blast should ragdoll nearby player');
  assert.ok(bombSim.ball.bombCountdown > 14.0, 'Bomb timer should reset back to 15s after explosion');

  // 4. Sticky Honey Ball adheres to player and releases when kicked
  const honeyCfg = createDefaultMatchConfig();
  honeyCfg.redCount = 1;
  honeyCfg.blueCount = 1;
  honeyCfg.ballType = 'honey_ball';
  const honeySim = createMatchSimulation(honeyCfg, { forceRain: false });
  assert.equal(honeySim.ball.isStickyBall, true);
  const pH = honeySim.players.find((p) => p.humanSlot === 1)!;
  const npcH = honeySim.players.find((p) => !p.isHuman)!;
  npcH.x = 8;
  npcH.z = 4;
  pH.x = 0;
  pH.z = 0;
  pH.facing = Math.PI / 2;
  honeySim.ball.x = 0.72;
  honeySim.ball.y = 0.45;
  honeySim.ball.z = 0;
  honeySim.ball.vx = -2.0;
  stepSimulation(honeySim, 0.03, { p1: idleInput() });
  assert.equal(honeySim.ball.stickyTargetPlayerId, pH.id, 'Honey ball should stick to player on contact');

  stepSimulation(honeySim, 0.03, { p1: { ...idleInput(), kickPressed: true } });
  for (let i = 0; i < 10; i++) {
    stepSimulation(honeySim, 0.03, { p1: idleInput() });
  }
  assert.equal(honeySim.ball.stickyTargetPlayerId, null, 'Honey ball should release when kicked');
});

test('B grabs/drops prop (walk-only + A throw 3-use break), Hold A = Super Kick, Quick X never punches, Hold X = Mega Punch', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const opp = sim.players.find((p) => !p.isHuman)!;
  opp.x = 9;
  opp.z = 5;

  // Step ~4.0s so initial pair of 2 random props drops
  for (let i = 0; i < 105; i++) {
    stepSimulation(sim, 0.04, { p1: idleInput() });
  }
  assert.equal(sim.props.length, 3, 'Expected 3 random props to drop');
  assert.ok(sim.props[0].usesRemaining >= 1);
  assert.ok(sim.propSpawnTimer > 50, 'Next prop drop batch should schedule ~60s (1 minute) later');

  // Keep ball/opp away during grab + walk-speed check
  sim.ball.x = -9;
  sim.ball.z = -5;
  sim.ball.vx = 0;
  sim.ball.vz = 0;
  opp.x = 9;
  opp.z = 5;

  // Grab prop with B (`grabPressed: true`)
  const prop = sim.props[0];
  prop.carriedByPlayerId = null;
  prop.x = 0.6;
  prop.y = 0.4;
  prop.z = 0;
  prop.vx = 0;
  prop.vy = 0;
  prop.vz = 0;
  if (sim.props[1]) {
    sim.props[1].carriedByPlayerId = null;
    sim.props[1].x = -8;
    sim.props[1].z = 5;
  }
  sim.hitstopTimer = 0;
  p1.fallTimer = 0;
  p1.ragdollBlend = 0;
  p1.punchPhase = 'none';
  p1.kickPhase = 'none';
  p1.x = 0;
  p1.z = 0;
  p1.vx = 0;
  p1.vz = 0;
  p1.facing = Math.PI / 2;

  stepSimulation(sim, 0.02, { p1: { ...idleInput(), grabPressed: true } });
  assert.equal(p1.carryingPropId, prop.id, 'B button should grab nearby prop overhead');
  assert.equal(prop.carriedByPlayerId, p1.id);

  // While carrying prop, holding runHeld stays capped at WALK_SPEED
  for (let i = 0; i < 30; i++) {
    stepSimulation(sim, 0.03, { p1: { ...idleInput(), moveX: 1, runHeld: true } });
  }
  assert.equal(p1.carryingPropId, prop.id, 'Player should still be carrying the prop');
  const carrySpeed = Math.hypot(p1.vx, p1.vz);
  assert.ok(carrySpeed <= 2.65, `Carrying prop must restrict player to walk speed (~2.4-2.57), got ${carrySpeed}`);

  // Moving ball hitting carrier forces prop drop
  sim.ball.x = p1.x + 0.55;
  sim.ball.y = 0.6;
  sim.ball.z = p1.z;
  sim.ball.vx = -6.0;
  sim.ball.vy = 0;
  sim.ball.vz = 0;
  stepSimulation(sim, 0.02, { p1: idleInput() });
  assert.equal(p1.carryingPropId, null, 'Getting hit by a moving ball must make carrier drop the prop');

  // Re-grab for A-throw test
  prop.x = p1.x + 0.5;
  prop.y = 0.4;
  prop.z = p1.z;
  prop.vx = 0;
  prop.vy = 0;
  prop.vz = 0;
  sim.ball.x = -9;
  sim.ball.z = -5;
  sim.ball.vx = 0;
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), grabPressed: true } });
  assert.equal(p1.carryingPropId, prop.id);

  // Press A to throw carried prop into opponent -> knocks opponent down & consumes 1 use (3 -> 2)
  p1.x = 0;
  p1.z = 0;
  p1.vx = 0;
  p1.vz = 0;
  p1.facing = Math.PI / 2;
  opp.x = 3.0;
  opp.z = 0;
  opp.vx = 0;
  opp.vz = 0;
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickPressed: true } });
  assert.equal(p1.carryingPropId, null, 'Pressing A must throw the carried prop');
  for (let i = 0; i < 15; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
  }
  assert.ok(opp.fallTimer > 0.5, 'Thrown prop must knock opponent down');
  assert.equal(prop.usesRemaining, 2, 'Hitting opponent with thrown prop should consume 1 of 3 uses');

  // Shatter after 3rd use
  prop.usesRemaining = 1;
  prop.carriedByPlayerId = p1.id;
  p1.carryingPropId = prop.id;
  opp.fallTimer = 0;
  opp.x = 2.6;
  opp.z = 0;
  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickPressed: true } });
  for (let i = 0; i < 15; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
  }
  assert.ok(!sim.props.some((pr) => pr.id === prop.id), 'Prop must shatter and vanish after 3rd use');

  // Quick tap X (< 0.25s) MUST NEVER punch — it triggers spin_right kick!
  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  for (let i = 0; i < 4; i++) {
    stepSimulation(sim, 0.03, { p1: { ...idleInput(), kickRightSpinPressed: i === 0, kickRightHeld: true } });
  }
  assert.equal(p1.punchPhase, 'none', 'Quick X hold (< 0.25s) must NEVER enter punch charge');
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickRightHeld: false } });
  assert.equal(p1.kickVariant, 'spin_right', 'Releasing quick X tap must trigger left-leg spin kick');
  assert.equal(p1.punchPhase, 'none', 'Quick X release must NEVER trigger punch strike');

  // Wait for kick retract to clear and isolate p1 for Hold-X charge test
  for (let i = 0; i < 20; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  p1.x = 0;
  p1.z = 0;
  p1.fallTimer = 0;
  p1.collisionStunTimer = 0;
  p1.punchPhase = 'none';
  p1.punchHoldTimer = 0;
  p1.wasPunchHeld = false;
  sim.ball.x = -9;
  sim.ball.z = -5;
  sim.ball.vx = 0;
  sim.ball.vz = 0;
  opp.x = 9;
  opp.z = 5;

  // Holding X long (>= 0.25s) charges Mega Punch and releasing launches opponent far away!
  // Ditahan kurang dari 5 detik lalu dilepas = pukulan batal
  for (let i = 0; i < 60; i++) {
    stepSimulation(sim, 0.04, { p1: { ...idleInput(), kickRightSpinPressed: i === 0, kickRightHeld: true } });
  }
  assert.equal(p1.punchPhase, 'charge');
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickRightHeld: false } });
  assert.equal(p1.punchPhase, 'none', 'Release before 5s must cancel the punch');
  p1.punchHoldTimer = 0;
  p1.wasPunchHeld = false;
  for (let i = 0; i < 130; i++) {
    stepSimulation(sim, 0.04, { p1: { ...idleInput(), kickRightHeld: true } });
  }
  assert.equal(p1.punchPhase, 'charge', 'Holding X >= 0.25s must enter punch charge');
  assert.ok(p1.punchCharge >= 0.999, `Expected full punch charge after 5s, got ${p1.punchCharge}`);

  opp.fallTimer = 0;
  opp.ragdollBlend = 0;
  opp.x = p1.x + 1.15;
  opp.z = p1.z;
  opp.vx = 0;
  opp.vz = 0;
  sim.hitstopTimer = 0;
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickRightHeld: false } });
  for (let i = 0; i < 10; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
  }
  assert.ok(opp.fallTimer > 1.0, 'Hold-X charged punch must knock opponent down');
  // vx kini dibaca dari kecepatan badan ragdoll (setelah gesekan/udara), bukan kecepatan awal
  assert.ok(opp.vx > 6.5, `Hold-X charged punch should launch opponent far away, got vx=${opp.vx}`);

  // Holding A long (>= 0.22s) charges Super Kick and releasing fires blistering shot + fire!
  for (let i = 0; i < 20; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  sim.ball.x = 1.05;
  sim.ball.y = 0.45;
  sim.ball.z = 0;
  sim.ball.vx = 0;
  sim.ball.vz = 0;
  sim.ball.isClashedFire = false;

  for (let i = 0; i < 18; i++) {
    stepSimulation(sim, 0.04, { p1: { ...idleInput(), kickPressed: i === 0, kickHeld: true } });
  }
  assert.equal(p1.kickPhase, 'super_charge', 'Holding A >= 0.22s must enter super_charge');
  assert.ok(p1.kickCharge >= 0.4, `Expected kickCharge >= 0.4, got ${p1.kickCharge}`);

  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickHeld: false } });
  assert.equal(p1.kickVariant, 'super_kick', 'Releasing held A must fire super_kick');
  for (let i = 0; i < 8; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
  }
  assert.ok(sim.ball.vx > 16.0, `Super kick must blast ball very hard, got vx=${sim.ball.vx}`);
  assert.equal(sim.ball.isClashedFire, true, 'Charged Super Kick should ignite the ball');
});

test('props are solid against ball (never vanish or clip on ball hit), block player pass-through, and NPCs grab & throw props', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  p1.x = -8;
  p1.z = -5;

  // Spawn a pair of props cleanly on the pitch
  spawnRandomPropPair(sim, ['wooden_box', 'oil_drum']);
  stepSimulation(sim, 0.03, { p1: idleInput() });
  assert.equal(sim.props.length, 2);
  const prop = sim.props[0];
  prop.x = 0;
  prop.y = 0.36;
  prop.z = 0;
  prop.vx = 0;
  prop.vy = 0;
  prop.vz = 0;
  prop.usesRemaining = 3;

  // Blast the ball straight at the prop multiple times
  sim.ball.x = -1.6;
  sim.ball.y = 0.42;
  sim.ball.z = 0;
  sim.ball.vx = 18.0;
  sim.ball.vy = 0;
  sim.ball.vz = 0;
  npc.x = 9;
  npc.z = 5;

  let bouncedBack = false;
  for (let i = 0; i < 12; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
    const sep = Math.hypot(sim.ball.x - prop.x, sim.ball.z - prop.z);
    assert.ok(sep >= sim.ball.radius + prop.radius - 0.12, `Ball must NEVER clip inside solid prop (sep=${sep})`);
    if (sim.ball.vx < 0) bouncedBack = true;
  }
  assert.equal(bouncedBack, true, 'Ball hitting solid prop must bounce off physically');
  assert.equal(prop.usesRemaining, 3, 'Ball hitting a prop must NEVER damage or destroy it');
  assert.ok(sim.props.some((pr) => pr.id === prop.id), 'Prop must remain intact after ball collision');

  // Solid collision against player walking into prop
  sim.ball.x = -9;
  sim.ball.z = 5;
  sim.ball.vx = 0;
  p1.x = -1.1;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  prop.x = 0;
  prop.y = 0.36;
  prop.z = 0;
  prop.vx = 0;
  prop.vz = 0;
  for (let i = 0; i < 20; i++) {
    stepSimulation(sim, 0.03, { p1: { ...idleInput(), moveX: 1, runHeld: false } });
    const pd = Math.hypot(p1.x - prop.x, p1.z - prop.z);
    assert.ok(pd >= 0.44 + prop.radius - 0.12, `Player must not clip through solid prop (dist=${pd})`);
  }

  // NPC AI grabs nearby loose prop and throws at opponent!
  npc.x = prop.x - 0.9;
  npc.z = prop.z;
  npc.facing = Math.PI / 2;
  npc.fallTimer = 0;
  const npcGrabDecision = computeNpcInput(sim, npc);
  assert.equal(npcGrabDecision.grabPressed, true, 'NPC should press grab near a loose prop');

  // Simulate NPC carrying prop aimed at p1 -> throws it!
  npc.carryingPropId = prop.id;
  prop.carriedByPlayerId = npc.id;
  p1.x = npc.x + 3.0;
  p1.z = npc.z;
  p1.fallTimer = 0;
  npc.facing = Math.PI / 2;
  const npcThrowDecision = computeNpcInput(sim, npc);
  assert.equal(npcThrowDecision.kickPressed, true, 'NPC carrying a prop aimed at opponent should throw it');
});

test('2-half match: setiap babak berdurasi penuh (2m + 2m), pindah babak di 120s tersisa', () => {
  const cfg = createDefaultMatchConfig();
  cfg.durationMinutes = 2;
  cfg.halves = 2;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  assert.equal(sim.currentHalf, 1);
  assert.equal(sim.timeRemaining, 240);

  sim.timeRemaining = 120.02;
  stepSimulation(sim, 0.04, {});
  assert.equal(sim.currentHalf, 2, 'Match should advance to 2nd Half at 120s remaining in a 2m-per-half match');
  assert.ok(sim.halfTimeBannerTimer > 0, 'Halftime transition banner should activate');
  assert.ok(sim.events.some((e) => e.type === 'halftime'), 'Expected halftime event');
});

test('longer forward dash travels >= 3.0m forward and sustained dash duration >= 0.45s', () => {
  assert.ok(DASH_DURATION >= 0.45, `Expected extended DASH_DURATION >= 0.45s, got ${DASH_DURATION}`);
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const npc = sim.players.find((p) => !p.isHuman)!;
  npc.x = -10;
  npc.z = -5;
  sim.ball.x = 10;
  sim.ball.z = 5;

  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;

  stepSimulation(sim, 0.02, { p1: { ...idleInput(), dashPressed: true } });
  for (let i = 0; i < 16; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  assert.ok(p1.x >= 3.0, `Expected longer forward dash >= 3.0m, traveled ${p1.x.toFixed(2)}m`);
});

test('Training mode spawns 1 player vs 1 NPC goalkeeper, soccer ball, random arena, and goalkeeper emits save', () => {
  const trainCfg = createTrainingConfig(undefined, () => 0.42);
  assert.equal(trainCfg.mode, 'training');
  assert.equal(trainCfg.ballType, 'soccer');
  assert.equal(trainCfg.redCount, 1);
  assert.equal(trainCfg.blueCount, 1);
  assert.equal(trainCfg.itemSpawnMode, 'off');

  const sim = createMatchSimulation(trainCfg, { forceRain: false });
  assert.equal(sim.players.length, 2);
  assert.equal(sim.weather.isRaining, false);
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const gk = sim.players.find((p) => !p.isHuman)!;
  assert.ok(gk.x > 6.0, `Expected goalkeeper anchored near right goal line, got x=${gk.x}`);

  // Even after stepping several seconds, Training mode must never spawn random props or center pickup orbs
  for (let i = 0; i < 120; i++) {
    stepSimulation(sim, 0.04, { p1: idleInput() });
  }
  assert.equal(sim.props.length, 0, 'Training mode must not clutter pitch with random props');
  assert.equal(sim.pickupOrb.active, false, 'Training mode must not spawn pickup orbs');

  // Test goalkeeper save reaction + 'save' event emission on shot toward Blue goal
  gk.x = PITCH_HALF_X - 1.3;
  gk.z = 0;
  gk.fallTimer = 0;
  p1.x = -8;
  p1.z = -4;
  sim.ball.x = PITCH_HALF_X - 1.8;
  sim.ball.y = 0.55;
  sim.ball.z = 0.1;
  sim.ball.vx = 10.0;
  sim.ball.vz = 0;

  let sawSave = false;
  for (let i = 0; i < 12; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
    if (sim.events.some((e) => e.type === 'save')) sawSave = true;
  }
  assert.equal(sawSave, true, 'Goalkeeper blocking/clearing a shot on goal must emit a save event');
});

test('A/X close-range angled kick reliably connects with ball and foul event fires on excessive contact', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const opp = sim.players.find((p) => !p.isHuman)!;
  opp.x = 9;
  opp.z = 5;

  // Ball slightly off-center (25 deg angle ahead-right of player facing +X) -> A kick assists and hits cleanly!
  p1.x = 0;
  p1.z = 0;
  p1.facing = Math.PI / 2;
  sim.ball.x = 1.1;
  sim.ball.y = 0.45;
  sim.ball.z = 0.48;
  sim.ball.vx = 0;
  sim.ball.vz = 0;

  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickPressed: true } });
  for (let i = 0; i < 14; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  const ballSpeed = Math.hypot(sim.ball.vx, sim.ball.vz);
  assert.ok(ballSpeed > 10.0, `Expected close-range A kick to connect easily, got ballSpeed=${ballSpeed}`);

  // Excessive contact via Hold-X Mega Punch emits a 'foul' event
  for (let i = 0; i < 16; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  sim.hitstopTimer = 0;
  p1.x = 0;
  p1.z = 0;
  p1.vx = 0;
  p1.vz = 0;
  p1.facing = Math.PI / 2;
  p1.kickPhase = 'none';
  p1.punchPhase = 'none';
  p1.punchHoldTimer = 0;
  p1.wasPunchHeld = false;
  sim.ball.x = -8;
  sim.ball.z = -4;
  sim.ball.vx = 0;
  sim.ball.vz = 0;
  for (let i = 0; i < 20; i++) {
    stepSimulation(sim, 0.04, { p1: { ...idleInput(), kickRightSpinPressed: i === 0, kickRightHeld: true } });
  }
  opp.fallTimer = 0;
  opp.ragdollBlend = 0;
  opp.x = p1.x + 1.05;
  opp.z = p1.z;
  opp.vx = 0;
  opp.vz = 0;
  sim.hitstopTimer = 0;
  let sawFoul = false;
  stepSimulation(sim, 0.02, { p1: { ...idleInput(), kickRightHeld: false } });
  if (sim.events.some((e) => e.type === 'foul')) sawFoul = true;
  for (let i = 0; i < 8; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
    if (sim.events.some((e) => e.type === 'foul')) sawFoul = true;
  }
  assert.equal(sawFoul, true, 'Mega punch knockdown should emit a foul event');
});

test('Training mode runs with unlimited time and never ends from match clock', () => {
  const trainCfg = createTrainingConfig(createDefaultMatchConfig(), () => 0.1);
  trainCfg.durationMinutes = 2;
  const sim = createMatchSimulation(trainCfg, { forceRain: false });
  const initialTimer = sim.timeRemaining;

  // Step well past 2 minutes (150s of simulation ticks)
  for (let i = 0; i < 3000; i++) {
    stepSimulation(sim, 0.05, { p1: idleInput() });
  }
  assert.equal(sim.matchEnded, false, 'Training mode must have unlimited time and never end');
  assert.equal(sim.timeRemaining, initialTimer, 'Training clock should never count down');
  assert.equal(sim.currentHalf, 1);
});

test('Story opponent customization and Boss AI specialty spawn and act cleanly', () => {
  const cfg = createDefaultMatchConfig();
  cfg.mode = 'story';
  cfg.redCount = 1;
  cfg.blueCount = 1;
  cfg.p1Team = 'red';
  cfg.storyOpponentCustom = { animal: 'crocodile', hat: 'royal_crown', mask: 'oni', cape: 'dragon_wings' };
  cfg.storyAi = { difficulty: 0.92, bossStyle: 'power_shot', opponentName: 'Rex Croc' };

  const sim = createMatchSimulation(cfg, { forceRain: false });
  const boss = sim.players.find((p) => p.team === 'blue')!;
  assert.equal(boss.custom.animal, 'crocodile');
  assert.equal(boss.custom.hat, 'royal_crown');

  for (let i = 0; i < 60; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  assert.ok(Number.isFinite(sim.ball.x) && Number.isFinite(boss.x));
});

test('4-player local multiplayer slots p1..p4 spawn independently and respond only to their own input', () => {
  const cfg = createDefaultMatchConfig();
  cfg.mode = 'coop';
  cfg.matchSubMode = 'local_multiplayer';
  cfg.localPlayerCount = 4;
  cfg.redCount = 2;
  cfg.blueCount = 2;
  cfg.p1Team = 'red';
  cfg.p2Team = 'blue';
  cfg.p3Team = 'red';
  cfg.p4Team = 'blue';

  assert.equal(cfg.p1Custom.clothes, 'solid');
  assert.equal(cfg.p2Custom.clothes, 'solid');
  assert.ok(cfg.p1Custom.shoes && cfg.p4Custom?.shoes);

  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p1 = sim.players.find((p) => p.humanSlot === 1)!;
  const p2 = sim.players.find((p) => p.humanSlot === 2)!;
  const p3 = sim.players.find((p) => p.humanSlot === 3)!;
  const p4 = sim.players.find((p) => p.humanSlot === 4)!;

  assert.ok(p1 && p2 && p3 && p4, 'All 4 local human players must spawn');
  assert.equal(sim.players.filter((p) => p.isHuman).length, 4);

  const p1StartZ = p1.z;
  const p3StartX = p3.x;
  // Drive ONLY P3 (+X) and P4 (-Z); P1 & P2 stay idle!
  for (let i = 0; i < 10; i++) {
    stepSimulation(sim, 0.03, {
      p1: idleInput(),
      p2: idleInput(),
      p3: { ...idleInput(), moveX: 1 },
      p4: { ...idleInput(), moveZ: -1 },
    });
  }
  assert.ok(p3.x > p3StartX + 0.1, 'P3 must move +X from p3 input');
  assert.ok(p4.vz < -0.5, 'P4 must move -Z from p4 input');
  assert.equal(Math.abs(p1.z - p1StartZ) < 0.01, true, 'Idle P1 must remain isolated from P3/P4 inputs');
});

test('scoreLimit triggers immediate match victory and weatherMode snow activates snow weather', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  cfg.scoreLimit = 3;
  cfg.weatherMode = 'snow';
  cfg.aiDifficulty = 'hard';
  cfg.gameSpeed = 1.25;

  const sim = createMatchSimulation(cfg);
  assert.equal(sim.weather.isSnowing, true, 'weatherMode snow must set isSnowing = true');
  assert.equal(sim.weather.isRaining, false, 'weatherMode snow must not trigger rain');

  sim.redScore = 2;
  sim.ball.x = PITCH_HALF_X + 0.85;
  sim.ball.y = 1.0;
  sim.ball.z = 0;
  sim.ball.vx = 6.0;
  stepSimulation(sim, 0.03, { p1: idleInput() });

  assert.equal(sim.redScore, 3);
  assert.equal(sim.matchEnded, true, 'Reaching scoreLimit must end match immediately');
});

test('ball hitting back of goal net is cushioned cleanly without stiff bounce back onto pitch', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });

  // Fire a fast shot deep inside the right goal into the back net (x = PITCH_HALF_X + 2.3)
  sim.ball.x = PITCH_HALF_X + 2.15;
  sim.ball.y = 1.25;
  sim.ball.z = 0;
  sim.ball.vx = 14.0;
  sim.ball.vy = 0;
  sim.ball.vz = 0;

  stepSimulation(sim, 0.03, { p1: idleInput() });
  assert.ok(
    sim.ball.vx < 0 && Math.abs(sim.ball.vx) <= 3.6,
    `Expected soft goal-net cushion (|vx| <= 3.6 after 14 m/s shot), got vx=${sim.ball.vx}`
  );
});



test('Seri di akhir babak 2: jeda 5 detik lalu golden goal, gol pertama menang', () => {
  const cfg = { ...createDefaultMatchConfig(), halves: 2 as const };
  const sim = createMatchSimulation(cfg);
  sim.currentHalf = 2;
  sim.timeRemaining = 0.01;
  stepSimulation(sim, 0.04, {});
  assert.equal(sim.goldenGoal, true, 'Seri harus memicu golden goal');
  assert.equal(sim.matchEnded, false);
  assert.ok(sim.halfTimeBannerTimer >= 4.9, 'Harus ada jeda 5 detik');
});


test('Bom meledak sekali lalu hilang, telur menetas jadi banteng, ramuan mengubah ukuran', () => {
  const sim = createMatchSimulation({ ...createDefaultMatchConfig(), halves: 2 as const });
  const human = sim.players[0];
  spawnRandomPropPair(sim, ['bomb', 'ostrich_egg', 'potion']);
  assert.equal(sim.props.length, 3);
  const bomb = sim.props.find((pr) => pr.kind === 'bomb')!;
  const egg = sim.props.find((pr) => pr.kind === 'ostrich_egg')!;
  const potion = sim.props.find((pr) => pr.kind === 'potion')!;
  // Jauhkan dari pemain; langsung jatuh ke tanah
  for (const pr of [bomb, egg, potion]) {
    pr.y = 0.36;
    pr.vy = 0;
  }
  bomb.x = 6;
  bomb.z = 4;
  egg.x = -6;
  egg.z = 4;
  potion.x = human.x;
  potion.z = human.z;
  bomb.fuse = 0.05;
  egg.fuse = 0.05;
  let explosions = 0;
  for (let i = 0; i < 6; i++) {
    stepSimulation(sim, 0.04, {});
    explosions += sim.events.filter((e) => e.type === 'bomb_explode').length;
  }
  assert.equal(explosions, 1, 'Bom harus meledak tepat sekali');
  assert.ok(!sim.props.some((pr) => pr.kind === 'bomb'), 'Bom hilang setelah meledak');
  assert.equal(sim.bulls.length, 1, 'Telur menetas jadi satu banteng');
  assert.ok(human.sizeTarget === 0.55 || human.sizeTarget === 1.7, 'Ramuan mengubah ukuran pemain');
});


test('Banteng bisa dinaiki dengan tombol grab dan tetap bergerak sendiri; telur tidak kembar', () => {
  const sim = createMatchSimulation({ ...createDefaultMatchConfig(), halves: 2 as const });
  const human = sim.players[0];
  // Gelombang acak: telur burung unta tidak boleh lebih dari satu dan jenis tidak boleh kembar
  for (let n = 0; n < 40; n++) {
    sim.props.length = 0;
    sim.bulls.length = 0;
    spawnRandomPropPair(sim);
    assert.equal(sim.props.length, 3);
    assert.ok(sim.props.filter((pr) => pr.kind === 'ostrich_egg').length <= 1, 'Telur maksimal satu');
    assert.equal(new Set(sim.props.map((pr) => pr.kind)).size, 3, 'Jenis benda tidak kembar');
  }
  sim.props.length = 0;
  spawnRandomPropPair(sim, ['ostrich_egg']);
  const egg = sim.props[0];
  egg.y = 0.36;
  egg.vy = 0;
  egg.fuse = 0.02;
  egg.x = 6;
  egg.z = 4;
  human.x = 6;
  human.z = 3;
  stepSimulation(sim, 0.04, {});
  stepSimulation(sim, 0.04, {});
  assert.equal(sim.bulls.length, 1);
  const bull = sim.bulls[0];
  bull.stun = 0.3;
  human.x = bull.x + 1.0;
  human.z = bull.z;
  stepSimulation(sim, 0.04, { p1: { ...idleInput(), grabPressed: true } });
  assert.equal(human.ridingBullId, bull.id, 'Pemain harus menunggangi banteng');
  const x0 = bull.x;
  const z0 = bull.z;
  for (let i = 0; i < 30; i++) stepSimulation(sim, 0.04, {});
  assert.ok(Math.hypot(bull.x - x0, bull.z - z0) > 0.5, 'Banteng bergerak sendiri');
  assert.ok(Math.hypot(human.x - bull.x, human.z - bull.z) < 0.01, 'Penunggang ikut banteng');
});
