import { ANIMALS, BALLS, randomNpcCustomization } from './catalog';
import {
  addRagdollImpulse,
  createRagdoll,
  getRagdollGetUpFacing,
  getRagdollHip,
  getRagdollParticleRadius,
  getRagdollTorsoVelocity,
  pokeRagdollParticle,
  RAGDOLL_PARTICLE_COUNT,
  shiftRagdoll,
  stepRagdoll,
} from './ragdoll';
import {
  ArenaPropSim,
  BullSim,
  BallSim,
  CenterItemType,
  GoalPostsState,
  HeadVariant,
  InputFrame,
  JellyPostSpring,
  KickVariant,
  MatchConfig,
  MatchSimulation,
  PlayerCustomization,
  PlayerSim,
  PropKind,
  PuddleSpot,
  TeamId,
} from './types';

export const PITCH_HALF_X = 11.2;
export const PITCH_HALF_Z = 7.4;
export const GOAL_HALF_Z = 3.15;
export const GOAL_HEIGHT = 3.5;
export const GOAL_DEPTH = 2.0;
export const POST_RADIUS = 0.15;

export const WALK_SPEED = 2.88; // +20%
export const RUN_SPEED = 5.52; // +20%
export const DASH_SPEED = 8.4;
export const DASH_DURATION = 0.48;
export const DASH_COOLDOWN = 1.0;

export const PLAYER_ACCEL = 11.5;
export const PLAYER_DECEL = 15.0;
export const GROUND_FRICTION = 13.5;
export const TURN_SPEED = 9.5;
export const GRAVITY = 19.0;
/** Lama fase bangun (detik) di akhir fallTimer: ragdoll dibekukan lalu di-blend kembali ke pose berdiri */
export const RAGDOLL_GETUP_TIME = 0.42;
/** Pemain yang terkena ragdoll lemas total 3 detik (termasuk fase bangun) */
/** Jeda sebelum babak 2 / perpanjangan golden goal (detik) */
export const HALF_BREAK_SECONDS = 2.0;

export const RAGDOLL_LIMP_TIME = 3.0;

export const KICK_PREP_TIME = 0.05;
export const KICK_EXTEND_TIME = 0.16;
export const KICK_RETRACT_TIME = 0.16;
export const KICK_SPIN_EXTEND_TIME = 0.28;
export const KICK_SPIN_RETRACT_TIME = 0.15;
export const KICK_MAX_REACH = 1.65;
export const KICK_SPIN_REACH = 0.98; // Responsive extended arc reach for A/X 180° spin kicks
export const SUPER_KICK_HOLD_THRESHOLD = 0.22; // Hold A >= 0.22s to charge super kick
export const SUPER_KICK_CHARGE_RATE = 1.25;
export const BACKFLIP_TIME = 0.34;

export const HEAD_TURN_SPEED = 16.0;
export const HEAD_PREP_TIME = 0.05;
export const HEAD_EXTEND_TIME = 0.18;
export const HEAD_RETRACT_TIME = 0.18;
export const HEAD_SPIN_EXTEND_TIME = 0.26;
export const HEAD_SPIN_RETRACT_TIME = 0.16;
export const SALTO_EXTEND_TIME = 0.30;
export const NECK_BASE_Y = 0.96;
export const NECK_BASE_LEN = 0.36;
export const NECK_MAX_EXTEND = 1.48;

export const BALL_RESPAWN_IDLE_SECONDS = 15.0;
export const ITEM_EFFECT_DURATION = 20.0;
export const ITEM_RESPAWN_COOLDOWN = 60.0;

export const RAIN_PROBABILITY = 0.3; // 30% chance of rain per match
export const RAIN_DURATION_SECONDS = 120.0; // 2 minutes

export const TIMER_BOMB_INTERVAL = 15.0;
export const PROP_SPAWN_INTERVAL = 60.0; // 3 random objects drop every 1 minute
export const PROP_INITIAL_SPAWN_DELAY = 3.5;
export const PROP_MAX_USES = 3;
export const PROP_KINDS: PropKind[] = ['wooden_chair', 'wooden_box', 'oil_drum', 'water_gallon'];
/** Semua jenis benda yang bisa jatuh dari langit (termasuk bom, ramuan, telur burung unta) */
export const SPAWN_PROP_KINDS: PropKind[] = [...PROP_KINDS, 'bomb', 'potion', 'ostrich_egg'];
export const BULL_DURATION = 20.0;
export const PUNCH_FULL_HOLD_SECONDS = 5.0;
export const PUNCH_HOLD_THRESHOLD = 0.25; // Must hold X >= 0.25s to charge punch (tapping X never punches)
export const PUNCH_CHARGE_RATE = 1 / (PUNCH_FULL_HOLD_SECONDS - PUNCH_HOLD_THRESHOLD); // penuh setelah X ditahan 5 detik; kurang dari itu pukulan batal
export const PUNCH_STRIKE_TIME = 0.22;
export const PUNCH_RECOVER_TIME = 0.16;

function makeSpring(): JellyPostSpring {
  return { dispX: 0, dispY: 0, dispZ: 0, velX: 0, velY: 0, velZ: 0 };
}

export function createGoalPostsState(): GoalPostsState {
  return {
    leftGoal: { leftPost: makeSpring(), rightPost: makeSpring(), crossbar: makeSpring() },
    rightGoal: { leftPost: makeSpring(), rightPost: makeSpring(), crossbar: makeSpring() },
  };
}

function updateJellySpring(s: JellyPostSpring, dt: number) {
  const k = 115;
  const damp = 8.5;
  s.velX += (-k * s.dispX - damp * s.velX) * dt;
  s.velY += (-k * s.dispY - damp * s.velY) * dt;
  s.velZ += (-k * s.dispZ - damp * s.velZ) * dt;
  s.dispX += s.velX * dt;
  s.dispY += s.velY * dt;
  s.dispZ += s.velZ * dt;
}

export function normalizeAngle(a: number): number {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

export function createBallSim(config: MatchConfig): BallSim {
  const spec = BALLS.find((b) => b.id === config.ballType) ?? BALLS[0];
  const initHalfY =
    spec.shape === 'cylinder' || spec.shape === 'disc'
      ? (spec.cylinderHeight ?? 0.2) * 0.5
      : spec.radius;

  return {
    x: 0,
    y: initHalfY + 0.6,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    rotX: 0,
    rotY: 0,
    rotZ: 0,
    spinX: 0,
    spinY: 0,
    spinZ: 0,
    radius: spec.radius,
    mass: spec.mass,
    restitution: spec.restitution,
    airDrag: spec.airDrag,
    groundFriction: spec.groundFriction,
    shape: spec.shape,
    colliderType: spec.colliderType,
    prolateScaleZ: spec.prolateScaleZ ?? 1,
    cylinderHeight: spec.cylinderHeight ?? spec.radius * 2,
    sliding: Boolean(spec.sliding),
    untouchedTimer: 0,
    lastTouchTeam: null,
    lastTouchPlayerId: null,
    isClashedFire: false,
    clashFireTimer: 0,
    scaleMultiplier: 1,
    isBombArmed: false,
    isJelly10x: false,
    hitFlashTimer: 0,
    bombCountdown: spec.id === 'timer_bomb' ? TIMER_BOMB_INTERVAL : 0,
    isStickyBall: spec.id === 'honey_ball',
    stickyTargetPlayerId: null,
    stickyTimer: 0,
    stickyCooldown: 0,
  };
}

function createPlayerSim(
  id: string,
  team: TeamId,
  isHuman: boolean,
  humanSlot: 0 | 1 | 2 | 3 | 4,
  custom: PlayerCustomization,
  x: number,
  z: number,
  facing: number
): PlayerSim {
  return {
    id,
    team,
    isHuman,
    humanSlot,
    custom,
    x,
    y: 0,
    z,
    vx: 0,
    vy: 0,
    vz: 0,
    facing,
    turnRateVisual: 0,
    animState: 'idle',
    walkCycle: 0,
    squashX: 1,
    squashY: 1,
    kickPhase: 'none',
    kickTimer: 0,
    kickVariant: 'forward',
    kickLeg: 'right',
    kickStretch: 0,
    kickSpinAngle: 0,
    kickSpinDir: 0,
    kickTargetDirX: Math.sin(facing),
    kickTargetDirZ: Math.cos(facing),
    kickPendingTurn: 0,
    kickHitApplied: false,
    kickHoldTimer: 0,
    wasKickHeld: false,
    kickCharge: 0,
    backflipAngle: 0,
    headPhase: 'none',
    headTimer: 0,
    headVariant: 'forward',
    neckStretch: 0,
    neckCurve: 0,
    headSpinAngle: 0,
    headSpinDir: 0,
    saltoAngle: 0,
    headTargetDirX: Math.sin(facing),
    headTargetDirY: 0,
    headTargetDirZ: Math.cos(facing),
    headDesiredFacing: facing,
    headHitApplied: false,
    dashTimer: 0,
    dashCooldown: 0,
    ridingBullId: null,
    sizeScale: 1,
    sizeTarget: 1,
    sizeTimer: 0,
    fallTimer: 0,
    ragdollBlend: 0,
    ragdollPitch: 0,
    ragdollRoll: 0,
    ragdollVelPitch: 0,
    ragdollVelRoll: 0,
    ragdollArmL: 0,
    ragdollArmR: 0,
    ragdollLegL: 0,
    ragdollLegR: 0,
    ragdollNeck: 0,
    ragdollHeadRoll: 0,
    ragdoll: null,
    collisionStunTimer: 0,
    ghostAttachedTimer: 0,
    carryingPropId: null,
    punchPhase: 'none',
    punchTimer: 0,
    punchCharge: 0,
    punchHitApplied: false,
    wasPunchHeld: false,
    punchHoldTimer: 0,
  };
}

function spawnFormationPositions(team: TeamId, count: number): Array<{ x: number; z: number }> {
  const dir = team === 'red' ? -1 : 1;
  const positions: Array<{ x: number; z: number }> = [];
  for (let i = 0; i < count; i++) {
    const lane = count === 1 ? 0 : (i / (count - 1) - 0.5) * 2;
    const depth = i === 0 ? 3.4 : 5.8 + (i % 2) * 1.5;
    positions.push({
      x: dir * depth,
      z: lane * 3.4,
    });
  }
  return positions;
}

const DEFAULT_RAIN_PUDDLES: PuddleSpot[] = [
  { x: -4.8, z: -2.6, radius: 1.5 },
  { x: 4.5, z: 2.9, radius: 1.65 },
  { x: -1.4, z: 3.4, radius: 1.35 },
  { x: 2.2, z: -3.2, radius: 1.45 },
  { x: 0.3, z: 0.2, radius: 1.2 },
];

/**
 * Jam yang ditampilkan di HUD. Dengan 2 babak, jam dihitung per babak sehingga babak ke-2
 * dimulai dari waktu yang sama dengan babak ke-1 (mis. 2:30 -> 0:00 di kedua babak).
 */
export function getDisplayClock(sim: Pick<MatchSimulation, 'config' | 'timeRemaining' | 'currentHalf'>): number {
  const halves = sim.config.halves ?? 2;
  if (halves !== 2 || sim.config.mode === 'training') return sim.timeRemaining;
  const halfLen = sim.config.durationMinutes * 60;
  return sim.currentHalf === 1 ? Math.max(0, sim.timeRemaining - halfLen) : Math.min(halfLen, sim.timeRemaining);
}

export function createMatchSimulation(
  config: MatchConfig,
  options?: { forceRain?: boolean; rainRoll?: number }
): MatchSimulation {
  const players: PlayerSim[] = [];
  const localHumans = Math.max(
    1,
    Math.min(
      4,
      config.localPlayerCount ?? (config.mode === 'coop' || config.mode === 'lan' ? 2 : 1)
    )
  );
  const isTraining = config.mode === 'training';

  interface HumanSlotAssign {
    slot: 1 | 2 | 3 | 4;
    team: TeamId;
    custom: PlayerCustomization;
  }
  const humanAssignments: HumanSlotAssign[] = [
    { slot: 1, team: config.p1Team, custom: { ...config.p1Custom } },
  ];
  if (!isTraining && localHumans >= 2) {
    humanAssignments.push({ slot: 2, team: config.p2Team, custom: { ...config.p2Custom } });
  }
  if (!isTraining && localHumans >= 3) {
    humanAssignments.push({
      slot: 3,
      team: config.p3Team ?? 'red',
      custom: { ...(config.p3Custom ?? randomNpcCustomization(21)) },
    });
  }
  if (!isTraining && localHumans >= 4) {
    humanAssignments.push({
      slot: 4,
      team: config.p4Team ?? 'blue',
      custom: { ...(config.p4Custom ?? randomNpcCustomization(37)) },
    });
  }

  const redHumans = humanAssignments.filter((h) => h.team === 'red');
  const blueHumans = humanAssignments.filter((h) => h.team === 'blue');
  const effectiveRedCount = Math.max(config.redCount, redHumans.length);
  const effectiveBlueCount = Math.max(config.blueCount, blueHumans.length);

  const redPos = spawnFormationPositions('red', effectiveRedCount);
  const bluePos = spawnFormationPositions('blue', effectiveBlueCount);

  for (let i = 0; i < effectiveRedCount; i++) {
    let isHuman = false;
    let slot: 0 | 1 | 2 | 3 | 4 = 0;
    let custom = randomNpcCustomization(i + 1);
    const assigned = redHumans[i];
    if (assigned) {
      isHuman = true;
      slot = assigned.slot;
      custom = assigned.custom;
    } else if (config.mode === 'story' && config.storyOpponentCustom && config.p1Team !== 'red' && i === 0) {
      custom = { ...config.storyOpponentCustom };
    }
    const spawnX = isTraining && !isHuman ? -(PITCH_HALF_X - 1.35) : redPos[i].x;
    const spawnZ = isTraining && !isHuman ? 0 : redPos[i].z;
    if (!isHuman && config.teamCustoms?.[`red_${i}`]) custom = { ...config.teamCustoms[`red_${i}`] };
    const redSim = createPlayerSim(`red_${i}`, 'red', isHuman, slot, custom, spawnX, spawnZ, Math.PI / 2);
    redSim.stats = config.playerStats?.[`red_${i}`];
    players.push(redSim);
  }

  for (let i = 0; i < effectiveBlueCount; i++) {
    let isHuman = false;
    let slot: 0 | 1 | 2 | 3 | 4 = 0;
    let custom = randomNpcCustomization(i + 13);
    const assigned = blueHumans[i];
    if (assigned) {
      isHuman = true;
      slot = assigned.slot;
      custom = assigned.custom;
    } else if (config.mode === 'story' && config.storyOpponentCustom && config.p1Team !== 'blue' && i === 0) {
      custom = { ...config.storyOpponentCustom };
    }
    const spawnX = isTraining && !isHuman ? PITCH_HALF_X - 1.35 : bluePos[i].x;
    const spawnZ = isTraining && !isHuman ? 0 : bluePos[i].z;
    if (!isHuman && config.teamCustoms?.[`blue_${i}`]) custom = { ...config.teamCustoms[`blue_${i}`] };
    const blueSim = createPlayerSim(`blue_${i}`, 'blue', isHuman, slot, custom, spawnX, spawnZ, -Math.PI / 2);
    blueSim.stats = config.playerStats?.[`blue_${i}`];
    players.push(blueSim);
  }

  const hasItems = !isTraining && config.itemSpawnMode !== 'off' && config.enabledItems.length > 0;
  const firstItem: CenterItemType = hasItems ? config.enabledItems[0] : 'fire_power';

  const roll = options?.rainRoll ?? Math.random();
  const wMode = config.weatherMode ?? 'auto';
  const hasRain =
    options?.forceRain !== undefined
      ? options.forceRain
      : isTraining
        ? false
        : wMode === 'rain'
          ? true
          : wMode === 'sunny' || wMode === 'snow'
            ? false
            : roll < RAIN_PROBABILITY;
  const isSnowing = options?.forceRain !== undefined ? false : !isTraining && wMode === 'snow';
  const propsAllowed = !isTraining && config.propsEnabled !== false;

  return {
    config,
    players,
    ball: createBallSim(config),
    goalPosts: createGoalPostsState(),
    pickupOrb: {
      active: false,
      type: firstItem,
      x: 0,
      y: 0.75,
      z: 0,
      respawnTimer: hasItems ? ITEM_RESPAWN_COOLDOWN : 999999,
      bobPhase: 0,
    },
    activeItems: [],
    meteors: [],
    weather: {
      hasRainInMatch: hasRain,
      isRaining: hasRain,
      isSnowing,
      rainTimer: hasRain ? RAIN_DURATION_SECONDS : 0,
      wetness: hasRain ? 0.35 : 0,
      puddles: DEFAULT_RAIN_PUDDLES.map((p) => ({ ...p })),
    },
    props: [],
    bulls: [],
    propSpawnTimer: propsAllowed ? PROP_INITIAL_SPAWN_DELAY : 999999,
    propBatchCount: 0,
    redScore: 0,
    blueScore: 0,
    // Setiap babak berdurasi penuh durationMinutes (babak 2 sama dengan babak 1)
    timeRemaining: config.durationMinutes * 60 * (config.mode !== 'training' && (config.halves ?? 2) === 2 ? 2 : 1),
    elapsedTime: 0,
    currentHalf: 1,
    halfTimeBannerTimer: 0,
    goldenGoal: false,
    goalCelebrationTimer: 0,
    lastScoringTeam: null,
    hitstopTimer: 0,
    cameraTrauma: 0,
    cameraZoomPulse: 0,
    matchEnded: false,
    lastKickCollisionTick: null,
    events: [],
  };
}

export function resetPositionsForKickoff(sim: MatchSimulation) {
  const redPlayers = sim.players.filter((p) => p.team === 'red');
  const bluePlayers = sim.players.filter((p) => p.team === 'blue');
  const redPos = spawnFormationPositions('red', redPlayers.length);
  const bluePos = spawnFormationPositions('blue', bluePlayers.length);

  for (const pr of sim.props) {
    if (pr.carriedByPlayerId) {
      pr.carriedByPlayerId = null;
      pr.y = Math.max(0.38, pr.y);
      pr.vx = 0;
      pr.vy = 0;
      pr.vz = 0;
      pr.thrownActive = false;
    }
  }

  const resetPlayer = (p: PlayerSim, pos: { x: number; z: number }, facing: number) => {
    p.x = pos.x;
    p.z = pos.z;
    p.y = 0;
    p.vx = 0;
    p.vy = 0;
    p.vz = 0;
    p.facing = facing;
    p.fallTimer = 0;
    p.ragdollBlend = 0;
    p.ragdollPitch = 0;
    p.ragdollRoll = 0;
    p.ragdollVelPitch = 0;
    p.ragdollVelRoll = 0;
    p.ragdollArmL = 0;
    p.ragdollArmR = 0;
    p.ragdollLegL = 0;
    p.ragdollLegR = 0;
    p.ragdollNeck = 0;
    p.ragdollHeadRoll = 0;
    p.ragdoll = null;
    p.kickPhase = 'none';
    p.kickStretch = 0;
    p.kickSpinAngle = 0;
    p.kickSpinDir = 0;
    p.kickHoldTimer = 0;
    p.wasKickHeld = false;
    p.kickCharge = 0;
    p.backflipAngle = 0;
    p.headPhase = 'none';
    p.neckStretch = 0;
    p.neckCurve = 0;
    p.headSpinAngle = 0;
    p.headSpinDir = 0;
    p.saltoAngle = 0;
    p.carryingPropId = null;
    p.punchPhase = 'none';
    p.punchTimer = 0;
    p.punchCharge = 0;
    p.punchHitApplied = false;
    p.wasPunchHeld = false;
    p.punchHoldTimer = 0;
  };

  const isTraining = sim.config.mode === 'training';
  redPlayers.forEach((p, idx) =>
    resetPlayer(
      p,
      isTraining && !p.isHuman ? { x: -(PITCH_HALF_X - 1.35), z: 0 } : redPos[idx],
      Math.PI / 2
    )
  );
  bluePlayers.forEach((p, idx) =>
    resetPlayer(
      p,
      isTraining && !p.isHuman ? { x: PITCH_HALF_X - 1.35, z: 0 } : bluePos[idx],
      -Math.PI / 2
    )
  );

  const freshBall = createBallSim(sim.config);
  sim.ball.x = 0;
  sim.ball.y = freshBall.y;
  sim.ball.z = 0;
  sim.ball.vx = 0;
  sim.ball.vy = 0;
  sim.ball.vz = 0;
  sim.ball.rotX = 0;
  sim.ball.rotY = 0;
  sim.ball.rotZ = 0;
  sim.ball.spinX = 0;
  sim.ball.spinY = 0;
  sim.ball.spinZ = 0;
  sim.ball.untouchedTimer = 0;
  sim.ball.isClashedFire = false;
  sim.ball.clashFireTimer = 0;
  sim.ball.stickyTargetPlayerId = null;
  sim.ball.stickyTimer = 0;
  sim.ball.stickyCooldown = 0;
  if (sim.config.ballType === 'timer_bomb') {
    sim.ball.bombCountdown = TIMER_BOMB_INTERVAL;
  }
  sim.events.push({ type: 'whistle' });
}

export function getExtendedFootPosition(p: PlayerSim): { x: number; y: number; z: number } {
  const isSpin = p.kickVariant === 'spin_left' || p.kickVariant === 'spin_right';
  const reachScale = isSpin ? KICK_SPIN_REACH : KICK_MAX_REACH;
  const reach = 0.42 + Math.max(0, p.kickStretch) * reachScale;

  if (isSpin) {
    const worldAngle = p.facing + p.kickSpinAngle * p.kickSpinDir;
    return {
      x: p.x + Math.sin(worldAngle) * reach,
      y: p.y + 0.45,
      z: p.z + Math.cos(worldAngle) * reach,
    };
  }
  return {
    x: p.x + p.kickTargetDirX * reach,
    y: p.y + (p.kickVariant === 'jump_kick' ? 0.58 : 0.42),
    z: p.z + p.kickTargetDirZ * reach,
  };
}

/**
 * Multi-segment leg collider samples along the active kicking leg (hip, thigh, calf/betis, foot)
 * so any part of the leg—especially the calf (betis) and shin—can kick the ball cleanly.
 */
export function getKickingLegSamplePoints(
  p: PlayerSim
): Array<{ x: number; y: number; z: number; radius: number }> {
  const isSpin = p.kickVariant === 'spin_left' || p.kickVariant === 'spin_right';
  const isBackflip = p.kickVariant === 'backflip_front_fire' || p.kickVariant === 'backflip_lob';
  const reachScale = isSpin ? KICK_SPIN_REACH : KICK_MAX_REACH;
  const fullReach = 0.45 + Math.max(0, p.kickStretch) * reachScale;

  const dirX = isSpin
    ? Math.sin(p.facing + p.kickSpinAngle * p.kickSpinDir)
    : p.kickTargetDirX;
  const dirZ = isSpin
    ? Math.cos(p.facing + p.kickSpinAngle * p.kickSpinDir)
    : p.kickTargetDirZ;

  // Vertical swing arc for leg whip or aerial backflip
  const spinArcLift = isSpin ? Math.max(0.06, Math.cos(p.kickSpinAngle * 0.5) * 0.24) : 0;
  const flipLift = isBackflip ? Math.max(0.25, Math.sin(p.backflipAngle * 0.5) * 0.85) : 0;
  const baseHipY = p.y + (isBackflip ? 0.55 : 0.36);
  const tipY = p.y + (isBackflip ? 0.84 + flipLift : p.kickVariant === 'jump_kick' || p.kickVariant === 'super_kick' ? 0.58 : 0.44 + spinArcLift);

  const fractions = [0.22, 0.48, 0.74, 1.0];
  const radii = isBackflip ? [0.54, 0.6, 0.66, 0.74] : [0.48, 0.54, 0.6, 0.66];
  return fractions.map((t, idx) => ({
    x: p.x + dirX * (fullReach * t),
    y: baseHipY + (tipY - baseHipY) * t,
    z: p.z + dirZ * (fullReach * t),
    radius: radii[idx],
  }));
}

export interface NeckPoseParams {
  pivotYaw: number;
  pivotPitch: number;
  segPitch: number;
  segLen: number;
  headRoll: number;
  bodyPitch: number;
  bodyYaw: number;
  bodyOffsetY: number;
}

/**
 * Shared forward-kinematic pose for the 4-segment articulated curved rubber neck.
 * Used identically by both the 3D character renderer (`models.ts`) and physics hitbox (`getExtendedHeadPosition`).
 */
export function computeNeckPose(p: PlayerSim): NeckPoseParams {
  const totalLen = NECK_BASE_LEN + Math.max(0, p.neckStretch) * NECK_MAX_EXTEND;
  const segLen = totalLen / 4;

  const isSalto = p.headPhase !== 'none' && p.headVariant === 'salto_curved';
  const isBackflipFront = p.kickPhase !== 'none' && p.kickVariant === 'backflip_front_fire';
  const isBackflipBack = p.kickPhase !== 'none' && p.kickVariant === 'backflip_lob';
  const forwardLean = p.animState === 'run' ? 0.18 : p.animState === 'normal_walk' ? 0.08 : 0;
  const kickLean =
    p.kickPhase === 'super_charge'
      ? -0.14
      : p.kickPhase === 'prep'
        ? -0.22
        : p.kickPhase === 'extend' && (p.kickVariant === 'forward' || p.kickVariant === 'super_kick')
          ? -0.2
          : 0;

  const flipAngle = isBackflipFront ? p.backflipAngle : isBackflipBack ? -p.backflipAngle : 0;
  const bodyOffsetY = isSalto
    ? Math.sin(p.saltoAngle * 0.5) * 0.24
    : isBackflipFront || isBackflipBack
      ? Math.sin(p.backflipAngle * 0.5) * 0.22
      : 0;
  // Body NEVER rotates on Y when kicking! Only the kicking leg swings 180°.
  const bodyYaw = 0;
  const bodyPitch = forwardLean + kickLean + (isSalto ? p.saltoAngle : 0) + flipAngle;

  if (p.headPhase === 'none' || p.neckStretch <= 0.01) {
    return {
      pivotYaw: 0,
      pivotPitch: 0,
      segPitch: 0,
      segLen,
      headRoll: 0,
      bodyPitch,
      bodyYaw,
      bodyOffsetY,
    };
  }

  if (p.headVariant === 'spin_left' || p.headVariant === 'spin_right') {
    const pivotYaw = p.headSpinAngle * p.headSpinDir;
    const pivotPitch = 1.52 * Math.min(1, p.neckStretch);
    const segPitch = 0.09 * p.neckCurve * p.neckStretch;
    const headRoll = -0.35 * p.headSpinDir * p.neckStretch;
    return { pivotYaw, pivotPitch, segPitch, segLen, headRoll, bodyPitch, bodyYaw, bodyOffsetY };
  }

  if (p.headVariant === 'salto_curved') {
    // Salto with straight-ahead long curved neck arching forward
    const pivotYaw = 0;
    const pivotPitch = 0.34 + 0.52 * p.neckStretch;
    const segPitch = 0.23 * p.neckCurve * p.neckStretch;
    return { pivotYaw, pivotPitch, segPitch, segLen, headRoll: 0, bodyPitch, bodyYaw, bodyOffsetY };
  }

  // Directional heading (left / right / forward / backward) — exact inverse of root.rotation.y = p.facing
  const cosF = Math.cos(p.facing);
  const sinF = Math.sin(p.facing);
  const localX = p.headTargetDirX * cosF - p.headTargetDirZ * sinF;
  const localZ = p.headTargetDirX * sinF + p.headTargetDirZ * cosF;
  const pivotYaw = Math.atan2(localX, localZ);
  const targetDrop = Math.max(0.45, Math.min(1.56, 1.34 - p.headTargetDirY * 0.65));
  const pivotPitch = targetDrop * Math.min(1, p.neckStretch);
  const segPitch = 0.14 * p.neckCurve * p.neckStretch;
  const headRoll = p.headVariant === 'left' ? -0.32 * p.neckStretch : p.headVariant === 'right' ? 0.32 * p.neckStretch : 0;

  return { pivotYaw, pivotPitch, segPitch, segLen, headRoll, bodyPitch, bodyYaw, bodyOffsetY };
}

/**
 * Computes exact world coordinates of the extended head bone tip using the 4-segment neck chain.
 */
export function getExtendedHeadPosition(p: PlayerSim): { x: number; y: number; z: number } {
  const pose = computeNeckPose(p);

  // Start at top of neck inside neckPivot-local frame, accumulating 4 curved segments along +Y/+Z plane
  let ny = 0;
  let nz = 0;
  let pitchAcc = pose.pivotPitch;
  for (let i = 0; i < 4; i++) {
    pitchAcc += pose.segPitch;
    ny += Math.cos(pitchAcc) * pose.segLen;
    nz += Math.sin(pitchAcc) * pose.segLen;
  }

  // Rotate neck-local point by pivotYaw around Y, then add neckPivot offset (0, NECK_BASE_Y, 0) in bodyGroup
  const cy = Math.cos(pose.pivotYaw);
  const sy = Math.sin(pose.pivotYaw);
  const bx = nz * sy;
  const by = NECK_BASE_Y + ny;
  const bz = nz * cy;

  // Apply bodyGroup rotation: rotation.y = bodyYaw, rotation.x = bodyPitch (Three.js default XYZ order: X then Y)
  const cx = Math.cos(pose.bodyPitch);
  const sx = Math.sin(pose.bodyPitch);
  const px = bx;
  const py = by * cx - bz * sx;
  const pz = by * sx + bz * cx;

  const cby = Math.cos(pose.bodyYaw);
  const sby = Math.sin(pose.bodyYaw);
  const gx = px * cby + pz * sby;
  const gy = pose.bodyOffsetY + py;
  const gz = -px * sby + pz * cby;

  // Apply root.rotation.y = p.facing and root.position = (p.x, p.y, p.z)
  const cf = Math.cos(p.facing);
  const sf = Math.sin(p.facing);
  return {
    x: p.x + gx * cf + gz * sf,
    y: p.y + gy,
    z: p.z - gx * sf + gz * cf,
  };
}

export function hasActiveItem(sim: MatchSimulation, type: CenterItemType): boolean {
  return sim.activeItems.some((item) => item.type === type && item.remaining > 0);
}

export function triggerJump(p: PlayerSim) {
  if (p.fallTimer > 0 || p.y > 0.05) return;
  p.vy = 6.7 * (p.stats?.jump ?? 1);
  p.squashX = 0.84;
  p.squashY = 1.22;
}

export function triggerKick(p: PlayerSim, variant: KickVariant = 'spin_left', ball?: BallSim) {
  if (p.fallTimer > 0 || (p.kickPhase !== 'none' && p.kickPhase !== 'super_charge')) return;

  // Soft close-range aim assist for spin/super/backflip kicks when ball is mostly in front
  if (
    ball &&
    (variant === 'spin_left' ||
      variant === 'spin_right' ||
      variant === 'super_kick' ||
      variant === 'backflip_front_fire' ||
      variant === 'backflip_lob')
  ) {
    const bdx = ball.x - p.x;
    const bdz = ball.z - p.z;
    const bDist = Math.hypot(bdx, bdz);
    if (bDist > 0.08 && bDist < 2.2 * (p.stats?.control ?? 1)) {
      const fX = Math.sin(p.facing);
      const fZ = Math.cos(p.facing);
      const dot = (bdx / bDist) * fX + (bdz / bDist) * fZ;
      if (dot > 0.48) {
        const ballYaw = Math.atan2(bdx, bdz);
        const turnDelta = normalizeAngle(ballYaw - p.facing);
        const maxTurn = 0.42 * (p.stats?.accuracy ?? 1);
        const clampedTurn = Math.max(-maxTurn, Math.min(maxTurn, turnDelta));
        p.facing = normalizeAngle(p.facing + clampedTurn);
      }
    }
  }

  const fwdX = Math.sin(p.facing);
  const fwdZ = Math.cos(p.facing);

  p.kickVariant = variant;
  p.kickPhase = 'prep';
  p.kickTimer = 0;
  p.kickHitApplied = false;
  p.kickTargetDirX = fwdX;
  p.kickTargetDirZ = fwdZ;
  p.kickSpinAngle = 0;
  p.kickSpinDir = 0;
  p.kickPendingTurn = 0;
  p.backflipAngle = 0;
  p.squashX = 1.18;
  p.squashY = 0.84;

  if (variant === 'spin_left') {
    // A Tap: Right leg 180° sweep right-to-left (-PI/2 -> +PI/2) while torso stays steady
    p.kickLeg = 'right';
    p.kickSpinDir = 1;
    p.kickSpinAngle = -Math.PI * 0.5;
    p.kickStretch = 0.48;
    p.kickPhase = 'extend';
  } else if (variant === 'spin_right') {
    // X Tap: Left leg 180° sweep left-to-right (-PI/2 -> +PI/2) while torso stays steady
    p.kickLeg = 'left';
    p.kickSpinDir = -1;
    p.kickSpinAngle = -Math.PI * 0.5;
    p.kickStretch = 0.48;
    p.kickPhase = 'extend';
  } else if (variant === 'super_kick') {
    // Hold-A Super Kick release
    p.kickLeg = 'right';
    p.kickPhase = 'extend';
    p.vx += fwdX * (2.6 + p.kickCharge * 2.4);
    p.vz += fwdZ * (2.6 + p.kickCharge * 2.4);
    p.squashX = 1.28;
    p.squashY = 0.8;
  } else if (variant === 'backflip_front_fire') {
    // Jump + A: Front-leg forward flip-kick that ignites the ball on fire!
    p.kickLeg = 'right';
    p.kickPhase = 'extend';
    p.vy = Math.max(p.vy, 5.2);
    p.vx += fwdX * 2.2;
    p.vz += fwdZ * 2.2;
  } else if (variant === 'backflip_lob') {
    // Jump + X: Backward backflip that launches the ball high!
    p.kickLeg = 'left';
    p.kickPhase = 'extend';
    p.vy = Math.max(p.vy, 5.4);
  } else if (variant === 'left') {
    p.kickLeg = 'left';
    const ang = p.facing + Math.PI * 0.5;
    p.kickTargetDirX = Math.sin(ang);
    p.kickTargetDirZ = Math.cos(ang);
  } else if (variant === 'right') {
    p.kickLeg = 'right';
    const ang = p.facing - Math.PI * 0.5;
    p.kickTargetDirX = Math.sin(ang);
    p.kickTargetDirZ = Math.cos(ang);
  } else if (variant === 'diag_left') {
    p.kickLeg = 'left';
    const ang = p.facing + Math.PI * 0.25;
    p.kickTargetDirX = Math.sin(ang);
    p.kickTargetDirZ = Math.cos(ang);
  } else if (variant === 'diag_right') {
    p.kickLeg = 'right';
    const ang = p.facing - Math.PI * 0.25;
    p.kickTargetDirX = Math.sin(ang);
    p.kickTargetDirZ = Math.cos(ang);
  } else if (variant === 'backward') {
    p.kickLeg = 'right';
    p.kickPendingTurn = normalizeAngle(p.facing + Math.PI);
  } else if (variant === 'jump_kick') {
    p.kickLeg = 'right';
    p.kickPhase = 'extend';
    p.vy = p.y <= 0.05 ? 6.9 : Math.max(p.vy, 3.2);
    p.vx += fwdX * 2.4;
    p.vz += fwdZ * 2.4;
  } else {
    // Straight body-aligned forward kick
    p.kickLeg = 'right';
  }
  void ball;
}

export function triggerHeadAttack(p: PlayerSim, variant: HeadVariant, ball?: BallSim) {
  if (p.fallTimer > 0 || p.headPhase !== 'none') return;

  const fwdX = Math.sin(p.facing);
  const fwdZ = Math.cos(p.facing);

  p.headVariant = variant;
  p.headTimer = 0;
  p.headHitApplied = false;
  p.neckStretch = 0;
  p.neckCurve = 0.45;
  p.headSpinAngle = 0;
  p.headSpinDir = 0;
  p.headTargetDirX = fwdX;
  p.headTargetDirY = 0;
  p.headTargetDirZ = fwdZ;
  p.headDesiredFacing = p.facing;
  p.squashX = 0.9;
  p.squashY = 1.14;

  if (variant === 'spin_left') {
    // L Button: Long rubber neck + head rotates 360° to the LEFT (+1 CCW)
    p.headSpinDir = 1;
    p.headPhase = 'extend';
    p.neckCurve = 0.65;
  } else if (variant === 'spin_right') {
    // R Button: Long rubber neck + head rotates 360° to the RIGHT (-1 CW)
    p.headSpinDir = -1;
    p.headPhase = 'extend';
    p.neckCurve = 0.65;
  } else if (variant === 'salto_curved') {
    // X Button: Salto flip with long curved straight-ahead rubber neck!
    p.headPhase = 'extend';
    p.neckCurve = 1.0;
    p.saltoAngle = 0;
    p.vy = p.y <= 0.05 ? 6.9 : Math.max(p.vy, 3.2);
    p.vx += fwdX * 2.5;
    p.vz += fwdZ * 2.5;
  } else if (variant === 'left') {
    p.headPhase = 'prep';
    p.neckCurve = 0.85;
    const ang = p.facing + Math.PI * 0.45;
    p.headTargetDirX = Math.sin(ang);
    p.headTargetDirZ = Math.cos(ang);
  } else if (variant === 'right') {
    p.headPhase = 'prep';
    p.neckCurve = 0.85;
    const ang = p.facing - Math.PI * 0.45;
    p.headTargetDirX = Math.sin(ang);
    p.headTargetDirZ = Math.cos(ang);
  } else if (variant === 'backward') {
    // Rotate character toward rear first, then extend neck toward ball
    p.headPhase = 'turn_first';
    p.neckCurve = 0.75;
    const rearAng = ball
      ? Math.atan2(ball.x - p.x, ball.z - p.z)
      : normalizeAngle(p.facing + Math.PI);
    p.headDesiredFacing = rearAng;
    p.headTargetDirX = Math.sin(rearAng);
    p.headTargetDirZ = Math.cos(rearAng);
    if (ball) {
      const d = Math.hypot(ball.x - p.x, ball.z - p.z) || 1;
      p.headTargetDirY = Math.max(-0.4, Math.min(1.0, (ball.y - (p.y + 0.95)) / d));
    }
  } else {
    p.headPhase = 'prep';
    p.neckCurve = 0.7;
  }

  if (ball && variant !== 'spin_left' && variant !== 'spin_right' && variant !== 'salto_curved' && variant !== 'backward') {
    const dx = ball.x - p.x;
    const dz = ball.z - p.z;
    const d = Math.hypot(dx, dz) || 1;
    if (d < 3.4) {
      p.headTargetDirX = dx / d;
      p.headTargetDirZ = dz / d;
      p.headTargetDirY = Math.max(-0.4, Math.min(1.0, (ball.y - (p.y + 0.95)) / d));
    }
  }
}

export function triggerDash(p: PlayerSim) {
  if (p.fallTimer > 0 || p.dashCooldown > 0 || p.dashTimer > 0) return;
  p.dashTimer = DASH_DURATION;
  p.dashCooldown = DASH_COOLDOWN;
  const speedMult = p.ghostAttachedTimer > 0 ? 0.65 : 1.0;
  p.vx = Math.sin(p.facing) * DASH_SPEED * speedMult;
  p.vz = Math.cos(p.facing) * DASH_SPEED * speedMult;
  p.squashX = 1.24;
  p.squashY = 0.82;
}

let propIdCounter = 0;

export function dropCarriedProp(
  sim: MatchSimulation,
  p: PlayerSim,
  tossVx = 0,
  tossVy = 1.6,
  tossVz = 0
) {
  if (!p.carryingPropId) return;
  const pr = sim.props.find((item) => item.id === p.carryingPropId);
  p.carryingPropId = null;
  if (pr) {
    pr.carriedByPlayerId = null;
    pr.thrownActive = false;
    pr.thrownByPlayerId = null;
    pr.thrownByTeam = null;
    pr.x = p.x + Math.sin(p.facing) * 0.45;
    pr.y = Math.max(0.45, p.y + 1.15);
    pr.z = p.z + Math.cos(p.facing) * 0.45;
    pr.vx = tossVx;
    pr.vy = tossVy;
    pr.vz = tossVz;
    sim.events.push({ type: 'prop_drop', x: pr.x, y: pr.y, z: pr.z, label: pr.kind });
  }
}

export function spawnRandomPropPair(sim: MatchSimulation, fixedKinds?: PropKind[]) {
  const count = fixedKinds ? fixedKinds.length : 3;
  const spots: Array<{ x: number; z: number }> = [];
  for (let i = 0; i < count; i++) {
    let sx = (Math.random() - 0.5) * 14.0;
    let sz = (Math.random() - 0.5) * 9.2;
    for (let tries = 0; tries < 8; tries++) {
      if (spots.every((s) => Math.hypot(sx - s.x, sz - s.z) >= 3.0)) break;
      sx = (Math.random() - 0.5) * 14.0;
      sz = (Math.random() - 0.5) * 9.2;
    }
    spots.push({ x: sx, z: sz });
    let kind: PropKind;
    if (fixedKinds) {
      kind = fixedKinds[i];
    } else {
      // Jenis benda tidak boleh kembar dalam satu gelombang; telur burung unta maksimal satu di lapangan
      const eggAround = sim.props.some((pr) => pr.kind === 'ostrich_egg' && pr.usesRemaining > 0) || sim.bulls.length > 0;
      const used = new Set(sim.props.slice(-i).map((pr) => pr.kind));
      const pool = SPAWN_PROP_KINDS.filter((k) => !used.has(k) && !(k === 'ostrich_egg' && eggAround));
      const choices = pool.length > 0 ? pool : SPAWN_PROP_KINDS.filter((k) => k !== 'ostrich_egg');
      kind = choices[Math.floor(Math.random() * choices.length)];
    }
    propIdCounter += 1;
    const prop: ArenaPropSim = {
      id: `prop_${propIdCounter}`,
      kind,
      x: sx,
      y: 10.5 + i * 1.8,
      z: sz,
      vx: (Math.random() - 0.5) * 0.8,
      vy: -2.0,
      vz: (Math.random() - 0.5) * 0.8,
      rotY: Math.random() * Math.PI * 2,
      radius: 0.48,
      usesRemaining: kind === 'bomb' || kind === 'potion' || kind === 'ostrich_egg' ? 1 : PROP_MAX_USES,
      carriedByPlayerId: null,
      thrownByPlayerId: null,
      thrownByTeam: null,
      thrownActive: false,
      flashTimer: 0,
      fuse: kind === 'bomb' ? 6.5 : kind === 'ostrich_egg' ? 10 : 0,
    };
    sim.props.push(prop);
    sim.events.push({ type: 'prop_spawn', x: sx, y: prop.y, z: sz, label: kind });
  }
}

function damageProp(sim: MatchSimulation, prop: ArenaPropSim, amount = 1) {
  prop.usesRemaining = Math.max(0, prop.usesRemaining - amount);
  prop.flashTimer = 0.16;
  if (prop.usesRemaining <= 0) {
    if (prop.carriedByPlayerId) {
      const carrier = sim.players.find((pl) => pl.id === prop.carriedByPlayerId);
      if (carrier) carrier.carryingPropId = null;
      prop.carriedByPlayerId = null;
    }
    sim.events.push({ type: 'prop_break', x: prop.x, y: prop.y + 0.3, z: prop.z, label: prop.kind });
    if (prop.kind === 'bomb' && !prop.done) explodeBombProp(sim, prop);
    if (prop.kind === 'ostrich_egg' && !prop.done) {
      prop.done = true;
      spawnBull(sim, prop.x, prop.z);
    }
  }
}

/** Bom meledak SEKALI lalu hilang: melempar pemain dan bola di sekitarnya */
function explodeBombProp(sim: MatchSimulation, prop: ArenaPropSim) {
  if (prop.done) return;
  prop.done = true;
  prop.usesRemaining = 0;
  if (prop.carriedByPlayerId) {
    const carrier = sim.players.find((pl) => pl.id === prop.carriedByPlayerId);
    if (carrier) carrier.carryingPropId = null;
    prop.carriedByPlayerId = null;
  }
  const radius = 4.4;
  sim.events.push({ type: 'bomb_explode', x: prop.x, y: Math.max(0.5, prop.y), z: prop.z, intensity: 1 });
  sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.8);
  sim.cameraZoomPulse = Math.max(sim.cameraZoomPulse, 0.5);
  for (const other of sim.players) {
    const dx = other.x - prop.x;
    const dz = other.z - prop.z;
    const dist = Math.hypot(dx, dz) || 0.1;
    if (dist < radius) {
      const blast = (1 - dist / radius) * 13.0;
      if (other.carryingPropId) dropCarriedProp(sim, other, (dx / dist) * 5, 3.0, (dz / dist) * 5);
      startRagdollFall(other, other.vx + (dx / dist) * blast, 4.8, other.vz + (dz / dist) * blast, 1.3, sim);
    }
  }
  const ball = sim.ball;
  const bdx = ball.x - prop.x;
  const bdz = ball.z - prop.z;
  const bd = Math.hypot(bdx, bdz) || 0.1;
  if (bd < radius + 1) {
    const k = 1 - bd / (radius + 1);
    ball.vx += (bdx / bd) * 11 * k;
    ball.vz += (bdz / bd) * 11 * k;
    ball.vy = Math.max(ball.vy, 5.5 * k + 2);
  }
}

function spawnBull(sim: MatchSimulation, x: number, z: number) {
  if (sim.bulls.length >= 3) return;
  propIdCounter += 1;
  sim.bulls.push({
    id: `bull_${propIdCounter}`,
    x,
    z,
    vx: 0,
    vz: 0,
    facing: 0,
    timer: BULL_DURATION,
    stun: 0.9,
    targetId: null,
    visited: [],
  });
  sim.events.push({ type: 'prop_spawn', x, y: 1.0, z, label: 'bull' });
  sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.3);
}

/** Banteng menyeruduk setiap pemain bergantian selama 20 detik */
function updateBulls(sim: MatchSimulation, dt: number) {
  for (const b of sim.bulls) {
    b.timer -= dt;
    b.stun = Math.max(0, b.stun - dt);
    if (b.stun > 0) {
      const damp = Math.max(0, 1 - 5 * dt);
      b.vx *= damp;
      b.vz *= damp;
    } else {
      let target = sim.players.find((p) => p.id === b.targetId && p.fallTimer <= 0 && !p.ridingBullId) ?? null;
      if (!target) {
        let pool = sim.players.filter((p) => !b.visited.includes(p.id) && p.fallTimer <= 0 && !p.ridingBullId);
        if (pool.length === 0) {
          b.visited = [];
          pool = sim.players.filter((p) => p.fallTimer <= 0 && !p.ridingBullId);
        }
        let bestD = Infinity;
        for (const p of pool) {
          const d = Math.hypot(p.x - b.x, p.z - b.z);
          if (d < bestD) {
            bestD = d;
            target = p;
          }
        }
        b.targetId = target ? target.id : null;
      }
      if (target) {
        const dx = target.x - b.x;
        const dz = target.z - b.z;
        const dist = Math.hypot(dx, dz) || 0.001;
        const ux = dx / dist;
        const uz = dz / dist;
        const k = Math.min(1, 6 * dt);
        b.vx += (ux * 9.8 - b.vx) * k;
        b.vz += (uz * 9.8 - b.vz) * k;
        if (dist < 1.1) {
          if (target.carryingPropId) dropCarriedProp(sim, target, ux * 4, 3.0, uz * 4);
          startRagdollFall(target, ux * 12 + b.vx * 0.3, 7.5, uz * 12 + b.vz * 0.3, 1.4, sim);
          sim.events.push({ type: 'ragdoll_fall', x: target.x, y: target.y + 0.6, z: target.z });
          sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.35);
          b.visited.push(target.id);
          b.targetId = null;
          b.stun = 0.8;
        }
      }
    }
    b.x = Math.max(-(PITCH_HALF_X + 1.2), Math.min(PITCH_HALF_X + 1.2, b.x + b.vx * dt));
    b.z = Math.max(-(PITCH_HALF_Z + 0.6), Math.min(PITCH_HALF_Z + 0.6, b.z + b.vz * dt));
    if (Math.hypot(b.vx, b.vz) > 0.6) b.facing = Math.atan2(b.vx, b.vz);
    const ball = sim.ball;
    const bdx = ball.x - b.x;
    const bdz = ball.z - b.z;
    const bd = Math.hypot(bdx, bdz) || 0.1;
    if (bd < 1.25 && ball.y < 1.8 && Math.hypot(b.vx, b.vz) > 2) {
      ball.vx += (bdx / bd) * 4.5;
      ball.vz += (bdz / bd) * 4.5;
      ball.vy = Math.max(ball.vy, 3.2);
    }
  }
  sim.bulls = sim.bulls.filter((b) => {
    if (b.timer > 0) return true;
    sim.events.push({ type: 'prop_break', x: b.x, y: 1.0, z: b.z, label: 'bull' });
    return false;
  });
}

/** Koefisien pantul efektif: benturan pelan kehilangan elastisitas (bola benar-benar berhenti memantul), bentuk menentukan karakter. */
function getBounceRestitution(ball: BallSim, impactVy: number): number {
  const softness = Math.min(1, 0.62 + impactVy / 11);
  let e = ball.restitution * softness;
  if (ball.shape === 'sphere' && ball.mass < 0.6) e *= 0.96; // bola ringan cepat kehilangan energi karena udara/lentur
  return Math.max(0.05, e);
}

/** Bola vs tubuh ragdoll: bola memantul lembut dan tubuh yang kena ikut terpental/terseret. */
function collideBallWithRagdoll(ball: BallSim, p: PlayerSim) {
  const rd = p.ragdoll;
  if (!rd) return;
  for (let i = 0; i < RAGDOLL_PARTICLE_COUNT; i++) {
    const px = rd.pos[i * 3];
    const py = rd.pos[i * 3 + 1];
    const pz = rd.pos[i * 3 + 2];
    const res = collidePointWithBallShape(px, py, pz, getRagdollParticleRadius(i), ball);
    if (!res.hit) continue;
    ball.x += res.nx * res.pen;
    ball.y += Math.max(0, res.ny * res.pen);
    ball.z += res.nz * res.pen;
    const rvx = ball.vx - rd.vel[i * 3];
    const rvy = ball.vy - rd.vel[i * 3 + 1];
    const rvz = ball.vz - rd.vel[i * 3 + 2];
    const vn = rvx * res.nx + rvy * res.ny + rvz * res.nz;
    if (vn >= 0) continue;
    const bounce = 0.45;
    ball.vx -= (1 + bounce) * vn * res.nx * 0.8;
    ball.vy -= (1 + bounce) * vn * res.ny * 0.8;
    ball.vz -= (1 + bounce) * vn * res.nz * 0.8;
    // tubuh menerima impuls berlawanan (bola ringan -> dorongan kecil)
    const push = Math.min(5.5, -vn * 0.32);
    pokeRagdollParticle(rd, i, -res.nx * push, -res.ny * push * 0.6, -res.nz * push);
  }
}

function startRagdollFall(
  p: PlayerSim,
  knockVx: number,
  knockVy: number,
  knockVz: number,
  duration = 1.15,
  sim?: MatchSimulation
) {
  if (sim && p.carryingPropId) {
    dropCarriedProp(sim, p, knockVx * 0.35, 2.2, knockVz * 0.35);
  }
  const dirFlip = Math.random() > 0.5 ? 1 : -1;
  // Lemas ragdoll tepat 3 detik; fase bangun RAGDOLL_GETUP_TIME ada di ujung fallTimer
  void duration;
  p.fallTimer = RAGDOLL_LIMP_TIME / Math.max(0.75, Math.min(1.3, p.stats?.balance ?? 1));
  p.animState = 'fall';
  // Terpental tinggi ke atas supaya jatuhnya lucu
  knockVy = Math.max(knockVy, 9.5 + Math.random() * 3.5);
  const balanceK = 1 / Math.max(0.75, Math.min(1.3, p.stats?.balance ?? 1));
  knockVx *= 1.25 * balanceK;
  knockVz *= 1.25 * balanceK;
  if (p.ragdoll && p.fallTimer > 0) {
    // Sudah terkapar: dorongan baru ditambahkan ke ragdoll yang sedang bergerak
    addRagdollImpulse(p.ragdoll, knockVx * 0.5, Math.max(0, knockVy) * 0.5, knockVz * 0.5);
  } else {
    p.ragdoll = createRagdoll(p.x, p.y, p.z, p.facing, knockVx, knockVy, knockVz);
  }
  p.vx = knockVx;
  p.vy = knockVy;
  p.vz = knockVz;
  // Instant limp ("lemes seketika") transition on high-speed impact / clash / fire
  p.ragdollBlend = 0.85;
  p.ragdollPitch = 0.38;
  p.ragdollRoll = dirFlip * 0.28;
  p.ragdollVelPitch = 22 + Math.random() * 8;
  p.ragdollVelRoll = dirFlip * (9 + Math.random() * 5);
  p.ragdollArmL = -0.65 - Math.random() * 0.45;
  p.ragdollArmR = -0.65 - Math.random() * 0.45;
  p.ragdollLegL = 0.42 + Math.random() * 0.35;
  p.ragdollLegR = -0.35 - Math.random() * 0.35;
  p.ragdollNeck = dirFlip * (0.35 + Math.random() * 0.3);
  p.ragdollHeadRoll = -dirFlip * (0.45 + Math.random() * 0.35);
  p.kickPhase = 'none';
  p.kickSpinAngle = 0;
  p.kickSpinDir = 0;
  p.kickHoldTimer = 0;
  p.wasKickHeld = false;
  p.kickCharge = 0;
  p.backflipAngle = 0;
  p.headPhase = 'none';
  p.neckStretch = 0;
  p.headSpinAngle = 0;
  p.headSpinDir = 0;
  p.saltoAngle = 0;
  p.punchPhase = 'none';
  p.punchTimer = 0;
  p.punchCharge = 0;
  p.punchHitApplied = false;
  p.punchHoldTimer = 0;
  p.wasPunchHeld = false;
}

export function computeNpcInput(sim: MatchSimulation, npc: PlayerSim): InputFrame {
  const ball = sim.ball;
  const attackDir = npc.team === 'red' ? 1 : -1;
  const ownGoalX = npc.team === 'red' ? -PITCH_HALF_X : PITCH_HALF_X;
  const targetGoalX = -ownGoalX;

  let kickPressed = false;
  let kickRightSpinPressed = false;
  let grabPressed = false;
  let jumpPressed = false;
  let headSpinLeftPressed = false;
  let dashPressed = false;

  // 0. Training Mode Dedicated Goalkeeper AI: guards goal line, tracks shot Z, dives/clears incoming balls
  if (sim.config.mode === 'training') {
    const goalLineX = ownGoalX + attackDir * 1.15;
    const distBall = Math.hypot(ball.x - npc.x, ball.z - npc.z);

    // Predict where incoming ball will cross goalLineX
    const ballMovingTowardGoal = (attackDir < 0 && ball.vx > 0.8) || (attackDir > 0 && ball.vx < -0.8);
    let interceptZ = ball.z;
    if (ballMovingTowardGoal && Math.abs(ball.vx) > 0.8) {
      const tToGoal = Math.max(0, Math.min(0.65, (goalLineX - ball.x) / ball.vx));
      interceptZ = ball.z + ball.vz * tToGoal;
    }
    const clampedZ = Math.max(-GOAL_HALF_Z * 0.9, Math.min(GOAL_HALF_Z * 0.9, interceptZ));

    const ballInBox = Math.abs(ball.x - ownGoalX) < 3.6 && Math.abs(ball.z) < GOAL_HALF_Z + 0.9;
    const desiredX = ballInBox
      ? ownGoalX + attackDir * Math.max(0.75, Math.min(2.8, Math.abs(ball.x - ownGoalX)))
      : goalLineX;
    const desiredZ = clampedZ;

    const dx = desiredX - npc.x;
    const dz = desiredZ - npc.z;
    const d = Math.hypot(dx, dz);

    // If ball is close enough inside/near the box -> clear it back toward midfield!
    if (distBall < 2.25 && npc.fallTimer <= 0) {
      if (ball.y > 1.05 && npc.y <= 0.05) {
        jumpPressed = true;
      } else {
        const fwdX = Math.sin(npc.facing);
        const fwdZ = Math.cos(npc.facing);
        const bx = (ball.x - npc.x) / (distBall || 1);
        const bz = (ball.z - npc.z) / (distBall || 1);
        const dot = fwdX * bx + fwdZ * bz;
        if (dot < 0.2) {
          headSpinLeftPressed = true;
        } else if (fwdX * bz - fwdZ * bx < 0) {
          kickPressed = true;
        } else {
          kickRightSpinPressed = true;
        }
      }
    }

    // Dive dash laterally if shot is fast and headed toward corner
    if (ballMovingTowardGoal && Math.abs(ball.vx) > 5.5 && Math.abs(dz) > 1.25 && npc.dashCooldown <= 0) {
      dashPressed = true;
    }

    return {
      moveX: d > 0.14 ? dx / d : 0,
      moveZ: d > 0.14 ? dz / d : 0,
      runHeld: d > 0.7 || ballMovingTowardGoal,
      kickPressed,
      kickHeld: false,
      kickRightSpinPressed,
      kickRightHeld: false,
      grabPressed: false,
      jumpPressed,
      headSpinLeftPressed,
      dashPressed,
    };
  }

  // 1. If NPC is currently carrying a prop -> aim at nearest standing opponent and throw it!
  if (npc.carryingPropId) {
    let bestOpp: PlayerSim | null = null;
    let bestDist = Infinity;
    for (const pl of sim.players) {
      if (pl.team === npc.team || pl.fallTimer > 0) continue;
      const dp = Math.hypot(pl.x - npc.x, pl.z - npc.z);
      if (dp < bestDist) {
        bestDist = dp;
        bestOpp = pl;
      }
    }
    const tx = bestOpp ? bestOpp.x : targetGoalX;
    const tz = bestOpp ? bestOpp.z : 0;
    const dx = tx - npc.x;
    const dz = tz - npc.z;
    const d = Math.hypot(dx, dz) || 1;
    const fwdX = Math.sin(npc.facing);
    const fwdZ = Math.cos(npc.facing);
    const dot = (dx / d) * fwdX + (dz / d) * fwdZ;
    if (d < 9.0 && dot > 0.68) {
      kickPressed = true;
    }
    return {
      moveX: d > 0.2 ? dx / d : 0,
      moveZ: d > 0.2 ? dz / d : 0,
      runHeld: false,
      kickPressed,
      kickHeld: false,
      kickRightSpinPressed: false,
      kickRightHeld: false,
      grabPressed: false,
      jumpPressed: false,
      headSpinLeftPressed: false,
      dashPressed: false,
    };
  }

  // 2. Check for nearby loose props on the field to grab & throw at opponents
  const distBall = Math.hypot(ball.x - npc.x, ball.z - npc.z);
  let nearestLooseProp: ArenaPropSim | null = null;
  let nearestPropDist = Infinity;
  for (const pr of sim.props) {
    if (pr.carriedByPlayerId || pr.usesRemaining <= 0 || pr.y > 1.35) continue;
    const dp = Math.hypot(pr.x - npc.x, pr.z - npc.z);
    if (dp < nearestPropDist) {
      nearestPropDist = dp;
      nearestLooseProp = pr;
    }
  }

  // Seek loose prop opportunistically if it's nearby (< 4.8m) and ball isn't immediately underfoot
  if (nearestLooseProp && (nearestPropDist < 1.65 || (nearestPropDist < 4.8 && distBall > 2.0))) {
    const dx = nearestLooseProp.x - npc.x;
    const dz = nearestLooseProp.z - npc.z;
    const d = Math.hypot(dx, dz) || 1;
    if (nearestPropDist < 1.65 && npc.fallTimer <= 0) {
      grabPressed = true;
    }
    return {
      moveX: d > 0.15 ? dx / d : 0,
      moveZ: d > 0.15 ? dz / d : 0,
      runHeld: nearestPropDist > 1.5,
      kickPressed: false,
      kickHeld: false,
      kickRightSpinPressed: false,
      kickRightHeld: false,
      grabPressed,
      jumpPressed: false,
      headSpinLeftPressed: false,
      dashPressed: false,
    };
  }

  // 3. Normal soccer ball play AI (scaled by Story Mode difficulty or Match Settings AI Difficulty)
  const storyDiff =
    sim.config.storyAi?.difficulty ??
    (sim.config.aiDifficulty === 'easy' ? 0.38 : sim.config.aiDifficulty === 'hard' ? 0.95 : 0.68);
  const bossStyle = sim.config.storyAi?.bossStyle;

  const toGoalX = targetGoalX - ball.x;
  const toGoalZ = 0 - ball.z;
  const goalDist = Math.hypot(toGoalX, toGoalZ) || 1;
  const behindX = ball.x - (toGoalX / goalDist) * 0.95;
  const behindZ = ball.z - (toGoalZ / goalDist) * 0.95;

  const teammates = sim.players.filter((p) => p.team === npc.team);
  const myIndex = teammates.findIndex((p) => p.id === npc.id);
  let targetX = behindX;
  let targetZ = behindZ;

  // Higher-difficulty story challengers guard goal line when ball speeds toward their own goal
  const ballThreateningOwnGoal =
    storyDiff >= 0.6 &&
    ((attackDir < 0 && ball.vx > 2.2 && ball.x > 0) || (attackDir > 0 && ball.vx < -2.2 && ball.x < 0));
  if (ballThreateningOwnGoal && distBall > 2.6) {
    targetX = ownGoalX + attackDir * 1.65;
    targetZ = Math.max(-GOAL_HALF_Z * 0.85, Math.min(GOAL_HALF_Z * 0.85, ball.z + ball.vz * 0.25));
  } else if (teammates.length > 1 && myIndex === teammates.length - 1) {
    targetX = ownGoalX * 0.55 + ball.x * 0.45;
    targetZ = ball.z * 0.5;
  } else if (teammates.length >= 3 && myIndex === 1) {
    targetX = behindX - attackDir * 1.4;
    targetZ = behindZ + (ball.z > 0 ? -2.4 : 2.4);
  }

  const dx = targetX - npc.x;
  const dz = targetZ - npc.z;
  const d = Math.hypot(dx, dz);
  const runThreshold = storyDiff >= 0.7 ? 0.65 : 1.35;
  const runHeld = d > runThreshold || distBall > (storyDiff >= 0.75 ? 1.55 : 2.2);

  let kickHeld = false;
  const strikeRange = bossStyle === 'elastic_reach' ? 2.45 : storyDiff >= 0.78 ? 2.28 : 2.05;

  if (distBall < strikeRange && npc.fallTimer <= 0) {
    const fwdX = Math.sin(npc.facing);
    const fwdZ = Math.cos(npc.facing);
    const bx = (ball.x - npc.x) / (distBall || 1);
    const bz = (ball.z - npc.z) / (distBall || 1);
    const dot = fwdX * bx + fwdZ * bz;
    const cross = fwdX * bz - fwdZ * bx;

    if (bossStyle === 'aerial_flip' || bossStyle === 'balanced_titan') {
      if (ball.y > 0.85 && npc.y <= 0.05) {
        jumpPressed = true;
      } else if (npc.y > 0.18 && ball.y > 0.65) {
        kickPressed = true;
      }
    }

    if (!jumpPressed && !kickPressed) {
      if (ball.y > 1.15 && npc.y <= 0.05) {
        jumpPressed = true;
      } else if (npc.y > 0.2 && ball.y > 0.95) {
        kickPressed = true; // Jump + A fire backflip on high ball!
      } else if (bossStyle === 'rubber_header') {
        if (dot < 0.55 || Math.random() < 0.48) {
          headSpinLeftPressed = true;
        } else {
          kickPressed = true;
        }
      } else if (bossStyle === 'curve_master') {
        if (dot < 0.15) {
          headSpinLeftPressed = true;
        } else {
          kickRightSpinPressed = true;
        }
      } else if (bossStyle === 'power_shot') {
        if (npc.kickPhase === 'super_charge' && npc.kickCharge < 0.55 && distBall < 1.95) {
          kickHeld = true;
        } else if (distBall > 1.35 && distBall < 2.25 && npc.kickPhase === 'none' && dot > 0.45) {
          kickHeld = true;
        } else if (dot < 0.2) {
          headSpinLeftPressed = true;
        } else {
          kickPressed = true;
        }
      } else if (bossStyle === 'balanced_titan') {
        if (npc.kickPhase === 'super_charge' && npc.kickCharge < 0.45 && distBall < 2.0) {
          kickHeld = true;
        } else if (distBall > 1.55 && npc.kickPhase === 'none' && dot > 0.65 && Math.random() < 0.35) {
          kickHeld = true;
        } else if (dot < 0.25) {
          headSpinLeftPressed = true;
        } else if (cross < 0) {
          kickPressed = true;
        } else {
          kickRightSpinPressed = true;
        }
      } else {
        if (dot < 0.25) {
          headSpinLeftPressed = true;
        } else if (cross < 0) {
          kickPressed = true;
        } else {
          kickRightSpinPressed = true;
        }
      }
    }
  } else if (npc.kickPhase === 'super_charge') {
    // Release charged Super Kick cleanly once opponent/ball leaves tight range
    kickHeld = false;
  }

  const dashChance = bossStyle === 'elastic_reach' ? 0.08 : 0.015 + storyDiff * 0.035;
  if (distBall > 3.2 && distBall < 6.4 && npc.dashCooldown <= 0 && Math.random() < dashChance) {
    dashPressed = true;
  }

  // Rookie opponents pause briefly between kicks so beginners can out-dribble them cleanly
  const throttleFactor = storyDiff < 0.48 && npc.kickPhase === 'none' ? 0.84 : 1.0;

  return {
    moveX: d > 0.15 ? (dx / d) * throttleFactor : 0,
    moveZ: d > 0.15 ? (dz / d) * throttleFactor : 0,
    runHeld,
    kickPressed,
    kickHeld,
    kickRightSpinPressed,
    kickRightHeld: false,
    grabPressed,
    jumpPressed,
    headSpinLeftPressed,
    dashPressed,
  };
}

function getBallEffectiveHalfY(ball: BallSim): number {
  const s = ball.scaleMultiplier;
  if (ball.colliderType === 'cylinder') {
    return ball.cylinderHeight * 0.5 * s;
  }
  if (ball.colliderType === 'box') {
    const h = ball.radius * 0.88 * s;
    const cx = Math.cos(ball.rotX);
    const sx = Math.sin(ball.rotX);
    const cz = Math.cos(ball.rotZ);
    const sz = Math.sin(ball.rotZ);
    // Exact vertical support radius of rotated cube in Three.js XYZ order
    const m10 = Math.abs(-cx * sz + sx * 0 * cz);
    const m11 = Math.abs(cx * cz);
    const m12 = Math.abs(sx);
    return h * Math.max(1, m10 + m11 + m12);
  }
  if (ball.colliderType === 'ellipsoid') {
    const rx = ball.radius * 0.88 * s;
    const ry = ball.radius * 0.88 * s;
    const rz = ball.radius * ball.prolateScaleZ * s;
    // Exact analytical vertical support radius of rotated ellipsoid
    const cx = Math.cos(ball.rotX);
    const sx = Math.sin(ball.rotX);
    const cz = Math.cos(ball.rotZ);
    const sz = Math.sin(ball.rotZ);
    const ux = sx * sz;
    const uy = cx * cz;
    const uz = -sx * cz;
    return Math.hypot(rx * ux, ry * uy, rz * uz);
  }
  return ball.radius * s;
}

/**
 * Shape-accurate collision check between a spherical collider (e.g. foot, head, goalpost)
 * and the ball's real 3D geometry (Sphere, Cylinder Puck/Disc, Box Dice, or Ellipsoid).
 */
export function collidePointWithBallShape(
  px: number,
  py: number,
  pz: number,
  hitRadius: number,
  ball: BallSim
): { hit: boolean; nx: number; ny: number; nz: number; pen: number } {
  const s = ball.scaleMultiplier;
  const dx = ball.x - px;
  const dy = ball.y - py;
  const dz = ball.z - pz;

  if (ball.colliderType === 'box') {
    const h = ball.radius * 0.88 * s;
    const qx = px - ball.x;
    const qy = py - ball.y;
    const qz = pz - ball.z;

    const cY = Math.cos(-ball.rotY);
    const sY = Math.sin(-ball.rotY);
    const t1x = qx * cY + qz * sY;
    const t1y = qy;
    const t1z = -qx * sY + qz * cY;

    const cX = Math.cos(-ball.rotX);
    const sX = Math.sin(-ball.rotX);
    const lx = t1x;
    const ly = t1y * cX - t1z * sX;
    const lz = t1y * sX + t1z * cX;

    const cx = Math.max(-h, Math.min(h, lx));
    const cy = Math.max(-h, Math.min(h, ly));
    const cz = Math.max(-h, Math.min(h, lz));
    const ddx = cx - lx;
    const ddy = cy - ly;
    const ddz = cz - lz;
    const dist = Math.hypot(ddx, ddy, ddz);

    if (dist <= 0.0001) {
      return { hit: true, nx: 0, ny: 1, nz: 0, pen: hitRadius + h };
    }
    if (dist <= hitRadius) {
      const nlx = ddx / dist;
      const nly = ddy / dist;
      const nlz = ddz / dist;
      const cXp = Math.cos(ball.rotX);
      const sXp = Math.sin(ball.rotX);
      const r1x = nlx;
      const r1y = nly * cXp - nlz * sXp;
      const r1z = nly * sXp + nlz * cXp;
      const cYp = Math.cos(ball.rotY);
      const sYp = Math.sin(ball.rotY);
      return {
        hit: true,
        nx: r1x * cYp + r1z * sYp,
        ny: r1y,
        nz: -r1x * sYp + r1z * cYp,
        pen: hitRadius - dist,
      };
    }
    return { hit: false, nx: 0, ny: 0, nz: 0, pen: 0 };
  }

  if (ball.colliderType === 'cylinder') {
    const cylR = ball.radius * s;
    const halfH = ball.cylinderHeight * 0.5 * s;
    const qx = px - ball.x;
    const qy = py - ball.y;
    const qz = pz - ball.z;
    const dXZ = Math.hypot(qx, qz);

    let cx = qx;
    let cz = qz;
    if (dXZ > cylR && dXZ > 0.0001) {
      cx = (qx / dXZ) * cylR;
      cz = (qz / dXZ) * cylR;
    }
    const cy = Math.max(-halfH, Math.min(halfH, qy));
    const diffX = cx - qx;
    const diffY = cy - qy;
    const diffZ = cz - qz;
    const dist = Math.hypot(diffX, diffY, diffZ);

    if (dist <= 0.0001) {
      return { hit: true, nx: 0, ny: 1, nz: 0, pen: hitRadius + halfH - Math.abs(qy) };
    }
    if (dist <= hitRadius) {
      return {
        hit: true,
        nx: diffX / dist,
        ny: diffY / dist,
        nz: diffZ / dist,
        pen: hitRadius - dist,
      };
    }
    return { hit: false, nx: 0, ny: 0, nz: 0, pen: 0 };
  }

  if (ball.colliderType === 'ellipsoid') {
    const rx = ball.radius * 0.88 * s;
    const ry = ball.radius * 0.88 * s;
    const rz = ball.radius * ball.prolateScaleZ * s;

    const qx = px - ball.x;
    const qy = py - ball.y;
    const qz = pz - ball.z;

    const cY = Math.cos(-ball.rotY);
    const sY = Math.sin(-ball.rotY);
    const t1x = qx * cY + qz * sY;
    const t1y = qy;
    const t1z = -qx * sY + qz * cY;

    const cX = Math.cos(-ball.rotX);
    const sX = Math.sin(-ball.rotX);
    const lx = t1x;
    const ly = t1y * cX - t1z * sX;
    const lz = t1y * sX + t1z * cX;

    const u = Math.hypot(lx / rx, ly / ry, lz / rz);
    if (u <= 0.0001) {
      return { hit: true, nx: 0, ny: 1, nz: 0, pen: hitRadius + ry };
    }
    if (u <= 1.0) {
      const len = Math.hypot(lx, ly, lz) || 1;
      const n1x = -lx / len;
      const n1y = -ly / len;
      const n1z = -lz / len;
      const fx = n1x;
      const fy = n1y * Math.cos(ball.rotX) - n1z * Math.sin(ball.rotX);
      const fz = n1y * Math.sin(ball.rotX) + n1z * Math.cos(ball.rotX);
      return {
        hit: true,
        nx: fx * Math.cos(ball.rotY) + fz * Math.sin(ball.rotY),
        ny: fy,
        nz: -fx * Math.sin(ball.rotY) + fz * Math.cos(ball.rotY),
        pen: hitRadius,
      };
    }
    const surfX = lx / u;
    const surfY = ly / u;
    const surfZ = lz / u;
    const dist = Math.hypot(lx - surfX, ly - surfY, lz - surfZ);
    if (dist <= hitRadius) {
      const nLocalX = (surfX - lx) / (dist || 1);
      const nLocalY = (surfY - ly) / (dist || 1);
      const nLocalZ = (surfZ - lz) / (dist || 1);
      const cXp = Math.cos(ball.rotX);
      const sXp = Math.sin(ball.rotX);
      const r1x = nLocalX;
      const r1y = nLocalY * cXp - nLocalZ * sXp;
      const r1z = nLocalY * sXp + nLocalZ * cXp;
      const cYp = Math.cos(ball.rotY);
      const sYp = Math.sin(ball.rotY);
      return {
        hit: true,
        nx: r1x * cYp + r1z * sYp,
        ny: r1y,
        nz: -r1x * sYp + r1z * cYp,
        pen: hitRadius - dist,
      };
    }
    return { hit: false, nx: 0, ny: 0, nz: 0, pen: 0 };
  }

  // Default sphere
  const effR = ball.radius * s;
  const dist = Math.hypot(dx, dy, dz);
  if (dist < effR + hitRadius) {
    if (dist <= 0.0001) return { hit: true, nx: 0, ny: 1, nz: 0, pen: effR + hitRadius };
    return {
      hit: true,
      nx: dx / dist,
      ny: dy / dist,
      nz: dz / dist,
      pen: effR + hitRadius - dist,
    };
  }
  return { hit: false, nx: 0, ny: 0, nz: 0, pen: 0 };
}

function triggerBombBallExplosion(sim: MatchSimulation, blastRadius = 4.8) {
  const ball = sim.ball;
  sim.events.push({ type: 'bomb_explode', x: ball.x, y: ball.y, z: ball.z, intensity: 1 });
  if (!ball.isJelly10x) {
    sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.88);
    sim.cameraZoomPulse = Math.max(sim.cameraZoomPulse, 0.55);
  }
  // Blast ball slightly upward & outward
  ball.vy = Math.max(ball.vy, 7.8);
  ball.vx += (Math.random() - 0.5) * 6.0;
  ball.vz += (Math.random() - 0.5) * 6.0;

  for (const other of sim.players) {
    const dx = other.x - ball.x;
    const dz = other.z - ball.z;
    const dist = Math.hypot(dx, dz) || 0.1;
    if (dist < blastRadius) {
      const blast = (1 - dist / blastRadius) * 13.0;
      if (other.carryingPropId) {
        dropCarriedProp(sim, other, (dx / dist) * 5, 3.0, (dz / dist) * 5);
      }
      startRagdollFall(other, other.vx + (dx / dist) * blast, 4.4, other.vz + (dz / dist) * blast, 1.3);
    }
  }
}

function maybeEmitGoalSave(sim: MatchSimulation, defender: PlayerSim, prevBallVx: number) {
  const ownGoalX = defender.team === 'red' ? -PITCH_HALF_X : PITCH_HALF_X;
  const nearOwnGoal = Math.abs(defender.x - ownGoalX) < 4.5 && Math.abs(defender.z) < GOAL_HALF_Z + 1.6;
  if (!nearOwnGoal) return;

  const wasHeadedToGoal =
    (ownGoalX < 0 && prevBallVx < -3.0) || (ownGoalX > 0 && prevBallVx > 3.0);
  const nowCleared =
    (ownGoalX < 0 && sim.ball.vx >= -1.0) || (ownGoalX > 0 && sim.ball.vx <= 1.0);

  if (wasHeadedToGoal && nowCleared) {
    sim.events.push({
      type: 'save',
      team: defender.team,
      x: sim.ball.x,
      y: sim.ball.y,
      z: sim.ball.z,
    });
  }
}

function applyStrikeToBall(
  sim: MatchSimulation,
  p: PlayerSim,
  dirX: number,
  dirY: number,
  dirZ: number,
  basePower: number,
  isStraightKick = false,
  spinTorqueY = 0
) {
  const ball = sim.ball;
  const prevBallVx = ball.vx;
  const animal = ANIMALS.find((a) => a.id === p.custom.animal) ?? ANIMALS[0];
  const fireMult = hasActiveItem(sim, 'fire_power') ? 1.55 : 1.0;
  const rubberMult = ball.isJelly10x ? 1.32 : 1.0;

  // Detach sticky honey ball on any real strike
  if (ball.stickyTargetPlayerId) {
    ball.stickyTargetPlayerId = null;
    ball.stickyTimer = 0;
    ball.stickyCooldown = 0.45;
  }

  const now = sim.elapsedTime;
  let isClash = false;
  if (
    sim.lastKickCollisionTick &&
    sim.lastKickCollisionTick.team !== p.team &&
    now - sim.lastKickCollisionTick.time <= 0.28
  ) {
    isClash = true;
  }
  sim.lastKickCollisionTick = { playerId: p.id, team: p.team, time: now };

  const power =
    (basePower * animal.kickPowerBonus * (p.stats?.power ?? 1) * fireMult * rubberMult * (isClash ? 1.65 : 1.0)) / Math.sqrt(ball.mass);

  const effectiveDirY = ball.sliding ? Math.min(0.14, dirY * 0.55) : dirY;

  if (isStraightKick) {
    const forwardMomentum = Math.max(0, p.vx * dirX + p.vz * dirZ) * 0.25;
    const totalPower = power + forwardMomentum;
    ball.vx = dirX * totalPower;
    ball.vz = dirZ * totalPower;
    ball.vy = Math.max(ball.vy * 0.15, effectiveDirY * totalPower);
  } else {
    ball.vx = dirX * power + p.vx * 0.3;
    ball.vy = Math.max(ball.vy * 0.2, effectiveDirY * power);
    ball.vz = dirZ * power + p.vz * 0.3;
  }

  if (ball.sliding) {
    ball.spinX = 0;
    ball.spinZ = 0;
    ball.spinY = spinTorqueY !== 0 ? spinTorqueY : (Math.random() - 0.5) * 10.0;
  } else {
    ball.spinX = ball.vz * 1.4;
    ball.spinZ = -ball.vx * 1.4;
    ball.spinY = spinTorqueY !== 0 ? spinTorqueY : isStraightKick ? 0 : (Math.random() - 0.5) * 4.5;
  }

  ball.untouchedTimer = 0;
  ball.lastTouchTeam = p.team;
  ball.lastTouchPlayerId = p.id;
  ball.hitFlashTimer = 0.11;

  maybeEmitGoalSave(sim, p, prevBallVx);

  if (isClash) {
    ball.isClashedFire = true;
    ball.clashFireTimer = 4.5;
    sim.hitstopTimer = 0.068;
    if (!ball.isJelly10x) {
      sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.82);
    }
    sim.cameraZoomPulse = 0.65;
    sim.events.push({ type: 'clash', x: ball.x, y: ball.y, z: ball.z, intensity: 1 });
  } else {
    const isHeavyKick = power >= 15.5;
    sim.hitstopTimer = Math.max(sim.hitstopTimer, isHeavyKick ? 0.045 : 0.028);
    if (!ball.isJelly10x) {
      sim.cameraTrauma = Math.min(1, sim.cameraTrauma + (isHeavyKick ? 0.36 : 0.2));
    }
    if (isHeavyKick) {
      sim.cameraZoomPulse = Math.max(sim.cameraZoomPulse, 0.38);
    }
    sim.events.push({
      type: 'kick',
      team: p.team,
      x: ball.x,
      y: ball.y,
      z: ball.z,
      intensity: Math.min(1, power / 14),
    });
  }

  if (ball.isBombArmed && power > 7.5) {
    ball.isBombArmed = false;
    triggerBombBallExplosion(sim, 4.5);
  }
}

function activateCenterItem(sim: MatchSimulation, type: CenterItemType, collector: PlayerSim | null) {
  sim.activeItems = sim.activeItems.filter((i) => i.type !== type);
  let targetPlayerId: string | null = null;

  if (type === 'heavy_ghost') {
    const candidates = collector ? sim.players.filter((p) => p.team !== collector.team) : sim.players;
    const chosen = candidates[Math.floor(Math.random() * candidates.length)] ?? sim.players[0];
    if (chosen) {
      chosen.ghostAttachedTimer = ITEM_EFFECT_DURATION;
      targetPlayerId = chosen.id;
    }
  }

  sim.activeItems.push({
    type,
    remaining: ITEM_EFFECT_DURATION,
    targetPlayerId,
  });

  if (type === 'bomb_ball') {
    sim.ball.isBombArmed = true;
  }

  sim.events.push({ type: 'item_pickup', x: 0, y: 0.8, z: 0, label: type });
}

export function stepSimulation(
  sim: MatchSimulation,
  rawDt: number,
  humanInputs: { p1?: InputFrame; p2?: InputFrame; p3?: InputFrame; p4?: InputFrame }
) {
  const dt = Math.min(rawDt, 0.05);
  sim.events.length = 0;

  if (sim.matchEnded) return;

  sim.cameraTrauma = Math.max(0, sim.cameraTrauma - dt * 2.2);
  sim.cameraZoomPulse = Math.max(0, sim.cameraZoomPulse - dt * 2.4);
  sim.ball.hitFlashTimer = Math.max(0, sim.ball.hitFlashTimer - dt);

  if (sim.hitstopTimer > 0) {
    sim.hitstopTimer = Math.max(0, sim.hitstopTimer - dt);
    return;
  }

  sim.elapsedTime += dt;

  // Weather / Rain Timer (2 minutes max when active)
  if (sim.weather.isRaining) {
    sim.weather.rainTimer = Math.max(0, sim.weather.rainTimer - dt);
    sim.weather.wetness = Math.min(1, sim.weather.wetness + dt * 0.25);
    if (sim.weather.rainTimer <= 0) {
      sim.weather.isRaining = false;
    }
  } else {
    sim.weather.wetness = Math.max(0, sim.weather.wetness - dt * 0.08);
  }

  // Match timer pauses during goal celebration or halftime kickoff transition
  if (sim.goalCelebrationTimer > 0) {
    sim.goalCelebrationTimer -= dt;
    if (sim.goalCelebrationTimer <= 0) {
      sim.goalCelebrationTimer = 0;
      resetPositionsForKickoff(sim);
    }
  } else if (sim.halfTimeBannerTimer > 0) {
    sim.halfTimeBannerTimer -= dt;
    if (sim.halfTimeBannerTimer <= 0) {
      sim.halfTimeBannerTimer = 0;
    }
  } else if (sim.config.mode !== 'training' && sim.goldenGoal) {
    // Golden goal: waktu berhenti di 0:00, gol pertama langsung memenangkan pertandingan
    sim.timeRemaining = 0;
  } else if (sim.config.mode !== 'training') {
    sim.timeRemaining = Math.max(0, sim.timeRemaining - dt);

    const totalHalves = sim.config.halves ?? 2;
    const halfBoundary = sim.config.durationMinutes * 60;
    if (totalHalves === 2 && sim.currentHalf === 1 && sim.timeRemaining <= halfBoundary && sim.timeRemaining > 0.05) {
      sim.currentHalf = 2;
      sim.halfTimeBannerTimer = HALF_BREAK_SECONDS;
      resetPositionsForKickoff(sim);
      sim.events.push({ type: 'halftime', x: 0, y: 1.5, z: 0 });
    }

    if (sim.timeRemaining <= 0) {
      if (sim.redScore === sim.blueScore && totalHalves === 2) {
        // Seri di akhir babak 2: jeda 5 detik lalu golden goal
        sim.goldenGoal = true;
        sim.timeRemaining = 0;
        sim.halfTimeBannerTimer = HALF_BREAK_SECONDS;
        resetPositionsForKickoff(sim);
        sim.events.push({ type: 'halftime', x: 0, y: 1.5, z: 0 });
      } else {
        sim.matchEnded = true;
        sim.events.push({ type: 'whistle' });
        return;
      }
    }
  }

  // Jeda pergantian match: semua karakter & bola diam sampai teks pergantian selesai
  if (sim.goalCelebrationTimer <= 0 && sim.halfTimeBannerTimer > 0) {
    return;
  }

  // Random 2-Prop Drop Spawner (drops 2 random objects initially and every 2 minutes = 120s; disabled in Training or when propsEnabled === false)
  if (sim.goalCelebrationTimer <= 0 && sim.halfTimeBannerTimer <= 0) {
    if (sim.config.mode !== 'training' && sim.config.propsEnabled !== false) {
      sim.propSpawnTimer -= dt;
      if (sim.propSpawnTimer <= 0) {
        spawnRandomPropPair(sim);
        sim.propBatchCount += 1;
        sim.propSpawnTimer = PROP_SPAWN_INTERVAL;
      }
    }

    // 15-second Timer Bomb Ball periodic blast
    if (sim.config.ballType === 'timer_bomb') {
      sim.ball.bombCountdown -= dt;
      if (sim.ball.bombCountdown <= 0) {
        sim.ball.bombCountdown = TIMER_BOMB_INTERVAL;
        triggerBombBallExplosion(sim, 4.8);
      }
    }
  }

  // Update active center items (20s duration)
  for (const item of sim.activeItems) {
    item.remaining -= dt;
  }
  sim.activeItems = sim.activeItems.filter((i) => i.remaining > 0);

  // Center Item Orb Spawner (once every 1 minute = 60s; disabled in Training mode)
  const itemsEnabled =
    sim.config.mode !== 'training' && sim.config.itemSpawnMode !== 'off' && sim.config.enabledItems.length > 0;
  if (itemsEnabled) {
    if (!sim.pickupOrb.active) {
      sim.pickupOrb.respawnTimer -= dt;
      if (sim.pickupOrb.respawnTimer <= 0) {
        const pool = sim.config.enabledItems;
        sim.pickupOrb.type = pool[Math.floor(Math.random() * pool.length)];
        sim.pickupOrb.active = true;
        sim.pickupOrb.bobPhase = 0;
      }
    } else {
      sim.pickupOrb.bobPhase += dt * 2.5;
      sim.pickupOrb.y = 0.72 + Math.sin(sim.pickupOrb.bobPhase) * 0.14;

      let pickedBy: PlayerSim | null = null;
      let picked = false;
      for (const p of sim.players) {
        if (Math.hypot(p.x - sim.pickupOrb.x, p.z - sim.pickupOrb.z) < 1.05) {
          pickedBy = p;
          picked = true;
          break;
        }
      }
      if (!picked && Math.hypot(sim.ball.x - sim.pickupOrb.x, sim.ball.z - sim.pickupOrb.z) < sim.ball.radius * sim.ball.scaleMultiplier + 0.65) {
        picked = true;
      }
      if (picked) {
        sim.pickupOrb.active = false;
        sim.pickupOrb.respawnTimer = ITEM_RESPAWN_COOLDOWN;
        activateCenterItem(sim, sim.pickupOrb.type, pickedBy);
      }
    }
  }

  sim.ball.scaleMultiplier = hasActiveItem(sim, 'giant_ball') ? 2.1 : 1.0;
  sim.ball.isJelly10x = hasActiveItem(sim, 'jelly_10x');
  if (sim.ball.isJelly10x) {
    sim.cameraTrauma = 0;
  }
  if (!hasActiveItem(sim, 'bomb_ball')) {
    sim.ball.isBombArmed = false;
  }

  // Meteor Shower item hazard
  if (hasActiveItem(sim, 'meteor_shower')) {
    if (sim.meteors.length < 3 && Math.random() < dt * 1.4) {
      sim.meteors.push({
        active: true,
        x: (Math.random() - 0.5) * (PITCH_HALF_X * 1.6),
        y: 12.0,
        z: (Math.random() - 0.5) * (PITCH_HALF_Z * 1.6),
        vy: -15.5,
        impacted: false,
        life: 0.45,
      });
    }
  }

  for (const m of sim.meteors) {
    if (!m.active) continue;
    if (!m.impacted) {
      m.y += m.vy * dt;
      if (m.y <= 0.1) {
        m.y = 0;
        m.impacted = true;
        if (!sim.ball.isJelly10x) {
          sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.45);
        }
        sim.events.push({ type: 'meteor_impact', x: m.x, y: 0, z: m.z, intensity: 0.9 });

        for (const p of sim.players) {
          const dx = p.x - m.x;
          const dz = p.z - m.z;
          const dist = Math.hypot(dx, dz) || 0.1;
          if (dist < 2.6) {
            const f = (1 - dist / 2.6) * 9.5;
            startRagdollFall(p, p.vx + (dx / dist) * f, 3.8, p.vz + (dz / dist) * f, 1.1, sim);
          }
        }
        const bdx = sim.ball.x - m.x;
        const bdz = sim.ball.z - m.z;
        const bdist = Math.hypot(bdx, bdz) || 0.1;
        if (bdist < 2.8) {
          const bf = (1 - bdist / 2.8) * 12.0;
          sim.ball.vx += (bdx / bdist) * bf;
          sim.ball.vz += (bdz / bdist) * bf;
          sim.ball.vy = 6.5;
        }
      }
    } else {
      m.life -= dt;
      if (m.life <= 0) m.active = false;
    }
  }
  sim.meteors = sim.meteors.filter((m) => m.active);

  // Update Jelly Goalpost Springs
  updateJellySpring(sim.goalPosts.leftGoal.leftPost, dt);
  updateJellySpring(sim.goalPosts.leftGoal.rightPost, dt);
  updateJellySpring(sim.goalPosts.leftGoal.crossbar, dt);
  updateJellySpring(sim.goalPosts.rightGoal.leftPost, dt);
  updateJellySpring(sim.goalPosts.rightGoal.rightPost, dt);
  updateJellySpring(sim.goalPosts.rightGoal.crossbar, dt);

  // Update Players
  for (const p of sim.players) {
    const animal = ANIMALS.find((a) => a.id === p.custom.animal) ?? ANIMALS[0];

    p.dashCooldown = Math.max(0, p.dashCooldown - dt);
    p.dashTimer = Math.max(0, p.dashTimer - dt);
    if (p.sizeTimer > 0) {
      p.sizeTimer -= dt;
      if (p.sizeTimer <= 0) p.sizeTarget = 1;
    }
    p.sizeScale += (p.sizeTarget - p.sizeScale) * Math.min(1, 6 * dt);
    p.collisionStunTimer = Math.max(0, p.collisionStunTimer - dt);
    p.ghostAttachedTimer = Math.max(0, p.ghostAttachedTimer - dt);

    p.squashX += (1 - p.squashX) * Math.min(1, dt * 12);
    p.squashY += (1 - p.squashY) * Math.min(1, dt * 12);

    let input: InputFrame;
    if (p.humanSlot === 1 && humanInputs.p1) {
      input = humanInputs.p1;
    } else if (p.humanSlot === 2 && humanInputs.p2) {
      input = humanInputs.p2;
    } else if (p.humanSlot === 3 && humanInputs.p3) {
      input = humanInputs.p3;
    } else if (p.humanSlot === 4 && humanInputs.p4) {
      input = humanInputs.p4;
    } else if (!p.isHuman) {
      input = computeNpcInput(sim, p);
    } else {
      input = {
        moveX: 0,
        moveZ: 0,
        runHeld: false,
        kickPressed: false,
        kickHeld: false,
        kickRightSpinPressed: false,
        kickRightHeld: false,
        grabPressed: false,
        jumpPressed: false,
        headSpinLeftPressed: false,
        dashPressed: false,
      };
    }

    // Instant Limp Articulated Ragdoll Fall & Get Up (lemes seketika, zero limb clipping)
    if (p.fallTimer > 0) {
      if (p.carryingPropId) {
        dropCarriedProp(sim, p, p.vx * 0.4, 2.0, p.vz * 0.4);
      }
      p.fallTimer -= dt;
      p.vx *= Math.max(0, 1 - 4.2 * dt);
      p.vz *= Math.max(0, 1 - 4.2 * dt);
      p.kickStretch *= Math.max(0, 1 - 24 * dt);
      p.neckStretch *= Math.max(0, 1 - 24 * dt);

      if (p.fallTimer >= RAGDOLL_GETUP_TIME) {
        p.ragdollBlend = Math.min(1, p.ragdollBlend + dt * 16.0);
        const targetPitch = Math.PI * 0.48;
        p.ragdollVelPitch += (targetPitch - p.ragdollPitch) * 38 * dt;
        p.ragdollVelPitch *= Math.max(0, 1 - 6.5 * dt);
        p.ragdollPitch += p.ragdollVelPitch * dt;
        if (p.ragdollPitch > Math.PI * 0.5) {
          p.ragdollPitch = Math.PI * 0.5;
          p.ragdollVelPitch = -Math.abs(p.ragdollVelPitch) * 0.28;
        }

        p.ragdollVelRoll += (0 - p.ragdollRoll) * 10 * dt;
        p.ragdollVelRoll *= Math.max(0, 1 - 6.0 * dt);
        p.ragdollRoll += p.ragdollVelRoll * dt;

        // Floppy ragdoll joint settle
        const settle = Math.min(1, dt * 6);
        p.ragdollArmL += (-1.05 - p.ragdollArmL) * settle;
        p.ragdollArmR += (-1.05 - p.ragdollArmR) * settle;
        p.ragdollLegL += (0.28 - p.ragdollLegL) * settle;
        p.ragdollLegR += (-0.28 - p.ragdollLegR) * settle;
        p.animState = 'fall';
      } else {
        p.ragdollBlend = Math.max(0, p.ragdollBlend - dt * 5.2);
        const recAlpha = Math.min(1, dt * 12);
        p.ragdollPitch += (0 - p.ragdollPitch) * recAlpha;
        p.ragdollRoll += (0 - p.ragdollRoll) * recAlpha;
        p.ragdollArmL += (0 - p.ragdollArmL) * recAlpha;
        p.ragdollArmR += (0 - p.ragdollArmR) * recAlpha;
        p.ragdollLegL += (0 - p.ragdollLegL) * recAlpha;
        p.ragdollLegR += (0 - p.ragdollLegR) * recAlpha;
        p.ragdollNeck += (0 - p.ragdollNeck) * recAlpha;
        p.ragdollHeadRoll += (0 - p.ragdollHeadRoll) * recAlpha;
        p.animState = 'get_up';
      }
      p.wasPunchHeld = false;
      p.punchHoldTimer = 0;
      p.wasKickHeld = false;
      p.kickHoldTimer = 0;

      // === Ragdoll fisik sungguhan: rangka partikel dengan gravitasi, lantai, dinding & gesekan ===
      if (p.ragdoll) {
        const rd = p.ragdoll;
        const lying = p.fallTimer >= RAGDOLL_GETUP_TIME;
        // pergeseran dari luar (misal separasi antar pemain) ikut diterapkan ke seluruh rangka
        shiftRagdoll(rd, p.x - rd.lastX, p.z - rd.lastZ);
        if (lying) {
          stepRagdoll(rd, dt, {
            gravity: GRAVITY,
            bounds: { halfX: PITCH_HALF_X, halfZ: PITCH_HALF_Z, goalHalfZ: GOAL_HALF_Z },
          });
          p.ragdollBlend = Math.min(1, Math.max(p.ragdollBlend, 0.85) + dt * 16.0);
        } else {
          if (!rd.getUpFacingSet) {
            // Bangun menghadap arah yang wajar dari posisi tergeletak
            p.facing = getRagdollGetUpFacing(rd.pos);
            rd.getUpFacingSet = true;
          }
          p.ragdollBlend = Math.max(0, Math.min(1, p.fallTimer / RAGDOLL_GETUP_TIME));
        }
        const hip = getRagdollHip(rd.pos);
        p.x = hip.x;
        p.z = hip.z;
        p.y = 0;
        rd.lastX = p.x;
        rd.lastZ = p.z;
        // gerak sepenuhnya diurus ragdoll (integrasi posisi di bawah dilewati); p.vx/vz hanya cerminan kecepatan badan
        const tv = getRagdollTorsoVelocity(rd);
        p.vx = tv.vx;
        p.vy = tv.vy;
        p.vz = tv.vz;
      }
    } else {
      p.ragdoll = null;
      p.ragdollBlend = 0;
      p.ragdollPitch = 0;
      p.ragdollRoll = 0;
      p.ragdollVelPitch = 0;
      p.ragdollVelRoll = 0;
      p.ragdollArmL = 0;
      p.ragdollArmR = 0;
      p.ragdollLegL = 0;
      p.ragdollLegR = 0;
      p.ragdollNeck = 0;
      p.ragdollHeadRoll = 0;

      // B (`grabPressed`): Grab nearby loose prop OR gently drop carried prop
      if (input.grabPressed && p.punchPhase === 'none') {
        let bullNear: BullSim | null = null;
        if (!p.carryingPropId && !p.ridingBullId) {
          let bd = 2.1;
          for (const bl of sim.bulls) {
            const d = Math.hypot(bl.x - p.x, bl.z - p.z);
            if (d < bd) {
              bd = d;
              bullNear = bl;
            }
          }
        }
        if (p.ridingBullId) {
          // Turun dari banteng
          const bl = sim.bulls.find((x) => x.id === p.ridingBullId);
          p.ridingBullId = null;
          p.vy = 4.5;
          p.vx = (bl ? bl.vx : 0) * 0.6;
          p.vz = (bl ? bl.vz : 0) * 0.6;
          sim.events.push({ type: 'prop_drop', x: p.x, y: p.y + 1.0, z: p.z, label: 'bull' });
        } else if (bullNear) {
          // Naik ke punggung banteng (banteng tetap bergerak sendiri)
          p.ridingBullId = bullNear.id;
          p.dashTimer = 0;
          p.kickPhase = 'none';
          p.headPhase = 'none';
          sim.events.push({ type: 'prop_grab', x: p.x, y: p.y + 1.2, z: p.z, label: 'bull' });
        } else if (p.carryingPropId) {
          dropCarriedProp(sim, p, Math.sin(p.facing) * 2.2, 1.8, Math.cos(p.facing) * 2.2);
        } else {
          let nearest: ArenaPropSim | null = null;
          let bestDist = 1.85;
          for (const pr of sim.props) {
            if (pr.carriedByPlayerId || pr.usesRemaining <= 0) continue;
            if (pr.y > 2.0 || pr.kind === 'potion') continue;
            const dProp = Math.hypot(pr.x - p.x, pr.z - p.z);
            if (dProp < bestDist) {
              bestDist = dProp;
              nearest = pr;
            }
          }
          if (nearest) {
            p.carryingPropId = nearest.id;
            nearest.carriedByPlayerId = p.id;
            nearest.thrownActive = false;
            nearest.thrownByPlayerId = null;
            nearest.thrownByTeam = null;
            nearest.vx = 0;
            nearest.vy = 0;
            nearest.vz = 0;
            p.kickPhase = 'none';
            p.kickStretch = 0;
            p.kickSpinAngle = 0;
            p.kickSpinDir = 0;
            p.kickCharge = 0;
            p.kickHoldTimer = 0;
            p.headPhase = 'none';
            p.neckStretch = 0;
            p.dashTimer = 0;
            sim.events.push({ type: 'prop_grab', x: p.x, y: p.y + 1.2, z: p.z, label: nearest.kind });
          }
        }
      }

      const isCarrying = p.carryingPropId !== null;
      if (isCarrying) {
        // When carrying a prop: walk only, A throws the carried prop forward!
        if (input.kickPressed) {
          const pr = sim.props.find((item) => item.id === p.carryingPropId);
          p.carryingPropId = null;
          if (pr) {
            pr.carriedByPlayerId = null;
            pr.thrownActive = true;
            pr.thrownByPlayerId = p.id;
            pr.thrownByTeam = p.team;
            const fwdX = Math.sin(p.facing);
            const fwdZ = Math.cos(p.facing);
            pr.x = p.x + fwdX * 0.72;
            pr.y = p.y + 1.48;
            pr.z = p.z + fwdZ * 0.72;
            pr.vx = fwdX * 14.5 + p.vx * 0.25;
            pr.vy = 4.6;
            pr.vz = fwdZ * 14.5 + p.vz * 0.25;
            p.squashX = 1.22;
            p.squashY = 0.84;
            sim.events.push({ type: 'prop_throw', x: pr.x, y: pr.y, z: pr.z, label: pr.kind });
          }
        }
        p.punchPhase = 'none';
        p.punchTimer = 0;
        p.punchCharge = 0;
        p.wasPunchHeld = false;
        p.punchHoldTimer = 0;
        p.wasKickHeld = false;
        p.kickHoldTimer = 0;
        p.kickCharge = 0;
      } else {
        const isAirborne = p.y > 0.08 || p.vy > 1.2;

        // 1. X Button Hold-Only Punch State Machine (Hold >= 0.25s -> Punch; quick tap NEVER punches!)
        if (
          !isAirborne &&
          input.kickRightHeld &&
          (p.kickPhase === 'none' || p.punchPhase === 'charge') &&
          p.headPhase === 'none'
        ) {
          p.punchHoldTimer += dt;
          if (p.punchHoldTimer >= PUNCH_HOLD_THRESHOLD) {
            p.punchPhase = 'charge';
            p.punchTimer += dt;
            p.punchCharge = Math.min(1, p.punchCharge + dt * PUNCH_CHARGE_RATE);
          }
        } else if (!input.kickRightHeld && p.punchPhase === 'charge' && p.punchCharge < 0.999) {
          // Dilepas sebelum 5 detik: pukulan dibatalkan
          p.punchPhase = 'none';
          p.punchTimer = 0;
          p.punchCharge = 0;
          p.punchHoldTimer = 0;
          p.wasPunchHeld = false;
        } else if (!input.kickRightHeld && p.punchPhase === 'charge') {
          // Released X after charging -> Execute Mega Punch Strike!
          p.punchPhase = 'strike';
          p.punchTimer = 0;
          p.punchHitApplied = false;
          p.punchHoldTimer = 0;
          const lunge = 5.2 + p.punchCharge * 5.0;
          p.vx += Math.sin(p.facing) * lunge;
          p.vz += Math.cos(p.facing) * lunge;
          p.squashX = 1.24;
          p.squashY = 0.84;
        } else if (
          !isAirborne &&
          p.punchPhase === 'none' &&
          p.kickPhase === 'none' &&
          ((!input.kickRightHeld && p.wasPunchHeld && p.punchHoldTimer > 0 && p.punchHoldTimer < PUNCH_HOLD_THRESHOLD) ||
            (input.kickRightSpinPressed && !input.kickRightHeld))
        ) {
          // Quick tap X on ground -> Left-Leg 180° Spin Kick Right
          p.punchHoldTimer = 0;
          triggerKick(p, 'spin_right', sim.ball);
        } else if (!input.kickRightHeld) {
          p.punchHoldTimer = 0;
        }
        p.wasPunchHeld = Boolean(input.kickRightHeld);

        // Execute active punch strike / recover
        if (p.punchPhase === 'strike') {
          p.punchTimer += dt;
          if (!p.punchHitApplied) {
            const fistX = p.x + Math.sin(p.facing) * 0.85;
            const fistZ = p.z + Math.cos(p.facing) * 0.85;
            const fistY = p.y + 0.78;

            // Punch opponent: sends them flying far away!
            for (const other of sim.players) {
              if (other.id === p.id || other.fallTimer > 0) continue;
              const dx = other.x - fistX;
              const dz = other.z - fistZ;
              const dist = Math.hypot(dx, dz);
              if (dist < 1.55) {
                p.punchHitApplied = true;
                const dLen = Math.hypot(other.x - p.x, other.z - p.z) || 1;
                const dirX = (other.x - p.x) / dLen;
                const dirZ = (other.z - p.z) / dLen;
                const knockSpeed = (12.0 + p.punchCharge * 12.5) * (p.stats?.strength ?? 1);
                const knockVy = 5.4 + p.punchCharge * 3.2;
                startRagdollFall(other, dirX * knockSpeed, knockVy, dirZ * knockSpeed, 1.65, sim);
                sim.hitstopTimer = Math.max(sim.hitstopTimer, 0.055);
                if (!sim.ball.isJelly10x) {
                  sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.45 + p.punchCharge * 0.35);
                }
                sim.cameraZoomPulse = Math.max(sim.cameraZoomPulse, 0.45);
                sim.events.push({
                  type: 'punch_hit',
                  team: p.team,
                  x: other.x,
                  y: other.y + 0.8,
                  z: other.z,
                  intensity: 0.6 + p.punchCharge * 0.4,
                });
                if (other.team !== p.team) {
                  sim.events.push({
                    type: 'foul',
                    team: p.team,
                    x: other.x,
                    y: other.y + 0.8,
                    z: other.z,
                  });
                }
                break;
              }
            }

            // Punch loose prop -> launches it at opponents without wasting durability on air!
            if (!p.punchHitApplied) {
              for (const pr of sim.props) {
                if (pr.carriedByPlayerId || pr.usesRemaining <= 0) continue;
                if (Math.hypot(pr.x - fistX, pr.z - fistZ) < 1.45) {
                  p.punchHitApplied = true;
                  const spd = 12.0 + p.punchCharge * 8.0;
                  pr.vx = Math.sin(p.facing) * spd;
                  pr.vy = 4.2 + p.punchCharge * 2.5;
                  pr.vz = Math.cos(p.facing) * spd;
                  pr.thrownActive = true;
                  pr.thrownByPlayerId = p.id;
                  pr.thrownByTeam = p.team;
                  sim.events.push({
                    type: 'punch_hit',
                    team: p.team,
                    x: pr.x,
                    y: pr.y + 0.3,
                    z: pr.z,
                    intensity: 0.55 + p.punchCharge * 0.45,
                  });
                  break;
                }
              }
            }

            // Punch ball
            if (!p.punchHitApplied) {
              const hitBall = collidePointWithBallShape(fistX, fistY, fistZ, 0.65, sim.ball);
              if (hitBall.hit) {
                p.punchHitApplied = true;
                applyStrikeToBall(
                  sim,
                  p,
                  Math.sin(p.facing),
                  0.24,
                  Math.cos(p.facing),
                  13.5 + p.punchCharge * 9.0,
                  true
                );
                sim.events.push({
                  type: 'punch_hit',
                  team: p.team,
                  x: sim.ball.x,
                  y: sim.ball.y,
                  z: sim.ball.z,
                  intensity: 0.5 + p.punchCharge * 0.5,
                });
              }
            }
          }

          if (p.punchTimer >= PUNCH_STRIKE_TIME) {
            p.punchPhase = 'recover';
            p.punchTimer = 0;
          }
        } else if (p.punchPhase === 'recover') {
          p.punchTimer += dt;
          if (p.punchTimer >= PUNCH_RECOVER_TIME) {
            p.punchPhase = 'none';
            p.punchTimer = 0;
            p.punchCharge = 0;
            p.punchHitApplied = false;
          }
        }

        if (p.punchPhase === 'none') {
          if (input.dashPressed) triggerDash(p);
          if (input.jumpPressed) triggerJump(p);
          if (input.headSpinLeftPressed) triggerHeadAttack(p, 'spin_left', sim.ball);

          const airNow = p.y > 0.08 || p.vy > 1.2;

          // Aerial Combos: Jump+A = Front-Leg Fire Backflip; Jump+X = Backward Lob Backflip!
          if (airNow && input.kickPressed && (p.kickPhase === 'none' || p.kickPhase === 'super_charge')) {
            p.kickHoldTimer = 0;
            p.kickCharge = 0;
            triggerKick(p, 'backflip_front_fire', sim.ball);
          } else if (airNow && input.kickRightSpinPressed && p.kickPhase === 'none') {
            p.punchHoldTimer = 0;
            triggerKick(p, 'backflip_lob', sim.ball);
          } else if (!airNow) {
            // Grounded A Button: Tap = 180° Spin Kick Left; Hold >= 0.22s = Charge Super Kick!
            if (
              input.kickHeld &&
              (p.kickPhase === 'none' || p.kickPhase === 'super_charge') &&
              p.headPhase === 'none'
            ) {
              p.kickHoldTimer += dt;
              if (p.kickHoldTimer >= SUPER_KICK_HOLD_THRESHOLD) {
                p.kickPhase = 'super_charge';
                p.kickCharge = Math.min(1, p.kickCharge + dt * SUPER_KICK_CHARGE_RATE);
              }
            } else if (!input.kickHeld && p.kickPhase === 'super_charge') {
              // Released A after Super Kick charge -> unleash blazing Super Kick!
              p.kickHoldTimer = 0;
              triggerKick(p, 'super_kick', sim.ball);
            } else if (
              p.kickPhase === 'none' &&
              ((!input.kickHeld && p.wasKickHeld && p.kickHoldTimer > 0 && p.kickHoldTimer < SUPER_KICK_HOLD_THRESHOLD) ||
                (input.kickPressed && !input.kickHeld))
            ) {
              p.kickHoldTimer = 0;
              triggerKick(p, 'spin_left', sim.ball);
            } else if (!input.kickHeld) {
              p.kickHoldTimer = 0;
            }
          }
          p.wasKickHeld = Boolean(input.kickHeld);
        }
      }

      // Movement (walk-only speed cap when carrying a prop; slowed while charging Super Kick, Punch, or Honey Ball)
      const inMag = Math.min(1, Math.hypot(input.moveX, input.moveZ));
      const ghostFactor = p.ghostAttachedTimer > 0 ? 0.56 : 1.0;
      const isChargingAny = p.punchPhase === 'charge' || p.kickPhase === 'super_charge';
      const carryOrChargeFactor = isChargingAny ? 0.62 : sim.ball.stickyTargetPlayerId === p.id ? 0.84 : 1.0;

      if (p.dashTimer > 0 && p.fallTimer <= 0) {
        const dashSpeedMult = p.ghostAttachedTimer > 0 ? 0.65 : 1.0;
        p.vx = Math.sin(p.facing) * DASH_SPEED * dashSpeedMult;
        p.vz = Math.cos(p.facing) * DASH_SPEED * dashSpeedMult;
      } else if (p.dashTimer <= 0 && p.collisionStunTimer <= 0 && p.headPhase !== 'turn_first') {
        if (inMag > 0.08) {
          const dirX = input.moveX / (Math.hypot(input.moveX, input.moveZ) || 1);
          const dirZ = input.moveZ / (Math.hypot(input.moveX, input.moveZ) || 1);

          const targetFacing = Math.atan2(dirX, dirZ);
          const diff = normalizeAngle(targetFacing - p.facing);
          const maxStep = TURN_SPEED * (p.stats?.reaction ?? 1) * dt;
          if (Math.abs(diff) <= maxStep) {
            p.facing = targetFacing;
            p.turnRateVisual = diff / Math.max(dt, 0.001);
          } else {
            p.facing = normalizeAngle(p.facing + Math.sign(diff) * maxStep);
            p.turnRateVisual = Math.sign(diff) * TURN_SPEED;
          }

          const isRunning = !isCarrying && input.runHeld && !isChargingAny;
          const baseMaxSpeed = isRunning ? RUN_SPEED : WALK_SPEED * Math.max(0.45, inMag);
          // Stamina: pelari berstamina rendah melambat seiring pertandingan berjalan
          const fatigue = p.stats ? Math.min(1, sim.elapsedTime / 150) * Math.max(0, 1.15 - p.stats.stamina) * 0.4 : 0;
          const targetSpeed =
            baseMaxSpeed * animal.speedBonus * (p.stats?.speed ?? 1) * (1 - fatigue) * ghostFactor * carryOrChargeFactor;

          const targetVx = dirX * targetSpeed;
          const targetVz = dirZ * targetSpeed;

          const accelK = PLAYER_ACCEL * (p.stats?.accel ?? 1);
          p.vx += (targetVx - p.vx) * Math.min(1, accelK * dt);
          p.vz += (targetVz - p.vz) * Math.min(1, accelK * dt);
        } else {
          p.turnRateVisual = 0;
          const speed = Math.hypot(p.vx, p.vz);
          if (speed > 0.01) {
            const drop = Math.max(speed * GROUND_FRICTION, PLAYER_DECEL) * dt;
            const newSpeed = Math.max(0, speed - drop);
            const ratio = newSpeed / speed;
            p.vx *= ratio;
            p.vz *= ratio;
          } else {
            p.vx = 0;
            p.vz = 0;
          }
        }
      }

      // 1. Rubber Kick State Machine (180° Spin Kicks, Super Kick, Jump+A Fire Backflip, Jump+X Lob Backflip)
      const isSpinKick = p.kickVariant === 'spin_left' || p.kickVariant === 'spin_right';
      const isBackflipKick = p.kickVariant === 'backflip_front_fire' || p.kickVariant === 'backflip_lob';

      if (p.kickPhase === 'super_charge') {
        p.kickTimer += dt;
      } else if (p.kickPhase === 'prep') {
        p.kickTimer += dt;
        if (p.kickVariant === 'backward') {
          const diff = normalizeAngle(p.kickPendingTurn - p.facing);
          const step = Math.min(Math.abs(diff), HEAD_TURN_SPEED * dt);
          p.facing = normalizeAngle(p.facing + Math.sign(diff) * step);
          p.kickTargetDirX = Math.sin(p.facing);
          p.kickTargetDirZ = Math.cos(p.facing);
        }
        p.kickStretch = -0.15 * (p.kickTimer / KICK_PREP_TIME);
        if (p.kickTimer >= KICK_PREP_TIME && (p.kickVariant !== 'backward' || Math.abs(normalizeAngle(p.kickPendingTurn - p.facing)) < 0.15)) {
          p.kickPhase = 'extend';
          p.kickTimer = 0;
        }
      } else if (p.kickPhase === 'extend') {
        p.kickTimer += dt;
        if (isSpinKick) {
          const progress = Math.min(1, p.kickTimer / KICK_SPIN_EXTEND_TIME);
          const eased = 0.5 - 0.5 * Math.cos(progress * Math.PI);
          // 180° arc: -PI/2 -> +PI/2 (ONLY kicking leg moves; torso stays fixed!)
          p.kickSpinAngle = -Math.PI * 0.5 + eased * Math.PI;
          p.kickStretch = 0.48 + 0.52 * Math.sin(progress * Math.PI);
          const worldAngle = p.facing + p.kickSpinAngle * p.kickSpinDir;
          p.kickTargetDirX = Math.sin(worldAngle);
          p.kickTargetDirZ = Math.cos(worldAngle);

          if (!p.kickHitApplied) {
            const samples = getKickingLegSamplePoints(p);
            for (const pt of samples) {
              const hitRes = collidePointWithBallShape(pt.x, pt.y, pt.z, pt.radius, sim.ball);
              if (hitRes.hit) {
                p.kickHitApplied = true;
                const dx = sim.ball.x - p.x;
                const dz = sim.ball.z - p.z;
                const len = Math.hypot(dx, dz) || 1;
                const sweepX = (dx / len) * 0.62 + p.kickTargetDirX * 0.38;
                const sweepZ = (dz / len) * 0.62 + p.kickTargetDirZ * 0.38;
                const sLen = Math.hypot(sweepX, sweepZ) || 1;
                if (p.kickVariant === 'spin_right') {
                  // Tombol X: tendangan melambung (lob) tinggi ke depan
                  applyStrikeToBall(sim, p, sweepX / sLen, 0.9, sweepZ / sLen, 15.5, true, p.kickSpinDir * 4.0);
                  sim.ball.vy = Math.max(sim.ball.vy, 11.5);
                } else {
                  applyStrikeToBall(sim, p, sweepX / sLen, 0.24, sweepZ / sLen, 18.5, false, p.kickSpinDir * 9.5);
                }
                break;
              }
            }
            // Swept-sector continuity check so fast-moving balls never tunnel past the whip arc
            if (!p.kickHitApplied) {
              const bdx = sim.ball.x - p.x;
              const bdz = sim.ball.z - p.z;
              const bDistXZ = Math.hypot(bdx, bdz);
              if (bDistXZ <= 1.52 && sim.ball.y <= p.y + 1.28) {
                const ballYaw = Math.atan2(bdx, bdz);
                if (Math.abs(normalizeAngle(ballYaw - worldAngle)) < 0.48) {
                  p.kickHitApplied = true;
                  const len = bDistXZ || 1;
                  const sweepX = (bdx / len) * 0.62 + p.kickTargetDirX * 0.38;
                  const sweepZ = (bdz / len) * 0.62 + p.kickTargetDirZ * 0.38;
                  const sLen = Math.hypot(sweepX, sweepZ) || 1;
                  if (p.kickVariant === 'spin_right') {
                  // Tombol X: tendangan melambung (lob) tinggi ke depan
                  applyStrikeToBall(sim, p, sweepX / sLen, 0.9, sweepZ / sLen, 15.5, true, p.kickSpinDir * 4.0);
                  sim.ball.vy = Math.max(sim.ball.vy, 11.5);
                } else {
                  applyStrikeToBall(sim, p, sweepX / sLen, 0.24, sweepZ / sLen, 18.5, false, p.kickSpinDir * 9.5);
                }
                }
              }
            }
          }

          if (p.kickTimer >= KICK_SPIN_EXTEND_TIME) {
            p.kickPhase = 'retract';
            p.kickTimer = 0;
          }
        } else if (isBackflipKick) {
          const progress = Math.min(1, p.kickTimer / BACKFLIP_TIME);
          p.backflipAngle = progress * Math.PI * 2;
          p.kickStretch = Math.sin(progress * Math.PI) * 0.95;
          p.kickTargetDirX = Math.sin(p.facing);
          p.kickTargetDirZ = Math.cos(p.facing);

          if (!p.kickHitApplied) {
            const samples = getKickingLegSamplePoints(p);
            for (const pt of samples) {
              const hitRes = collidePointWithBallShape(pt.x, pt.y, pt.z, pt.radius, sim.ball);
              if (hitRes.hit) {
                p.kickHitApplied = true;
                if (p.kickVariant === 'backflip_front_fire') {
                  // Jump + A: Front-leg backflip ignites ball on fire and shoots blazing fast!
                  sim.ball.isClashedFire = true;
                  sim.ball.clashFireTimer = 5.0;
                  applyStrikeToBall(sim, p, p.kickTargetDirX, 0.24, p.kickTargetDirZ, 21.5, true);
                  sim.events.push({ type: 'clash', x: sim.ball.x, y: sim.ball.y, z: sim.ball.z, intensity: 0.9 });
                } else {
                  // Jump + X: Backward backflip lofts/lobs the ball high into the air!
                  applyStrikeToBall(sim, p, p.kickTargetDirX * 0.6, 0.8, p.kickTargetDirZ * 0.6, 17.5, true);
                  sim.ball.vy = Math.max(sim.ball.vy, 13.0);
                }
                break;
              }
            }
          }

          if (p.kickTimer >= BACKFLIP_TIME) {
            p.kickPhase = 'retract';
            p.kickTimer = 0;
            p.backflipAngle = 0;
          }
        } else {
          const progress = Math.min(1, p.kickTimer / KICK_EXTEND_TIME);
          p.kickStretch = Math.sin(progress * Math.PI * 0.5);

          if (!p.kickHitApplied) {
            const samples = getKickingLegSamplePoints(p);
            for (const pt of samples) {
              const hitRes = collidePointWithBallShape(pt.x, pt.y, pt.z, pt.radius, sim.ball);
              if (hitRes.hit) {
                p.kickHitApplied = true;
                if (p.kickVariant === 'super_kick') {
                  const superPower = 20.0 + p.kickCharge * 10.5;
                  if (p.kickCharge >= 0.35) {
                    sim.ball.isClashedFire = true;
                    sim.ball.clashFireTimer = 4.5;
                    sim.events.push({ type: 'clash', x: sim.ball.x, y: sim.ball.y, z: sim.ball.z, intensity: 0.95 });
                  }
                  applyStrikeToBall(sim, p, p.kickTargetDirX, 0.26, p.kickTargetDirZ, superPower, true);
                } else {
                  const kickPower = p.dashTimer > 0 ? 19.5 : 17.2;
                  applyStrikeToBall(sim, p, p.kickTargetDirX, 0.22, p.kickTargetDirZ, kickPower, true);
                }
                break;
              }
            }
          }

          if (p.kickTimer >= KICK_EXTEND_TIME) {
            p.kickPhase = 'retract';
            p.kickTimer = 0;
          }
        }
      } else if (p.kickPhase === 'retract') {
        p.kickTimer += dt;
        const retractDur = isSpinKick ? KICK_SPIN_RETRACT_TIME : KICK_RETRACT_TIME;
        const progress = Math.min(1, p.kickTimer / retractDur);
        p.kickStretch = (1 - progress) * Math.cos(progress * Math.PI * 1.5);
        if (isSpinKick) {
          p.kickSpinAngle = Math.PI * 0.5;
        }
        if (p.kickTimer >= retractDur) {
          p.kickPhase = 'none';
          p.kickStretch = 0;
          p.kickSpinAngle = 0;
          p.kickSpinDir = 0;
          p.kickCharge = 0;
          p.backflipAngle = 0;
        }
      }

      // 2. Rubber Neck Heading & Salto Long Curved Neck State Machine (B, L)
      const isHeadSpin = p.headVariant === 'spin_left' || p.headVariant === 'spin_right';
      const isSaltoHead = p.headVariant === 'salto_curved';

      if (p.headPhase === 'turn_first') {
        p.headTimer += dt;
        const diff = normalizeAngle(p.headDesiredFacing - p.facing);
        const step = Math.min(Math.abs(diff), HEAD_TURN_SPEED * dt);
        p.facing = normalizeAngle(p.facing + Math.sign(diff) * step);
        p.turnRateVisual = Math.sign(diff) * HEAD_TURN_SPEED;
        if (Math.abs(diff) < 0.14 || p.headTimer > 0.28) {
          p.facing = p.headDesiredFacing;
          p.headTargetDirX = Math.sin(p.facing);
          p.headTargetDirZ = Math.cos(p.facing);
          p.headPhase = 'extend';
          p.headTimer = 0;
        }
      } else if (p.headPhase === 'prep') {
        p.headTimer += dt;
        p.neckStretch = 0.08 * (p.headTimer / HEAD_PREP_TIME);
        if (p.headTimer >= HEAD_PREP_TIME) {
          p.headPhase = 'extend';
          p.headTimer = 0;
        }
      } else if (p.headPhase === 'extend') {
        p.headTimer += dt;
        if (isHeadSpin) {
          const progress = Math.min(1, p.headTimer / HEAD_SPIN_EXTEND_TIME);
          p.headSpinAngle = progress * Math.PI * 2;
          p.neckStretch = Math.sin(progress * Math.PI) * 1.0;

          if (!p.headHitApplied) {
            const headPos = getExtendedHeadPosition(p);
            const hitRes = collidePointWithBallShape(headPos.x, headPos.y, headPos.z, 0.54, sim.ball);
            if (hitRes.hit) {
              p.headHitApplied = true;
              const worldAngle = p.facing + p.headSpinAngle * p.headSpinDir;
              const hitDirX = Math.sin(worldAngle);
              const hitDirZ = Math.cos(worldAngle);
              applyStrikeToBall(sim, p, hitDirX, 0.26, hitDirZ, 12.6, false, p.headSpinDir * 7.5);
            }
          }

          if (p.headTimer >= HEAD_SPIN_EXTEND_TIME) {
            p.headPhase = 'retract';
            p.headTimer = 0;
          }
        } else if (isSaltoHead) {
          const progress = Math.min(1, p.headTimer / SALTO_EXTEND_TIME);
          p.saltoAngle = progress * Math.PI * 2;
          p.neckStretch = Math.sin(progress * Math.PI * 0.85) * 1.0;
          p.headTargetDirX = Math.sin(p.facing);
          p.headTargetDirZ = Math.cos(p.facing);

          if (!p.headHitApplied) {
            const headPos = getExtendedHeadPosition(p);
            const hitRes = collidePointWithBallShape(headPos.x, headPos.y, headPos.z, 0.62, sim.ball);
            if (hitRes.hit) {
              p.headHitApplied = true;
              // Salto ignites the ball on fire and fires it super fast!
              sim.ball.isClashedFire = true;
              sim.ball.clashFireTimer = 5.0;
              applyStrikeToBall(sim, p, p.headTargetDirX, 0.22, p.headTargetDirZ, 21.5, true);
              sim.events.push({ type: 'clash', x: sim.ball.x, y: sim.ball.y, z: sim.ball.z, intensity: 0.9 });
            }
          }

          if (p.headTimer >= SALTO_EXTEND_TIME) {
            p.headPhase = 'retract';
            p.headTimer = 0;
            p.saltoAngle = 0;
          }
        } else {
          // Directional rubber heading (forward, left, right, backward)
          const progress = Math.min(1, p.headTimer / HEAD_EXTEND_TIME);
          p.neckStretch = Math.sin(progress * Math.PI * 0.5);

          if (!p.headHitApplied) {
            const headPos = getExtendedHeadPosition(p);
            const hitRes = collidePointWithBallShape(headPos.x, headPos.y, headPos.z, 0.56, sim.ball);
            if (hitRes.hit) {
              p.headHitApplied = true;
              applyStrikeToBall(sim, p, p.headTargetDirX, 0.26, p.headTargetDirZ, 12.2, true);
            }
          }

          if (p.headTimer >= HEAD_EXTEND_TIME) {
            p.headPhase = 'retract';
            p.headTimer = 0;
          }
        }
      } else if (p.headPhase === 'retract') {
        p.headTimer += dt;
        const retractDur = isHeadSpin ? HEAD_SPIN_RETRACT_TIME : HEAD_RETRACT_TIME;
        const progress = Math.min(1, p.headTimer / retractDur);
        p.neckStretch = Math.max(0, (1 - progress) * Math.cos(progress * Math.PI * 1.2));
        if (isHeadSpin) {
          p.headSpinAngle = Math.PI * 2;
        }
        if (p.headTimer >= retractDur) {
          p.headPhase = 'none';
          p.neckStretch = 0;
          p.neckCurve = 0;
          p.headSpinAngle = 0;
          p.headSpinDir = 0;
          p.saltoAngle = 0;
        }
      }

      // Animation State Classification
      const horizSpeed = Math.hypot(p.vx, p.vz);
      if (p.punchPhase === 'charge') {
        p.animState = 'punch_charge';
      } else if (p.punchPhase === 'strike' || p.punchPhase === 'recover') {
        p.animState = 'punch_strike';
      } else if (p.headPhase !== 'none') {
        p.animState =
          p.headVariant === 'salto_curved'
            ? 'salto_head'
            : p.headVariant === 'spin_left' || p.headVariant === 'spin_right'
              ? 'head_spin_360'
              : 'head_rubber';
      } else if (p.kickPhase === 'super_charge') {
        p.animState = 'super_kick_charge';
      } else if (p.kickPhase === 'prep') {
        p.animState = 'kick_prep';
      } else if (p.kickPhase !== 'none') {
        p.animState =
          p.kickVariant === 'backflip_front_fire'
            ? 'backflip_front'
            : p.kickVariant === 'backflip_lob'
              ? 'backflip_back'
              : p.kickVariant === 'super_kick'
                ? 'super_kick'
                : p.kickVariant === 'spin_left' || p.kickVariant === 'spin_right'
                  ? 'spin_kick_360'
                  : 'rubber_kick';
      } else if (p.y > 0.08) p.animState = 'jump';
      else if (p.collisionStunTimer > 0) p.animState = 'collision';
      else if (horizSpeed > 3.1) p.animState = 'run';
      else if (horizSpeed > 1.35) p.animState = 'normal_walk';
      else if (horizSpeed > 0.2) p.animState = 'slow_walk';
      else if (p.turnRateVisual > 1.5) p.animState = 'turn_left';
      else if (p.turnRateVisual < -1.5) p.animState = 'turn_right';
      else p.animState = 'idle';

      p.walkCycle += horizSpeed * dt * 3.8;
    }

    // Integrate Position & Vertical Gravity (pemain ragdoll digerakkan oleh rangka fisiknya sendiri)
    const ragdollDriven = p.ragdoll !== null && p.fallTimer > 0;
    if (!ragdollDriven) {
      p.x += p.vx * dt;
      p.z += p.vz * dt;
    }
    if (!ragdollDriven && (p.y > 0 || p.vy > 0)) {
      p.vy -= GRAVITY * dt;
      p.y += p.vy * dt;
      if (p.y <= 0) {
        p.y = 0;
        if (p.vy < -2.0) {
          p.squashX = 1.2;
          p.squashY = 0.8;
          if (p.fallTimer <= 0) p.animState = 'landing';
        }
        p.vy = 0;
      }
    }

    const maxPlayerX = Math.abs(p.z) < GOAL_HALF_Z - 0.35 ? PITCH_HALF_X + 0.65 : PITCH_HALF_X - 0.35;
    p.x = Math.max(-maxPlayerX, Math.min(maxPlayerX, p.x));
    p.z = Math.max(-(PITCH_HALF_Z - 0.35), Math.min(PITCH_HALF_Z - 0.35, p.z));
  }

  // Player-to-Player Separation & High-Impact Body Collision Ragdoll
  for (let i = 0; i < sim.players.length; i++) {
    for (let j = i + 1; j < sim.players.length; j++) {
      const a = sim.players[i];
      const b = sim.players[j];
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const dist = Math.hypot(dx, dz);
      const minD = 0.92;
      if (dist < minD && dist > 0.001) {
        // Strength: pemain lebih kuat menggeser lawan lebih jauh saat berbenturan
        const strA = a.stats?.strength ?? 1;
        const strB = b.stats?.strength ?? 1;
        const pushA = (minD - dist) * (strB / (strA + strB));
        const pushB = (minD - dist) * (strA / (strA + strB));
        const nx = dx / dist;
        const nz = dz / dist;
        a.x -= nx * pushA;
        a.z -= nz * pushA;
        b.x += nx * pushB;
        b.z += nz * pushB;

        const relSp = Math.hypot(a.vx - b.vx, a.vz - b.vz);
        if (relSp > 5.8 && a.team !== b.team) {
          // Dash hanya menyenggol: lawan terdorong sedikit tapi TIDAK jatuh
          if (a.dashTimer > 0 && b.fallTimer <= 0) {
            b.vx += nx * 2.4;
            b.vz += nz * 2.4;
            b.squashX = 1.12;
            b.squashY = 0.9;
          } else if (b.dashTimer > 0 && a.fallTimer <= 0) {
            a.vx -= nx * 2.4;
            a.vz -= nz * 2.4;
            a.squashX = 1.12;
            a.squashY = 0.9;
          }
        }
      }
    }
  }

  // Update Drop Props (Wooden Chair, Wooden Box, Oil Drum, Water Gallon — 3 uses durability)
  for (const pr of sim.props) {
    pr.flashTimer = Math.max(0, pr.flashTimer - dt);
    if (pr.usesRemaining <= 0) continue;

    if (pr.kind === 'bomb') {
      pr.fuse = (pr.fuse ?? 6.5) - dt;
      if (pr.fuse < 2.5) pr.flashTimer = Math.floor(pr.fuse * 7) % 2 === 0 ? 0.12 : 0;
      if (pr.fuse <= 0) {
        explodeBombProp(sim, pr);
        continue;
      }
    } else if (pr.kind === 'ostrich_egg' && !pr.carriedByPlayerId && pr.y < 0.6) {
      pr.fuse = (pr.fuse ?? 10) - dt;
      const bl = sim.ball;
      const hitByBall =
        Math.hypot(bl.x - pr.x, bl.z - pr.z) < pr.radius + bl.radius * bl.scaleMultiplier + 0.05 &&
        Math.hypot(bl.vx, bl.vz) > 5;
      if (pr.fuse <= 0 || hitByBall) {
        damageProp(sim, pr, 99);
        continue;
      }
    } else if (pr.kind === 'potion' && !pr.carriedByPlayerId && pr.y < 1.2) {
      let drunk = false;
      for (const pl of sim.players) {
        if (pl.fallTimer > 0) continue;
        if (Math.hypot(pl.x - pr.x, pl.z - pr.z) < 1.25 && pl.y < pr.y + 1.6) {
          // Ramuan: pemain mengecil atau membesar selama 20 detik
          pl.sizeTarget = Math.random() < 0.5 ? 0.55 : 1.7;
          pl.sizeTimer = 20;
          pr.usesRemaining = 0;
          pr.done = true;
          sim.events.push({ type: 'item_pickup', x: pl.x, y: pl.y + 1.0, z: pl.z, label: 'potion' });
          drunk = true;
          break;
        }
      }
      if (drunk) continue;
    }

    if (pr.carriedByPlayerId) {
      const holder = sim.players.find((pl) => pl.id === pr.carriedByPlayerId);
      if (!holder || holder.fallTimer > 0) {
        pr.carriedByPlayerId = null;
        if (holder) holder.carryingPropId = null;
        pr.vy = -1.0;
      } else {
        pr.x = holder.x;
        pr.y = holder.y + 1.58;
        pr.z = holder.z;
        pr.rotY = holder.facing;
        pr.vx = holder.vx;
        pr.vy = holder.vy;
        pr.vz = holder.vz;
      }
      continue;
    }

    pr.vy -= GRAVITY * dt;
    pr.x += pr.vx * dt;
    pr.y += pr.vy * dt;
    pr.z += pr.vz * dt;
    pr.rotY += (Math.hypot(pr.vx, pr.vz) > 0.3 ? 3.2 : 0) * dt;

    // Ground bounce
    if (pr.y < 0.36) {
      pr.y = 0.36;
      if (pr.vy < -1.8) {
        pr.vy = Math.abs(pr.vy) * 0.35;
      } else {
        pr.vy = 0;
      }
      const friction = Math.max(0, 1 - 6.5 * dt);
      pr.vx *= friction;
      pr.vz *= friction;
      if (pr.thrownActive && Math.hypot(pr.vx, pr.vz) < 1.2) {
        pr.thrownActive = false;
        damageProp(sim, pr, 1);
      }
    }

    // Wall bounce
    if (pr.x < -PITCH_HALF_X + 0.45) {
      pr.x = -PITCH_HALF_X + 0.45;
      pr.vx = Math.abs(pr.vx) * 0.55;
      if (pr.thrownActive) {
        pr.thrownActive = false;
        damageProp(sim, pr, 1);
      }
    } else if (pr.x > PITCH_HALF_X - 0.45) {
      pr.x = PITCH_HALF_X - 0.45;
      pr.vx = -Math.abs(pr.vx) * 0.55;
      if (pr.thrownActive) {
        pr.thrownActive = false;
        damageProp(sim, pr, 1);
      }
    }
    if (pr.z < -PITCH_HALF_Z + 0.45) {
      pr.z = -PITCH_HALF_Z + 0.45;
      pr.vz = Math.abs(pr.vz) * 0.55;
      if (pr.thrownActive) {
        pr.thrownActive = false;
        damageProp(sim, pr, 1);
      }
    } else if (pr.z > PITCH_HALF_Z - 0.45) {
      pr.z = PITCH_HALF_Z - 0.45;
      pr.vz = -Math.abs(pr.vz) * 0.55;
      if (pr.thrownActive) {
        pr.thrownActive = false;
        damageProp(sim, pr, 1);
      }
    }

    // Thrown prop vs players (3-use durability only decrements per throw use, NEVER on ball touch!)
    if (pr.thrownActive && pr.usesRemaining > 0) {
      for (const target of sim.players) {
        if (target.id === pr.thrownByPlayerId || target.fallTimer > 0) continue;
        if (Math.hypot(target.x - pr.x, target.z - pr.z) < 0.95 && Math.abs(pr.y - (target.y + 0.7)) < 1.2) {
          startRagdollFall(target, pr.vx * 0.72, 4.4, pr.vz * 0.72, 1.35, sim);
          pr.thrownActive = false;
          pr.vx *= -0.28;
          pr.vz *= -0.28;
          damageProp(sim, pr, 1);
          sim.events.push({ type: 'ragdoll_fall', x: target.x, y: target.y + 0.6, z: target.z });
          if (pr.thrownByTeam && pr.thrownByTeam !== target.team) {
            sim.events.push({ type: 'foul', team: pr.thrownByTeam, x: target.x, y: target.y + 0.6, z: target.z });
          }
          break;
        }
      }
    }
  }

  // Solid Player <-> Loose Prop Collision (zero clipping: players cannot walk straight through props)
  for (const pr of sim.props) {
    if (pr.carriedByPlayerId || pr.usesRemaining <= 0 || pr.kind === 'potion') continue;
    for (const pl of sim.players) {
      if (pl.fallTimer > 0) continue;
      if (pl.y > pr.y + 0.78) continue; // Allow jumping cleanly over props
      const dx = pl.x - pr.x;
      const dz = pl.z - pr.z;
      const dist = Math.hypot(dx, dz);
      const minD = 0.44 + pr.radius;
      if (dist < minD) {
        const nx = dist > 0.001 ? dx / dist : 1;
        const nz = dist > 0.001 ? dz / dist : 0;
        const pen = minD - dist;
        pl.x += nx * pen * 0.65;
        pl.z += nz * pen * 0.65;
        pr.x -= nx * pen * 0.35;
        pr.z -= nz * pen * 0.35;

        const rvx = pl.vx - pr.vx;
        const rvz = pl.vz - pr.vz;
        const vn = rvx * nx + rvz * nz;
        if (vn < 0) {
          pr.vx += nx * vn * 0.65;
          pr.vz += nz * vn * 0.65;
          pl.vx -= nx * vn * 0.35;
          pl.vz -= nz * vn * 0.35;
        }
      }
    }
  }

  // Solid Prop <-> Prop Separation
  for (let i = 0; i < sim.props.length; i++) {
    const a = sim.props[i];
    if (a.carriedByPlayerId || a.usesRemaining <= 0) continue;
    for (let j = i + 1; j < sim.props.length; j++) {
      const b = sim.props[j];
      if (b.carriedByPlayerId || b.usesRemaining <= 0) continue;
      if (Math.abs(a.y - b.y) > 0.9) continue;
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const dist = Math.hypot(dx, dz);
      const minD = a.radius + b.radius;
      if (dist < minD) {
        const nx = dist > 0.001 ? dx / dist : 1;
        const nz = dist > 0.001 ? dz / dist : 0;
        const push = (minD - dist) * 0.5;
        a.x -= nx * push;
        a.z -= nz * push;
        b.x += nx * push;
        b.z += nz * push;
      }
    }
  }

  // Solid Prop <-> Ball Collision (ball NEVER passes through and NEVER destroys prop!)
  resolveSolidBallVsProps(sim);

  sim.props = sim.props.filter((pr) => pr.usesRemaining > 0);
  updateBulls(sim, dt);
  // Penunggang mengikuti banteng; terlepas jika jatuh / banteng hilang
  for (const rp of sim.players) {
    if (!rp.ridingBullId) continue;
    const bl = sim.bulls.find((x) => x.id === rp.ridingBullId);
    if (!bl || rp.fallTimer > 0) {
      rp.ridingBullId = null;
      continue;
    }
    rp.x = bl.x;
    rp.z = bl.z;
    rp.y = 1.65;
    rp.vx = bl.vx;
    rp.vz = bl.vz;
    rp.vy = 0;
    rp.facing = bl.facing;
  }

  // Shape-Realistic Ball Physics
  const ball = sim.ball;
  ball.untouchedTimer += dt;
  ball.stickyCooldown = Math.max(0, ball.stickyCooldown - dt);
  if (ball.clashFireTimer > 0) {
    ball.clashFireTimer -= dt;
    if (ball.clashFireTimer <= 0) ball.isClashedFire = false;
  }

  // Sticky Honey Ball adherence state
  if (ball.stickyTargetPlayerId) {
    const host = sim.players.find((pl) => pl.id === ball.stickyTargetPlayerId);
    if (
      host &&
      host.fallTimer <= 0 &&
      !host.carryingPropId &&
      host.kickPhase === 'none' &&
      host.headPhase === 'none' &&
      host.punchPhase !== 'strike' &&
      host.dashTimer <= 0 &&
      ball.stickyTimer > 0 &&
      sim.goalCelebrationTimer <= 0 &&
      sim.halfTimeBannerTimer <= 0
    ) {
      ball.stickyTimer -= dt;
      ball.x = host.x + Math.sin(host.facing) * 0.66;
      ball.z = host.z + Math.cos(host.facing) * 0.66;
      ball.y = host.y + ball.radius * ball.scaleMultiplier;
      ball.vx = host.vx;
      ball.vy = 0;
      ball.vz = host.vz;
      ball.untouchedTimer = 0;
    } else {
      ball.stickyTargetPlayerId = null;
      ball.stickyTimer = 0;
      ball.stickyCooldown = 0.45;
    }
  }

  if (ball.untouchedTimer >= BALL_RESPAWN_IDLE_SECONDS && sim.goalCelebrationTimer <= 0) {
    ball.x = 0;
    ball.y = getBallEffectiveHalfY(ball) + 1.4;
    ball.z = 0;
    ball.vx = 0;
    ball.vy = 0;
    ball.vz = 0;
    ball.spinX = 0;
    ball.spinY = 0;
    ball.spinZ = 0;
    ball.untouchedTimer = 0;
    ball.isClashedFire = false;
    ball.stickyTargetPlayerId = null;
    sim.events.push({ type: 'ball_respawn', x: 0, y: ball.y, z: 0 });
  }

  if (hasActiveItem(sim, 'updraft_wind')) {
    if (ball.y < 2.4) {
      ball.vy += 17.5 * dt;
    } else {
      ball.vy += 6.5 * dt;
    }
  }

  const effRadius = ball.radius * ball.scaleMultiplier;
  const speedHoriz = Math.hypot(ball.vx, ball.vz);

  if (sim.config.ballType === 'tennis' && ball.y > effRadius + 0.1) {
    ball.vx += -ball.vz * ball.spinY * 0.035 * dt;
    ball.vz += ball.vx * ball.spinY * 0.035 * dt;
  }

  let gravityScale = 1.0;
  if (sim.config.ballType === 'beach_volleyball' && ball.vy < 0) {
    gravityScale = 0.68;
  } else if (ball.shape === 'disc' && ball.vy < 0 && speedHoriz > 2.5) {
    // Flat flying disc glides gracefully on air cushion
    gravityScale = Math.max(0.38, 1.0 - speedHoriz * 0.06);
  }

  ball.vy -= GRAVITY * gravityScale * dt;
  ball.vx *= Math.max(0, 1 - ball.airDrag * dt);
  ball.vz *= Math.max(0, 1 - ball.airDrag * dt);

  ball.x += ball.vx * dt;
  ball.y += ball.vy * dt;
  ball.z += ball.vz * dt;

  // Shape-Accurate Rotation Rules
  const effectiveGroundHalfY = getBallEffectiveHalfY(ball);
  if (ball.sliding) {
    // Hockey Puck & Flat Disc: NEVER tumble end-over-end! Spin strictly around vertical Y axis.
    ball.rotX = 0;
    ball.rotZ = 0;
    ball.spinX = 0;
    ball.spinZ = 0;
    ball.rotY += ball.spinY * dt;
    ball.spinY *= Math.max(0, 1 - 0.55 * dt);
  } else if (ball.y <= effectiveGroundHalfY + 0.05) {
    if (speedHoriz > 0.02) {
      ball.rotZ -= (ball.vx * dt) / Math.max(0.2, effRadius);
      ball.rotX += (ball.vz * dt) / Math.max(0.2, effRadius);
      ball.rotY += ball.spinY * dt * 0.45;
    } else {
      ball.spinX = 0;
      ball.spinZ = 0;
    }
  } else {
    ball.rotX += ball.spinX * dt;
    ball.rotY += ball.spinY * dt;
    ball.rotZ += ball.spinZ * dt;
  }

  // Shape-realistic Ground Bounce + Puddle Splash
  if (ball.y < effectiveGroundHalfY) {
    ball.y = effectiveGroundHalfY;
    if (ball.vy < -0.55) {
      const impactVy = Math.abs(ball.vy);
      if (ball.isJelly10x) {
        ball.vy = Math.min(12.8, Math.max(4.8, impactVy * 1.45));
      } else {
        ball.vy = Math.min(14.5, impactVy * getBounceRestitution(ball, impactVy));
      }

      if (impactVy > 1.35) {
        sim.events.push({
          type: 'ball_bounce',
          x: ball.x,
          y: 0.1,
          z: ball.z,
          intensity: Math.min(1, impactVy / 10),
        });
      }

      if (sim.weather.wetness > 0.15) {
        for (const pud of sim.weather.puddles) {
          if (Math.hypot(ball.x - pud.x, ball.z - pud.z) < pud.radius) {
            sim.events.push({ type: 'water_splash', x: ball.x, y: 0.05, z: ball.z, intensity: Math.min(1, impactVy / 8) });
            break;
          }
        }
      }

      if (ball.colliderType === 'ellipsoid') {
        // Bola lonjong / telur: mendarat di sisi panjang -> pantulan rendah & menggelinding;
        // mendarat di ujung -> melenting lebih tinggi lalu melenceng sepanjang sumbu panjangnya.
        const tip = Math.min(1, Math.abs(Math.sin(ball.rotX)) * 0.8 + Math.abs(Math.sin(ball.rotZ)) * 0.5);
        const side = Math.sign(Math.sin(ball.rotX) || 1);
        const kick = impactVy * (0.12 + tip * 0.34) * side;
        ball.vx += Math.sin(ball.rotY) * kick;
        ball.vz += Math.cos(ball.rotY) * kick;
        ball.vy *= 0.6 + tip * 0.55;
        ball.spinX += (tip - 0.5) * 5.0 * side;
        ball.spinZ += (Math.random() - 0.5) * 2.4 * tip;
      } else if (ball.colliderType === 'box') {
        // Dadu kubus: mendarat rata = dempingan kuat (thud); mendarat di sudut/sisi miring = terguling & melompat acak
        const tilt = Math.min(1, Math.abs(Math.sin(ball.rotX)) + Math.abs(Math.sin(ball.rotZ)));
        ball.vy *= 0.5 + tilt * 0.4;
        if (tilt > 0.18) {
          ball.vx += (Math.random() - 0.5) * impactVy * 0.5 * tilt;
          ball.vz += (Math.random() - 0.5) * impactVy * 0.5 * tilt;
          ball.spinX += (Math.random() - 0.5) * 9.0 * tilt;
          ball.spinZ += (Math.random() - 0.5) * 9.0 * tilt;
        } else {
          ball.vx *= 0.82;
          ball.vz *= 0.82;
        }
      } else if (sim.config.ballType === 'metal') {
        ball.vy *= 0.72;
      } else if (ball.sliding) {
        // Puck / cakram: dampak tumpul (nyaris tidak memantul), tetap meluncur di rumput
        ball.vy *= 0.5;
        ball.vx *= 1.02;
        ball.vz *= 1.02;
      }
    } else {
      ball.vy = 0;
      if (ball.colliderType === 'ellipsoid') {
        ball.rotX *= Math.max(0, 1 - 6 * dt);
      }
    }

    // Wet grass lowers ground rolling/sliding friction slightly!
    const wetFactor = 1 - 0.32 * sim.weather.wetness;
    const gf = Math.max(0, 1 - ball.groundFriction * wetFactor * dt);
    ball.vx *= gf;
    ball.vz *= gf;
    if (Math.hypot(ball.vx, ball.vz) < 0.015) {
      ball.vx = 0;
      ball.vz = 0;
    }
  }

  // Ball vs Players (using Shape-Accurate Ball Collider!)
  if (!ball.stickyTargetPlayerId) {
    for (const p of sim.players) {
      if (p.fallTimer > 0) {
        if (p.ragdoll && p.fallTimer >= RAGDOLL_GETUP_TIME) collideBallWithRagdoll(ball, p);
        continue;
      }
      const res = collidePointWithBallShape(p.x, p.y + 0.65, p.z, 0.48, ball);

      if (res.hit) {
        ball.x += res.nx * res.pen;
        ball.y += Math.max(0, res.ny * res.pen);
        ball.z += res.nz * res.pen;

        const relVx = ball.vx - p.vx;
        const relVy = ball.vy - p.vy;
        const relVz = ball.vz - p.vz;
        const impactSpeed = Math.hypot(relVx, relVy, relVz);
        const vn = relVx * res.nx + relVy * res.ny + relVz * res.nz;

        // If player is carrying a prop and gets hit by a moving ball, drop the prop!
        if (p.carryingPropId && impactSpeed >= 3.2) {
          dropCarriedProp(sim, p, -res.nx * 3.0, 2.2, -res.nz * 3.0);
        }

        // Sticky Honey Ball sticks softly to player on gentle contact
        if (
          ball.isStickyBall &&
          ball.stickyCooldown <= 0 &&
          impactSpeed < 10.5 &&
          !p.carryingPropId &&
          p.kickPhase === 'none' &&
          p.headPhase === 'none' &&
          p.punchPhase !== 'strike' &&
          p.dashTimer <= 0
        ) {
          ball.stickyTargetPlayerId = p.id;
          ball.stickyTimer = 2.6;
          ball.vx = p.vx;
          ball.vy = 0;
          ball.vz = p.vz;
          ball.untouchedTimer = 0;
          ball.lastTouchTeam = p.team;
          ball.lastTouchPlayerId = p.id;
          sim.events.push({ type: 'honey_stick', x: ball.x, y: ball.y, z: ball.z });
          break;
        }

        if (vn < 0) {
          const prevBallVx = ball.vx;
          const bounce = ball.isJelly10x ? 0.95 : ball.isStickyBall ? 0.28 : 0.72;
          ball.vx -= (1 + bounce) * vn * res.nx - p.vx * 0.25;
          ball.vy -= (1 + bounce) * vn * res.ny;
          ball.vz -= (1 + bounce) * vn * res.nz - p.vz * 0.25;
          if (ball.sliding) {
            ball.vy = Math.min(ball.vy, 1.4);
            ball.spinY += (res.nx * p.vz - res.nz * p.vx) * 1.4;
          }
          ball.untouchedTimer = 0;
          ball.lastTouchTeam = p.team;
          ball.lastTouchPlayerId = p.id;
          maybeEmitGoalSave(sim, p, prevBallVx);

          // Sentuhan bola biasa TIDAK menjatuhkan pemain; hanya tendangan sangat kuat/cepat (>= 22 m/s) atau bola api kencang (>= 14 m/s) yang memicu ragdoll
          const isFireBall = ball.isClashedFire || hasActiveItem(sim, 'fire_power');
          if (impactSpeed >= 22.0 || (isFireBall && impactSpeed >= 14.0)) {
            startRagdollFall(p, -res.nx * Math.min(8.5, impactSpeed * 0.55), 2.6, -res.nz * Math.min(8.5, impactSpeed * 0.55), 1.2, sim);
            if (!ball.isJelly10x) {
              sim.cameraTrauma = Math.min(1, sim.cameraTrauma + 0.4);
            }
            sim.events.push({ type: 'ragdoll_fall', x: p.x, y: p.y + 0.5, z: p.z });
          }
        }
      }
    }
  }

  // Ball vs Jelly Goalposts
  collideBallWithSegment(ball, -PITCH_HALF_X, 0, -GOAL_HALF_Z, -PITCH_HALF_X, GOAL_HEIGHT, -GOAL_HALF_Z, POST_RADIUS, sim.goalPosts.leftGoal.leftPost, sim);
  collideBallWithSegment(ball, -PITCH_HALF_X, 0, GOAL_HALF_Z, -PITCH_HALF_X, GOAL_HEIGHT, GOAL_HALF_Z, POST_RADIUS, sim.goalPosts.leftGoal.rightPost, sim);
  collideBallWithSegment(ball, -PITCH_HALF_X, GOAL_HEIGHT, -GOAL_HALF_Z, -PITCH_HALF_X, GOAL_HEIGHT, GOAL_HALF_Z, POST_RADIUS, sim.goalPosts.leftGoal.crossbar, sim);
  collideBallWithSegment(ball, PITCH_HALF_X, 0, -GOAL_HALF_Z, PITCH_HALF_X, GOAL_HEIGHT, -GOAL_HALF_Z, POST_RADIUS, sim.goalPosts.rightGoal.leftPost, sim);
  collideBallWithSegment(ball, PITCH_HALF_X, 0, GOAL_HALF_Z, PITCH_HALF_X, GOAL_HEIGHT, GOAL_HALF_Z, POST_RADIUS, sim.goalPosts.rightGoal.rightPost, sim);
  collideBallWithSegment(ball, PITCH_HALF_X, GOAL_HEIGHT, -GOAL_HALF_Z, PITCH_HALF_X, GOAL_HEIGHT, GOAL_HALF_Z, POST_RADIUS, sim.goalPosts.rightGoal.crossbar, sim);

  // Rangka atas gawang (batang samping atas & batang belakang atas) + atap jaring: bola memantul
  for (const sgn of [-1, 1] as const) {
    const goal = sgn < 0 ? sim.goalPosts.leftGoal : sim.goalPosts.rightGoal;
    const xLine = sgn * PITCH_HALF_X;
    const xBack = sgn * (PITCH_HALF_X + GOAL_DEPTH);
    collideBallWithSegment(ball, xLine, GOAL_HEIGHT, -GOAL_HALF_Z, xBack, GOAL_HEIGHT, -GOAL_HALF_Z, POST_RADIUS, goal.crossbar, sim);
    collideBallWithSegment(ball, xLine, GOAL_HEIGHT, GOAL_HALF_Z, xBack, GOAL_HEIGHT, GOAL_HALF_Z, POST_RADIUS, goal.crossbar, sim);
    collideBallWithSegment(ball, xBack, GOAL_HEIGHT, -GOAL_HALF_Z, xBack, GOAL_HEIGHT, GOAL_HALF_Z, POST_RADIUS, goal.crossbar, sim);
    const rEff = ball.radius * ball.scaleMultiplier;
    const withinRoofX = sgn * ball.x > PITCH_HALF_X && sgn * ball.x < PITCH_HALF_X + GOAL_DEPTH;
    if (withinRoofX && Math.abs(ball.z) < GOAL_HALF_Z && ball.y > GOAL_HEIGHT && ball.y - rEff < GOAL_HEIGHT && ball.vy < 0) {
      // Atap jaring: pantulan lembut dari atas
      ball.y = GOAL_HEIGHT + rEff;
      ball.vy = Math.abs(ball.vy) * 0.6;
      ball.vx *= 0.92;
      ball.vz *= 0.92;
      sim.events.push({ type: 'ball_bounce', x: ball.x, y: ball.y, z: ball.z, intensity: Math.min(1, Math.abs(ball.vy) / 8) });
    }
  }

  // Sidewalls Z (Honey ball sticks/dampens strongly on wall impact!)
  const wallBounce = ball.isJelly10x ? 1.18 : ball.isStickyBall ? 0.22 : Math.max(0.75, ball.restitution);
  if (ball.z - effRadius < -PITCH_HALF_Z) {
    const vzBefore = Math.abs(ball.vz);
    ball.z = -PITCH_HALF_Z + effRadius;
    ball.vz = Math.min(13.5, vzBefore * wallBounce);
    if (ball.sliding) ball.spinY += ball.vx * 0.45;
    else ball.spinX += ball.vx * 0.6;
    if (vzBefore > 3.4) pushWallSpark(sim, ball.x, ball.y, -PITCH_HALF_Z, 0, 1, vzBefore);
    if (vzBefore > 1.8) sim.events.push({ type: 'ball_bounce', x: ball.x, y: ball.y, z: ball.z, intensity: Math.min(1, vzBefore / 10) });
  } else if (ball.z + effRadius > PITCH_HALF_Z) {
    const vzBefore = Math.abs(ball.vz);
    ball.z = PITCH_HALF_Z - effRadius;
    ball.vz = -Math.min(13.5, vzBefore * wallBounce);
    if (ball.sliding) ball.spinY -= ball.vx * 0.45;
    else ball.spinX -= ball.vx * 0.6;
    if (vzBefore > 3.4) pushWallSpark(sim, ball.x, ball.y, PITCH_HALF_Z, 0, -1, vzBefore);
    if (vzBefore > 1.8) sim.events.push({ type: 'ball_bounce', x: ball.x, y: ball.y, z: ball.z, intensity: Math.min(1, vzBefore / 10) });
  }

  // Endwalls X & Goal Scoring
  const inGoalMouthZ = Math.abs(ball.z) < GOAL_HALF_Z - POST_RADIUS;
  const inGoalMouthY = ball.y < GOAL_HEIGHT - POST_RADIUS;

  if (inGoalMouthZ && inGoalMouthY) {
    if (sim.goalCelebrationTimer <= 0) {
      const limit = sim.config.scoreLimit && sim.config.scoreLimit > 0 ? sim.config.scoreLimit : null;
      if (ball.x < -(PITCH_HALF_X + effRadius * 0.4)) {
        sim.blueScore += 1;
        sim.goalCelebrationTimer = 2.6;
        sim.lastScoringTeam = 'blue';
        sim.cameraTrauma = 0.65;
        sim.cameraZoomPulse = 0.8;
        sim.events.push({ type: 'goal', team: 'blue', x: ball.x, y: ball.y, z: ball.z });
        if (((limit && sim.blueScore >= limit) || sim.goldenGoal) && sim.config.mode !== 'training') {
          sim.matchEnded = true;
          sim.events.push({ type: 'whistle' });
        }
      } else if (ball.x > PITCH_HALF_X + effRadius * 0.4) {
        sim.redScore += 1;
        sim.goalCelebrationTimer = 2.6;
        sim.lastScoringTeam = 'red';
        sim.cameraTrauma = 0.65;
        sim.cameraZoomPulse = 0.8;
        sim.events.push({ type: 'goal', team: 'red', x: ball.x, y: ball.y, z: ball.z });
        if (((limit && sim.redScore >= limit) || sim.goldenGoal) && sim.config.mode !== 'training') {
          sim.matchEnded = true;
          sim.events.push({ type: 'whistle' });
        }
      }
    }

    if (ball.x - effRadius < -(PITCH_HALF_X + GOAL_DEPTH)) {
      ball.x = -(PITCH_HALF_X + GOAL_DEPTH) + effRadius;
      ball.vx = Math.abs(ball.vx) * 0.16;
      ball.vy *= 0.82;
      ball.vz *= 0.82;
    } else if (ball.x + effRadius > PITCH_HALF_X + GOAL_DEPTH) {
      ball.x = PITCH_HALF_X + GOAL_DEPTH - effRadius;
      ball.vx = -Math.abs(ball.vx) * 0.16;
      ball.vy *= 0.82;
      ball.vz *= 0.82;
    }
    if (Math.abs(ball.x) > PITCH_HALF_X) {
      if (ball.z - effRadius < -GOAL_HALF_Z) {
        const hit = Math.abs(ball.vz);
        ball.z = -GOAL_HALF_Z + effRadius;
        ball.vz = Math.abs(ball.vz) * 0.22;
        ball.vx *= 0.85;
        if (hit > 5) pushWallSpark(sim, ball.x, ball.y, -GOAL_HALF_Z, 0, 1, hit);
      } else if (ball.z + effRadius > GOAL_HALF_Z) {
        const hit = Math.abs(ball.vz);
        ball.z = GOAL_HALF_Z - effRadius;
        ball.vz = -Math.abs(ball.vz) * 0.22;
        ball.vx *= 0.85;
        if (hit > 5) pushWallSpark(sim, ball.x, ball.y, GOAL_HALF_Z, 0, -1, hit);
      }
      if (ball.y + effRadius > GOAL_HEIGHT) {
        const hit = Math.abs(ball.vy);
        ball.y = GOAL_HEIGHT - effRadius;
        ball.vy = -Math.abs(ball.vy) * 0.2;
        ball.vx *= 0.85;
        if (hit > 5) pushWallSpark(sim, ball.x, GOAL_HEIGHT, ball.z, 0, 0, hit);
      }
    }
  } else {
    if (ball.x - effRadius < -PITCH_HALF_X) {
      const vxBefore = Math.abs(ball.vx);
      ball.x = -PITCH_HALF_X + effRadius;
      ball.vx = Math.min(13.5, vxBefore * wallBounce);
      if (ball.sliding) ball.spinY -= ball.vz * 0.45;
      else ball.spinZ += ball.vz * 0.6;
      if (vxBefore > 3.4) pushWallSpark(sim, -PITCH_HALF_X, ball.y, ball.z, 1, 0, vxBefore);
      if (vxBefore > 1.8) sim.events.push({ type: 'ball_bounce', x: ball.x, y: ball.y, z: ball.z, intensity: Math.min(1, vxBefore / 10) });
    } else if (ball.x + effRadius > PITCH_HALF_X) {
      const vxBefore = Math.abs(ball.vx);
      ball.x = PITCH_HALF_X - effRadius;
      ball.vx = -Math.min(13.5, vxBefore * wallBounce);
      if (ball.sliding) ball.spinY += ball.vz * 0.45;
      else ball.spinZ -= ball.vz * 0.6;
      if (vxBefore > 3.4) pushWallSpark(sim, PITCH_HALF_X, ball.y, ball.z, -1, 0, vxBefore);
      if (vxBefore > 1.8) sim.events.push({ type: 'ball_bounce', x: ball.x, y: ball.y, z: ball.z, intensity: Math.min(1, vxBefore / 10) });
    }
  }

  // Final post-movement pass: guarantee zero clipping between fast-moving ball and solid props
  resolveSolidBallVsProps(sim);
}

/** Percikan cahaya di titik tumbukan bola dengan pembatas. (nx,nz) = normal menghadap ke dalam lapangan. */
function pushWallSpark(sim: MatchSimulation, x: number, y: number, z: number, nx: number, nz: number, speed: number) {
  sim.events.push({
    type: 'wall_spark',
    x,
    y: Math.max(0.12, y),
    z,
    nx,
    nz,
    intensity: Math.min(1, speed / 14),
  });
}

function resolveSolidBallVsProps(sim: MatchSimulation) {
  const bR = sim.ball.radius * sim.ball.scaleMultiplier;
  for (const pr of sim.props) {
    if (pr.carriedByPlayerId || pr.usesRemaining <= 0) continue;
    const dx = sim.ball.x - pr.x;
    const dz = sim.ball.z - pr.z;
    const distXZ = Math.hypot(dx, dz);
    const minXZ = bR + pr.radius;
    const propTopY = pr.y + 0.44;
    const propBotY = pr.y - 0.36;

    if (distXZ < minXZ && sim.ball.y + bR > propBotY && sim.ball.y - bR < propTopY) {
      const overlapXZ = minXZ - distXZ;
      const overlapTop = propTopY - (sim.ball.y - bR);
      if (overlapTop > 0 && overlapTop < overlapXZ * 0.85 && sim.ball.y > pr.y + 0.15) {
        sim.ball.y = propTopY + bR;
        if (sim.ball.vy < 0) {
          sim.ball.vy = Math.abs(sim.ball.vy) * 0.65;
        }
      } else {
        const nx = distXZ > 0.001 ? dx / distXZ : 1;
        const nz = distXZ > 0.001 ? dz / distXZ : 0;
        sim.ball.x += nx * overlapXZ * 0.8;
        sim.ball.z += nz * overlapXZ * 0.8;
        pr.x = Math.max(-PITCH_HALF_X + 0.45, Math.min(PITCH_HALF_X - 0.45, pr.x - nx * overlapXZ * 0.2));
        pr.z = Math.max(-PITCH_HALF_Z + 0.45, Math.min(PITCH_HALF_Z - 0.45, pr.z - nz * overlapXZ * 0.2));

        const rvx = sim.ball.vx - pr.vx;
        const rvz = sim.ball.vz - pr.vz;
        const vn = rvx * nx + rvz * nz;
        if (vn < 0) {
          const bounce = 0.78;
          sim.ball.vx -= (1 + bounce) * vn * nx;
          sim.ball.vz -= (1 + bounce) * vn * nz;
          pr.vx += vn * nx * 0.42;
          pr.vz += vn * nz * 0.42;
          if (Math.abs(vn) > 1.8) {
            pr.flashTimer = 0.1;
            sim.events.push({
              type: 'ball_bounce',
              x: sim.ball.x,
              y: sim.ball.y,
              z: sim.ball.z,
              intensity: Math.min(1, Math.abs(vn) / 10),
            });
          }
        }
      }
      if (pr.thrownActive) {
        pr.thrownActive = false;
      }
    }
  }
}

function collideBallWithSegment(
  ball: BallSim,
  ax: number,
  ay: number,
  az: number,
  bx: number,
  by: number,
  bz: number,
  segRadius: number,
  spring: JellyPostSpring,
  sim: MatchSimulation
) {
  const abx = bx - ax;
  const aby = by - ay;
  const abz = bz - az;
  const apx = ball.x - ax;
  const apy = ball.y - ay;
  const apz = ball.z - az;
  const abLenSq = abx * abx + aby * aby + abz * abz;
  let t = abLenSq > 0 ? (apx * abx + apy * aby + apz * abz) / abLenSq : 0;
  t = Math.max(0, Math.min(1, t));

  const cx = ax + abx * t;
  const cy = ay + aby * t;
  const cz = az + abz * t;

  const res = collidePointWithBallShape(cx, cy, cz, segRadius, ball);
  if (res.hit) {
    ball.x += res.nx * res.pen;
    ball.y += res.ny * res.pen;
    ball.z += res.nz * res.pen;

    const vn = ball.vx * res.nx + ball.vy * res.ny + ball.vz * res.nz;
    if (vn < 0) {
      const bounce = ball.isJelly10x ? 1.25 : Math.max(0.84, ball.restitution);
      ball.vx -= (1 + bounce) * vn * res.nx;
      ball.vy -= (1 + bounce) * vn * res.ny;
      ball.vz -= (1 + bounce) * vn * res.nz;

      if (ball.isJelly10x) {
        const sp = Math.hypot(ball.vx, ball.vy, ball.vz);
        if (sp > 14.5) {
          const s = 14.5 / sp;
          ball.vx *= s;
          ball.vy *= s;
          ball.vz *= s;
        }
      }

      const impactStrength = Math.min(8.5, Math.abs(vn) * 0.7);
      spring.velX -= res.nx * impactStrength;
      spring.velY -= res.ny * impactStrength;
      spring.velZ -= res.nz * impactStrength;

      sim.events.push({
        type: 'post_hit',
        x: cx,
        y: cy,
        z: cz,
        intensity: Math.min(1, Math.abs(vn) / 10),
      });
    }
  }
}
