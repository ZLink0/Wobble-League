import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultMatchConfig } from './catalog';
import { createMatchSimulation, stepSimulation } from './physics';
import {
  computeReplayCameraPose,
  REPLAY_BUFFER_SECONDS,
  ReplayRecorder,
  sampleReplayFrame,
} from './replay';

test('ReplayRecorder retains rolling 15-second buffer, bookmarks goals, interpolates frames, and computes camera angles', () => {
  assert.equal(REPLAY_BUFFER_SECONDS, 15.0);

  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const recorder = new ReplayRecorder();
  recorder.recordStep(sim, 0, true);

  // Step 18 seconds at 0.05s increments
  for (let i = 0; i < 360; i++) {
    sim.ball.x = Math.sin(i * 0.1) * 4;
    stepSimulation(sim, 0.05, {});
    if (i === 240) {
      // Simulate a goal event at ~12s
      sim.redScore += 1;
      sim.events.push({ type: 'goal', team: 'red', x: 11.4, y: 1.0, z: 0 });
    }
    recorder.recordStep(sim, 0.05);
  }

  const bundle = recorder.getBundle();
  assert.ok(bundle.tailFrames.length >= 200, 'Expected dense 15s replay frame buffer');
  const span = bundle.tailFrames[bundle.tailFrames.length - 1].time - bundle.tailFrames[0].time;
  assert.ok(span <= 15.1 && span >= 14.0, `Expected rolling buffer capped at ~15s, got ${span.toFixed(2)}s`);
  assert.equal(bundle.goals.length, 1, 'Expected goal event to be bookmarked');
  assert.equal(bundle.goals[0].team, 'red');
  assert.ok((bundle.goals[0].clipFrames?.length ?? 0) > 20, 'Expected saved goal clip frames');

  // Verify mid-frame interpolation
  const firstT = bundle.tailFrames[0].time;
  const midT = firstT + 0.025;
  const sampled = sampleReplayFrame(bundle.tailFrames, midT);
  assert.ok(sampled !== null, 'Expected interpolated replay frame');
  assert.ok(Math.abs(sampled!.time - midT) < 0.001);

  // Verify immediate Goal Replay clip helper
  const recentClip = recorder.getRecentClip(4.0);
  assert.ok(recentClip.length >= 40, 'Expected recent goal replay clip frames');
  const recentSpan = recentClip[recentClip.length - 1].time - recentClip[0].time;
  assert.ok(recentSpan <= 4.1 && recentSpan >= 3.5, `Expected ~4.0s recent clip span, got ${recentSpan.toFixed(2)}s`);
  assert.ok(Number.isFinite(sampled!.players[0].kickCharge) && Number.isFinite(sampled!.players[0].backflipAngle));

  // Verify all 4 replay camera angles compute valid coordinates and goal_cam sits in front of the goal mouth
  for (const angle of ['broadcast', 'goal_cam', 'follow_ball', 'overhead'] as const) {
    const cam = computeReplayCameraPose(angle, sampled!, 'red');
    assert.equal(cam.pos.length, 3);
    assert.equal(cam.lookAt.length, 3);
    assert.ok(cam.pos.every((n) => Number.isFinite(n)), `Camera ${angle} returned non-finite pos`);
    // Semua kamera replay berada di pinggir lapangan (z positif, jarak lebar)
    assert.ok(cam.pos[2] >= 15, `Camera ${angle} harus di sisi lapangan, got z=${cam.pos[2]}`);
  }
});
