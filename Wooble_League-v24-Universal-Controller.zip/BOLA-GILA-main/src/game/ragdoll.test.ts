import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultMatchConfig } from './catalog';
import { createMatchSimulation, stepSimulation, GRAVITY, PITCH_HALF_X, PITCH_HALF_Z, GOAL_HALF_Z } from './physics';
import {
  createRagdoll,
  getRagdollEnergy,
  getRagdollFrame,
  getRagdollHip,
  ragdollMaxLinkError,
  ragdollMinHeight,
  stepRagdoll,
} from './ragdoll';
import { captureReplayFrame, sampleReplayFrame } from './replay';
import { InputFrame } from './types';

const bounds = { halfX: PITCH_HALF_X, halfZ: PITCH_HALF_Z, goalHalfZ: GOAL_HALF_Z };

function idleInput(): InputFrame {
  return {
    moveX: 0,
    moveZ: 0,
    runHeld: false,
    kickPressed: false,
    kickRightSpinPressed: false,
    jumpPressed: false,
    headSpinLeftPressed: false,
    dashPressed: false,
  };
}

test('ragdoll fisik: sendi tetap utuh, tidak menembus lantai, lalu diam tergeletak', () => {
  const dirs: Array<[number, number, number]> = [
    [0, 2.2, 5],
    [6, 4.4, 0],
    [-4, 2.6, -4],
    [0, 0, 0],
  ];
  for (const [kx, ky, kz] of dirs) {
    const rd = createRagdoll(0, 0, 0, 0.7, kx, ky, kz, () => 0.5);
    let worstLink = 0;
    let worstFloor = Infinity;
    for (let i = 0; i < 150; i++) {
      stepRagdoll(rd, 1 / 60, { gravity: GRAVITY, bounds });
      worstLink = Math.max(worstLink, ragdollMaxLinkError(rd));
      worstFloor = Math.min(worstFloor, ragdollMinHeight(rd));
    }
    assert.ok(worstLink < 0.06, `constraint sendi harus utuh, error maks ${worstLink}`);
    assert.ok(worstFloor > -0.02, `tidak boleh menembus lantai, min ${worstFloor}`);
    assert.ok(getRagdollEnergy(rd) < 0.8, `harus hampir diam setelah 2.5 detik, energi ${getRagdollEnergy(rd)}`);
    const f = getRagdollFrame(rd.pos);
    assert.ok(Math.abs(f.zAxis[1]) > 0.8, `badan harus tergeletak (telungkup/telentang), z.y=${f.zAxis[1]}`);
    assert.ok(getRagdollHip(rd.pos).y < 0.4, 'pinggul harus dekat lantai');
  }
});

test('ragdoll fisik: terpental searah dorongan, tertahan dinding lapangan', () => {
  const rd = createRagdoll(10.5, 0, 0, 0, 12, 3, 0, () => 0.5);
  for (let i = 0; i < 180; i++) stepRagdoll(rd, 1 / 60, { gravity: GRAVITY, bounds });
  for (let i = 0; i < RAGDOLL_N(); i++) {
    assert.ok(rd.pos[i * 3] <= PITCH_HALF_X + 0.66, 'partikel tidak boleh keluar jauh dari gawang/dinding');
  }
});

function RAGDOLL_N() {
  return 13;
}

test('integrasi sim: tendangan keras memicu ragdoll fisik, lalu bangun bersih', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p = sim.players.find((pl) => pl.humanSlot === 1)!;
  p.x = 0;
  p.z = 0;
  sim.ball.x = 0.7;
  sim.ball.y = 0.65;
  sim.ball.z = 0;
  sim.ball.vx = -18;
  sim.ball.vy = 0;
  sim.ball.vz = 0;

  stepSimulation(sim, 0.02, { p1: idleInput() });
  assert.ok(p.ragdoll, 'ragdoll fisik harus dibuat saat jatuh');
  assert.ok(p.fallTimer > 0.8);

  let moved = 0;
  for (let i = 0; i < 20; i++) {
    stepSimulation(sim, 0.03, { p1: idleInput() });
    assert.equal(p.y, 0, 'pemain ragdoll tetap di tanah (tinggi diurus partikel)');
    assert.ok(Number.isFinite(p.x) && Number.isFinite(p.z));
    moved = Math.max(moved, Math.hypot(p.x, p.z));
  }
  assert.ok(moved > 1.0, `pemain harus terpental/terseret, hanya ${moved}`);

  assert.ok(p.fallTimer > 3.5, 'lemas ragdoll berlangsung ~5 detik');
  for (let i = 0; i < 190; i++) {
    // jauhkan bola agar AI lawan tidak menjatuhkan pemain lagi
    sim.ball.x = -8;
    sim.ball.z = 5;
    sim.ball.vx = 0;
    sim.ball.vz = 0;
    stepSimulation(sim, 0.03, { p1: idleInput() });
  }
  assert.equal(p.fallTimer <= 0, true);
  assert.equal(p.ragdoll, null, 'ragdoll dibersihkan setelah bangun');
  assert.equal(p.ragdollBlend, 0);
  assert.ok(Number.isFinite(p.facing));
});

test('bola memantul dari tubuh ragdoll dan tubuh ikut terdorong', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p = sim.players.find((pl) => pl.humanSlot === 1)!;
  p.x = 0;
  p.z = 0;
  sim.ball.x = 0.7;
  sim.ball.y = 0.65;
  sim.ball.z = 0;
  sim.ball.vx = -18;
  stepSimulation(sim, 0.02, { p1: idleInput() });
  assert.ok(p.ragdoll);
  // tunggu sampai tergeletak, lalu jatuhkan bola ke tubuhnya
  for (let i = 0; i < 14; i++) stepSimulation(sim, 0.03, { p1: idleInput() });
  const hip = getRagdollHip(p.ragdoll!.pos);
  sim.ball.x = hip.x;
  sim.ball.z = hip.z;
  sim.ball.y = 1.6;
  sim.ball.vx = 0;
  sim.ball.vy = -9;
  sim.ball.vz = 0;
  let minY = Infinity;
  let bounced = false;
  let prevVy = sim.ball.vy;
  for (let i = 0; i < 25 && p.fallTimer > 0.5; i++) {
    stepSimulation(sim, 0.02, { p1: idleInput() });
    minY = Math.min(minY, sim.ball.y);
    if (prevVy < 0 && sim.ball.vy > 0) bounced = true;
    prevVy = sim.ball.vy;
  }
  assert.ok(bounced, 'bola harus memantul ke atas');
});

test('replay merekam & menginterpolasi pose ragdoll fisik', () => {
  const cfg = createDefaultMatchConfig();
  cfg.redCount = 1;
  cfg.blueCount = 1;
  const sim = createMatchSimulation(cfg, { forceRain: false });
  const p = sim.players.find((pl) => pl.humanSlot === 1)!;
  p.x = 0;
  p.z = 0;
  sim.ball.x = 0.7;
  sim.ball.y = 0.65;
  sim.ball.vx = -18;
  stepSimulation(sim, 0.02, { p1: idleInput() });
  const frames = [captureReplayFrame(sim)];
  sim.elapsedTime += 0.05;
  stepSimulation(sim, 0.05, { p1: idleInput() });
  frames.push(captureReplayFrame(sim));
  frames[1].time = frames[0].time + 0.05;
  const mid = sampleReplayFrame(frames, frames[0].time + 0.025)!;
  const pose = mid.players.find((pl) => pl.id === p.id)!;
  assert.ok(pose.ragdoll && pose.ragdoll.pos.length === 39, 'pose replay membawa 13 partikel');
});
