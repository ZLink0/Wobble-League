import * as THREE from 'three';

function createAreaLightMaterial(intensity: number): THREE.MeshLambertMaterial {
  return new THREE.MeshLambertMaterial({
    color: 0x000000,
    emissive: 0xffffff,
    emissiveIntensity: intensity,
  });
}

/**
 * Self-contained studio RoomEnvironment scene for PMREMGenerator.
 * Built solely from core `'three'` primitives so bundlers never fail on
 * subpath exports like `three/addons/...`.
 */
export class RoomEnvironment extends THREE.Scene {
  constructor() {
    super();

    this.name = 'RoomEnvironment';
    this.position.y = -3.5;

    const geometry = new THREE.BoxGeometry();
    geometry.deleteAttribute('uv');

    const roomMaterial = new THREE.MeshStandardMaterial({ side: THREE.BackSide });
    const boxMaterial = new THREE.MeshStandardMaterial();

    const mainLight = new THREE.PointLight(0xffffff, 900, 28, 2);
    mainLight.position.set(0.418, 16.199, 0.3);
    this.add(mainLight);

    const room = new THREE.Mesh(geometry, roomMaterial);
    room.position.set(-0.757, 13.219, 0.717);
    room.scale.set(31.713, 28.305, 28.591);
    this.add(room);

    const boxes = new THREE.InstancedMesh(geometry, boxMaterial, 6);
    const transform = new THREE.Object3D();

    const placements: Array<{ pos: [number, number, number]; rotY: number; scale: [number, number, number] }> = [
      { pos: [-10.906, 2.009, 1.846], rotY: -0.195, scale: [2.328, 7.905, 4.651] },
      { pos: [-5.607, -0.754, -0.758], rotY: 0.994, scale: [1.97, 1.534, 3.955] },
      { pos: [6.167, 0.857, 7.803], rotY: 0.561, scale: [3.927, 6.285, 3.687] },
      { pos: [-2.017, 0.018, 6.124], rotY: 0.333, scale: [2.002, 4.566, 2.064] },
      { pos: [2.291, -0.756, -2.621], rotY: -0.286, scale: [1.546, 1.552, 1.496] },
      { pos: [-2.193, -0.369, -5.547], rotY: 0.516, scale: [3.875, 3.487, 2.986] },
    ];

    placements.forEach((p, idx) => {
      transform.position.set(p.pos[0], p.pos[1], p.pos[2]);
      transform.rotation.set(0, p.rotY, 0);
      transform.scale.set(p.scale[0], p.scale[1], p.scale[2]);
      transform.updateMatrix();
      boxes.setMatrixAt(idx, transform.matrix);
    });
    this.add(boxes);

    const lights: Array<{ pos: [number, number, number]; scale: [number, number, number]; intensity: number }> = [
      { pos: [-16.116, 14.37, 8.208], scale: [0.1, 2.428, 2.739], intensity: 50 },
      { pos: [-16.109, 18.021, -8.207], scale: [0.1, 2.425, 2.751], intensity: 50 },
      { pos: [14.904, 12.198, -1.832], scale: [0.15, 4.265, 6.331], intensity: 17 },
      { pos: [-0.462, 8.89, 14.52], scale: [4.38, 5.441, 0.088], intensity: 43 },
      { pos: [3.235, 11.486, -12.541], scale: [2.5, 2.0, 0.1], intensity: 20 },
      { pos: [0.0, 20.0, 0.0], scale: [1.0, 0.1, 1.0], intensity: 100 },
    ];

    for (const l of lights) {
      const panel = new THREE.Mesh(geometry, createAreaLightMaterial(l.intensity));
      panel.position.set(l.pos[0], l.pos[1], l.pos[2]);
      panel.scale.set(l.scale[0], l.scale[1], l.scale[2]);
      this.add(panel);
    }
  }

  dispose() {
    const resources = new Set<{ dispose: () => void }>();
    this.traverse((object) => {
      if ((object as THREE.Mesh).isMesh) {
        const mesh = object as THREE.Mesh;
        resources.add(mesh.geometry);
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => resources.add(m));
        } else if (mesh.material) {
          resources.add(mesh.material);
        }
      }
    });
    for (const resource of resources) {
      resource.dispose();
    }
  }
}
