import { AnimalId } from './types';

/* =====================================================================
 *  PETA OPEN WORLD — dibangun prosedural & deterministik (tanpa file gambar)
 *  Ukuran 200 x 130 tile; 10 stadion dihubungkan jalan yang berkelok.
 * ===================================================================== */

export const WORLD_W = 200;
export const WORLD_H = 130;
export const TILE = 32;

export const T = {
  GRASS: 0,
  JUNGLE: 1,
  WATER: 2,
  SAND: 3,
  SNOW: 4,
  ROCK: 5,
  ROAD: 6,
  BRIDGE: 7,
  CONCRETE: 8,
  NEON: 9,
  MARBLE: 10,
  BEACH: 11,
  DIRT: 12,
} as const;

export const D = {
  NONE: 0,
  TREE: 1,
  PINE: 2,
  CACTUS: 3,
  BOULDER: 4,
  CRATE: 5,
  PILLAR: 6,
  STATUE: 7,
  PALM: 8,
  BUSH: 9, // dekorasi tidak menghalangi
  FLOWER: 10, // dekorasi tidak menghalangi
} as const;

export type BuildingKind = 'stadium' | 'house' | 'save' | 'shop' | 'hall' | 'training';
export interface Building {
  kind: BuildingKind;
  x: number; // tile kiri atas
  y: number;
  w: number;
  h: number;
  color: string;
  roof: string;
  label?: string;
  stadium?: number;
}

export type PoiKind = 'stadium' | 'save' | 'shop' | 'hall' | 'train' | 'rest' | 'chest' | 'sign' | 'found';
export interface Poi {
  id: string;
  kind: PoiKind;
  x: number; // tile titik interaksi
  y: number;
  label: string;
  stadium?: number;
  hall?: 'hall_start' | 'hall_mid' | 'hall_neon';
  coins?: number;
  text?: string;
  spot?: string;
}

export type NpcKind = 'villager' | 'athlete' | 'guard' | 'shop' | 'recruiter' | 'coach';
export interface NpcDef {
  id: string;
  kind: NpcKind;
  name: string;
  animal: AnimalId;
  x: number;
  y: number;
  lines: string[];
  wander: number; // radius jalan acak (tile)
}

export interface StadiumPlace {
  cx: number;
  cy: number;
  w: number;
  h: number;
  door: { x: number; y: number };
}

export interface WorldData {
  terrain: Uint8Array;
  deco: Uint8Array;
  solid: Uint8Array;
  buildings: Building[];
  pois: Poi[];
  npcs: NpcDef[];
  stadiums: StadiumPlace[];
  spawn: { x: number; y: number };
  towns: Array<{ name: string; x: number; y: number }>;
}

/* ------------------------------- noise ------------------------------- */
export function hash2(x: number, y: number, seed = 0): number {
  let h = (x * 374761393 + y * 668265263 + seed * 1442695041) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h = h ^ (h >>> 16);
  return ((h >>> 0) % 100000) / 100000;
}
function smooth(t: number) {
  return t * t * (3 - 2 * t);
}
export function vnoise(x: number, y: number, seed = 0): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = smooth(x - x0);
  const fy = smooth(y - y0);
  const a = hash2(x0, y0, seed);
  const b = hash2(x0 + 1, y0, seed);
  const c = hash2(x0, y0 + 1, seed);
  const d = hash2(x0 + 1, y0 + 1, seed);
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}

/* ------------------------------ definisi ------------------------------ */
const START = { x: 20, y: 116 };

// pusat stadion (tile)
const STADIUM_CENTERS: Array<{ x: number; y: number; w: number; h: number }> = [
  { x: 46, y: 104, w: 18, h: 10 },
  { x: 88, y: 110, w: 18, h: 10 },
  { x: 150, y: 100, w: 18, h: 10 },
  { x: 174, y: 68, w: 18, h: 10 },
  { x: 146, y: 34, w: 18, h: 10 },
  { x: 104, y: 40, w: 18, h: 10 },
  { x: 62, y: 26, w: 18, h: 10 },
  { x: 26, y: 54, w: 18, h: 10 },
  { x: 60, y: 76, w: 20, h: 11 },
  { x: 104, y: 78, w: 26, h: 13 },
];

const BIOME_GROUND = [T.GRASS, T.SAND, T.SNOW, T.JUNGLE, T.BEACH, T.CONCRETE, T.ROCK, T.NEON, T.MARBLE, T.MARBLE];
const START_BIOME_GROUND = T.GRASS;

const RIVERS: Array<Array<[number, number]>> = [
  [[66, 129], [68, 112], [76, 98], [70, 88]],
  [[128, 129], [124, 112], [130, 96], [122, 84], [126, 70]],
  [[120, 6], [118, 22], [126, 34], [122, 50], [130, 60]],
];

type Pt = [number, number];
const ROADS: Pt[][] = [
  [[20, 118], [32, 114], [46, 111]],
  [[46, 111], [60, 118], [72, 112], [88, 117]],
  [[88, 117], [108, 122], [126, 112], [140, 108], [150, 107]],
  [[150, 107], [162, 96], [170, 84], [174, 75]],
  [[174, 75], [168, 58], [158, 46], [146, 41]],
  [[146, 41], [128, 40], [118, 50], [104, 47]],
  [[104, 47], [90, 42], [76, 36], [62, 33]],
  [[62, 33], [46, 38], [34, 50], [26, 61]],
  [[26, 61], [40, 70], [50, 80], [60, 83]],
  [[60, 83], [80, 86], [92, 82], [104, 85]],
];
const SECRET_ROAD: Pt[] = [[62, 33], [48, 24], [34, 18], [22, 15]];

/* ------------------------------ pembangunan ------------------------------ */
let cached: WorldData | null = null;

export function buildWorld(): WorldData {
  if (cached) return cached;
  const W = WORLD_W;
  const H = WORLD_H;
  const terrain = new Uint8Array(W * H);
  const deco = new Uint8Array(W * H);
  const solid = new Uint8Array(W * H);
  const protect = new Uint8Array(W * H); // area bebas dekorasi
  const idx = (x: number, y: number) => y * W + x;
  const inb = (x: number, y: number) => x >= 0 && y >= 0 && x < W && y < H;

  const centers = [{ x: START.x, y: START.y }, ...STADIUM_CENTERS.map((s) => ({ x: s.x, y: s.y }))];
  const grounds = [START_BIOME_GROUND, ...BIOME_GROUND];

  // 1) Biome (Voronoi + domain warp)
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const wx = (vnoise(x * 0.06, y * 0.06, 3) - 0.5) * 16;
      const wy = (vnoise(x * 0.06 + 40, y * 0.06 + 40, 4) - 0.5) * 16;
      let best = 0;
      let bd = 1e9;
      for (let i = 0; i < centers.length; i++) {
        const dx = x + wx - centers[i].x;
        const dy = y + wy - centers[i].y;
        const d = dx * dx + dy * dy;
        if (d < bd) {
          bd = d;
          best = i;
        }
      }
      terrain[idx(x, y)] = grounds[best];
    }
  }

  // 2) Laut di timur laut + tepi peta
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const edge = x < 2 || y < 2 || x >= W - 2 || y >= H - 2;
      const n = vnoise(x * 0.09, y * 0.09, 9) * 8;
      const sea = x > 164 + n && y < 24 + n;
      const east = x > W - 7 + n * 0.3;
      if (edge || sea || east) terrain[idx(x, y)] = T.WATER;
    }
  }
  // pasir pesisir di sekitar air (tanpa mengubah salju/hutan jauh)
  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      if (terrain[idx(x, y)] === T.WATER) continue;
      let near = false;
      for (let dy = -2; dy <= 2 && !near; dy++)
        for (let dx = -2; dx <= 2 && !near; dx++) {
          if (inb(x + dx, y + dy) && terrain[idx(x + dx, y + dy)] === T.WATER) near = true;
        }
      if (near && terrain[idx(x, y)] !== T.ROCK) terrain[idx(x, y)] = T.BEACH;
    }
  }

  // 3) Sungai
  for (const river of RIVERS) {
    for (let i = 0; i < river.length - 1; i++) {
      const [x0, y0] = river[i];
      const [x1, y1] = river[i + 1];
      const steps = Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 2);
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const cx = x0 + (x1 - x0) * t + Math.sin(t * 6 + i) * 1.4;
        const cy = y0 + (y1 - y0) * t;
        for (let dy = -2; dy <= 2; dy++)
          for (let dx = -2; dx <= 2; dx++) {
            if (dx * dx + dy * dy <= 4.2) {
              const tx = Math.round(cx + dx);
              const ty = Math.round(cy + dy);
              if (inb(tx, ty)) terrain[idx(tx, ty)] = T.WATER;
            }
          }
      }
    }
  }

  // 4) Jalan (+ jembatan saat melewati air)
  const paintRoad = (pts: Pt[], dirt = false) => {
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[i];
      const [x1, y1] = pts[i + 1];
      const len = Math.hypot(x1 - x0, y1 - y0);
      const steps = Math.ceil(len * 2);
      const nx = -(y1 - y0) / (len || 1);
      const ny = (x1 - x0) / (len || 1);
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const wig = Math.sin(t * Math.PI * 2 + i * 1.7) * 1.6;
        const cx = x0 + (x1 - x0) * t + nx * wig;
        const cy = y0 + (y1 - y0) * t + ny * wig;
        for (let dy = -1; dy <= 1; dy++)
          for (let dx = -1; dx <= 1; dx++) {
            const tx = Math.round(cx + dx);
            const ty = Math.round(cy + dy);
            if (!inb(tx, ty) || tx < 2 || ty < 2 || tx >= W - 2 || ty >= H - 2) continue;
            const k = idx(tx, ty);
            terrain[k] = terrain[k] === T.WATER ? T.BRIDGE : dirt ? T.DIRT : T.ROAD;
            protect[k] = 1;
          }
      }
    }
  };
  for (const r of ROADS) paintRoad(r);
  paintRoad(SECRET_ROAD, true);

  // 5) Stadion, Save Center, plaza
  const buildings: Building[] = [];
  const pois: Poi[] = [];
  const stadiums: StadiumPlace[] = [];
  const fillRect = (x: number, y: number, w: number, h: number, t: number | null, pr = true) => {
    for (let yy = y; yy < y + h; yy++)
      for (let xx = x; xx < x + w; xx++) {
        if (!inb(xx, yy)) continue;
        if (t !== null) terrain[idx(xx, yy)] = t;
        if (pr) protect[idx(xx, yy)] = 1;
      }
  };
  const solidRect = (x: number, y: number, w: number, h: number) => {
    for (let yy = y; yy < y + h; yy++)
      for (let xx = x; xx < x + w; xx++) if (inb(xx, yy)) solid[idx(xx, yy)] = 1;
  };
  const STAD_COLORS = ['#4ade80', '#fbbf24', '#7dd3fc', '#22c55e', '#38bdf8', '#94a3b8', '#f97316', '#a855f7', '#facc15', '#f43f5e'];
  STADIUM_CENTERS.forEach((s, i) => {
    const bx = s.x - Math.floor(s.w / 2);
    const by = s.y - Math.floor(s.h / 2);
    // lahan & plaza
    fillRect(bx - 2, by - 2, s.w + 4, s.h + 4, null);
    fillRect(s.x - 5, by + s.h, 11, 5, T.ROAD);
    fillRect(bx - 16, by + s.h - 5, 14, 6, T.ROAD, true);
    buildings.push({ kind: 'stadium', x: bx, y: by, w: s.w, h: s.h, color: STAD_COLORS[i], roof: '#1e293b', label: `Stadion ${i + 1}`, stadium: i });
    solidRect(bx, by, s.w, s.h);
    const door = { x: s.x, y: by + s.h };
    stadiums.push({ cx: s.x, cy: s.y, w: s.w, h: s.h, door });
    pois.push({ id: `stadium_${i}`, kind: 'stadium', x: door.x, y: door.y, label: 'Masuk Stadion', stadium: i });
    // Player Save Center di sisi kiri plaza
    const sx = bx - 12;
    const sy = by + s.h - 3;
    buildings.push({ kind: 'save', x: sx, y: sy, w: 5, h: 3, color: '#fde68a', roof: '#ef4444', label: 'PLAYER SAVE CENTER' });
    solidRect(sx, sy, 5, 3);
    pois.push({ id: `save_${i}`, kind: 'save', x: sx + 2, y: sy + 3, label: 'Player Save Center', stadium: i });
  });

  // 6) Kota awal: Wobble Town
  const houseColors = ['#fca5a5', '#fcd34d', '#a7f3d0', '#bfdbfe', '#ddd6fe', '#fbcfe8'];
  const addHouse = (x: number, y: number, w = 4, h = 3, kind: BuildingKind = 'house', color?: string, roof?: string, label?: string) => {
    fillRect(x - 1, y - 1, w + 2, h + 3, null);
    buildings.push({ kind, x, y, w, h, color: color ?? houseColors[(x * 7 + y * 3) % houseColors.length], roof: roof ?? '#b45309', label });
    solidRect(x, y, w, h);
  };
  const addTown = (cx: number, cy: number, n: number, seed: number) => {
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + seed;
      const x = Math.round(cx + Math.cos(ang) * 9);
      const y = Math.round(cy + Math.sin(ang) * 6);
      addHouse(x, y);
    }
  };
  fillRect(START.x - 12, START.y - 9, 26, 20, T.GRASS);
  fillRect(START.x - 3, START.y - 2, 8, 6, T.ROAD);
  addTown(START.x, START.y, 6, 0.3);
  addHouse(START.x - 10, START.y + 4, 5, 3, 'shop', '#fde68a', '#16a34a', 'SHOP');
  pois.push({ id: 'shop_start', kind: 'shop', x: START.x - 8, y: START.y + 7, label: 'Toko Perlengkapan' });
  addHouse(START.x + 8, START.y + 3, 5, 3, 'hall', '#bfdbfe', '#2563eb', 'RECRUIT HALL');
  pois.push({ id: 'hall_start', kind: 'hall', x: START.x + 10, y: START.y + 6, label: 'Aula Rekrut Wobble Town', hall: 'hall_start' });
  fillRect(START.x + 4, START.y + 10, 9, 5, T.DIRT);
  buildings.push({ kind: 'training', x: START.x + 4, y: START.y + 10, w: 9, h: 5, color: '#a3e635', roof: '#65a30d', label: 'AREA LATIHAN' });
  pois.push({ id: 'train_start', kind: 'train', x: START.x + 8, y: START.y + 9, label: 'Area Latihan' });

  // 7) Kota tengah (Harbor Town) & Neon Quarter
  fillRect(120, 28, 20, 18, T.GRASS);
  addTown(128, 38, 4, 1.1);
  addHouse(121, 44, 5, 3, 'shop', '#fde68a', '#16a34a', 'SHOP');
  pois.push({ id: 'shop_mid', kind: 'shop', x: 123, y: 47, label: 'Toko Harbor' });
  addHouse(134, 44, 5, 3, 'hall', '#bfdbfe', '#2563eb', 'RECRUIT HALL');
  pois.push({ id: 'hall_mid', kind: 'hall', x: 136, y: 47, label: 'Aula Rekrut Harbor', hall: 'hall_mid' });
  fillRect(112, 54, 9, 5, T.DIRT);
  buildings.push({ kind: 'training', x: 112, y: 54, w: 9, h: 5, color: '#a3e635', roof: '#65a30d', label: 'AREA LATIHAN' });
  pois.push({ id: 'train_mid', kind: 'train', x: 116, y: 53, label: 'Area Latihan' });
  addHouse(36, 60, 5, 3, 'hall', '#e9d5ff', '#9333ea', 'RECRUIT HALL');
  pois.push({ id: 'hall_neon', kind: 'hall', x: 38, y: 63, label: 'Aula Rekrut Neon City', hall: 'hall_neon' });
  addHouse(36, 70, 4, 3);
  addHouse(14, 70, 4, 3);

  // 8) Area istirahat, papan petunjuk, peti rahasia, atlet tersembunyi
  const rests: Pt[] = [[60, 113], [112, 120], [160, 93], [152, 57], [92, 39], [40, 66], [75, 82]];
  rests.forEach(([x, y], i) => pois.push({ id: `rest_${i}`, kind: 'rest', x, y, label: 'Area Istirahat', text: 'Kamu duduk sebentar di bangku. Angin sejuk bertiup… Semangatmu pulih!' }));
  const chests: Array<[string, number, number, number]> = [
    ['chest_secret', 21, 15, 400],
    ['chest_forest', 183, 52, 220],
    ['chest_dune', 100, 126, 180],
    ['chest_snow', 160, 86, 200],
    ['chest_peak', 74, 20, 260],
  ];
  chests.forEach(([id, x, y, coins]) => pois.push({ id, kind: 'chest', x, y, label: 'Peti Harta', coins }));
  const founds: Array<[string, number, number]> = [
    ['found_snow', 157, 90],
    ['found_jungle', 181, 62],
    ['found_beach', 150, 27],
    ['found_secret', 22, 16],
    ['found_desert', 96, 124],
  ];
  founds.forEach(([spot, x, y]) => pois.push({ id: spot, kind: 'found', x, y, label: 'Atlet Misterius', spot }));
  const signs: Array<[number, number, string]> = [
    [34, 113, '⬅ Wobble Town   |   ➡ Green Valley Stadium'],
    [72, 114, '➡ Desert Arena — hati-hati sungai! Gunakan jembatan.'],
    [142, 107, '➡ Snowfield Stadium (lapangan es, licin!)'],
    [172, 80, '⬆ Jungle Stadium — hutan lebat di depan'],
    [160, 48, '⬅ Coastal Stadium | Harbor Town di barat'],
    [90, 43, '⬅ Mountain Stadium | Industrial Stadium di timur'],
    [44, 40, '⬇ Neon City Stadium — kota futuristik'],
    [82, 85, '➡ World Final Stadium (butuh 9 trofi)'],
    [48, 26, 'Jalan tanah di barat… konon ada harta rahasia.'],
  ];
  signs.forEach(([x, y, text], i) => pois.push({ id: `sign_${i}`, kind: 'sign', x, y, label: 'Papan Petunjuk', text }));
  // area bebas di sekitar POI
  for (const p of pois) for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (inb(p.x + dx, p.y + dy)) protect[idx(p.x + dx, p.y + dy)] = 1;
  for (const [x, y] of rests) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) protect[idx(x + dx, y + dy)] = 1;

  // 9) NPC
  const npcs: NpcDef[] = [];
  const addNpc = (id: string, kind: NpcKind, name: string, animal: AnimalId, x: number, y: number, lines: string[], wander = 2) => {
    npcs.push({ id, kind, name, animal, x, y, lines, wander });
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (inb(x + dx, y + dy)) protect[idx(x + dx, y + dy)] = 1;
  };
  addNpc('npc_mayor', 'villager', 'Wali Kota Hop', 'rabbit', START.x + 2, START.y + 1, ['Selamat datang di Wobble Town! Jadilah juara dunia Wobble League.', 'Kumpulkan 10 trofi dari 10 stadion. Setiap stadion punya turnamen 10 pertandingan.', 'Semua stadion bisa dicapai dengan berjalan kaki. Ikuti jalan setapak!'], 3);
  addNpc('npc_shop1', 'shop', 'Paman Gear', 'bear', START.x - 6, START.y + 7, ['Perlengkapan terbaik ada di sini! Bicara lagi untuk membuka toko.'], 0);
  addNpc('npc_hall1', 'recruiter', 'Agen Talenta', 'owl', START.x + 10, START.y + 7, ['Mau membangun tim impian? Lihat atlet yang tersedia!'], 0);
  addNpc('npc_coach1', 'coach', 'Pelatih Ben', 'gorilla', START.x + 8, START.y + 8, ['Pengalaman bertanding bisa diubah jadi statistik. Ayo latihan!'], 0);
  addNpc('npc_kid1', 'villager', 'Bocah Wobble', 'capybara', START.x - 4, START.y + 3, ['Aku mau jadi atlet seperti kamu!', 'Katanya ada jalan rahasia di dekat Mountain Stadium.'], 3);
  addNpc('npc_gran', 'villager', 'Nenek Lila', 'alpaca', START.x + 5, START.y - 4, ['Stadion pertama ada di timur, Green Valley. Lawannya masih pemula.'], 2);
  addNpc('npc_ath1', 'athlete', 'Atlet Veteran', 'wolf', 36, 114, ['Tips: atur susunan tim sebelum bertanding. Statistik benar-benar terasa!', 'Bola berat di gurun, licin di salju.'], 3);
  addNpc('npc_ath2', 'athlete', 'Rival Misterius', 'tiger', 74, 112, ['Aku akan jadi juara dunia lebih dulu darimu!'], 3);
  addNpc('npc_desert', 'villager', 'Pedagang Unta', 'giraffe', 96, 118, ['Di oasis ada atlet yang sedang berteduh. Cari di dekat peti harta!'], 2);
  addNpc('npc_snow', 'villager', 'Pemburu Salju', 'penguin', 146, 109, ['Brrr! Di dataran salju ada atlet bersembunyi.'], 2);
  addNpc('npc_jungle', 'villager', 'Penjaga Hutan', 'koala', 170, 77, ['Hutan ini lebat. Ikuti jalan atau kamu akan tersesat.'], 2);
  addNpc('npc_coast', 'villager', 'Nelayan Pantai', 'flamingo', 144, 44, ['Ombak hari ini bagus untuk bermain bola pantai.'], 3);
  addNpc('npc_shop2', 'shop', 'Bibi Perlengkapan', 'hippo', 127, 47, ['Koleksi perlengkapan Harbor lengkap!'], 0);
  addNpc('npc_hall2', 'recruiter', 'Agen Harbor', 'red_panda', 140, 47, ['Atlet tangguh menunggu di aula ini.'], 0);
  addNpc('npc_coach2', 'coach', 'Pelatih Sora', 'bear', 116, 52, ['Latihan membuat jadi juara!'], 0);
  addNpc('npc_worker', 'villager', 'Pekerja Pabrik', 'shiba', 100, 52, ['Stadion Industri paling keras. Jangan remehkan lawan beton!'], 3);
  addNpc('npc_climber', 'villager', 'Pendaki', 'kangaroo', 70, 32, ['Puncak gunung tinggi sekali! Ada peti di tebing barat.'], 2);
  addNpc('npc_neon1', 'villager', 'Anak Neon', 'axolotl', 34, 66, ['Kota ini tak pernah tidur!'], 3);
  addNpc('npc_hall3', 'recruiter', 'Agen Neon', 'lion', 38, 64, ['Atlet kelas atas hanya di Neon City.'], 0);
  addNpc('npc_noble', 'villager', 'Bangsawan', 'elephant', 66, 84, ['Royal Championship hanya untuk yang terbaik.'], 2);
  addNpc('npc_final', 'athlete', 'Juara Bertahan', 'gorilla', 96, 86, ['World Final Stadium terkunci sampai kamu punya 9 trofi lain.', 'Setelah 10 trofi, World Championship menantimu!'], 2);
  stadiums.forEach((s, i) => addNpc(`guard_${i}`, 'guard', 'Penjaga Save', 'bear', s.door.x - 12, s.door.y + 1, ['Selamat datang di PLAYER SAVE CENTER. Simpan progresmu di papan save.'], 0));

  // 10) Dekorasi / penghalang per biome
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const k = idx(x, y);
      if (protect[k] || solid[k]) continue;
      const t = terrain[k];
      const r = hash2(x, y, 77);
      const clump = vnoise(x * 0.18, y * 0.18, 21);
      let d: number = D.NONE;
      if (t === T.GRASS) d = r < 0.04 + clump * 0.06 ? D.TREE : r < 0.12 ? D.FLOWER : r < 0.15 ? D.BUSH : 0;
      else if (t === T.JUNGLE) d = r < 0.22 + clump * 0.3 ? D.PALM : r < 0.3 ? D.BUSH : 0;
      else if (t === T.SAND) d = r < 0.035 ? D.CACTUS : r < 0.06 ? D.BOULDER : 0;
      else if (t === T.SNOW) d = r < 0.1 + clump * 0.12 ? D.PINE : r < 0.13 ? D.BOULDER : 0;
      else if (t === T.BEACH) d = r < 0.035 ? D.PALM : r < 0.06 ? D.BUSH : 0;
      else if (t === T.CONCRETE) d = r < 0.07 ? D.CRATE : 0;
      else if (t === T.NEON) d = r < 0.045 ? D.PILLAR : 0;
      else if (t === T.MARBLE) d = r < 0.03 ? D.STATUE : r < 0.09 ? D.TREE : r < 0.13 ? D.FLOWER : 0;
      else if (t === T.ROCK) d = clump > 0.5 || r < 0.28 ? D.BOULDER : r < 0.33 ? D.PINE : 0;
      deco[k] = d;
    }
  }

  // 11) Grid solid
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const k = idx(x, y);
      const t = terrain[k];
      const d = deco[k];
      if (t === T.WATER) solid[k] = 1;
      if (d !== D.NONE && d !== D.BUSH && d !== D.FLOWER) solid[k] = 1;
      if (x < 1 || y < 1 || x >= W - 1 || y >= H - 1) solid[k] = 1;
    }
  }
  // pastikan titik interaksi, NPC dan spawn tidak tertutup
  const clear = (x: number, y: number, r = 1) => {
    for (let dy = -r; dy <= r; dy++)
      for (let dx = -r; dx <= r; dx++) {
        if (!inb(x + dx, y + dy)) continue;
        const k = idx(x + dx, y + dy);
        const blocked = buildings.some((b) => x + dx >= b.x && x + dx < b.x + b.w && y + dy >= b.y && y + dy < b.y + b.h);
        if (!blocked && terrain[k] !== T.WATER) {
          solid[k] = 0;
          deco[k] = D.NONE;
        }
      }
  };
  for (const p of pois) clear(p.x, p.y, 1);
  for (const n of npcs) clear(n.x, n.y, 1);
  const spawn = { x: START.x + 2, y: START.y + 4 };
  clear(spawn.x, spawn.y, 2);

  cached = {
    terrain,
    deco,
    solid,
    buildings,
    pois,
    npcs,
    stadiums,
    spawn,
    towns: [
      { name: 'Wobble Town', x: START.x, y: START.y },
      { name: 'Harbor Town', x: 128, y: 38 },
      { name: 'Neon Quarter', x: 36, y: 64 },
    ],
  };
  return cached;
}

export function isSolidTile(w: WorldData, tx: number, ty: number): boolean {
  if (tx < 0 || ty < 0 || tx >= WORLD_W || ty >= WORLD_H) return true;
  return w.solid[ty * WORLD_W + tx] === 1;
}
