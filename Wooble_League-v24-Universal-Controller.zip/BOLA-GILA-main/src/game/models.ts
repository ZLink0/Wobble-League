import * as THREE from 'three';
import { ANIMALS, BALLS, CAPES, HATS, MASKS, SHOE_STYLES } from './catalog';
import { buildScenery } from './scenery';
import { buildStaff } from './staff';
// Banner sponsor pembatas lapangan: 16 gambar, dipilih acak setiap lapangan dibangun
const SPONSOR_URLS = Object.values(
  import.meta.glob('../assets/sponsors/*.webp', { eager: true, query: '?url', import: 'default' })
) as string[];
let sponsorImgCache: HTMLImageElement[] | null = null;
function getSponsorImages(): HTMLImageElement[] {
  if (!sponsorImgCache) {
    sponsorImgCache = SPONSOR_URLS.map((u) => {
      const im = new Image();
      im.src = u;
      return im;
    });
  }
  return sponsorImgCache;
}
import {
  computeNeckPose,
  GOAL_DEPTH,
  GOAL_HALF_Z,
  GOAL_HEIGHT,
  KICK_MAX_REACH,
  KICK_SPIN_REACH,
  NECK_BASE_LEN,
  NECK_BASE_Y,
  PITCH_HALF_X,
  PITCH_HALF_Z,
  POST_RADIUS,
} from './physics';
import { getRagdollFrame, RD } from './ragdoll';
import {
  createBallTexture,
  createBrickWallTexture,
  createContactShadowTexture,
  createFantasyCapeTexture,
  type FantasyCapeStyle,
  createDiceFaceTextures,
  createFireAuraTexture,
  createGrassTexture,
  createPitchSurfaceTexture,
  createJerseyFaceTextures,
  createPuddleTexture,
  createSpectatorTexture,
  createSponsorBoardTexture,
  createWoodenCrateTexture,
} from './textures';
import {
  ArenaPropSim,
  ArenaSpec,
  BallSim,
  BallShapeKind,
  CenterItemType,
  GoalPostsState,
  GrassPatternId,
  NetStyleId,
  PlayerCustomization,
  PlayerSim,
  PropKind,
  TeamId,
  WeatherState,
} from './types';

export interface NeckSegmentRig {
  pivot: THREE.Group;
  mesh: THREE.Mesh;
}

export interface CharacterRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  torsoMesh: THREE.Mesh;
  neckPivot: THREE.Group;
  neckSegments: NeckSegmentRig[];
  headGroup: THREE.Group;
  leftLegPivot: THREE.Group;
  leftLegStretchPivot: THREE.Group;
  leftLegMesh: THREE.Mesh;
  leftFootMesh: THREE.Mesh;
  rightLegPivot: THREE.Group;
  rightLegStretchPivot: THREE.Group;
  rightLegMesh: THREE.Mesh;
  rightFootMesh: THREE.Mesh;
  leftArmPivot: THREE.Group;
  rightArmPivot: THREE.Group;
  punchAuraMesh: THREE.Mesh;
  superKickAuraMesh: THREE.Mesh;
  capePivot: THREE.Group;
  arrowMesh: THREE.Mesh | null;
  teamRingMesh: THREE.Mesh;
  shadowMesh: THREE.Mesh;
  ghostMesh: THREE.Group;
  propellerSpinner: THREE.Object3D | null;
  /** true bila frame sebelumnya dirender dengan ragdoll fisik (perlu reset skala/quaternion saat kembali normal) */
  ragdollPosed?: boolean;
}

export interface GoalNetCloth {
  mesh: THREE.Mesh;
  restLocal: Float32Array;
  restWorld: Float32Array;
  disp: Float32Array;
  vel: Float32Array;
  pinWeight: Float32Array;
  cols: number;
  rows: number;
  outX: number;
  outY: number;
  outZ: number;
  localOutX: number;
  localOutY: number;
  localOutZ: number;
}

export interface GoalRig {
  leftPost: THREE.Mesh;
  rightPost: THREE.Mesh;
  crossbar: THREE.Mesh;
  netGroup: THREE.Group;
  nets: GoalNetCloth[];
}

export interface SpectatorSeat {
  x: number;
  y: number;
  z: number;
  rotY: number;
  phase: number;
}

export interface SpectatorLayer {
  mesh: THREE.InstancedMesh;
  seats: SpectatorSeat[];
}

export interface ArenaRig {
  group: THREE.Group;
  leftGoal: GoalRig;
  rightGoal: GoalRig;
  spectatorLayers: SpectatorLayer[];
  pitchMat: THREE.MeshStandardMaterial;
  puddleMat: THREE.MeshStandardMaterial;
  puddleMeshes: THREE.Mesh[];
  disposables: Array<{ dispose: () => void }>;
  /** Animasi latar sekeliling (mobil, ombak, awan) */
  tickScenery: (t: number) => void;
  /** Pelatih, petugas keamanan, dan bendera penonton */
  tickStaff: (t: number, scoringTeam: 'red' | 'blue' | null, excite: number, camPos?: THREE.Vector3) => void;
}

const _vecA = new THREE.Vector3();
const _vecB = new THREE.Vector3();
const _quatA = new THREE.Quaternion();
const _up = new THREE.Vector3(0, 1, 0);
const _down = new THREE.Vector3(0, -1, 0);
const _specDummy = new THREE.Object3D();

function buildHatMesh(hatId: string): { group: THREE.Group; spinner: THREE.Object3D | null } {
  const g = new THREE.Group();
  let spinner: THREE.Object3D | null = null;
  const spec = HATS.find((h) => h.id === hatId) ?? HATS[0];
  if (spec.style === 'none') return { group: g, spinner: null };

  const matA = new THREE.MeshStandardMaterial({ color: spec.primaryColor, roughness: 0.45 });
  const matB = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, roughness: 0.35 });

  switch (spec.style) {
    case 'propeller': {
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), matA);
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.32, 0.05, 12, 1, false, 0, Math.PI), matB);
      brim.position.set(0, 0.02, 0.12);
      const prop = new THREE.Group();
      prop.position.set(0, 0.3, 0);
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.03, 0.07), matB);
      prop.add(blade);
      g.add(cap, brim, prop);
      spinner = prop;
      break;
    }
    case 'cone': {
      const base = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.05, 0.46), matA);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.55, 10), matA);
      cone.position.y = 0.28;
      const stripe = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.14, 0.12, 10), matB);
      stripe.position.y = 0.26;
      g.add(base, cone, stripe);
      break;
    }
    case 'cheese': {
      const shape = new THREE.Shape();
      shape.moveTo(-0.22, 0);
      shape.lineTo(0.25, 0);
      shape.lineTo(0, 0.42);
      shape.closePath();
      const geo = new THREE.ExtrudeGeometry(shape, { depth: 0.24, bevelEnabled: true, bevelSize: 0.02, bevelThickness: 0.02 });
      geo.center();
      const wedge = new THREE.Mesh(geo, matA);
      wedge.position.y = 0.18;
      wedge.rotation.x = Math.PI * 0.5;
      g.add(wedge);
      break;
    }
    case 'plunger': {
      const cup = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.6), matA);
      cup.rotation.x = Math.PI;
      cup.position.y = 0.14;
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.48, 8), matB);
      handle.position.y = 0.35;
      g.add(cup, handle);
      break;
    }
    case 'viking': {
      const helm = new THREE.Mesh(new THREE.SphereGeometry(0.29, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), matA);
      const hornL = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.28, 8), matB);
      hornL.position.set(0.28, 0.18, 0);
      hornL.rotation.z = -0.8;
      const hornR = hornL.clone();
      hornR.position.x = -0.28;
      hornR.rotation.z = 0.8;
      g.add(helm, hornL, hornR);
      break;
    }
    case 'octopus': {
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 10), matA);
      head.position.y = 0.18;
      g.add(head);
      for (let i = 0; i < 6; i++) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.025, 0.26, 6), matB);
        const a = (i / 6) * Math.PI * 2;
        leg.position.set(Math.cos(a) * 0.2, 0.06, Math.sin(a) * 0.2);
        leg.rotation.z = Math.cos(a) * 0.6;
        leg.rotation.x = -Math.sin(a) * 0.6;
        g.add(leg);
      }
      break;
    }
    case 'crown': {
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.15, 0.14, 8), matA);
      ring.position.y = 0.09;
      g.add(ring);
      for (let i = 0; i < 4; i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.12, 6), matB);
        const a = (i / 4) * Math.PI * 2;
        spike.position.set(Math.cos(a) * 0.15, 0.2, Math.sin(a) * 0.15);
        g.add(spike);
      }
      break;
    }
    case 'chef': {
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.18, 12), matB);
      band.position.y = 0.09;
      const puff = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 10), matA);
      puff.position.y = 0.32;
      g.add(band, puff);
      break;
    }
    case 'antenna': {
      const stemL = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.3, 6), matA);
      stemL.position.set(0.12, 0.16, 0);
      stemL.rotation.z = -0.25;
      const orbL = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), matB);
      orbL.position.set(0.17, 0.31, 0);
      const stemR = stemL.clone();
      stemR.position.x = -0.12;
      stemR.rotation.z = 0.25;
      const orbR = orbL.clone();
      orbR.position.x = -0.17;
      g.add(stemL, orbL, stemR, orbR);
      break;
    }
    case 'pot': {
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.15, 0.25, 10), matA);
      pot.position.y = 0.13;
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.2, 6), matB);
      stem.position.y = 0.32;
      const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.04, 0.1), matB);
      leaf.position.y = 0.42;
      g.add(pot, stem, leaf);
      break;
    }
    case 'wizard': {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.38, 0.04, 14), matA);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.55, 12), matA);
      cone.position.y = 0.28;
      cone.rotation.z = 0.14;
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, 0.06, 12), matB);
      band.position.y = 0.08;
      g.add(brim, cone, band);
      break;
    }
    case 'sombrero': {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.48, 0.05, 16), matA);
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 0.24, 12), matB);
      top.position.y = 0.14;
      g.add(brim, top);
      break;
    }
    case 'pan': {
      const pan = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.25, 0.08, 14), matA);
      pan.position.y = 0.05;
      const handle = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.05, 0.36), matA);
      handle.position.set(0, 0.06, -0.38);
      const egg = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), matB);
      egg.scale.y = 0.35;
      egg.position.y = 0.1;
      g.add(pan, handle, egg);
      break;
    }
    case 'cactus': {
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.38, 8), matA);
      trunk.position.y = 0.19;
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.08, 0.08), matA);
      arm.position.y = 0.22;
      const flower = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), matB);
      flower.position.y = 0.41;
      g.add(trunk, arm, flower);
      break;
    }
    case 'duck': {
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), matA);
      body.scale.z = 1.3;
      body.position.y = 0.14;
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), matA);
      head.position.set(0, 0.3, 0.16);
      const beak = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 0.12), matB);
      beak.position.set(0, 0.29, 0.28);
      g.add(body, head, beak);
      break;
    }
    case 'tv': {
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.38, 0.38), matA);
      box.position.y = 0.18;
      const screen = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.26, 0.04), matB);
      screen.position.set(0, 0.19, 0.19);
      const ant1 = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.22, 6), matA);
      ant1.position.set(0.08, 0.44, 0);
      ant1.rotation.z = -0.35;
      g.add(box, screen, ant1);
      break;
    }
    case 'banana': {
      for (let i = 0; i < 4; i++) {
        const ban = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 0.32, 8), matA);
        const a = (i / 4) * Math.PI * 2;
        ban.position.set(Math.cos(a) * 0.16, 0.16, Math.sin(a) * 0.16);
        ban.rotation.z = Math.cos(a) * 0.5;
        ban.rotation.x = -Math.sin(a) * 0.5;
        g.add(ban);
      }
      break;
    }
    case 'burger': {
      const bunB = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.09, 12), matA);
      bunB.position.y = 0.05;
      const lettuce = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.27, 0.05, 10), matB);
      lettuce.position.y = 0.13;
      const bunT = new THREE.Mesh(new THREE.SphereGeometry(0.25, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.5), matA);
      bunT.position.y = 0.16;
      g.add(bunB, lettuce, bunT);
      break;
    }
    case 'dino': {
      for (let i = 0; i < 3; i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.2, 6), i % 2 === 0 ? matA : matB);
        spike.position.set(0, 0.12, 0.14 - i * 0.16);
        spike.rotation.x = -0.25 * i;
        g.add(spike);
      }
      break;
    }
    // ---------- Topi Fantasy & Penyihir ----------
    case 'archmage': {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.42, 0.035, 18), matA);
      const lower = new THREE.Mesh(new THREE.ConeGeometry(0.27, 0.5, 14), matA);
      lower.position.y = 0.27;
      const upper = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.36, 12), matA);
      upper.position.set(0.05, 0.62, 0);
      upper.rotation.z = -0.35;
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.2, 8), matA);
      tip.position.set(0.17, 0.84, 0);
      tip.rotation.z = -1.0;
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.265, 0.285, 0.07, 16), matB);
      band.position.y = 0.06;
      const starMat = new THREE.MeshStandardMaterial({ color: '#fde047', emissive: '#facc15', emissiveIntensity: 0.9 });
      g.add(brim, lower, upper, tip, band);
      const starPos: Array<[number, number, number]> = [[0.0, 0.3, 0.22], [0.17, 0.18, 0.16], [-0.16, 0.42, 0.12], [0.1, 0.5, -0.1], [-0.12, 0.2, -0.2]];
      for (const [x, y, z] of starPos) {
        const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.035), starMat);
        star.position.set(x, y, z);
        g.add(star);
      }
      break;
    }
    case 'tornwizard': {
      // Pinggiran sobek (ada celah), pucuk patah menjuntai, tambalan & serpihan kain
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.37, 0.39, 0.035, 16, 1, false, 0, Math.PI * 1.55), matA);
      const lower = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.34, 12, 1, true), matA);
      lower.position.y = 0.19;
      (lower.material as THREE.MeshStandardMaterial).side = THREE.DoubleSide;
      const bend = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.3, 10), matA);
      bend.position.set(0.08, 0.46, 0);
      bend.rotation.z = -0.7;
      const droop = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.22, 8), matA);
      droop.position.set(0.28, 0.5, 0);
      droop.rotation.z = -2.1;
      const patch = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.02), matB);
      patch.position.set(-0.07, 0.17, 0.17);
      patch.rotation.set(-0.35, 0, 0.3);
      const hole = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.02), new THREE.MeshStandardMaterial({ color: '#0f0a1e' }));
      hole.position.set(0.08, 0.1, 0.2);
      hole.rotation.x = -0.55;
      g.add(brim, lower, bend, droop, patch, hole);
      for (let i = 0; i < 4; i++) {
        const shred = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.12 + (i % 2) * 0.06, 0.012), matA);
        const a = Math.PI * 1.65 + i * 0.22;
        shred.position.set(Math.cos(a) * 0.37, -0.07, Math.sin(a) * 0.37);
        shred.rotation.z = (i - 1.5) * 0.15;
        g.add(shred);
      }
      break;
    }
    case 'witch': {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.44, 0.03, 18), matA);
      const c1 = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.3, 14), matA);
      c1.position.y = 0.17;
      const c2 = new THREE.Mesh(new THREE.ConeGeometry(0.19, 0.3, 14), matA);
      c2.position.set(-0.03, 0.4, 0);
      c2.rotation.z = 0.2;
      const c3 = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.3, 12), matA);
      c3.position.set(-0.13, 0.63, 0);
      c3.rotation.z = 0.5;
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.245, 0.26, 0.07, 14), matB);
      band.position.y = 0.06;
      const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.08, 0.03), new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.6, roughness: 0.3 }));
      buckle.position.set(0, 0.06, 0.26);
      g.add(brim, c1, c2, c3, band, buckle);
      break;
    }
    case 'elf': {
      const glow = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, emissive: '#fbbf24', emissiveIntensity: 0.7 });
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.255, 0.02, 6, 20), matB);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.08;
      g.add(ring);
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * Math.PI * 2;
        const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.2 + (i % 2) * 0.06, 4), matA);
        leaf.scale.z = 0.4;
        leaf.position.set(Math.cos(a) * 0.255, 0.18, Math.sin(a) * 0.255);
        leaf.rotation.set(Math.sin(a) * 0.35, -a, -Math.cos(a) * 0.35);
        g.add(leaf);
      }
      const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.06), glow);
      gem.position.set(0, 0.1, 0.27);
      g.add(gem);
      break;
    }
    case 'dragonhelm': {
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.29, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.52), matA);
      dome.position.y = 0.02;
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.295, 0.295, 0.05, 14), matB);
      rim.position.y = 0.03;
      g.add(dome, rim);
      for (const sx of [-1, 1]) {
        const horn = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.38, 7), matB);
        horn.position.set(sx * 0.3, 0.2, -0.02);
        horn.rotation.z = -sx * 0.9;
        const hornTip = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.2, 6), matB);
        hornTip.position.set(sx * 0.5, 0.36, -0.02);
        hornTip.rotation.z = -sx * 0.2;
        g.add(horn, hornTip);
      }
      for (let i = 0; i < 4; i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.12, 5), matB);
        spike.position.set(0, 0.28 - i * 0.015, 0.14 - i * 0.12);
        spike.rotation.x = -0.4;
        g.add(spike);
      }
      break;
    }
    case 'crystals': {
      const c1 = new THREE.MeshStandardMaterial({ color: spec.primaryColor, emissive: spec.primaryColor, emissiveIntensity: 0.55, roughness: 0.15, transparent: true, opacity: 0.88 });
      const c2 = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, emissive: spec.secondaryColor, emissiveIntensity: 0.55, roughness: 0.15, transparent: true, opacity: 0.88 });
      const orbit = new THREE.Group();
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.075 + (i % 2) * 0.03), i % 2 ? c1 : c2);
        crystal.scale.y = 1.6;
        crystal.position.set(Math.cos(a) * 0.3, 0.3 + Math.sin(i * 1.7) * 0.1, Math.sin(a) * 0.3);
        orbit.add(crystal);
      }
      const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.1), c1);
      core.scale.y = 1.7;
      core.position.y = 0.38;
      orbit.add(core);
      g.add(orbit);
      spinner = orbit;
      break;
    }
    case 'brokenhelm': {
      // Helm ksatria penyok: separuh kubah sobek, jambul patah, retakan
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.3, 14, 10, 0, Math.PI * 1.6, 0, Math.PI * 0.55), matA);
      dome.position.y = 0.0;
      (dome.material as THREE.MeshStandardMaterial).side = THREE.DoubleSide;
      const visor = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.05, 0.05), new THREE.MeshStandardMaterial({ color: '#0f172a' }));
      visor.position.set(0, 0.06, 0.28);
      const crack = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.2, 0.01), new THREE.MeshStandardMaterial({ color: '#1e293b' }));
      crack.position.set(0.08, 0.16, 0.27);
      crack.rotation.z = 0.5;
      const stump = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.1, 0.18), matB);
      stump.position.set(0, 0.3, -0.02);
      g.add(dome, visor, crack, stump);
      for (let i = 0; i < 3; i++) {
        const plume = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.14, 0.05), matB);
        plume.position.set((i - 1) * 0.03, 0.4 + i * 0.01, -0.06 - i * 0.05);
        plume.rotation.set(0.5 + i * 0.3, 0, (i - 1) * 0.3);
        g.add(plume);
      }
      break;
    }
    case 'phoenix': {
      const flameA = new THREE.MeshStandardMaterial({ color: spec.primaryColor, emissive: '#ea580c', emissiveIntensity: 0.9 });
      const flameB = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, emissive: '#facc15', emissiveIntensity: 0.9 });
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.27, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.45), matA);
      g.add(cap);
      for (let i = 0; i < 5; i++) {
        const t = i - 2;
        const feather = new THREE.Mesh(new THREE.ConeGeometry(0.06 - Math.abs(t) * 0.008, 0.5 - Math.abs(t) * 0.06, 6), i % 2 ? flameB : flameA);
        feather.position.set(t * 0.1, 0.3 - Math.abs(t) * 0.04, -0.06 - Math.abs(t) * 0.03);
        feather.rotation.set(-0.35, 0, -t * 0.28);
        g.add(feather);
      }
      break;
    }
    case 'druid': {
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.025, 6, 20), matA);
      band.rotation.x = Math.PI / 2;
      band.position.y = 0.06;
      g.add(band);
      for (const sx of [-1, 1]) {
        const main = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.028, 0.46, 5), matA);
        main.position.set(sx * 0.3, 0.3, 0);
        main.rotation.z = -sx * 0.4;
        g.add(main);
        for (let k = 0; k < 3; k++) {
          const tine = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.02, 0.2, 5), matA);
          tine.position.set(sx * (0.36 + k * 0.05), 0.28 + k * 0.12, 0);
          tine.rotation.z = sx * 0.7;
          g.add(tine);
        }
        const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.1, 4), matB);
        leaf.position.set(sx * 0.4, 0.2, 0.04);
        leaf.rotation.z = -sx * 1.2;
        g.add(leaf);
      }
      break;
    }
    case 'raggedcap': {
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), matA);
      dome.position.y = 0.0;
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.285, 0.285, 0.08, 12), matB);
      rim.position.y = 0.02;
      const dark = new THREE.MeshStandardMaterial({ color: '#0f172a' });
      for (const [x, y, z, r] of [[0.1, 0.2, 0.18, 0.5], [-0.14, 0.14, 0.2, -0.4], [0.18, 0.12, -0.14, 0.9]] as Array<[number, number, number, number]>) {
        const hole = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.045, 0.02), dark);
        hole.position.set(x, y, z);
        hole.lookAt(x * 3, y * 3 - 0.2, z * 3);
        hole.rotation.z += r;
        g.add(hole);
      }
      const tuft = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), matB);
      tuft.position.set(0, 0.28, 0);
      tuft.scale.set(1, 0.7, 1);
      g.add(dome, rim, tuft);
      for (let i = 0; i < 6; i++) {
        const a = Math.PI * 0.1 + i * 0.5;
        const thread = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.1 + (i % 3) * 0.05, 0.01), matB);
        thread.position.set(Math.cos(a) * 0.285, -0.05, Math.sin(a) * 0.285);
        thread.rotation.z = (i % 2 ? 1 : -1) * 0.18;
        g.add(thread);
      }
      break;
    }
    case 'ufo':
    default: {
      const saucer = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.07, 14), matA);
      saucer.position.y = 0.15;
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.5), matB);
      dome.position.y = 0.18;
      g.add(saucer, dome);
      break;
    }
  }
  return { group: g, spinner };
}

function buildMaskMesh(maskId: string): THREE.Group {
  const g = new THREE.Group();
  const spec = MASKS.find((m) => m.id === maskId) ?? MASKS[0];
  if (spec.style === 'none') return g;

  const matA = new THREE.MeshStandardMaterial({ color: spec.primaryColor, roughness: 0.4 });
  const matB = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, roughness: 0.3 });

  switch (spec.style) {
    case 'visor': {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.12, 0.12), matA);
      bar.position.set(0, 0.06, 0.24);
      g.add(bar);
      break;
    }
    case 'googly': {
      const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), matA);
      eyeL.position.set(0.11, 0.07, 0.26);
      const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), matB);
      pupilL.position.set(0.11, 0.07, 0.33);
      const eyeR = eyeL.clone();
      eyeR.position.x = -0.11;
      const pupilR = pupilL.clone();
      pupilR.position.x = -0.11;
      g.add(eyeL, pupilL, eyeR, pupilR);
      break;
    }
    case 'mustache': {
      const glasses = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.1, 0.08), matA);
      glasses.position.set(0, 0.07, 0.25);
      const nose = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), matB);
      nose.position.set(0, 0.0, 0.32);
      const stache = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.07, 0.07), matA);
      stache.position.set(0, -0.07, 0.28);
      g.add(glasses, nose, stache);
      break;
    }
    case 'bag': {
      const bag = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.56, 0.56), matA);
      bag.position.set(0, 0.04, 0.02);
      const smile = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.05, 0.04), matB);
      smile.position.set(0, -0.06, 0.31);
      g.add(bag, smile);
      break;
    }
    case 'oni': {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.3, 0.1), matA);
      plate.position.set(0, 0.02, 0.24);
      const tuskL = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.14, 6), matB);
      tuskL.position.set(0.14, -0.08, 0.3);
      const tuskR = tuskL.clone();
      tuskR.position.x = -0.14;
      g.add(plate, tuskL, tuskR);
      break;
    }
    default: {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.22, 0.12), matA);
      plate.position.set(0, 0.04, 0.23);
      const trim = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.24, 0.14), matB);
      trim.position.set(0, 0.05, 0.23);
      g.add(plate, trim);
      break;
    }
  }
  return g;
}

function buildCapeMesh(capeId: string): THREE.Group {
  const g = new THREE.Group();
  const spec = CAPES.find((c) => c.id === capeId) ?? CAPES[0];
  if (spec.style === 'none') return g;

  const matA = new THREE.MeshStandardMaterial({ color: spec.primaryColor, roughness: 0.65, side: THREE.DoubleSide });
  const matB = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, roughness: 0.45, side: THREE.DoubleSide });

  const FANTASY_CAPES = ['starry', 'arcane', 'dragonscale', 'galaxy', 'phoenixcape', 'frost', 'vine', 'royalmage', 'raggedcape', 'shadow'];
  if (FANTASY_CAPES.includes(spec.style)) {
    // Jubah fantasi: bidang melengkung dengan tekstur lukisan (tepi robek/berapi dari alpha)
    const tex = createFantasyCapeTexture(spec.style as FantasyCapeStyle, spec.primaryColor, spec.secondaryColor);
    const glowy = ['galaxy', 'arcane', 'phoenixcape', 'shadow', 'starry'].includes(spec.style);
    const clothMat = new THREE.MeshStandardMaterial({
      map: tex,
      transparent: true,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
      roughness: 0.7,
      emissive: glowy ? new THREE.Color('#ffffff') : new THREE.Color('#000000'),
      emissiveMap: glowy ? tex : null,
      emissiveIntensity: glowy ? 0.45 : 0,
    });
    const capeW = 0.68;
    const capeH = 0.84;
    const geo = new THREE.PlaneGeometry(capeW, capeH, 8, 10);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i); // +capeH/2 (atas) .. -capeH/2 (bawah)
      const t = 1 - (y + capeH / 2) / capeH; // 0 atas .. 1 bawah
      // melengkung membungkus punggung + sedikit melebar & bergelombang di bawah
      const bend = -Math.cos((x / capeW) * Math.PI) * 0.05 * (0.4 + t);
      const ripple = Math.sin(x * 16 + t * 3) * 0.012 * t;
      pos.setZ(i, bend - t * 0.06 + ripple);
    }
    geo.computeVertexNormals();
    const cloth = new THREE.Mesh(geo, clothMat);
    cloth.rotation.y = Math.PI; // sisi bergambar menghadap ke belakang
    cloth.position.set(0, -capeH / 2 + 0.04, -0.06);
    cloth.castShadow = false;
    // Kerah + kancing permata di leher
    const collarMat = new THREE.MeshStandardMaterial({ color: spec.secondaryColor, roughness: 0.35, metalness: 0.45 });
    const collar = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.07, 0.1), collarMat);
    collar.position.set(0, 0.04, -0.02);
    const gemMat = new THREE.MeshStandardMaterial({ color: spec.primaryColor, emissive: spec.primaryColor, emissiveIntensity: 0.6, roughness: 0.15 });
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.045), gemMat);
    gem.position.set(0, 0.03, 0.05);
    g.add(cloth, collar, gem);
    return g;
  }

  if (spec.style === 'jetpack') {
    const tankL = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.44, 8), matA);
    tankL.position.set(0.12, -0.22, -0.1);
    const tankR = tankL.clone();
    tankR.position.x = -0.12;
    const flameL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.18, 6), matB);
    flameL.rotation.x = Math.PI;
    flameL.position.set(0.12, -0.5, -0.1);
    const flameR = flameL.clone();
    flameR.position.x = -0.12;
    g.add(tankL, tankR, flameL, flameR);
  } else if (spec.style === 'wings') {
    const wingL = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.34, 0.05), matA);
    wingL.position.set(0.28, -0.16, -0.08);
    wingL.rotation.y = -0.35;
    wingL.rotation.z = 0.2;
    const wingR = wingL.clone();
    wingR.position.x = -0.28;
    wingR.rotation.y = 0.35;
    wingR.rotation.z = -0.2;
    g.add(wingL, wingR);
  } else {
    const cloth = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.62, 0.05), matA);
    cloth.position.set(0, -0.32, -0.05);
    const trim = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.1, 0.06), matB);
    trim.position.set(0, -0.58, -0.05);
    g.add(cloth, trim);
  }
  return g;
}

function buildAnimalHeadFeatures(headGroup: THREE.Group, animalId: string, bodyColor: string, accentColor: string, snoutColor: string) {
  const matBody = new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.72 });
  const matAccent = new THREE.MeshStandardMaterial({ color: accentColor, roughness: 0.65 });
  const matSnout = new THREE.MeshStandardMaterial({ color: snoutColor, roughness: 0.7 });
  const matEye = new THREE.MeshStandardMaterial({ color: '#111827', roughness: 0.25 });
  const matWhite = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.3 });

  const cranium = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.44, 0.46), matBody);
  cranium.castShadow = true;
  headGroup.add(cranium);

  const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.11, 0.04), matWhite);
  eyeL.position.set(0.12, 0.06, 0.23);
  const pupilL = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.07, 0.05), matEye);
  pupilL.position.set(0.12, 0.06, 0.245);
  const eyeR = eyeL.clone();
  eyeR.position.x = -0.12;
  const pupilR = pupilL.clone();
  pupilR.position.x = -0.12;
  headGroup.add(eyeL, pupilL, eyeR, pupilR);

  if (animalId === 'flamingo' || animalId === 'penguin' || animalId === 'owl') {
    const beak = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.26, 6), matSnout);
    beak.rotation.x = Math.PI * 0.5;
    beak.position.set(0, -0.04, 0.32);
    headGroup.add(beak);
  } else if (animalId === 'crocodile') {
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.14, 0.38), matSnout);
    snout.position.set(0, -0.08, 0.34);
    headGroup.add(snout);
  } else {
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.16, 0.18), matSnout);
    snout.position.set(0, -0.08, 0.27);
    const nose = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.06, 0.05), matEye);
    nose.position.set(0, -0.03, 0.36);
    headGroup.add(snout, nose);
  }

  if (animalId === 'alpaca' || animalId === 'kangaroo') {
    const earL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.26, 0.09), matAccent);
    earL.position.set(0.16, 0.32, 0);
    earL.rotation.z = -0.2;
    const earR = earL.clone();
    earR.position.x = -0.16;
    earR.rotation.z = 0.2;
    headGroup.add(earL, earR);
  } else if (animalId === 'shiba' || animalId === 'red_panda') {
    const earL = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.2, 4), matAccent);
    earL.position.set(0.18, 0.28, 0.02);
    const earR = earL.clone();
    earR.position.x = -0.18;
    headGroup.add(earL, earR);
  } else if (animalId === 'axolotl') {
    for (let i = 0; i < 3; i++) {
      const gillL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.06, 0.06), matAccent);
      gillL.position.set(0.32, 0.1 - i * 0.09, 0);
      gillL.rotation.z = 0.2 - i * 0.2;
      const gillR = gillL.clone();
      gillR.position.x = -0.32;
      gillR.rotation.z = -gillL.rotation.z;
      headGroup.add(gillL, gillR);
    }
  } else if (animalId === 'capybara' || animalId === 'gorilla') {
    const earL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.08), matAccent);
    earL.position.set(0.26, 0.14, -0.04);
    const earR = earL.clone();
    earR.position.x = -0.26;
    headGroup.add(earL, earR);
  } else if (animalId === 'flamingo') {
    const crest = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.16, 0.22), matAccent);
    crest.position.set(0, 0.26, -0.05);
    headGroup.add(crest);
  }

  // ---------- Hewan tambahan ----------
  const matDark = new THREE.MeshStandardMaterial({ color: '#1f2937', roughness: 0.6 });
  const matTusk = new THREE.MeshStandardMaterial({ color: '#fffbeb', roughness: 0.4 });
  const matPink = new THREE.MeshStandardMaterial({ color: '#f9a8d4', roughness: 0.6 });
  const ball = (r: number, mat: THREE.Material, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), mat);
    m.position.set(x, y, z);
    headGroup.add(m);
    return m;
  };
  const block = (w: number, h: number, d: number, mat: THREE.Material, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.rotation.set(rx, ry, rz);
    headGroup.add(m);
    return m;
  };
  const cone = (r: number, h: number, mat: THREE.Material, x: number, y: number, z: number, rx = 0, rz = 0) => {
    const m = new THREE.Mesh(new THREE.ConeGeometry(r, h, 6), mat);
    m.position.set(x, y, z);
    m.rotation.set(rx, 0, rz);
    headGroup.add(m);
    return m;
  };

  if (animalId === 'lion') {
    // Surai singa mengelilingi wajah
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      block(0.17, 0.17, 0.14, matAccent, Math.cos(a) * 0.3, Math.sin(a) * 0.28, -0.1, 0, 0, a);
    }
    ball(0.07, matAccent, 0.2, 0.26, 0.0);
    ball(0.07, matAccent, -0.2, 0.26, 0.0);
  } else if (animalId === 'tiger') {
    ball(0.08, matBody, 0.2, 0.26, 0);
    ball(0.08, matBody, -0.2, 0.26, 0);
    for (let i = 0; i < 3; i++) {
      block(0.1, 0.025, 0.02, matAccent, 0.13, 0.19 - i * 0.045, 0.235, 0, 0, 0.25);
      block(0.1, 0.025, 0.02, matAccent, -0.13, 0.19 - i * 0.045, 0.235, 0, 0, -0.25);
      block(0.025, 0.1, 0.4, matAccent, 0.26 - i * 0.0, 0.0 + i * 0.05, 0, 0, 0, 0);
    }
  } else if (animalId === 'elephant') {
    block(0.04, 0.36, 0.34, matSnout, 0.3, 0.06, -0.02, 0, 0, -0.12);
    block(0.04, 0.36, 0.34, matSnout, -0.3, 0.06, -0.02, 0, 0, 0.12);
    block(0.16, 0.16, 0.16, matBody, 0, -0.02, 0.34);
    block(0.14, 0.16, 0.14, matBody, 0, -0.16, 0.4);
    block(0.12, 0.14, 0.14, matBody, 0, -0.28, 0.42);
    cone(0.03, 0.14, matTusk, 0.1, -0.2, 0.34, -2.4, 0);
    cone(0.03, 0.14, matTusk, -0.1, -0.2, 0.34, -2.4, 0);
  } else if (animalId === 'rabbit') {
    for (const sx of [-1, 1]) {
      block(0.11, 0.46, 0.06, matBody, sx * 0.14, 0.42, 0, 0, 0, -sx * 0.12);
      block(0.06, 0.36, 0.02, matPink, sx * 0.14, 0.42, 0.035, 0, 0, -sx * 0.12);
    }
    ball(0.045, matWhite, 0, -0.1, 0.36);
  } else if (animalId === 'wolf') {
    cone(0.1, 0.24, matBody, 0.17, 0.32, 0.0);
    cone(0.1, 0.24, matBody, -0.17, 0.32, 0.0);
    cone(0.05, 0.14, matAccent, 0.17, 0.3, 0.02);
    cone(0.05, 0.14, matAccent, -0.17, 0.3, 0.02);
    block(0.2, 0.12, 0.2, matSnout, 0, -0.1, 0.4);
    block(0.1, 0.1, 0.1, matSnout, 0.26, -0.08, 0.12, 0, 0, 0.5);
    block(0.1, 0.1, 0.1, matSnout, -0.26, -0.08, 0.12, 0, 0, -0.5);
  } else if (animalId === 'owl') {
    for (const sx of [-1, 1]) {
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.03, 12), matAccent);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(sx * 0.12, 0.06, 0.225);
      headGroup.add(ring);
      cone(0.06, 0.2, matBody, sx * 0.19, 0.3, 0, 0, -sx * 0.3);
    }
  } else if (animalId === 'koala') {
    ball(0.15, matBody, 0.3, 0.2, -0.02);
    ball(0.15, matBody, -0.3, 0.2, -0.02);
    ball(0.09, matAccent, 0.3, 0.2, 0.05);
    ball(0.09, matAccent, -0.3, 0.2, 0.05);
    block(0.13, 0.16, 0.08, matDark, 0, -0.01, 0.37);
  } else if (animalId === 'hippo') {
    block(0.1, 0.1, 0.08, matBody, 0.2, 0.26, 0);
    block(0.1, 0.1, 0.08, matBody, -0.2, 0.26, 0);
    block(0.36, 0.2, 0.2, matSnout, 0, -0.1, 0.36);
    ball(0.025, matDark, 0.07, -0.02, 0.47);
    ball(0.025, matDark, -0.07, -0.02, 0.47);
    block(0.05, 0.05, 0.05, matTusk, 0.12, -0.2, 0.46);
    block(0.05, 0.05, 0.05, matTusk, -0.12, -0.2, 0.46);
  } else if (animalId === 'giraffe') {
    for (const sx of [-1, 1]) {
      const horn = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.2, 6), matAccent);
      horn.position.set(sx * 0.1, 0.32, 0);
      headGroup.add(horn);
      ball(0.04, matAccent, sx * 0.1, 0.44, 0);
      block(0.16, 0.05, 0.08, matBody, sx * 0.34, 0.12, 0, 0, 0, sx * 0.3);
    }
    for (const [x, y] of [[0.14, 0.12], [-0.1, 0.17], [0.0, 0.0], [-0.18, -0.06], [0.18, -0.08]] as Array<[number, number]>) {
      block(0.07, 0.07, 0.02, matAccent, x, y, 0.235);
    }
  } else if (animalId === 'bear') {
    ball(0.1, matBody, 0.2, 0.25, 0);
    ball(0.1, matBody, -0.2, 0.25, 0);
    ball(0.055, matAccent, 0.2, 0.25, 0.05);
    ball(0.055, matAccent, -0.2, 0.25, 0.05);
  }
}

export function buildSpectralGhostMesh(scale = 1): THREE.Group {
  const ghostMesh = new THREE.Group();
  const sheetMat = new THREE.MeshStandardMaterial({
    color: '#c084fc',
    emissive: '#7e22ce',
    emissiveIntensity: 0.4,
    transparent: true,
    opacity: 0.52,
    roughness: 0.25,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const headDome = new THREE.Mesh(new THREE.SphereGeometry(0.28 * scale, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), sheetMat);
  headDome.position.y = 0.18 * scale;

  const shroud = new THREE.Mesh(new THREE.CylinderGeometry(0.28 * scale, 0.38 * scale, 0.52 * scale, 14, 1, true), sheetMat);
  shroud.position.y = -0.08 * scale;

  const armL = new THREE.Mesh(new THREE.SphereGeometry(0.1 * scale, 8, 6), sheetMat);
  armL.scale.set(1.4, 0.8, 0.8);
  armL.position.set(0.32 * scale, 0.02 * scale, 0.08 * scale);
  const armR = armL.clone();
  armR.position.x = -0.32 * scale;

  const eyeMat = new THREE.MeshBasicMaterial({ color: '#fef08a', transparent: true, opacity: 0.92 });
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.05 * scale, 8, 6), eyeMat);
  eyeL.position.set(0.1 * scale, 0.16 * scale, 0.24 * scale);
  const eyeR = eyeL.clone();
  eyeR.position.x = -0.1 * scale;

  ghostMesh.add(headDome, shroud, armL, armR, eyeL, eyeR);
  return ghostMesh;
}

export function buildCharacterRig(
  team: TeamId,
  isHuman: boolean,
  custom: PlayerCustomization,
  shadowTex: THREE.Texture
): CharacterRig {
  const animal = ANIMALS.find((a) => a.id === custom.animal) ?? ANIMALS[0];

  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.rotation.order = 'YXZ';
  root.add(bodyGroup);

  const teamHex = team === 'red' ? '#dc2626' : '#2563eb';
  const clothesStyle = custom.clothes ?? 'solid';
  const trimHex = custom.trimColor && custom.trimColor.length > 0 ? custom.trimColor : '#ffffff';
  const furHex = custom.furColor && custom.furColor.length > 0 ? custom.furColor : animal.bodyColor;
  const shoeSpec = SHOE_STYLES.find((s) => s.id === custom.shoes) ?? SHOE_STYLES[0];

  const { frontTex, backTex, sideTex, sleeveTex } = createJerseyFaceTextures(
    teamHex,
    '#ffffff',
    clothesStyle,
    trimHex
  );
  const frontMat = new THREE.MeshStandardMaterial({
    map: frontTex,
    bumpMap: frontTex,
    bumpScale: 0.8,
    roughness: 0.58,
    metalness: 0.05,
  });
  const backMat = new THREE.MeshStandardMaterial({
    map: backTex,
    bumpMap: backTex,
    bumpScale: 0.8,
    roughness: 0.58,
    metalness: 0.05,
  });
  const sideMat = new THREE.MeshStandardMaterial({
    map: sideTex,
    bumpMap: sideTex,
    bumpScale: 0.8,
    roughness: 0.62,
    metalness: 0.04,
  });
  const capMat = new THREE.MeshStandardMaterial({
    color: teamHex,
    roughness: 0.65,
    metalness: 0.04,
  });
  const sleeveMat = new THREE.MeshStandardMaterial({
    map: sleeveTex,
    bumpMap: sleeveTex,
    bumpScale: 0.8,
    roughness: 0.58,
    metalness: 0.05,
  });
  const bodyMat = new THREE.MeshStandardMaterial({
    color: furHex,
    roughness: 0.72,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: shoeSpec.primaryColor,
    roughness: 0.32,
    metalness: 0.18,
  });

  // 6-face material order on BoxGeometry: [+X right, -X left, +Y top, -Y bottom, +Z front, -Z back]
  const torsoMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.56, 0.56, 0.42),
    [sideMat, sideMat, capMat, capMat, frontMat, backMat]
  );
  torsoMesh.position.y = 0.68;
  torsoMesh.castShadow = true;
  bodyGroup.add(torsoMesh);

  // Matching Team Collar on Plain Solid kit, or Trim Collar on Patterned kit
  const collarHex = clothesStyle === 'solid' ? (team === 'red' ? '#b91c1c' : '#1d4ed8') : trimHex;
  const trimMat = new THREE.MeshStandardMaterial({
    color: collarHex,
    roughness: 0.35,
    metalness: 0.2,
  });
  const collarRing = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.055, 0.28), trimMat);
  collarRing.position.set(0, 0.96, 0);
  bodyGroup.add(collarRing);

  const shoulderL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.44), sleeveMat);
  shoulderL.position.set(0.31, 0.9, 0);
  const shoulderR = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.44), sleeveMat);
  shoulderR.position.set(-0.31, 0.9, 0);
  bodyGroup.add(shoulderL, shoulderR);

  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.16, 0.2), bodyMat);
  tail.position.set(0, 0.54, -0.24);
  bodyGroup.add(tail);

  // 4-Segment Articulated Curved Rubber Neck + Head (Pivot at top of torso y = NECK_BASE_Y)
  const neckPivot = new THREE.Group();
  neckPivot.position.set(0, NECK_BASE_Y, 0);
  neckPivot.rotation.order = 'YXZ';
  bodyGroup.add(neckPivot);

  const segGeo = new THREE.CylinderGeometry(0.115, 0.125, 1, 8);
  segGeo.translate(0, 0.5, 0);
  const initSegLen = NECK_BASE_LEN / 4;
  const neckSegments: NeckSegmentRig[] = [];
  let parentGroup: THREE.Group = neckPivot;

  for (let i = 0; i < 4; i++) {
    const segPivot = new THREE.Group();
    segPivot.position.set(0, i === 0 ? 0 : initSegLen, 0);
    const segMesh = new THREE.Mesh(segGeo, bodyMat);
    segMesh.scale.set(1, initSegLen * 1.2, 1);
    segMesh.castShadow = true;
    segPivot.add(segMesh);
    parentGroup.add(segPivot);
    neckSegments.push({ pivot: segPivot, mesh: segMesh });
    parentGroup = segPivot;
  }

  const headGroup = new THREE.Group();
  headGroup.position.set(0, initSegLen, 0);
  parentGroup.add(headGroup);

  buildAnimalHeadFeatures(headGroup, animal.id, furHex, animal.accentColor, animal.snoutColor);

  const { group: hatGroup, spinner } = buildHatMesh(custom.hat);
  hatGroup.position.set(0, 0.22, 0);
  headGroup.add(hatGroup);

  const maskGroup = buildMaskMesh(custom.mask);
  headGroup.add(maskGroup);

  const capePivot = new THREE.Group();
  capePivot.position.set(0, 0.9, -0.22);
  bodyGroup.add(capePivot);
  capePivot.add(buildCapeMesh(custom.cape));

  const soleMat = new THREE.MeshStandardMaterial({ color: shoeSpec.accentColor, roughness: 0.4 });
  const sb = shoeSpec.bulkScale;

  function makeLeg(xOffset: number) {
    const legPivot = new THREE.Group();
    legPivot.position.set(xOffset, 0.38, 0);
    bodyGroup.add(legPivot);

    const stretchPivot = new THREE.Group();
    legPivot.add(stretchPivot);

    // Extend cleanly downward along -Y so +Z always faces forward (never reversed behind heel!)
    const legGeo = new THREE.CylinderGeometry(0.08, 0.07, 1, 8);
    legGeo.translate(0, -0.5, 0);
    const legMesh = new THREE.Mesh(legGeo, bodyMat);
    legMesh.scale.set(1, 0.28, 1);
    legMesh.castShadow = true;
    stretchPivot.add(legMesh);

    const footMesh = new THREE.Mesh(new THREE.BoxGeometry(0.16 * sb, 0.1 * sb, 0.22 * sb), shoeMat);
    footMesh.position.set(0, -0.31, 0.035);
    footMesh.castShadow = true;

    const soleMesh = new THREE.Mesh(new THREE.BoxGeometry(0.168 * sb, 0.034 * sb, 0.228 * sb), soleMat);
    soleMesh.position.set(0, -0.04 * sb, 0);
    footMesh.add(soleMesh);

    const laceStripe = new THREE.Mesh(new THREE.BoxGeometry(0.08 * sb, 0.025, 0.12 * sb), soleMat);
    laceStripe.position.set(0, 0.048 * sb, 0.02);
    footMesh.add(laceStripe);

    stretchPivot.add(footMesh);

    return { legPivot, stretchPivot, legMesh, footMesh };
  }

  const leftLeg = makeLeg(0.15);
  const rightLeg = makeLeg(-0.15);

  function makeArm(xOffset: number) {
    const armPivot = new THREE.Group();
    armPivot.position.set(xOffset, 0.86, 0);
    const sleeveMesh = new THREE.Mesh(new THREE.BoxGeometry(0.155, 0.15, 0.155), sleeveMat);
    sleeveMesh.position.y = -0.06;
    const armMesh = new THREE.Mesh(new THREE.BoxGeometry(0.135, 0.26, 0.135), bodyMat);
    armMesh.position.y = -0.22;
    armMesh.castShadow = true;
    armPivot.add(sleeveMesh, armMesh);
    bodyGroup.add(armPivot);
    return armPivot;
  }
  const leftArmPivot = makeArm(0.36);
  const rightArmPivot = makeArm(-0.36);

  // Hold-X Charge Punch glowing fist aura on right arm
  const punchAuraMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 10, 8),
    new THREE.MeshBasicMaterial({
      color: '#f97316',
      transparent: true,
      opacity: 0.78,
      depthWrite: false,
    })
  );
  punchAuraMesh.position.set(0, -0.34, 0.08);
  punchAuraMesh.visible = false;
  rightArmPivot.add(punchAuraMesh);

  // Hold-A Super Kick / Fire Backflip glowing aura on kicking foot
  const superKickAuraMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.24, 12, 10),
    new THREE.MeshBasicMaterial({
      color: '#fb923c',
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
    })
  );
  superKickAuraMesh.position.set(0, 0, 0.04);
  superKickAuraMesh.visible = false;
  rightLeg.footMesh.add(superKickAuraMesh);

  // Player-Only Small Team Arrow above character (NPCs get null!)
  let arrowMesh: THREE.Mesh | null = null;
  if (isHuman) {
    const arrowGeo = new THREE.ConeGeometry(0.17, 0.28, 4);
    arrowGeo.rotateX(Math.PI);
    const arrowMat = new THREE.MeshStandardMaterial({
      color: team === 'red' ? '#ff3b3b' : '#38bdf8',
      emissive: team === 'red' ? '#991b1b' : '#0369a1',
      emissiveIntensity: 0.45,
      roughness: 0.25,
    });
    arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
    arrowMesh.position.set(0, 2.05, 0);
    root.add(arrowMesh);
  }

  // Round Colored Circle Ring directly beneath EVERY player (Red or Blue team marker!)
  const ringGeo = new THREE.RingGeometry(0.45, 0.6, 28);
  ringGeo.rotateX(-Math.PI / 2);
  const ringMat = new THREE.MeshBasicMaterial({
    color: team === 'red' ? '#ef4444' : '#3b82f6',
    transparent: true,
    opacity: 0.88,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const teamRingMesh = new THREE.Mesh(ringGeo, ringMat);
  teamRingMesh.position.y = 0.024;
  root.add(teamRingMesh);

  // Contact shadow disc directly beneath character feet
  const shadowGeo = new THREE.CircleGeometry(0.55, 16);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    opacity: 0.52,
    depthWrite: false,
  });
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.position.y = 0.015;
  root.add(shadowMesh);

  // Translucent Spectral Heavy Ghost clinging behind slowed player
  const ghostMesh = buildSpectralGhostMesh(1.0);
  ghostMesh.position.set(0, 1.32, -0.4);
  ghostMesh.visible = false;
  root.add(ghostMesh);

  return {
    root,
    bodyGroup,
    torsoMesh,
    neckPivot,
    neckSegments,
    headGroup,
    leftLegPivot: leftLeg.legPivot,
    leftLegStretchPivot: leftLeg.stretchPivot,
    leftLegMesh: leftLeg.legMesh,
    leftFootMesh: leftLeg.footMesh,
    rightLegPivot: rightLeg.legPivot,
    rightLegStretchPivot: rightLeg.stretchPivot,
    rightLegMesh: rightLeg.legMesh,
    rightFootMesh: rightLeg.footMesh,
    leftArmPivot,
    rightArmPivot,
    punchAuraMesh,
    superKickAuraMesh,
    capePivot,
    arrowMesh,
    teamRingMesh,
    shadowMesh,
    ghostMesh,
    propellerSpinner: spinner,
  };
}

// ---- Ragdoll fisik: pemetaan partikel -> tulang rig ----
const _Y_UP = new THREE.Vector3(0, 1, 0);
const _Y_DOWN = new THREE.Vector3(0, -1, 0);
const _ID_Q = new THREE.Quaternion();
const _mBasis = new THREE.Matrix4();
const _bx = new THREE.Vector3();
const _by = new THREE.Vector3();
const _bz = new THREE.Vector3();
const _qBody = new THREE.Quaternion();
const _qYawInv = new THREE.Quaternion();
const _qBodyInv = new THREE.Quaternion();
const _qTmp = new THREE.Quaternion();
const _qTmp2 = new THREE.Quaternion();
const _vTmp = new THREE.Vector3();
const _vDir = new THREE.Vector3();

/** Putar pivot (yang menjulur ke bawah -Y) agar mengarah dari titik A ke B; hasil di-blend dari pose berdiri. */
function aimLimb(
  pivot: THREE.Group,
  pts: ArrayLike<number>,
  a: number,
  b: number,
  restLen: number,
  blend: number
) {
  _vDir.set(pts[b * 3] - pts[a * 3], pts[b * 3 + 1] - pts[a * 3 + 1], pts[b * 3 + 2] - pts[a * 3 + 2]);
  const len = _vDir.length();
  if (len < 1e-5) {
    pivot.quaternion.identity();
    pivot.scale.set(1, 1, 1);
    return;
  }
  _vDir.divideScalar(len).applyQuaternion(_qBodyInv);
  _qTmp.setFromUnitVectors(_Y_DOWN, _vDir);
  pivot.quaternion.copy(_ID_Q).slerp(_qTmp, blend);
  // anggota badan karet: boleh memendek (squash) saat tertekan lantai/badan
  const squash = Math.max(0.55, Math.min(1, len / restLen));
  pivot.scale.set(1, 1 + (squash - 1) * blend, 1);
}

/** Render pose dari ragdoll fisik (rangka partikel) ke rig karakter. */
function applyPhysicalRagdoll(rig: CharacterRig, p: CharacterPoseInput, pts: ArrayLike<number>, blend: number) {
  const b = Math.max(0, Math.min(1, blend));
  const fr = getRagdollFrame(pts);

  // Basis badan di dunia -> quaternion, lalu ke ruang lokal root (root berputar sebesar facing)
  _bx.set(fr.xAxis[0], fr.xAxis[1], fr.xAxis[2]);
  _by.set(fr.yAxis[0], fr.yAxis[1], fr.yAxis[2]);
  _bz.set(fr.zAxis[0], fr.zAxis[1], fr.zAxis[2]);
  _mBasis.makeBasis(_bx, _by, _bz);
  _qBody.setFromRotationMatrix(_mBasis);
  _qYawInv.setFromAxisAngle(_Y_UP, -p.facing);
  _qBody.premultiply(_qYawInv);
  _qBodyInv.copy(_qBody).invert();

  // Posisi titik asal badan relatif root
  _vTmp.set(fr.ox - p.x, fr.oy - p.y, fr.oz - p.z).applyQuaternion(_qYawInv);
  rig.bodyGroup.position.copy(_vTmp).multiplyScalar(b);
  rig.bodyGroup.quaternion.copy(_ID_Q).slerp(_qBody, b);
  rig.bodyGroup.scale.set(1, 1, 1);

  // Anggota badan (pivot sudah berada di bahu/pinggul pada ruang badan)
  aimLimb(rig.leftArmPivot, pts, RD.SH_L, RD.HAND_L, 0.36, b);
  aimLimb(rig.rightArmPivot, pts, RD.SH_R, RD.HAND_R, 0.36, b);
  aimLimb(rig.leftLegPivot, pts, RD.HIP_L, RD.FOOT_L, 0.34, b);
  aimLimb(rig.rightLegPivot, pts, RD.HIP_R, RD.FOOT_R, 0.34, b);

  // Leher 2 ruas: ruas bawah (segmen 0-1) mengikuti NECK_BASE->NECK_MID, ruas atas (2-3) NECK_MID->HEAD
  const nb = RD.NECK_BASE;
  const nm = RD.NECK_MID;
  const hd = RD.HEAD;
  _vDir
    .set(pts[nm * 3] - pts[nb * 3], pts[nm * 3 + 1] - pts[nb * 3 + 1], pts[nm * 3 + 2] - pts[nb * 3 + 2])
    .normalize()
    .applyQuaternion(_qBodyInv);
  const q1 = _qTmp.setFromUnitVectors(_Y_UP, _vDir);
  rig.neckPivot.quaternion.copy(_ID_Q).slerp(q1, b);
  _vDir
    .set(pts[hd * 3] - pts[nm * 3], pts[hd * 3 + 1] - pts[nm * 3 + 1], pts[hd * 3 + 2] - pts[nm * 3 + 2])
    .normalize()
    .applyQuaternion(_qBodyInv);
  // rotasi relatif ruas atas terhadap ruas bawah: q1^-1 * q2
  const q2 = _qTmp2.setFromUnitVectors(_Y_UP, _vDir);
  const rel = new THREE.Quaternion().copy(q1).invert().multiply(q2);
  const restSegLen = NECK_BASE_LEN / 4;
  for (let i = 0; i < rig.neckSegments.length; i++) {
    const seg = rig.neckSegments[i];
    seg.pivot.position.set(0, i === 0 ? 0 : restSegLen, 0);
    seg.mesh.scale.set(1, restSegLen * 1.2, 1);
    if (i === 2) seg.pivot.quaternion.copy(_ID_Q).slerp(rel, b);
    else seg.pivot.quaternion.identity();
  }
  rig.headGroup.position.set(0, restSegLen, 0);
  rig.headGroup.quaternion.identity();

  // Kaki/telapak: pose netral, jubah menjuntai
  const defaultLegLen = 0.28;
  for (const [stretch, legMesh, foot] of [
    [rig.leftLegStretchPivot, rig.leftLegMesh, rig.leftFootMesh],
    [rig.rightLegStretchPivot, rig.rightLegMesh, rig.rightFootMesh],
  ] as const) {
    stretch.rotation.set(0, 0, 0);
    legMesh.scale.set(1, defaultLegLen, 1);
    foot.position.set(0, -defaultLegLen - 0.03, 0.035);
    foot.rotation.set(0, 0, 0);
  }
  rig.capePivot.rotation.x = 0.25;
  rig.ragdollPosed = true;
}

export type CharacterPoseInput = Pick<
  PlayerSim,
  | 'x'
  | 'y'
  | 'z'
  | 'facing'
  | 'turnRateVisual'
  | 'walkCycle'
  | 'squashX'
  | 'squashY'
  | 'kickPhase'
  | 'kickVariant'
  | 'kickLeg'
  | 'kickStretch'
  | 'kickSpinAngle'
  | 'kickSpinDir'
  | 'kickTargetDirX'
  | 'kickTargetDirZ'
  | 'kickCharge'
  | 'backflipAngle'
  | 'headPhase'
  | 'headVariant'
  | 'neckStretch'
  | 'headSpinAngle'
  | 'headSpinDir'
  | 'saltoAngle'
  | 'headTargetDirX'
  | 'headTargetDirY'
  | 'headTargetDirZ'
  | 'fallTimer'
  | 'ragdollBlend'
  | 'ragdollPitch'
  | 'ragdollRoll'
  | 'ragdollArmL'
  | 'ragdollArmR'
  | 'ragdollLegL'
  | 'ragdollLegR'
  | 'ragdollNeck'
  | 'ragdollHeadRoll'
  | 'ghostAttachedTimer'
  | 'carryingPropId'
  | 'punchPhase'
  | 'punchCharge'
> & { vx?: number; vz?: number; dashTimer?: number; ragdoll?: { pos: ArrayLike<number> } | null };

export function syncCharacterRig(rig: CharacterRig, p: CharacterPoseInput, elapsedTime: number) {
  rig.root.position.set(p.x, p.y, p.z);
  rig.root.rotation.y = p.facing;

  // Ground team circle & contact shadow stay anchored cleanly to turf (y ~ 0.02) even when jumping
  rig.teamRingMesh.position.y = 0.024 - p.y;
  rig.shadowMesh.position.y = 0.015 - p.y;
  const airScale = Math.max(0.55, 1 - p.y * 0.25);
  rig.shadowMesh.scale.setScalar(airScale);
  (rig.shadowMesh.material as THREE.MeshBasicMaterial).opacity = 0.5 * airScale;

  if (rig.arrowMesh) {
    rig.arrowMesh.position.y = 2.02 + Math.sin(elapsedTime * 5) * 0.08 - p.y * 0.1;
  }

  if (rig.propellerSpinner) {
    rig.propellerSpinner.rotation.y += 0.28;
  }

  // Translucent Heavy Ghost visibility & spooky float
  rig.ghostMesh.visible = p.ghostAttachedTimer > 0;
  if (rig.ghostMesh.visible) {
    rig.ghostMesh.position.y = 1.32 + Math.sin(elapsedTime * 5.5) * 0.11;
    rig.ghostMesh.rotation.z = Math.sin(elapsedTime * 4) * 0.12;
  }

  const defaultLegLen = 0.28;
  const restSegLen = NECK_BASE_LEN / 4;

  // Instant Limp Articulated Ragdoll Fall & Zero-Clipping Get Up
  if (p.fallTimer > 0 || p.ragdollBlend > 0.01) {
    const b = Math.max(0, Math.min(1, p.ragdollBlend));
    rig.punchAuraMesh.visible = false;
    rig.superKickAuraMesh.visible = false;
    if (p.ragdoll) {
      // Ragdoll fisik penuh (gravitasi, tumbukan lantai, sendi) – lihat ragdoll.ts
      applyPhysicalRagdoll(rig, p, p.ragdoll.pos, b);
      return;
    }
    rig.bodyGroup.position.y = b * 0.36;
    rig.bodyGroup.rotation.set(p.ragdollPitch, 0, p.ragdollRoll);
    rig.bodyGroup.scale.set(1, 1, 1);

    rig.leftArmPivot.rotation.set(p.ragdollArmL * b, 0, 1.12 * b);
    rig.rightArmPivot.rotation.set(p.ragdollArmR * b, 0, -1.12 * b);
    rig.leftLegPivot.rotation.set(p.ragdollLegL * b, 0, 0.42 * b);
    rig.rightLegPivot.rotation.set(p.ragdollLegR * b, 0, -0.42 * b);
    rig.leftLegStretchPivot.rotation.set(0, 0, 0);
    rig.rightLegStretchPivot.rotation.set(0, 0, 0);
    rig.leftLegMesh.scale.set(1, defaultLegLen, 1);
    rig.rightLegMesh.scale.set(1, defaultLegLen, 1);
    rig.leftFootMesh.position.set(0, -defaultLegLen - 0.03, 0.035);
    rig.rightFootMesh.position.set(0, -defaultLegLen - 0.03, 0.035);
    rig.leftFootMesh.rotation.set(0, 0, 0);
    rig.rightFootMesh.rotation.set(0, 0, 0);

    rig.neckPivot.rotation.set(0.32 * b, p.ragdollNeck * b, 0);
    for (let i = 0; i < rig.neckSegments.length; i++) {
      rig.neckSegments[i].pivot.position.set(0, i === 0 ? 0 : restSegLen, 0);
      rig.neckSegments[i].pivot.rotation.set(0.14 * b, 0, 0);
      rig.neckSegments[i].mesh.scale.set(1, restSegLen * 1.2, 1);
    }
    rig.headGroup.position.set(0, restSegLen, 0);
    rig.headGroup.rotation.set(0.18 * b, 0, p.ragdollHeadRoll * b);
    return;
  }

  if (rig.ragdollPosed) {
    // Kembali dari ragdoll fisik: bersihkan quaternion/skala yang dipakai ragdoll
    rig.ragdollPosed = false;
    rig.bodyGroup.quaternion.identity();
    rig.bodyGroup.position.set(0, 0, 0);
    rig.neckPivot.quaternion.identity();
    for (const seg of rig.neckSegments) seg.pivot.quaternion.identity();
    rig.headGroup.quaternion.identity();
    for (const piv of [rig.leftArmPivot, rig.rightArmPivot, rig.leftLegPivot, rig.rightLegPivot]) {
      piv.quaternion.identity();
      piv.scale.set(1, 1, 1);
    }
  }

  const speed = p.vx !== undefined && p.vz !== undefined ? Math.hypot(p.vx, p.vz) : 1.4;
  const isDashing = (p.dashTimer ?? 0) > 0;
  const pose = computeNeckPose(p as PlayerSim);

  rig.bodyGroup.position.y = pose.bodyOffsetY;
  rig.bodyGroup.rotation.y = pose.bodyYaw;
  rig.bodyGroup.rotation.x = pose.bodyPitch + (isDashing ? 0.34 : 0);
  rig.bodyGroup.rotation.z = Math.max(-0.22, Math.min(0.22, -p.turnRateVisual * 0.025));
  rig.bodyGroup.scale.set(p.squashX, p.squashY, p.squashX);

  rig.capePivot.rotation.x =
    0.18 + Math.min(0.88, speed * 0.22 + (isDashing ? 0.24 : 0)) + Math.sin(elapsedTime * 9 + p.walkCycle) * 0.08;

  // Walk / Run / Jump / Dash Gait (compact rear swing so legs never stretch far backward)
  const swingAmp = p.y > 0.1 ? 0.32 : speed > 0.15 ? Math.min(0.62, speed * (isDashing ? 0.18 : 0.16)) : 0;
  const lSwing = p.y > 0.1 ? 0.25 : Math.sin(p.walkCycle) * swingAmp;
  const rSwing = p.y > 0.1 ? -0.25 : -Math.sin(p.walkCycle) * swingAmp;

  if (p.carryingPropId) {
    // Y Overhead Carry Pose: arms raised overhead holding the prop!
    rig.leftArmPivot.rotation.set(-Math.PI * 0.92, 0, 0.22);
    rig.rightArmPivot.rotation.set(-Math.PI * 0.92, 0, -0.22);
    rig.punchAuraMesh.visible = false;
  } else if (p.punchPhase === 'charge') {
    // Hold-X Charge Punch Windup: pull right fist back + pulsing orange-gold charge aura
    const c = Math.max(0, Math.min(1, p.punchCharge));
    rig.leftArmPivot.rotation.set(-0.45, 0, 0.25);
    rig.rightArmPivot.rotation.set(0.85 + c * 0.72, 0, -0.32);
    rig.bodyGroup.rotation.y += -0.35 - c * 0.38;
    rig.punchAuraMesh.visible = true;
    const auraScale = 0.7 + c * 1.15 + Math.sin(elapsedTime * 22) * 0.12;
    rig.punchAuraMesh.scale.setScalar(auraScale);
    const auraMat = rig.punchAuraMesh.material as THREE.MeshBasicMaterial;
    auraMat.color.set(c > 0.75 ? '#ef4444' : '#f59e0b');
    auraMat.opacity = 0.55 + c * 0.35;
  } else if (p.punchPhase === 'strike') {
    // Hold-X Strike: snap right fist forward!
    rig.leftArmPivot.rotation.set(0.55, 0, 0.25);
    rig.rightArmPivot.rotation.set(-Math.PI * 0.54, 0, 0.08);
    rig.bodyGroup.rotation.y += 0.48;
    rig.punchAuraMesh.visible = true;
    rig.punchAuraMesh.scale.setScalar(1.45 + p.punchCharge * 0.8);
    (rig.punchAuraMesh.material as THREE.MeshBasicMaterial).color.set('#fde047');
  } else if (p.punchPhase === 'recover') {
    rig.leftArmPivot.rotation.set(0.15, 0, 0.1);
    rig.rightArmPivot.rotation.set(-0.45, 0, 0);
    rig.punchAuraMesh.visible = false;
  } else if (isDashing) {
    // Aerodynamic Sprint Dash: both arms swept back with slight shoulder flare
    rig.leftArmPivot.rotation.set(0.72, 0, 0.3);
    rig.rightArmPivot.rotation.set(0.72, 0, -0.3);
    rig.punchAuraMesh.visible = false;
  } else {
    rig.leftArmPivot.rotation.set(rSwing * 0.9, 0, p.y > 0.1 ? 0.45 : 0);
    rig.rightArmPivot.rotation.set(lSwing * 0.9, 0, p.y > 0.1 ? -0.45 : 0);
    rig.punchAuraMesh.visible = false;
  }

  rig.leftLegPivot.rotation.set(lSwing, 0, 0);
  rig.rightLegPivot.rotation.set(rSwing, 0, 0);
  rig.leftLegStretchPivot.rotation.set(0, 0, 0);
  rig.rightLegStretchPivot.rotation.set(0, 0, 0);
  rig.leftLegMesh.scale.set(1, defaultLegLen, 1);
  rig.leftFootMesh.position.set(0, -defaultLegLen - 0.03, 0.035);
  rig.leftFootMesh.rotation.set(0, 0, 0);
  rig.rightLegMesh.scale.set(1, defaultLegLen, 1);
  rig.rightFootMesh.position.set(0, -defaultLegLen - 0.03, 0.035);
  rig.rightFootMesh.rotation.set(0, 0, 0);

  // Hold-A Super Kick Charge Stance & Fiery Kick Aura
  if (p.kickPhase === 'super_charge') {
    const kc = Math.max(0, Math.min(1, p.kickCharge));
    rig.rightLegPivot.rotation.set(0.45 + kc * 0.38, 0, 0);
    rig.leftLegPivot.rotation.set(-0.15, 0, 0.1);
    rig.leftArmPivot.rotation.set(-0.55, 0, 0.32);
    rig.rightArmPivot.rotation.set(0.45, 0, -0.32);
    rig.superKickAuraMesh.visible = true;
    const sc = 0.85 + kc * 1.15 + Math.sin(elapsedTime * 24) * 0.14;
    rig.superKickAuraMesh.scale.setScalar(sc);
    const kMat = rig.superKickAuraMesh.material as THREE.MeshBasicMaterial;
    kMat.color.set(kc >= 0.65 ? '#ef4444' : '#f59e0b');
    kMat.opacity = 0.58 + kc * 0.34;
  } else if (
    p.kickPhase !== 'none' &&
    (p.kickVariant === 'super_kick' || p.kickVariant === 'backflip_front_fire')
  ) {
    rig.superKickAuraMesh.visible = true;
    rig.superKickAuraMesh.scale.setScalar(1.35 + (p.kickCharge || 0.6) * 0.7);
    (rig.superKickAuraMesh.material as THREE.MeshBasicMaterial).color.set('#f97316');
  } else {
    rig.superKickAuraMesh.visible = false;
  }

  // Rubber Stretch Kick (A/X: 180° isolated leg sweep WITHOUT body spin; planted support leg + counter-arm balance)
  const isSpinKick = p.kickVariant === 'spin_left' || p.kickVariant === 'spin_right';
  if (p.kickPhase !== 'none' && p.kickPhase !== 'super_charge' && Math.abs(p.kickStretch) > 0.01) {
    if (isSpinKick) {
      // Rotate ONLY the kicking leg in local XZ plane; torso remains forward (pose.bodyYaw === 0)
      const spinYaw = p.kickSpinAngle * p.kickSpinDir;
      const arcMid = Math.cos(p.kickSpinAngle * 0.55);
      const liftY = 0.16 + Math.max(0, arcMid) * 0.28;
      _vecA.set(Math.sin(spinYaw), liftY, Math.cos(spinYaw)).normalize();
    } else if (p.kickVariant === 'backflip_front_fire') {
      _vecA.set(0, 0.55, 1.0).normalize();
    } else if (p.kickVariant === 'backflip_lob') {
      _vecA.set(0, 0.74, 0.82).normalize();
    } else {
      const cosF = Math.cos(-p.facing);
      const sinF = Math.sin(-p.facing);
      const localX = p.kickTargetDirX * cosF - p.kickTargetDirZ * sinF;
      const localZ = p.kickTargetDirX * sinF + p.kickTargetDirZ * cosF;
      _vecA.set(localX, p.kickVariant === 'super_kick' ? 0.28 : 0.2, localZ).normalize();
    }
    _quatA.setFromUnitVectors(_down, _vecA);

    const reachScale = isSpinKick ? KICK_SPIN_REACH : KICK_MAX_REACH;
    const stretchLen = Math.max(0.24, defaultLegLen + p.kickStretch * reachScale);
    const thickness = Math.max(0.62, 1 - Math.abs(p.kickStretch) * 0.26);
    const whipTilt = 0.24 * Math.max(0, p.kickStretch);

    if (!p.carryingPropId && p.punchPhase === 'none') {
      // Counter-arms balance the strike while keeping upper torso non-rotating
      const armBalance = isSpinKick ? p.kickSpinDir * 0.42 : 0.38;
      rig.leftArmPivot.rotation.set(-0.42 - armBalance, 0, 0.48);
      rig.rightArmPivot.rotation.set(-0.42 + armBalance, 0, -0.48);
    }

    if (p.kickLeg === 'left') {
      // Brace planted right leg cleanly without backward flare
      rig.rightLegPivot.rotation.set(0.12, 0, -0.12);
      rig.leftLegPivot.rotation.set(0, 0, 0);
      rig.leftLegStretchPivot.quaternion.copy(_quatA);
      rig.leftLegMesh.scale.set(thickness, stretchLen, thickness);
      rig.leftFootMesh.position.set(0, -stretchLen - 0.03, 0.025);
      rig.leftFootMesh.rotation.set(-whipTilt, 0, 0);
    } else {
      // Brace planted left leg cleanly without backward flare
      rig.leftLegPivot.rotation.set(0.12, 0, 0.12);
      rig.rightLegPivot.rotation.set(0, 0, 0);
      rig.rightLegStretchPivot.quaternion.copy(_quatA);
      rig.rightLegMesh.scale.set(thickness, stretchLen, thickness);
      rig.rightFootMesh.position.set(0, -stretchLen - 0.03, 0.025);
      rig.rightFootMesh.rotation.set(-whipTilt, 0, 0);
    }
  }

  // 4-Segment Articulated Curved Rubber Neck + Head Pose (L/R 360° Head Spin, X Salto Curved Neck, & Directional Headings)
  rig.neckPivot.rotation.set(pose.pivotPitch, pose.pivotYaw, 0);
  const neckThin = Math.max(0.56, 1 - Math.max(0, p.neckStretch) * 0.34);
  for (let i = 0; i < rig.neckSegments.length; i++) {
    const seg = rig.neckSegments[i];
    seg.pivot.position.set(0, i === 0 ? 0 : pose.segLen, 0);
    seg.pivot.rotation.set(pose.segPitch, 0, 0);
    seg.mesh.scale.set(neckThin, pose.segLen * 1.24, neckThin);
  }
  rig.headGroup.position.set(0, pose.segLen, 0);
  rig.headGroup.rotation.set(0, 0, pose.headRoll);
}

function buildGoal3D(isRightGoal: boolean, netMat: THREE.Material, postMat: THREE.Material): GoalRig {
  const xSign = isRightGoal ? 1 : -1;
  const xBase = xSign * PITCH_HALF_X;

  const postGeo = new THREE.CylinderGeometry(POST_RADIUS, POST_RADIUS, GOAL_HEIGHT, 12);
  postGeo.translate(0, GOAL_HEIGHT / 2, 0);

  const leftPost = new THREE.Mesh(postGeo, postMat);
  leftPost.position.set(xBase, 0, -GOAL_HALF_Z);
  leftPost.castShadow = true;

  const rightPost = new THREE.Mesh(postGeo, postMat);
  rightPost.position.set(xBase, 0, GOAL_HALF_Z);
  rightPost.castShadow = true;

  const crossbarGeo = new THREE.CylinderGeometry(POST_RADIUS, POST_RADIUS, GOAL_HALF_Z * 2 + POST_RADIUS * 2, 12);
  crossbarGeo.rotateX(Math.PI / 2);
  const crossbar = new THREE.Mesh(crossbarGeo, postMat);
  crossbar.position.set(xBase, GOAL_HEIGHT, 0);
  crossbar.castShadow = true;

  const netGroup = new THREE.Group();
  const depthMid = xBase + xSign * (GOAL_DEPTH / 2);
  const backX = xBase + xSign * GOAL_DEPTH;

  const backBarGeo = new THREE.CylinderGeometry(0.06, 0.06, GOAL_HEIGHT, 8);
  backBarGeo.translate(0, GOAL_HEIGHT / 2, 0);
  const bL = new THREE.Mesh(backBarGeo, postMat);
  bL.position.set(backX, 0, -GOAL_HALF_Z);
  const bR = new THREE.Mesh(backBarGeo, postMat);
  bR.position.set(backX, 0, GOAL_HALF_Z);
  const bTop = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, GOAL_HALF_Z * 2, 8), postMat);
  bTop.rotation.x = Math.PI / 2;
  bTop.position.set(backX, GOAL_HEIGHT, 0);
  netGroup.add(bL, bR, bTop);

  const makeClothPanel = (
    w: number,
    h: number,
    segW: number,
    segH: number,
    pos: [number, number, number],
    rotX: number,
    rotY: number,
    outX: number,
    outY: number,
    outZ: number
  ): GoalNetCloth => {
    const geo = new THREE.PlaneGeometry(w, h, segW, segH);
    const mesh = new THREE.Mesh(geo, netMat);
    mesh.position.set(pos[0], pos[1], pos[2]);
    mesh.rotation.set(rotX, rotY, 0);
    mesh.updateMatrix();

    const posAttr = geo.attributes.position as THREE.BufferAttribute;
    const count = posAttr.count;
    const restLocal = new Float32Array(count * 3);
    const restWorld = new Float32Array(count * 3);
    const disp = new Float32Array(count);
    const vel = new Float32Array(count);
    const pinWeight = new Float32Array(count);
    const cols = segW + 1;
    const rows = segH + 1;

    const invQuat = mesh.quaternion.clone().invert();
    const localOut = new THREE.Vector3(outX, outY, outZ).applyQuaternion(invQuat);
    const tmp = new THREE.Vector3();

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const idx = r * cols + c;
        const lx = posAttr.getX(idx);
        const ly = posAttr.getY(idx);
        const lz = posAttr.getZ(idx);
        restLocal[idx * 3] = lx;
        restLocal[idx * 3 + 1] = ly;
        restLocal[idx * 3 + 2] = lz;

        tmp.set(lx, ly, lz).applyMatrix4(mesh.matrix);
        restWorld[idx * 3] = tmp.x;
        restWorld[idx * 3 + 1] = tmp.y;
        restWorld[idx * 3 + 2] = tmp.z;

        // Pin perimeter frame edges (posts, crossbar, back stanchions, turf anchor)
        const edgeDistU = Math.min(c, segW - c) / Math.max(1, segW * 0.5);
        const edgeDistV = Math.min(r, segH - r) / Math.max(1, segH * 0.5);
        const isBorder = c === 0 || c === segW || r === 0 || r === segH;
        pinWeight[idx] = isBorder ? 0 : Math.min(1, Math.sqrt(edgeDistU * edgeDistV) * 1.35);
      }
    }

    netGroup.add(mesh);
    return {
      mesh,
      restLocal,
      restWorld,
      disp,
      vel,
      pinWeight,
      cols,
      rows,
      outX,
      outY,
      outZ,
      localOutX: localOut.x,
      localOutY: localOut.y,
      localOutZ: localOut.z,
    };
  };

  const backNet = makeClothPanel(
    GOAL_HALF_Z * 2,
    GOAL_HEIGHT,
    18,
    11,
    [backX, GOAL_HEIGHT / 2, 0],
    0,
    isRightGoal ? -Math.PI / 2 : Math.PI / 2,
    xSign,
    0,
    0
  );
  const topNet = makeClothPanel(
    GOAL_DEPTH,
    GOAL_HALF_Z * 2,
    9,
    18,
    [depthMid, GOAL_HEIGHT, 0],
    Math.PI / 2,
    0,
    0,
    1,
    0
  );
  const sideNetL = makeClothPanel(
    GOAL_DEPTH,
    GOAL_HEIGHT,
    9,
    11,
    [depthMid, GOAL_HEIGHT / 2, -GOAL_HALF_Z],
    0,
    0,
    0,
    0,
    -1
  );
  const sideNetR = makeClothPanel(
    GOAL_DEPTH,
    GOAL_HEIGHT,
    9,
    11,
    [depthMid, GOAL_HEIGHT / 2, GOAL_HALF_Z],
    0,
    0,
    0,
    0,
    1
  );

  return { leftPost, rightPost, crossbar, netGroup, nets: [backNet, topNet, sideNetL, sideNetR] };
}

const NET_ROPE_COLORS = ['#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#a855f7', '#ec4899', '#14b8a6', '#facc15'];

/** Tekstur jaring bergaya tali: simpul, kilau, dan sulur; warna tali aksen diacak */
function createNetTexture(style: NetStyleId, ropeColor: string, maxAnisotropy: number): THREE.CanvasTexture {
  const size = 128;
  const cell = size / 4;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  g.clearRect(0, 0, size, size);
  g.lineCap = 'round';
  const cordColor = (i: number, j: number, horiz: boolean) => {
    if (style === 'white') return '#f8fafc';
    if (style === 'striped') return horiz ? '#f8fafc' : i % 2 === 0 ? '#f8fafc' : '#0f172a';
    return (i + j + (horiz ? 1 : 0)) % 2 === 0 ? '#f8fafc' : '#0f172a';
  };
  const drawCord = (x1: number, y1: number, x2: number, y2: number, color: string, w: number) => {
    // bayangan
    g.strokeStyle = 'rgba(15,23,42,0.55)';
    g.lineWidth = w + 1.6;
    g.beginPath();
    g.moveTo(x1 + 0.8, y1 + 0.8);
    g.lineTo(x2 + 0.8, y2 + 0.8);
    g.stroke();
    // badan tali
    g.strokeStyle = color;
    g.lineWidth = w;
    g.beginPath();
    g.moveTo(x1, y1);
    g.lineTo(x2, y2);
    g.stroke();
    // sulur (twist) diagonal
    g.strokeStyle = 'rgba(15,23,42,0.35)';
    g.lineWidth = 0.9;
    const len = Math.hypot(x2 - x1, y2 - y1);
    const nx = (x2 - x1) / len;
    const ny = (y2 - y1) / len;
    for (let d = 2; d < len - 1; d += 3.2) {
      const px = x1 + nx * d;
      const py = y1 + ny * d;
      g.beginPath();
      g.moveTo(px - ny * w * 0.5, py + nx * w * 0.5);
      g.lineTo(px + ny * w * 0.5 + nx * 1.6, py - nx * w * 0.5 + ny * 1.6);
      g.stroke();
    }
    // kilau
    g.strokeStyle = 'rgba(255,255,255,0.35)';
    g.lineWidth = 0.8;
    g.beginPath();
    g.moveTo(x1 - ny * w * 0.25, y1 + nx * w * 0.25);
    g.lineTo(x2 - ny * w * 0.25, y2 + nx * w * 0.25);
    g.stroke();
  };
  for (let j = 0; j < 4; j++) {
    for (let i = 0; i < 4; i++) {
      const x = i * cell;
      const y = j * cell;
      const accentH = j === 0;
      const accentV = i === 0;
      drawCord(x, y, x + cell, y, accentH ? ropeColor : cordColor(i, j, true), accentH ? 5.2 : 3.4);
      drawCord(x, y, x, y + cell, accentV ? ropeColor : cordColor(i, j, false), accentV ? 5.2 : 3.4);
    }
  }
  // simpul di tiap persilangan
  for (let j = 0; j < 4; j++) {
    for (let i = 0; i < 4; i++) {
      g.fillStyle = i === 0 || j === 0 ? ropeColor : '#e2e8f0';
      g.strokeStyle = 'rgba(15,23,42,0.7)';
      g.lineWidth = 1;
      g.beginPath();
      g.arc(i * cell, j * cell, 3.1, 0, Math.PI * 2);
      g.fill();
      g.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 4);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, maxAnisotropy);
  return tex;
}

export function buildArena3D(
  arena: ArenaSpec,
  maxAnisotropy: number,
  grassPattern: GrassPatternId = 'stripes',
  netStyle: NetStyleId = 'checker'
): ArenaRig {
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];

  // Extended surrounding stadium ground
  const outerGroundMat = new THREE.MeshStandardMaterial({
    color: arena.grassB,
    roughness: 0.95,
  });
  const outerGround = new THREE.Mesh(new THREE.PlaneGeometry(160, 160), outerGroundMat);
  outerGround.rotation.x = -Math.PI / 2;
  outerGround.position.y = -0.04;
  outerGround.receiveShadow = true;
  group.add(outerGround);
  disposables.push(outerGroundMat, outerGround.geometry);

  // Main 3D Pitch Turf: dasar polos (area di luar garis putih) + permukaan bercorak HANYA di dalam garis
  const isWoodCourt = arena.id === 'futsal_court_blue' || arena.id === 'futsal_court_orange';
  const { map: grassMap, bumpMap: grassBump } = createGrassTexture(arena, maxAnisotropy, grassPattern);
  grassMap.dispose();
  // Dasar lapangan: jalur samping berwarna abu bertekstur (bukan putih); tidak ada margin di belakang gawang
  const apronCanvas = document.createElement('canvas');
  apronCanvas.width = apronCanvas.height = 256;
  const actx = apronCanvas.getContext('2d')!;
  actx.fillStyle = '#7d828a';
  actx.fillRect(0, 0, 256, 256);
  let aSeed = 4242;
  const aRnd = () => {
    aSeed = (aSeed * 1664525 + 1013904223) >>> 0;
    return aSeed / 4294967296;
  };
  for (let i = 0; i < 3200; i++) {
    const v = 90 + Math.floor(aRnd() * 80);
    actx.fillStyle = `rgba(${v},${v + 2},${v + 6},0.35)`;
    actx.fillRect(aRnd() * 256, aRnd() * 256, 1 + aRnd() * 3, 1 + aRnd() * 3);
  }
  actx.strokeStyle = 'rgba(40,44,52,0.55)';
  actx.lineWidth = 3;
  actx.strokeRect(0, 0, 256, 256);
  actx.beginPath();
  actx.moveTo(128, 0);
  actx.lineTo(128, 256);
  actx.moveTo(0, 128);
  actx.lineTo(256, 128);
  actx.lineWidth = 1.5;
  actx.stroke();
  const apronTex = new THREE.CanvasTexture(apronCanvas);
  apronTex.colorSpace = THREE.SRGBColorSpace;
  apronTex.wrapS = THREE.RepeatWrapping;
  apronTex.wrapT = THREE.RepeatWrapping;
  apronTex.repeat.set(10, 5);
  apronTex.anisotropy = maxAnisotropy;
  const pitchMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    map: apronTex,
    roughness: 0.85,
  });
  const pitchW = PITCH_HALF_X * 2;
  const pitchD = PITCH_HALF_Z * 2 + 2.0;
  const pitchMesh = new THREE.Mesh(new THREE.BoxGeometry(pitchW, 0.2, pitchD), pitchMat);
  pitchMesh.position.y = -0.1;
  pitchMesh.receiveShadow = true;
  group.add(pitchMesh);

  // Pijakan bertekstur (abu) di belakang tiap gawang
  const padLen = GOAL_DEPTH + 0.7;
  const padWid = (GOAL_HALF_Z + 1.0) * 2;
  const padGeo = new THREE.BoxGeometry(padLen, 0.2, padWid);
  {
    const uv = padGeo.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < uv.count; i++) {
      uv.setXY(i, uv.getX(i) * (padLen / pitchW), uv.getY(i) * (padWid / pitchD));
    }
    uv.needsUpdate = true;
  }
  for (const sign of [-1, 1]) {
    const pad = new THREE.Mesh(padGeo, pitchMat);
    pad.position.set(sign * (PITCH_HALF_X + padLen / 2), -0.1, 0);
    pad.receiveShadow = true;
    group.add(pad);
  }
  disposables.push(padGeo);
  const surfaceTex = createPitchSurfaceTexture(arena, maxAnisotropy, grassPattern, isWoodCourt);
  const surfaceMat = new THREE.MeshStandardMaterial({
    map: surfaceTex,
    roughness: isWoodCourt ? 0.5 : 0.85,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const surfaceGeo = new THREE.PlaneGeometry(PITCH_HALF_X * 2, PITCH_HALF_Z * 2);
  surfaceGeo.rotateX(-Math.PI / 2);
  const surfaceMesh = new THREE.Mesh(surfaceGeo, surfaceMat);
  surfaceMesh.position.y = 0.004;
  surfaceMesh.receiveShadow = true;
  group.add(surfaceMesh);
  disposables.push(grassBump, apronTex, pitchMat, pitchMesh.geometry, surfaceTex, surfaceMat, surfaceGeo);

  // 3D Raised Pitch Lines
  const lineMat = new THREE.MeshStandardMaterial({
    color: '#f8fafc',
    roughness: 0.65,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const addLine = (w: number, d: number, x: number, z: number) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.03, d), lineMat);
    m.position.set(x, 0.015, z);
    m.receiveShadow = true;
    group.add(m);
  };
  addLine(PITCH_HALF_X * 2, 0.14, 0, -PITCH_HALF_Z);
  addLine(PITCH_HALF_X * 2, 0.14, 0, PITCH_HALF_Z);
  addLine(0.14, PITCH_HALF_Z * 2, -PITCH_HALF_X, 0);
  addLine(0.14, PITCH_HALF_Z * 2, PITCH_HALF_X, 0);
  addLine(0.14, PITCH_HALF_Z * 2, 0, 0);

  // Enlarged Penalty boxes around enlarged goals
  addLine(3.2, 0.12, -PITCH_HALF_X + 1.6, -GOAL_HALF_Z - 1.2);
  addLine(3.2, 0.12, -PITCH_HALF_X + 1.6, GOAL_HALF_Z + 1.2);
  addLine(0.12, (GOAL_HALF_Z + 1.2) * 2, -PITCH_HALF_X + 3.2, 0);
  addLine(3.2, 0.12, PITCH_HALF_X - 1.6, -GOAL_HALF_Z - 1.2);
  addLine(3.2, 0.12, PITCH_HALF_X - 1.6, GOAL_HALF_Z + 1.2);
  addLine(0.12, (GOAL_HALF_Z + 1.2) * 2, PITCH_HALF_X - 3.2, 0);

  const centerCircleGeo = new THREE.RingGeometry(2.0, 2.16, 36);
  centerCircleGeo.rotateX(-Math.PI / 2);
  const centerCircle = new THREE.Mesh(centerCircleGeo, lineMat);
  centerCircle.position.y = 0.02;
  group.add(centerCircle);

  // Unique Perimeter Barrier Architecture per Arena (no GBC text anywhere!)
  const sponsorTex = createSponsorBoardTexture(maxAnisotropy);
  const sponsorMat = new THREE.MeshStandardMaterial({ map: sponsorTex, roughness: 0.45 });
  const brickTex = createBrickWallTexture(maxAnisotropy);
  const brickMat = new THREE.MeshStandardMaterial({ map: brickTex, roughness: 0.88 });
  const redBoardMat = new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.45 });
  const blueBoardMat = new THREE.MeshStandardMaterial({ color: '#2563eb', roughness: 0.45 });
  const barrierExtras: Array<{ dispose: () => void }> = [];

  // Papan sponsor lebih tinggi: gambar/tulisan HANYA di sisi depan (menghadap lapangan), sisi lain hitam
  const boardBlack = new THREE.MeshStandardMaterial({ color: '#080b10', roughness: 0.5, metalness: 0.35 });
  const trimMat = new THREE.MeshStandardMaterial({
    color: arena.borderColor,
    emissive: arena.borderColor,
    emissiveIntensity: 0.55,
    roughness: 0.35,
  });
  barrierExtras.push(boardBlack, trimMat);
  const loadBannerTex = (boardW: number, boardH: number) => {
    // Susun banner sponsor acak berjajar memenuhi papan (tanpa pengaturan, berubah tiap lapangan dibuat)
    const CW = 4096;
    const CH = Math.max(64, Math.round((CW * boardH) / boardW));
    const canvas = document.createElement('canvas');
    canvas.width = CW;
    canvas.height = CH;
    const ctx = canvas.getContext('2d')!;
    const imgs = getSponsorImages();
    const order = imgs.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = Math.min(8, maxAnisotropy);
    const draw = () => {
      ctx.fillStyle = '#080b10';
      ctx.fillRect(0, 0, CW, CH);
      const n = Math.max(1, Math.round(CW / (CH * 4.3)));
      const bw = CW / n;
      const pad = CH * 0.04;
      for (let i = 0; i < n; i++) {
        const im = imgs[order[i % order.length]];
        if (im && im.complete && im.naturalWidth > 0) {
          ctx.drawImage(im, i * bw + pad, pad, bw - pad * 2, CH - pad * 2);
        }
      }
      tex.needsUpdate = true;
    };
    imgs.forEach((im) => {
      if (!im.complete) im.addEventListener('load', draw);
    });
    draw();
    barrierExtras.push(tex);
    return tex;
  };
  const buildBoard = (w: number, h: number, d: number, z: number, frontIndex: 4 | 5) => {
    // Gambar banner hanya di sisi depan; sisi lain hitam polos
    const bannerMat = new THREE.MeshBasicMaterial({ map: loadBannerTex(w, h) });
    barrierExtras.push(bannerMat);
    const mats: THREE.Material[] = [boardBlack, boardBlack, boardBlack, boardBlack, boardBlack, boardBlack];
    mats[frontIndex] = bannerMat;
    const board = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mats);
    board.position.set(0, h / 2 + 0.06, z);
    board.castShadow = true;
    const trim = new THREE.Mesh(new THREE.BoxGeometry(w + 0.04, 0.08, d + 0.08), trimMat);
    trim.position.set(0, h + 0.1, z);
    group.add(board, trim);
    barrierExtras.push(board.geometry, trim.geometry);
  };
  // Utara: sisi depan menghadap +z (ke lapangan); Selatan: sisi depan menghadap -z (ke lapangan)
  buildBoard(PITCH_HALF_X * 2 + 0.6, 1.15, 0.26, -PITCH_HALF_Z - 0.18, 4);
  buildBoard(PITCH_HALF_X * 2 + 0.6, 0.38, 0.22, PITCH_HALF_Z + 0.18, 5);

  // Panel pagar kawat: pinggiran/rangka besi + bagian tengah jaring kawat (anyaman belah ketupat)
  const wireCanvas = document.createElement('canvas');
  wireCanvas.width = wireCanvas.height = 64;
  const wctx = wireCanvas.getContext('2d')!;
  wctx.clearRect(0, 0, 64, 64);
  wctx.strokeStyle = '#d5dde8';
  wctx.lineWidth = 3;
  wctx.beginPath();
  wctx.moveTo(0, 0); wctx.lineTo(64, 64);
  wctx.moveTo(0, 64); wctx.lineTo(64, 0);
  wctx.moveTo(-32, 32); wctx.lineTo(32, 96);
  wctx.moveTo(32, -32); wctx.lineTo(96, 32);
  wctx.moveTo(32, 96); wctx.lineTo(96, 32);
  wctx.moveTo(-32, 32); wctx.lineTo(32, -32);
  wctx.stroke();
  const wireBaseTex = new THREE.CanvasTexture(wireCanvas);
  wireBaseTex.wrapS = THREE.RepeatWrapping;
  wireBaseTex.wrapT = THREE.RepeatWrapping;
  wireBaseTex.colorSpace = THREE.SRGBColorSpace;
  wireBaseTex.anisotropy = Math.min(8, maxAnisotropy);
  const frameSteelMat = new THREE.MeshStandardMaterial({ color: '#475569', metalness: 0.75, roughness: 0.32 });
  barrierExtras.push(wireBaseTex, frameSteelMat);
  /** Panel berdiri pada bidang XY (panjang sepanjang sumbu X lokal). Kembalikan Group dengan origin di dasar tengah. */
  const makeWirePanel = (len: number, height: number, withPosts = true): THREE.Group => {
    const g = new THREE.Group();
    const tex = wireBaseTex.clone();
    tex.needsUpdate = true;
    tex.repeat.set(Math.max(2, Math.round(len / 0.22)), Math.max(2, Math.round(height / 0.22)));
    const meshMat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.1, side: THREE.DoubleSide });
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(len, height), meshMat);
    plane.position.set(0, height / 2, 0);
    g.add(plane);
    const t = 0.09;
    const railGeoH = new THREE.BoxGeometry(len + t, t, t * 1.2);
    const top = new THREE.Mesh(railGeoH, frameSteelMat);
    top.position.set(0, height, 0);
    const bottom = new THREE.Mesh(railGeoH, frameSteelMat);
    bottom.position.set(0, t / 2, 0);
    const mid = new THREE.Mesh(new THREE.BoxGeometry(len, t * 0.6, t * 0.8), frameSteelMat);
    mid.position.set(0, height * 0.5, 0);
    g.add(top, bottom, mid);
    const postCount = withPosts ? Math.max(2, Math.round(len / 2.4) + 1) : 2;
    const postGeo = new THREE.CylinderGeometry(0.07, 0.08, height + 0.12, 8);
    for (let i = 0; i < postCount; i++) {
      const post = new THREE.Mesh(postGeo, frameSteelMat);
      post.position.set(-len / 2 + (i / (postCount - 1)) * len, (height + 0.12) / 2, 0);
      post.castShadow = true;
      g.add(post);
    }
    barrierExtras.push(plane.geometry, meshMat, tex, railGeoH, mid.geometry, postGeo);
    return g;
  };

  const bStyle = arena.barrierStyle;
  if (bStyle === 'futsal_mesh') {
    // Wire-mesh steel futsal cage (kawat besi futsal) along North, West & East
    const steelMat = new THREE.MeshStandardMaterial({ color: '#334155', metalness: 0.72, roughness: 0.35 });
    const meshWireMat = new THREE.MeshBasicMaterial({ color: '#cbd5e1', wireframe: true, transparent: true, opacity: 0.68 });
    barrierExtras.push(steelMat, meshWireMat);


  } else if (bStyle === 'gravity_wall' || bStyle === 'sky_forcefield') {
    // Glowing translucent gravity / energy forcefield wall (tembok gravity)
    const wallColor = bStyle === 'gravity_wall' ? '#22d3ee' : '#818cf8';
    const postColor = bStyle === 'gravity_wall' ? '#0f172a' : '#e2e8f0';
    const pylonMat = new THREE.MeshStandardMaterial({ color: postColor, metalness: 0.55, roughness: 0.3 });
    const plasmaMat = new THREE.MeshBasicMaterial({
      color: wallColor,
      transparent: true,
      opacity: 0.32,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const energyBeamMat = new THREE.MeshBasicMaterial({ color: '#fef08a' });
    barrierExtras.push(pylonMat, plasmaMat, energyBeamMat);

    for (let i = 0; i <= 8; i++) {
      const px = -PITCH_HALF_X + (i / 8) * (PITCH_HALF_X * 2);
      const pylon = new THREE.Mesh(new THREE.BoxGeometry(0.28, 2.0, 0.28), pylonMat);
      pylon.position.set(px, 1.0, -PITCH_HALF_Z - 0.58);
      pylon.castShadow = true;
      const capOrb = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), energyBeamMat);
      capOrb.position.set(px, 2.08, -PITCH_HALF_Z - 0.58);
      group.add(pylon, capOrb);
    }
    const northField = new THREE.Mesh(new THREE.PlaneGeometry(PITCH_HALF_X * 2 + 0.4, 1.5), plasmaMat);
    northField.position.set(0, 1.25, -PITCH_HALF_Z - 0.58);
    const beam = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 0.4, 0.08, 0.08), energyBeamMat);
    beam.position.set(0, 1.95, -PITCH_HALF_Z - 0.58);
    group.add(northField, beam);

    // (Dinding energi transparan di belakang gawang kiri/kanan sudah dihapus)
  } else if (bStyle === 'ice_glass') {
    // White hockey dasher boards + clear cyan-tinted plexiglass barrier
    const dasherMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.35 });
    const glassMat = new THREE.MeshStandardMaterial({
      color: '#bae6fd',
      transparent: true,
      opacity: 0.36,
      roughness: 0.1,
      metalness: 0.2,
    });
    const capBlueMat = new THREE.MeshStandardMaterial({ color: '#0284c7', roughness: 0.4 });
    barrierExtras.push(dasherMat, glassMat, capBlueMat);

    const northBoard = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 1.4, 0.78, 0.28), dasherMat);
    northBoard.position.set(0, 0.39, -PITCH_HALF_Z - 0.62);
    const northGlass = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 1.4, 1.15, 0.08), glassMat);
    northGlass.position.set(0, 1.35, -PITCH_HALF_Z - 0.62);
    const northCap = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 1.4, 0.09, 0.32), capBlueMat);
    northCap.position.set(0, 0.8, -PITCH_HALF_Z - 0.62);
    group.add(northBoard, northGlass, northCap);
  } else if (bStyle === 'volcano_basalt' || bStyle === 'temple_stone' || bStyle === 'sandstone_wall') {
    // Sculpted jagged volcanic basalt rocks / mossy temple blocks / desert battlements
    const wallHex = bStyle === 'volcano_basalt' ? '#292524' : bStyle === 'sandstone_wall' ? '#d97706' : '#4d7c0f';
    const trimHex = bStyle === 'volcano_basalt' ? '#ea580c' : bStyle === 'sandstone_wall' ? '#fef08a' : '#84cc16';
    const rockMat = new THREE.MeshStandardMaterial({ color: wallHex, roughness: 0.9 });
    const veinMat = new THREE.MeshBasicMaterial({ color: trimHex });
    barrierExtras.push(rockMat, veinMat);

    for (let i = 0; i < 13; i++) {
      const bx = -PITCH_HALF_X + (i / 12) * (PITCH_HALF_X * 2);
      const h = 0.85 + (i % 3) * 0.38;
      const slab = new THREE.Mesh(
        bStyle === 'volcano_basalt' ? new THREE.DodecahedronGeometry(0.75, 0) : new THREE.BoxGeometry(1.55, h, 0.52),
        rockMat
      );
      slab.position.set(bx, h * 0.5, -PITCH_HALF_Z - 0.72);
      slab.castShadow = true;
      group.add(slab);
      if (bStyle === 'volcano_basalt' && i % 2 === 0) {
        const lavaCrack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.6), veinMat);
        lavaCrack.position.set(bx, 0.45, -PITCH_HALF_Z - 0.72);
        group.add(lavaCrack);
      }
    }
  } else if (bStyle === 'bamboo_rope' || bStyle === 'shrine_torii') {
    // Bamboo & braided rope fence OR vermilion crimson torii shrine gate rail
    const postHex = bStyle === 'bamboo_rope' ? '#84cc16' : '#dc2626';
    const railHex = bStyle === 'bamboo_rope' ? '#fde047' : '#0f172a';
    const pMat = new THREE.MeshStandardMaterial({ color: postHex, roughness: 0.6 });
    const rMat = new THREE.MeshStandardMaterial({ color: railHex, roughness: 0.55 });
    barrierExtras.push(pMat, rMat);

    for (let i = 0; i <= 10; i++) {
      const px = -PITCH_HALF_X + (i / 10) * (PITCH_HALF_X * 2);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 1.55, 8), pMat);
      pole.position.set(px, 0.775, -PITCH_HALF_Z - 0.6);
      pole.castShadow = true;
      group.add(pole);
    }
    const bar1 = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 0.8, 0.12, 0.12), rMat);
    bar1.position.set(0, 1.42, -PITCH_HALF_Z - 0.6);
    const bar2 = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 0.8, 0.1, 0.1), rMat);
    bar2.position.set(0, 0.85, -PITCH_HALF_Z - 0.6);
    group.add(bar1, bar2);
  } else if (bStyle === 'candy_fence') {
    // Colorful Candy Kingdom Lollipop Posts + Pastel Striped Rails
    const candyCols = ['#f472b6', '#38bdf8', '#fde047', '#34d399', '#c084fc'];
    const whiteMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.35 });
    const lolliMats = candyCols.map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.25 }));
    barrierExtras.push(whiteMat, ...lolliMats);

    for (let i = 0; i <= 10; i++) {
      const px = -PITCH_HALF_X + (i / 10) * (PITCH_HALF_X * 2);
      const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.55, 8), whiteMat);
      stick.position.set(px, 0.78, -PITCH_HALF_Z - 0.56);
      const candy = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.14, 16), lolliMats[i % lolliMats.length]);
      candy.rotation.x = Math.PI / 2;
      candy.position.set(px, 1.7, -PITCH_HALF_Z - 0.56);
      group.add(stick, candy);
    }
    const pastelRail = new THREE.Mesh(
      new THREE.BoxGeometry(PITCH_HALF_X * 2 + 0.8, 0.18, 0.16),
      lolliMats[0]
    );
    pastelRail.position.set(0, 0.82, -PITCH_HALF_Z - 0.56);
    group.add(pastelRail);
  } else if (bStyle === 'royal_gold') {
    // Grand Championship Royal Gold Pillars & Velvet Banners
    const goldMat = new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.65, roughness: 0.22 });
    const velvetMat = new THREE.MeshStandardMaterial({ color: '#581c87', roughness: 0.55 });
    barrierExtras.push(goldMat, velvetMat);

    for (let i = 0; i <= 8; i++) {
      const px = -PITCH_HALF_X + (i / 8) * (PITCH_HALF_X * 2);
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 1.9, 10), goldMat);
      col.position.set(px, 0.95, -PITCH_HALF_Z - 0.64);
      const crownOrb = new THREE.Mesh(new THREE.OctahedronGeometry(0.24, 0), goldMat);
      crownOrb.position.set(px, 2.08, -PITCH_HALF_Z - 0.64);
      group.add(col, crownOrb);
    }
    const royalWall = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 0.8, 0.95, 0.24), velvetMat);
    royalWall.position.set(0, 0.48, -PITCH_HALF_Z - 0.64);
    const goldRail = new THREE.Mesh(new THREE.BoxGeometry(PITCH_HALF_X * 2 + 0.8, 0.14, 0.28), goldMat);
    goldRail.position.set(0, 0.98, -PITCH_HALF_Z - 0.64);
    group.add(royalWall, goldRail);
  } else {
    // Classic Sports Arena Fence + Brick Perimeter Wall
    const blockColors = ['#ef4444', '#facc15', '#2563eb', '#22c55e', '#f97316', '#ec4899'];
    const blockGeo = new THREE.BoxGeometry(0.64, 0.64, 0.42);
    const blockMats = blockColors.map((col) => new THREE.MeshStandardMaterial({ color: col, roughness: 0.4 }));
    barrierExtras.push(blockGeo, ...blockMats);
    for (let i = 0; i < 11; i++) {
      const bx = -PITCH_HALF_X + (i / 10) * (PITCH_HALF_X * 2);
      const nb = new THREE.Mesh(blockGeo, blockMats[i % blockMats.length]);
      nb.position.set(bx, 0.32, -PITCH_HALF_Z - 0.54);
      nb.castShadow = true;
      group.add(nb);
    }
    // (Tembok bata merah di sisi atas/kiri/kanan sudah dihapus)
    // Pagar atas berbingkai besi + jaring kawat, tinggi total sama dengan pagar kiri-kanan (3.5 m)
  }

  // Corner pillar accents
  const cornerMat = new THREE.MeshStandardMaterial({ color: arena.borderColor, roughness: 0.45 });
  barrierExtras.push(cornerMat);
  for (const cx of [-PITCH_HALF_X - 0.45, PITCH_HALF_X + 0.45]) {
    for (const cz of [-PITCH_HALF_Z - 0.35, PITCH_HALF_Z + 0.35]) {
      const cornerB = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.52, 0.58), cornerMat);
      cornerB.position.set(cx, 0.26, cz);
      cornerB.castShadow = true;
      group.add(cornerB);
    }
  }

  // Side Wings + Tall Futsal Barrier Nets behind Left & Right Endlines
  const sideWingLen = PITCH_HALF_Z - GOAL_HALF_Z;
  const futsalNetMat = new THREE.MeshBasicMaterial({
    color: '#f8fafc',
    wireframe: true,
    transparent: true,
    opacity: 0.42,
  });
  const makeWing = (x: number, z: number, mat: THREE.Material) => {
    // Papan sayap kiri/kanan ditinggikan (1.1 m) + pagar kawat berbingkai besi di atasnya
    const w = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.1, sideWingLen), mat);
    w.position.set(x, 0.55, z);
    w.castShadow = true;
    // (Pagar kawat transparan di atas sayap dihapus agar belakang gawang bersih)
    group.add(w);
  };
  makeWing(-PITCH_HALF_X - 0.18, -(GOAL_HALF_Z + sideWingLen / 2), redBoardMat);
  makeWing(-PITCH_HALF_X - 0.18, GOAL_HALF_Z + sideWingLen / 2, redBoardMat);
  makeWing(PITCH_HALF_X + 0.18, -(GOAL_HALF_Z + sideWingLen / 2), blueBoardMat);
  makeWing(PITCH_HALF_X + 0.18, GOAL_HALF_Z + sideWingLen / 2, blueBoardMat);

  // Dekorasi sekeliling lapangan seperti desain referensi: lampu oranye di atas papan, rangka besi bersegmen,
  // dan dinding gawang merah/biru berlambang bola (berlaku untuk semua lapangan)
  {
    const glowMat = new THREE.MeshStandardMaterial({
      color: '#fbbf24',
      emissive: '#f59e0b',
      emissiveIntensity: 1.1,
      roughness: 0.3,
    });
    const steelMat = new THREE.MeshStandardMaterial({ color: '#4b5563', roughness: 0.4, metalness: 0.55 });
    const hazardMat = new THREE.MeshStandardMaterial({ color: '#facc15', roughness: 0.5 });
    barrierExtras.push(glowMat, steelMat, hazardMat);
    const spanX = PITCH_HALF_X * 2 + 0.6;
    // Lampu oranye + segmen besi di sepanjang papan utara (atas) dan selatan (bawah)
    for (const side of [-1, 1] as const) {
      const z = side * (PITCH_HALF_Z + 0.18);
      const h = side < 0 ? 1.15 : 0.38;
      for (let i = 0; i < 9; i++) {
        const x = -spanX / 2 + (i + 0.5) * (spanX / 9);
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(spanX / 9 - 0.5, 0.07, 0.1), glowMat);
        lamp.position.set(x, h + 0.2, z);
        group.add(lamp);
        barrierExtras.push(lamp.geometry);
      }
      for (let i = 0; i <= 9 && side > 0; i++) {
        const x = -spanX / 2 + i * (spanX / 9);
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, h + 0.16, 0.3), steelMat);
        post.position.set(x, (h + 0.16) / 2, z);
        group.add(post);
        barrierExtras.push(post.geometry);
      }
      if (side > 0) {
        // strip kuning di dasar papan depan (sisi kamera)
        for (let i = 0; i < 4; i++) {
          const x = -spanX / 2 + (i + 0.5) * (spanX / 4);
          const strip = new THREE.Mesh(new THREE.BoxGeometry(spanX / 4 - 1.2, 0.1, 0.24), hazardMat);
          strip.position.set(x, 0.12, z);
          group.add(strip);
          barrierExtras.push(strip.geometry);
        }
      }
    }
    // Lambang bola dengan karangan daun di dinding gawang kiri (merah) & kanan (biru)
    const emblemCanvas = document.createElement('canvas');
    emblemCanvas.width = emblemCanvas.height = 128;
    const ec = emblemCanvas.getContext('2d')!;
    ec.strokeStyle = 'rgba(255,255,255,0.9)';
    ec.lineWidth = 5;
    ec.beginPath();
    ec.arc(64, 64, 46, Math.PI * 0.75, Math.PI * 2.25);
    ec.stroke();
    ec.fillStyle = '#ffffff';
    ec.beginPath();
    ec.arc(64, 64, 30, 0, Math.PI * 2);
    ec.fill();
    ec.fillStyle = '#111827';
    ec.beginPath();
    for (let k = 0; k < 5; k++) {
      const a = (k / 5) * Math.PI * 2 - Math.PI / 2;
      const px = 64 + Math.cos(a) * 13;
      const py = 64 + Math.sin(a) * 13;
      if (k === 0) ec.moveTo(px, py);
      else ec.lineTo(px, py);
    }
    ec.closePath();
    ec.fill();
    const emblemTex = new THREE.CanvasTexture(emblemCanvas);
    emblemTex.colorSpace = THREE.SRGBColorSpace;
    const emblemMat = new THREE.MeshBasicMaterial({ map: emblemTex, transparent: true });
    barrierExtras.push(emblemTex, emblemMat);
    for (const sx of [-1, 1] as const) {
      for (const sz of [-1, 1] as const) {
        const emblem = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.8), emblemMat);
        emblem.position.set(sx * (PITCH_HALF_X + 0.035), 0.58, sz * (GOAL_HALF_Z + sideWingLen / 2));
        emblem.rotation.y = sx < 0 ? Math.PI / 2 : -Math.PI / 2;
        group.add(emblem);
        barrierExtras.push(emblem.geometry);
      }
    }
  }

  // Foreground Camera-Side Props (South sideline: low height <= 0.85m so pitch remains 100% clear!)
  const benchWoodMat = new THREE.MeshStandardMaterial({ color: '#d97706', roughness: 0.65 });
  const benchSteelMat = new THREE.MeshStandardMaterial({ color: '#64748b', roughness: 0.4, metalness: 0.35 });
  const coolerRedMat = new THREE.MeshStandardMaterial({ color: '#ef4444', roughness: 0.35 });
  const coolerBlueMat = new THREE.MeshStandardMaterial({ color: '#3b82f6', roughness: 0.35 });
  const lanternMat = new THREE.MeshStandardMaterial({ color: '#fef08a', emissive: '#facc15', emissiveIntensity: 0.7 });

  // Left & Right Team Dugout Benches + Cooler Jugs + Spare Ball Racks
  for (const side of [-1, 1] as const) {
    const bx = side * 6.4;
    const bz = PITCH_HALF_Z + 1.85;
    const seatPlank = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.12, 0.55), benchWoodMat);
    seatPlank.position.set(bx, 0.42, bz);
    seatPlank.castShadow = true;
    const backRest = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.34, 0.1), side < 0 ? redBoardMat : blueBoardMat);
    backRest.position.set(bx, 0.66, bz + 0.24);
    group.add(seatPlank, backRest);

    for (const lx of [bx - 1.1, bx + 1.1]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.42, 0.48), benchSteelMat);
      leg.position.set(lx, 0.21, bz);
      group.add(leg);
    }

    // Team Water Cooler beside bench
    const cooler = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.48, 10), side < 0 ? coolerRedMat : coolerBlueMat);
    cooler.position.set(bx - side * 1.85, 0.24, bz - 0.1);
    const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.08, 10), benchSteelMat);
    lid.position.set(bx - side * 1.85, 0.5, bz - 0.1);
    group.add(cooler, lid);

    // Camera Tripod + Broadcast Lens facing pitch from foreground corner
    const tx = side * 2.9;
    const tz = PITCH_HALF_Z + 1.55;
    const tripod = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.22, 0.68, 6), benchSteelMat);
    tripod.position.set(tx, 0.34, tz);
    const camBox = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.22, 0.42), benchSteelMat);
    camBox.position.set(tx, 0.76, tz);
    camBox.lookAt(0, 0.4, 0);
    group.add(tripod, camBox);

    // Foreground Left/Right Corner Stadium Lanterns
    const lanBase = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.38, 0.45), brickMat);
    lanBase.position.set(side * (PITCH_HALF_X - 0.4), 0.19, PITCH_HALF_Z + 1.75);
    const lanGlow = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.32, 0.32), lanternMat);
    lanGlow.position.set(side * (PITCH_HALF_X - 0.4), 0.54, PITCH_HALF_Z + 1.75);
    group.add(lanBase, lanGlow);
  }

  // Stadium Corner Flags
  const poleMat = new THREE.MeshStandardMaterial({ color: '#e2e8f0', roughness: 0.35 });
  const flagMat = new THREE.MeshStandardMaterial({ color: '#facc15', roughness: 0.5, side: THREE.DoubleSide });
  [
    [-PITCH_HALF_X, -PITCH_HALF_Z],
    [PITCH_HALF_X, -PITCH_HALF_Z],
    [-PITCH_HALF_X, PITCH_HALF_Z],
    [PITCH_HALF_X, PITCH_HALF_Z],
  ].forEach(([cx, cz]) => {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.9, 6), poleMat);
    pole.position.set(cx, 0.45, cz);
    const pennant = new THREE.Mesh(new THREE.PlaneGeometry(0.35, 0.22), flagMat);
    pennant.position.set(cx + (cx < 0 ? 0.18 : -0.18), 0.78, cz);
    group.add(pole, pennant);
  });

  // Stadium Tiered Bleachers (North + West + East) & 2D Animal-Human Spectator Seats (4 sprite types!)
  const standMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.8 });
  const seatMat = new THREE.MeshStandardMaterial({ color: arena.borderColor, roughness: 0.6 });
  const seatBuckets: SpectatorSeat[][] = [[], [], [], []];

  // Tribun stadion MELINGKAR menyatu: tiga tingkat bangku mengelilingi lapangan tanpa putus,
  // tinggi menurun mulus di sisi selatan (kamera) + dinding belakang tribun.
  const ringA = (ro: number) => PITCH_HALF_X + GOAL_DEPTH + 2.4 + ro;
  const ringB = (ro: number) => PITCH_HALF_Z + 0.4 + ro;
  interface RingPoint {
    x: number;
    z: number;
    tx: number;
    tz: number;
    nx: number;
    nz: number;
    south: number; // 0 = tinggi penuh, 1 = rendah (sisi kamera)
  }
  const ringSamples = (ro: number, spacing: number): RingPoint[] => {
    const A = ringA(ro);
    const B = ringB(ro);
    const M = 960;
    const xs: number[] = [];
    const zs: number[] = [];
    const cum: number[] = [0];
    for (let i = 0; i <= M; i++) {
      const th = (i / M) * Math.PI * 2;
      const c = Math.cos(th);
      const sn = Math.sin(th);
      xs.push(A * Math.sign(c) * Math.pow(Math.abs(c), 0.5));
      zs.push(B * Math.sign(sn) * Math.pow(Math.abs(sn), 0.5));
      if (i > 0) cum.push(cum[i - 1] + Math.hypot(xs[i] - xs[i - 1], zs[i] - zs[i - 1]));
    }
    const total = cum[M];
    const count = Math.max(8, Math.floor(total / spacing));
    const out: RingPoint[] = [];
    let idx = 0;
    for (let k = 0; k < count; k++) {
      const target = (k / count) * total;
      while (idx < M - 1 && cum[idx + 1] < target) idx++;
      const f = cum[idx + 1] > cum[idx] ? (target - cum[idx]) / (cum[idx + 1] - cum[idx]) : 0;
      const x = xs[idx] + (xs[idx + 1] - xs[idx]) * f;
      const z = zs[idx] + (zs[idx + 1] - zs[idx]) * f;
      let tx = xs[idx + 1] - xs[idx];
      let tz = zs[idx + 1] - zs[idx];
      const tl = Math.hypot(tx, tz) || 1;
      tx /= tl;
      tz /= tl;
      const zn = z / B;
      const t = Math.max(0, Math.min(1, (zn + 0.15) / 0.55));
      out.push({ x, z, tx, tz, nx: tz, nz: -tx, south: t * t * (3 - 2 * t) });
    }
    return out;
  };
  const tierGeo = new THREE.BoxGeometry(1, 0.7, 1.08);
  const wallGeo = new THREE.BoxGeometry(1, 1, 0.35);
  barrierExtras.push(tierGeo, wallGeo);
  const wallMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.85 });
  barrierExtras.push(wallMat);
  const buildInstanced = (
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    items: Array<{ x: number; y: number; z: number; rotY: number; sx: number; sy: number }>
  ) => {
    const mesh = new THREE.InstancedMesh(geo, mat, items.length);
    items.forEach((it, i) => {
      _specDummy.position.set(it.x, it.y, it.z);
      _specDummy.rotation.set(0, it.rotY, 0);
      _specDummy.scale.set(it.sx, it.sy, 1);
      _specDummy.updateMatrix();
      mesh.setMatrixAt(i, _specDummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    group.add(mesh);
  };
  const SEG = 1.0;
  for (let tier = 0; tier < 3; tier++) {
    const ro = 2.55 + tier * 1.15;
    const pts = ringSamples(ro, SEG);
    const items: Array<{ x: number; y: number; z: number; rotY: number; sx: number; sy: number }> = [];
    pts.forEach((pt, i) => {
      if (tier === 2 && pt.south > 0.55) return; // tingkat atas tidak menghalangi kamera selatan
      const y = (0.7 + tier * 0.75) * (1 - pt.south) + (0.42 + tier * 0.56) * pt.south;
      items.push({ x: pt.x, y, z: pt.z, rotY: Math.atan2(-pt.tz, pt.tx), sx: SEG * 1.08, sy: 1 });
      seatBuckets[(i + tier) % 4].push({
        x: pt.x,
        y: y + 0.78,
        z: pt.z,
        rotY: Math.atan2(-pt.nx, -pt.nz),
        phase: i * 0.7 + tier * 1.3,
      });
    });
    buildInstanced(tierGeo, tier % 2 === 0 ? standMat : seatMat, items);
  }
  {
    const wallPts = ringSamples(2.55 + 3 * 1.15 + 0.5, SEG);
    buildInstanced(
      wallGeo,
      wallMat,
      wallPts.map((pt) => ({
        x: pt.x,
        y: (2.6 * (1 - pt.south) + 0.6 * pt.south) / 2,
        z: pt.z,
        rotY: Math.atan2(-pt.tz, pt.tx),
        sx: SEG * 1.08,
        sy: 2.6 * (1 - pt.south) + 0.6 * pt.south,
      }))
    );
  }

  // 2D Animal-Human Sprite Spectators (4 distinct animal-human fan InstancedMesh billboards)
  const specPlaneGeo = new THREE.PlaneGeometry(0.95, 1.05);
  const spectatorLayers: SpectatorLayer[] = seatBuckets.map((seats, idx) => {
    const tex = createSpectatorTexture(idx);
    const mat = new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      alphaTest: 0.35,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.InstancedMesh(specPlaneGeo, mat, seats.length);
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    seats.forEach((seat, sIdx) => {
      _specDummy.position.set(seat.x, seat.y, seat.z);
      _specDummy.rotation.set(0, seat.rotY, 0);
      _specDummy.scale.setScalar(1);
      _specDummy.updateMatrix();
      mesh.setMatrixAt(sIdx, _specDummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
    disposables.push(tex, mat);
    return { mesh, seats };
  });

  // Wet Rain Puddles on Pitch (smoothly visible during rainy matches!)
  const puddleTex = createPuddleTexture();
  const puddleMat = new THREE.MeshStandardMaterial({
    map: puddleTex,
    transparent: true,
    opacity: 0,
    roughness: 0.08,
    metalness: 0.18,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -3,
  });
  const puddleSpots = [
    { x: -4.8, z: -2.6, radius: 1.5 },
    { x: 4.5, z: 2.9, radius: 1.65 },
    { x: -1.4, z: 3.4, radius: 1.35 },
    { x: 2.2, z: -3.2, radius: 1.45 },
    { x: 0.3, z: 0.2, radius: 1.2 },
  ];
  const puddleGeo = new THREE.CircleGeometry(1, 22);
  puddleGeo.rotateX(-Math.PI / 2);
  const puddleMeshes = puddleSpots.map((spot) => {
    const pm = new THREE.Mesh(puddleGeo, puddleMat);
    pm.position.set(spot.x, 0.025, spot.z);
    pm.scale.set(spot.radius, 1, spot.radius * 0.82);
    pm.visible = false;
    group.add(pm);
    return pm;
  });

  // Arena-themed 3D Stadium Floodlights / Landmarks around outer rim
  const trunkMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.85 });
  const canopyColor =
    arena.id === 'sakura_shrine'
      ? '#f9a8d4'
      : arena.id === 'glacier_rink'
        ? '#bae6fd'
        : arena.id === 'volcano_caldera'
          ? '#44403c'
          : arena.id === 'neon_dome'
            ? '#38bdf8'
            : arena.id === 'candy_kingdom'
              ? '#f472b6'
              : arena.id === 'grand_championship'
                ? '#facc15'
                : '#16a34a';
  const canopyMat = new THREE.MeshStandardMaterial({ color: canopyColor, roughness: 0.7 });

  const landmarkPts = ringSamples(2.55 + 3 * 1.15 + 2.2, 8.0);
  for (let i = 0; i < landmarkPts.length; i++) {
    const px = landmarkPts[i].x;
    const pz = landmarkPts[i].z;
    if (pz > 2 && Math.abs(px) < 12) continue; // Keep south camera view unobstructed!

    const prop = new THREE.Group();
    prop.position.set(px, 0, pz);
    if (arena.id === 'neon_dome' || arena.id === 'gbc_pixel_bowl' || arena.id === 'grand_championship' || i % 3 === 0) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 5.4, 8), standMat);
      pole.position.y = 2.7;
      const head = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.65, 0.45), canopyMat);
      head.position.y = 5.6;
      head.lookAt(0, 1, 0);
      prop.add(pole, head);
    } else {
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.34, 2.0, 8), trunkMat);
      trunk.position.y = 1.0;
      const crown = new THREE.Mesh(new THREE.DodecahedronGeometry(1.15, 0), canopyMat);
      crown.position.y = 2.6;
      prop.add(trunk, crown);
    }
    group.add(prop);
  }

  // Enlarged 3D Jelly Goalposts & Nets
  const postMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.25, metalness: 0.15 });
  // Jaring gawang berupa tali detail; warna gawang dipilih (putih / belang / bergaris), warna tali aksen acak
  const ropeColor = NET_ROPE_COLORS[Math.floor(Math.random() * NET_ROPE_COLORS.length)];
  const netTex = createNetTexture(netStyle, ropeColor, maxAnisotropy);
  const netMat = new THREE.MeshBasicMaterial({
    map: netTex,
    transparent: true,
    alphaTest: 0.08,
    side: THREE.DoubleSide,
  });

  const leftGoal = buildGoal3D(false, netMat, postMat);
  const rightGoal = buildGoal3D(true, netMat, postMat);
  group.add(leftGoal.leftPost, leftGoal.rightPost, leftGoal.crossbar, leftGoal.netGroup);
  group.add(rightGoal.leftPost, rightGoal.rightPost, rightGoal.crossbar, rightGoal.netGroup);

  disposables.push(
    lineMat,
    sponsorTex,
    sponsorMat,
    brickTex,
    brickMat,
    ...barrierExtras,
    redBoardMat,
    blueBoardMat,
    futsalNetMat,
    benchWoodMat,
    benchSteelMat,
    coolerRedMat,
    coolerBlueMat,
    lanternMat,
    poleMat,
    flagMat,
    standMat,
    seatMat,
    specPlaneGeo,
    puddleTex,
    puddleMat,
    puddleGeo,
    trunkMat,
    canopyMat,
    postMat,
    netMat,
    netTex,
    ...leftGoal.nets.map((n) => n.mesh.geometry),
    ...rightGoal.nets.map((n) => n.mesh.geometry)
  );

  const staff = buildStaff({
    pitchHalfX: PITCH_HALF_X,
    pitchHalfZ: PITCH_HALF_Z,
    goalDepth: GOAL_DEPTH,
    benchXs: [-6.4, 6.4],
    benchZ: PITCH_HALF_Z + 1.85,
    seats: seatBuckets.flat().map((st) => ({ x: st.x, y: st.y, z: st.z })),
  });
  group.add(staff.group);
  disposables.push(...staff.disposables);

  const scenery = buildScenery(arena.id);
  group.add(scenery.group);
  disposables.push(...scenery.disposables);

  return {
    group,
    leftGoal,
    rightGoal,
    spectatorLayers,
    pitchMat,
    puddleMat,
    puddleMeshes,
    disposables,
    tickScenery: scenery.update,
    tickStaff: staff.update,
  };
}

export function syncArenaSpectators(arenaRig: ArenaRig, elapsedTime: number, excitement: number) {
  const amp = 0.08 + excitement * 0.24;
  const speed = 4.5 + excitement * 8.0;
  for (const layer of arenaRig.spectatorLayers) {
    const { mesh, seats } = layer;
    for (let i = 0; i < seats.length; i++) {
      const s = seats[i];
      const hop = Math.abs(Math.sin(elapsedTime * speed + s.phase)) * amp;
      _specDummy.position.set(s.x, s.y + hop, s.z);
      _specDummy.rotation.set(0, s.rotY, Math.sin(elapsedTime * 3.5 + s.phase) * 0.09);
      _specDummy.scale.setScalar(1);
      _specDummy.updateMatrix();
      mesh.setMatrixAt(i, _specDummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  }
}

export function syncArenaWeather(arenaRig: ArenaRig, weather: WeatherState, elapsedTime: number) {
  const w = Math.max(0, Math.min(1, weather.wetness));
  if (weather.isSnowing) {
    // Frost-dusted turf sheen during snowy weather
    arenaRig.pitchMat.roughness = 0.42;
    arenaRig.pitchMat.color.setRGB(0.88, 0.95, 1.06);
  } else {
    // Wet grass gets darker and more reflective/glossy
    arenaRig.pitchMat.roughness = 0.85 - w * 0.62;
    const shade = 1 - w * 0.22;
    arenaRig.pitchMat.color.setRGB(shade * (1 - w * 0.05), shade, shade * (1 + w * 0.04));
  }

  const showPuddles = w > 0.03;
  arenaRig.puddleMat.opacity = w * 0.82;
  for (let i = 0; i < arenaRig.puddleMeshes.length; i++) {
    const pm = arenaRig.puddleMeshes[i];
    pm.visible = showPuddles;
    if (showPuddles && weather.isRaining) {
      const ripple = 1 + Math.sin(elapsedTime * 7 + i * 1.9) * 0.04;
      const base = weather.puddles[i]?.radius ?? 1.4;
      pm.scale.set(base * ripple, 1, base * 0.82 * ripple);
    }
  }
}

export function syncJellyGoalPosts(arenaRig: ArenaRig, gp: GoalPostsState) {
  const applyGoal = (rig: GoalRig, state: GoalPostsState['leftGoal'], xBase: number) => {
    rig.leftPost.position.set(xBase + state.leftPost.dispX, 0, -GOAL_HALF_Z + state.leftPost.dispZ);
    rig.leftPost.rotation.z = -state.leftPost.dispX * 0.25;
    rig.leftPost.rotation.x = state.leftPost.dispZ * 0.25;

    rig.rightPost.position.set(xBase + state.rightPost.dispX, 0, GOAL_HALF_Z + state.rightPost.dispZ);
    rig.rightPost.rotation.z = -state.rightPost.dispX * 0.25;
    rig.rightPost.rotation.x = state.rightPost.dispZ * 0.25;

    rig.crossbar.position.set(xBase + state.crossbar.dispX, GOAL_HEIGHT + state.crossbar.dispY, state.crossbar.dispZ);
    rig.crossbar.scale.set(1 + Math.abs(state.crossbar.dispY) * 0.2, 1, 1);
  };

  applyGoal(arenaRig.leftGoal, gp.leftGoal, -PITCH_HALF_X);
  applyGoal(arenaRig.rightGoal, gp.rightGoal, PITCH_HALF_X);
}

export function syncArenaGoalNets(
  arenaRig: ArenaRig,
  ball: Pick<BallSim, 'x' | 'y' | 'z' | 'vx' | 'vy' | 'vz' | 'radius' | 'scaleMultiplier'>,
  dt: number,
  elapsedTime: number
) {
  const dtStep = Math.min(0.04, Math.max(0.004, dt));
  const bR = Math.max(0.32, (ball.radius || 0.44) * (ball.scaleMultiplier || 1));
  const hitRange = bR + 0.95;
  const ballNearGoal = Math.abs(ball.x) > PITCH_HALF_X - 0.75;
  const ballSpeed = Math.hypot(ball.vx, ball.vy, ball.vz);

  const updateCloth = (cloth: GoalNetCloth) => {
    const posAttr = cloth.mesh.geometry.attributes.position as THREE.BufferAttribute;
    const { restLocal, restWorld, disp, vel, pinWeight, cols, rows } = cloth;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const idx = r * cols + c;
        const pw = pinWeight[idx];
        if (pw <= 0.001) {
          disp[idx] = 0;
          vel[idx] = 0;
          continue;
        }

        const wx = restWorld[idx * 3] + cloth.outX * disp[idx];
        const wy = restWorld[idx * 3 + 1] + cloth.outY * disp[idx];
        const wz = restWorld[idx * 3 + 2] + cloth.outZ * disp[idx];

        if (ballNearGoal) {
          const dx = wx - ball.x;
          const dy = wy - ball.y;
          const dz = wz - ball.z;
          const dist = Math.hypot(dx, dy, dz);
          if (dist < hitRange) {
            const push = (hitRange - dist) / hitRange;
            const outDotVel = ball.vx * cloth.outX + ball.vy * cloth.outY + ball.vz * cloth.outZ;
            const targetPocket = push * (bR * 2.4 + Math.min(0.8, Math.max(0, outDotVel) * 0.05)) * pw;
            if (disp[idx] < targetPocket) {
              disp[idx] += (targetPocket - disp[idx]) * 0.65;
            }
            vel[idx] += (Math.max(2.4, Math.max(0, outDotVel) * 0.85 + ballSpeed * 0.3)) * push * pw * dtStep * 14;
          }
        }

        const leftD = disp[r * cols + Math.max(0, c - 1)];
        const rightD = disp[r * cols + Math.min(cols - 1, c + 1)];
        const upD = disp[Math.max(0, r - 1) * cols + c];
        const downD = disp[Math.min(rows - 1, r + 1) * cols + c];
        const avgNeighbor = 0.25 * (leftD + rightD + upD + downD);

        // Coupled spring-damper cloth wave propagation
        const accel = -13 * disp[idx] + 78 * (avgNeighbor - disp[idx]) - 2.4 * vel[idx];
        vel[idx] += accel * dtStep;
        disp[idx] += vel[idx] * dtStep;
        if (disp[idx] > 1.75) {
          disp[idx] = 1.75;
          vel[idx] *= 0.4;
        } else if (disp[idx] < -0.22) {
          disp[idx] = -0.22;
          vel[idx] *= 0.4;
        }

        const breeze = Math.sin(elapsedTime * 2.3 + wx * 1.6 + wz * 1.85 + wy * 1.2) * 0.022 * pw;
        const totalOut = disp[idx] + breeze;
        const sagY = cloth.outY === 0 ? -Math.abs(totalOut) * 0.14 * pw : 0;

        posAttr.setXYZ(
          idx,
          restLocal[idx * 3] + cloth.localOutX * totalOut,
          restLocal[idx * 3 + 1] + cloth.localOutY * totalOut + sagY,
          restLocal[idx * 3 + 2] + cloth.localOutZ * totalOut
        );
      }
    }
    posAttr.needsUpdate = true;
  };

  for (const cloth of arenaRig.leftGoal.nets) updateCloth(cloth);
  for (const cloth of arenaRig.rightGoal.nets) updateCloth(cloth);
}

// 7 Distinct Sculpted 3D Center Pickup Item Models matching their names!
export function buildItemPickupModels(): Record<CenterItemType, THREE.Group> {
  const models = {} as Record<CenterItemType, THREE.Group>;

  // 1. Blazing Fire Ball: magma orb + sculpted flame tongues
  {
    const g = new THREE.Group();
    const fireTex = createFireAuraTexture();
    const core = new THREE.Mesh(
      new THREE.SphereGeometry(0.36, 16, 12),
      new THREE.MeshStandardMaterial({ map: fireTex, emissive: '#f97316', emissiveIntensity: 0.75, roughness: 0.3 })
    );
    g.add(core);
    const flameMat = new THREE.MeshBasicMaterial({ color: '#fde047', transparent: true, opacity: 0.85 });
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      const tongue = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.45, 7), flameMat);
      tongue.position.set(Math.cos(a) * 0.22, 0.28, Math.sin(a) * 0.22);
      tongue.rotation.z = -Math.cos(a) * 0.45;
      tongue.rotation.x = Math.sin(a) * 0.45;
      g.add(tongue);
    }
    models.fire_power = g;
  }

  // 2. Giant Ball: Big golden sphere + orbiting size-up ring
  {
    const g = new THREE.Group();
    const sphere = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.46, 1),
      new THREE.MeshStandardMaterial({ color: '#facc15', emissive: '#ca8a04', emissiveIntensity: 0.35, roughness: 0.28, metalness: 0.2 })
    );
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(0.62, 0.055, 8, 24),
      new THREE.MeshBasicMaterial({ color: '#fef08a' })
    );
    ring.rotation.x = Math.PI * 0.35;
    g.add(sphere, ring);
    models.giant_ball = g;
  }

  // 3. Meteor Shower: Craggy dark asteroid + glowing lava + mini satellites
  {
    const g = new THREE.Group();
    const rock = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.38, 0),
      new THREE.MeshStandardMaterial({ color: '#44403c', emissive: '#ef4444', emissiveIntensity: 0.45, roughness: 0.85 })
    );
    const mini1 = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.14, 0),
      new THREE.MeshStandardMaterial({ color: '#7c2d12', emissive: '#f97316', emissiveIntensity: 0.6 })
    );
    mini1.position.set(0.46, 0.22, 0);
    const mini2 = mini1.clone();
    mini2.position.set(-0.42, -0.18, 0.22);
    g.add(rock, mini1, mini2);
    models.meteor_shower = g;
  }

  // 4. Updraft Wind: Swirling sky-blue tornado cone + floating wind rings
  {
    const g = new THREE.Group();
    const windMat = new THREE.MeshBasicMaterial({ color: '#38bdf8', transparent: true, opacity: 0.72, side: THREE.DoubleSide });
    const funnel = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.72, 12, 1, true), windMat);
    funnel.rotation.x = Math.PI;
    const r1 = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.04, 6, 20), windMat);
    r1.rotation.x = Math.PI / 2;
    r1.position.y = 0.22;
    const r2 = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.035, 6, 20), windMat);
    r2.rotation.x = Math.PI / 2;
    r2.position.y = -0.14;
    g.add(funnel, r1, r2);
    models.updraft_wind = g;
  }

  // 5. Heavy Ghost: Sculpted translucent spectral ghost
  {
    models.heavy_ghost = buildSpectralGhostMesh(1.15);
  }

  // 6. Bomb Ball: Black spherical bomb + metal cap + lit fuse + glowing ember spark
  {
    const g = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.SphereGeometry(0.36, 16, 12),
      new THREE.MeshStandardMaterial({ color: '#111827', roughness: 0.35, metalness: 0.3 })
    );
    const cap = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.13, 0.1, 10),
      new THREE.MeshStandardMaterial({ color: '#94a3b8', metalness: 0.6, roughness: 0.3 })
    );
    cap.position.y = 0.35;
    const fuse = new THREE.Mesh(
      new THREE.CylinderGeometry(0.025, 0.025, 0.26, 6),
      new THREE.MeshStandardMaterial({ color: '#d6b384', roughness: 0.8 })
    );
    fuse.position.set(0.06, 0.49, 0);
    fuse.rotation.z = -0.35;
    const spark = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.09, 0),
      new THREE.MeshBasicMaterial({ color: '#fb7185' })
    );
    spark.position.set(0.12, 0.61, 0);
    g.add(body, cap, fuse, spark);
    models.bomb_ball = g;
  }

  // 7. Rubber Ball 10x: Glossy magenta elastic core + bouncy rubber rings
  {
    const g = new THREE.Group();
    const core = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 16, 12),
      new THREE.MeshStandardMaterial({
        color: '#ec4899',
        emissive: '#db2777',
        emissiveIntensity: 0.35,
        transparent: true,
        opacity: 0.82,
        roughness: 0.15,
      })
    );
    const band = new THREE.Mesh(
      new THREE.TorusGeometry(0.46, 0.055, 8, 22),
      new THREE.MeshBasicMaterial({ color: '#f9a8d4' })
    );
    band.rotation.x = Math.PI * 0.42;
    g.add(core, band);
    models.jelly_10x = g;
  }

  return models;
}

export interface BallRig {
  group: THREE.Group;
  shapePivot: THREE.Group;
  mesh: THREE.Mesh; // Sphere / Ellipsoid mesh
  diceMesh: THREE.Mesh; // 6-sided Cube Dice
  eggMesh: THREE.Mesh; // Lathe Ostrich Egg
  honeyDrips: THREE.Group; // Golden sticky honey glaze droplets
  bombTimerRing: THREE.Mesh; // Countdown pulse halo for 15s Timer Bomb
  crystalCore: THREE.Mesh;
  puckGroup: THREE.Group;
  puckMesh: THREE.Mesh;
  discGroup: THREE.Group;
  discMesh: THREE.Mesh;
  activeShape: BallShapeKind;
  activeBallId: string;
  isCrystal: boolean;
  fireGroup: THREE.Group;
  /** sprite api realistis (additive) yang mengikuti arah gerak bola */
  fireSprites: THREE.Sprite[];
  /** ekor bayangan putih saat bola melesat kencang */
  speedTrail: THREE.Sprite[];
  /** Jejak posisi bola sebelumnya (dunia) untuk ekor bayangan */
  trailHist: Array<{ x: number; y: number; z: number; t: number }>;
  bombGroup: THREE.Group;
  rubberShell: THREE.Mesh;
  windGroup: THREE.Group;
  shadowMesh: THREE.Mesh;
}

let _softTex: THREE.Texture | null = null;
let _flameTex: THREE.Texture | null = null;

/** Tekstur bulat lembut (putih) untuk ekor bayangan bola cepat */
function getSoftSpriteTexture(): THREE.Texture {
  if (_softTex) return _softTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.45, 'rgba(255,255,255,0.55)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  _softTex = new THREE.CanvasTexture(c);
  return _softTex;
}

/** Tekstur lidah api: inti terang, tepi oranye-merah yang memudar, bentuk meruncing ke atas */
function getFlameSpriteTexture(): THREE.Texture {
  if (_flameTex) return _flameTex;
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 96;
  const g = c.getContext('2d')!;
  g.translate(32, 60);
  g.scale(1, 1.45);
  const grad = g.createRadialGradient(0, 4, 1, 0, 0, 30);
  grad.addColorStop(0, 'rgba(255,255,235,1)');
  grad.addColorStop(0.25, 'rgba(255,214,110,0.95)');
  grad.addColorStop(0.55, 'rgba(255,120,30,0.6)');
  grad.addColorStop(1, 'rgba(200,30,0,0)');
  g.fillStyle = grad;
  g.beginPath();
  g.ellipse(0, 0, 26, 30, 0, 0, Math.PI * 2);
  g.fill();
  _flameTex = new THREE.CanvasTexture(c);
  return _flameTex;
}

export function buildBall3D(ball: BallSim, maxAnisotropy: number, shadowTex: THREE.Texture): BallRig {
  const group = new THREE.Group();
  const shapePivot = new THREE.Group();
  group.add(shapePivot);
  void ball;

  const tex = createBallTexture('soccer', maxAnisotropy);
  const sharedMat = new THREE.MeshStandardMaterial({
    map: tex,
    roughness: 0.35,
    metalness: 0.08,
  });

  // 1. Sphere / Ellipsoid 3D Mesh
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 28, 20), sharedMat);
  mesh.castShadow = true;
  shapePivot.add(mesh);

  // 1b. 6-Faced Cube Dice Mesh (1-6 pips on each face!)
  const diceTextures = createDiceFaceTextures(maxAnisotropy);
  const diceMats = diceTextures.map(
    (dTex) =>
      new THREE.MeshStandardMaterial({
        map: dTex,
        roughness: 0.28,
        metalness: 0.06,
      })
  );
  const diceMesh = new THREE.Mesh(new THREE.BoxGeometry(1.76, 1.76, 1.76), diceMats);
  diceMesh.castShadow = true;
  diceMesh.visible = false;
  shapePivot.add(diceMesh);

  // 1c. Sculpted Lathe Ostrich Egg Mesh (subtle tapered point + rounded base)
  const eggPoints: THREE.Vector2[] = [];
  for (let i = 0; i <= 18; i++) {
    const t = i / 18;
    const phi = t * Math.PI;
    const rEgg = Math.sin(phi) * (1 - 0.14 * Math.cos(phi));
    const yEgg = -Math.cos(phi);
    eggPoints.push(new THREE.Vector2(Math.max(0.001, rEgg), yEgg));
  }
  const eggGeo = new THREE.LatheGeometry(eggPoints, 26);
  eggGeo.rotateX(Math.PI / 2);
  const eggMesh = new THREE.Mesh(eggGeo, sharedMat);
  eggMesh.castShadow = true;
  eggMesh.visible = false;
  shapePivot.add(eggMesh);

  // 1d. Golden Sticky Honey Drips overlay for honey_ball
  const honeyDrips = new THREE.Group();
  const honeyCoatMat = new THREE.MeshStandardMaterial({
    color: '#fbbf24',
    emissive: '#d97706',
    emissiveIntensity: 0.18,
    transparent: true,
    opacity: 0.45,
    roughness: 0.08,
  });
  const honeyCoat = new THREE.Mesh(new THREE.SphereGeometry(1.06, 18, 12), honeyCoatMat);
  honeyDrips.add(honeyCoat);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const drop = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), honeyCoatMat);
    drop.position.set(Math.cos(a) * 0.94, Math.sin(i * 1.7) * 0.35, Math.sin(a) * 0.94);
    drop.scale.set(0.9, 1.35, 0.9);
    honeyDrips.add(drop);
  }
  honeyDrips.visible = false;
  shapePivot.add(honeyDrips);

  // Inner faceted crystal gem core (visible for Crystal Ball)
  const crystalCore = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.62, 0),
    new THREE.MeshStandardMaterial({
      color: '#c084fc',
      emissive: '#38bdf8',
      emissiveIntensity: 0.45,
      roughness: 0.12,
      metalness: 0.35,
    })
  );
  crystalCore.visible = false;
  shapePivot.add(crystalCore);

  // 2. Sculpted 3D Hockey Puck Cylinder Mesh
  const puckGroup = new THREE.Group();
  const puckMesh = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 1, 28, 1), sharedMat);
  puckMesh.castShadow = true;
  const puckRimMat = new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.45 });
  const puckTopRim = new THREE.Mesh(new THREE.TorusGeometry(0.95, 0.06, 6, 28), puckRimMat);
  puckTopRim.rotation.x = Math.PI / 2;
  puckTopRim.position.y = 0.48;
  const puckBotRim = puckTopRim.clone();
  puckBotRim.position.y = -0.48;
  puckGroup.add(puckMesh, puckTopRim, puckBotRim);
  puckGroup.visible = false;
  shapePivot.add(puckGroup);

  // 3. Sculpted 3D Flat Aerodynamic Flying Disc Mesh
  const discGroup = new THREE.Group();
  const discMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.96, 1.0, 0.55, 32, 1), sharedMat);
  discMesh.castShadow = true;
  const discDome = new THREE.Mesh(new THREE.CylinderGeometry(0.68, 0.88, 0.45, 28, 1), sharedMat);
  discDome.position.y = 0.25;
  const discLip = new THREE.Mesh(
    new THREE.TorusGeometry(0.95, 0.14, 8, 32),
    new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.3 })
  );
  discLip.rotation.x = Math.PI / 2;
  discLip.position.y = -0.1;
  discGroup.add(discMesh, discDome, discLip);
  discGroup.visible = false;
  shapePivot.add(discGroup);

  // Realistic Sculpted 3D Fire Flame Aura
  const fireGroup = new THREE.Group();
  const flameInnerMat = new THREE.MeshBasicMaterial({
    color: '#fef08a',
    transparent: true,
    opacity: 0.5,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const flameOuterMat = new THREE.MeshBasicMaterial({
    color: '#f97316',
    transparent: true,
    opacity: 0.38,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const glowAura = new THREE.Mesh(
    new THREE.SphereGeometry(1.16, 14, 10),
    new THREE.MeshBasicMaterial({ color: '#ea580c', transparent: true, opacity: 0.16, depthWrite: false, blending: THREE.AdditiveBlending })
  );
  fireGroup.add(glowAura);

  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const outerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.35, 7), flameOuterMat);
    outerFlame.position.set(Math.cos(a) * 0.75, 0.55, Math.sin(a) * 0.75);
    outerFlame.rotation.z = -Math.cos(a) * 0.35;
    outerFlame.rotation.x = Math.sin(a) * 0.35;
    fireGroup.add(outerFlame);

    const innerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.95, 6), flameInnerMat);
    innerFlame.position.set(Math.cos(a + 0.3) * 0.52, 0.45, Math.sin(a + 0.3) * 0.52);
    innerFlame.rotation.z = -Math.cos(a + 0.3) * 0.25;
    innerFlame.rotation.x = Math.sin(a + 0.3) * 0.25;
    fireGroup.add(innerFlame);
  }
  fireGroup.visible = false;
  group.add(fireGroup);

  // Lidah api sprite (additive) + ekor api mengikuti arah gerak
  const fireSprites: THREE.Sprite[] = [];
  for (let i = 0; i < 9; i++) {
    const sp = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: getFlameSpriteTexture(),
        color: '#ffd27a',
        transparent: true,
        opacity: 0.8,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      })
    );
    sp.visible = false;
    group.add(sp);
    fireSprites.push(sp);
  }

  // Ekor bayangan putih untuk bola cepat
  const speedTrail: THREE.Sprite[] = [];
  for (let i = 0; i < 16; i++) {
    const sp = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: getSoftSpriteTexture(),
        color: '#ffffff',
        transparent: true,
        opacity: 0,
        depthWrite: false,
      })
    );
    sp.visible = false;
    group.add(sp);
    speedTrail.push(sp);
  }

  // Sculpted Bomb Collar & Lit Spark Fuse + Countdown Halo Ring
  const bombGroup = new THREE.Group();
  const cap = new THREE.Mesh(
    new THREE.CylinderGeometry(0.24, 0.28, 0.22, 10),
    new THREE.MeshStandardMaterial({ color: '#64748b', metalness: 0.6, roughness: 0.3 })
  );
  cap.position.y = 1.02;
  const fuse = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.06, 0.55, 6),
    new THREE.MeshStandardMaterial({ color: '#d6b384', roughness: 0.8 })
  );
  fuse.position.set(0.14, 1.32, 0);
  fuse.rotation.z = -0.35;
  const spark = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.2, 0),
    new THREE.MeshBasicMaterial({ color: '#fbbf24' })
  );
  spark.position.set(0.26, 1.56, 0);
  bombGroup.add(cap, fuse, spark);
  bombGroup.visible = false;
  group.add(bombGroup);

  const bombTimerRing = new THREE.Mesh(
    new THREE.TorusGeometry(1.18, 0.07, 6, 26),
    new THREE.MeshBasicMaterial({ color: '#ef4444', transparent: true, opacity: 0.72, depthWrite: false })
  );
  bombTimerRing.rotation.x = Math.PI / 2;
  bombTimerRing.visible = false;
  group.add(bombTimerRing);

  // Glossy Translucent Rubber Ball 10x Outer Coat
  const rubberShell = new THREE.Mesh(
    new THREE.SphereGeometry(1.1, 20, 14),
    new THREE.MeshStandardMaterial({
      color: '#ec4899',
      emissive: '#db2777',
      emissiveIntensity: 0.25,
      transparent: true,
      opacity: 0.38,
      roughness: 0.12,
      depthWrite: false,
    })
  );
  rubberShell.visible = false;
  group.add(rubberShell);

  // Swirling Translucent Updraft Wind Rings
  const windGroup = new THREE.Group();
  const wMat = new THREE.MeshBasicMaterial({ color: '#38bdf8', transparent: true, opacity: 0.65, depthWrite: false });
  for (let i = 0; i < 3; i++) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.18 + i * 0.18, 0.06, 6, 22), wMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -0.6 + i * 0.55;
    windGroup.add(ring);
  }
  windGroup.visible = false;
  group.add(windGroup);

  const shadowGeo = new THREE.CircleGeometry(1, 18);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    opacity: 0.58,
    depthWrite: false,
  });
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.position.y = 0.02;

  return {
    group,
    shapePivot,
    mesh,
    diceMesh,
    eggMesh,
    honeyDrips,
    bombTimerRing,
    crystalCore,
    puckGroup,
    puckMesh,
    discGroup,
    discMesh,
    activeShape: 'sphere',
    activeBallId: 'soccer',
    isCrystal: false,
    fireGroup,
    fireSprites,
    speedTrail,
    trailHist: [],
    bombGroup,
    rubberShell,
    windGroup,
    shadowMesh,
  };
}

export function updateBallTextureAndShape(rig: BallRig, ballType: BallSim & { typeId?: string }, maxAnisotropy: number, typeId: string) {
  const spec = BALLS.find((b) => b.id === typeId) ?? BALLS[0];
  const mat = rig.mesh.material as THREE.MeshStandardMaterial;
  if (mat.map) mat.map.dispose();
  mat.map = createBallTexture(spec.id, maxAnisotropy);

  rig.activeShape = spec.shape;
  rig.activeBallId = spec.id;
  rig.isCrystal = spec.id === 'crystal';

  rig.mesh.visible = spec.shape === 'sphere' || (spec.shape === 'ellipsoid' && spec.id !== 'ostrich_egg');
  rig.eggMesh.visible = spec.shape === 'egg' || spec.id === 'ostrich_egg';
  rig.diceMesh.visible = spec.shape === 'cube' || spec.id === 'dice';
  rig.honeyDrips.visible = spec.id === 'honey_ball';
  rig.crystalCore.visible = rig.isCrystal;
  rig.puckGroup.visible = spec.shape === 'cylinder';
  rig.discGroup.visible = spec.shape === 'disc';

  if (spec.id === 'metal') {
    mat.roughness = 0.18;
    mat.metalness = 0.88;
    mat.transparent = false;
    mat.opacity = 1;
  } else if (spec.id === 'crystal') {
    mat.roughness = 0.08;
    mat.metalness = 0.15;
    mat.transparent = true;
    mat.opacity = 0.72;
  } else if (spec.id === 'rubber' || spec.id === 'honey_ball') {
    mat.roughness = 0.16;
    mat.metalness = 0.05;
    mat.transparent = false;
    mat.opacity = 1;
  } else if (spec.id === 'pro_gold') {
    mat.roughness = 0.3;
    mat.metalness = 0.28;
    mat.transparent = false;
    mat.opacity = 1;
  } else if (spec.id === 'tennis') {
    mat.roughness = 0.88;
    mat.metalness = 0.02;
    mat.transparent = false;
    mat.opacity = 1;
  } else if (spec.id === 'hockey') {
    mat.roughness = 0.55;
    mat.metalness = 0.06;
    mat.transparent = false;
    mat.opacity = 1;
  } else {
    mat.roughness = 0.36;
    mat.metalness = 0.08;
    mat.transparent = false;
    mat.opacity = 1;
  }
  mat.needsUpdate = true;
  void ballType;
}

export type BallPoseInput = {
  x: number;
  y: number;
  z: number;
  rotX: number;
  rotY: number;
  rotZ: number;
  scaleMultiplier: number;
  isClashedFire: boolean;
  isBombArmed: boolean;
  isJelly10x: boolean;
  hitFlashTimer: number;
  bombCountdown?: number;
  radius?: number;
  shape?: BallShapeKind;
  prolateScaleZ?: number;
  cylinderHeight?: number;
  vx?: number;
  vy?: number;
  vz?: number;
};

export function syncBallRig(
  rig: BallRig,
  ball: BallPoseInput,
  isFireItem: boolean,
  isWindItem: boolean,
  elapsedTime: number
) {
  rig.group.position.set(ball.x, ball.y, ball.z);

  const spec = BALLS.find((b) => b.id === rig.activeBallId) ?? BALLS[0];
  const baseRadius = ball.radius ?? spec.radius;
  const shape = ball.shape ?? rig.activeShape;
  const prolateZ = ball.prolateScaleZ ?? spec.prolateScaleZ ?? 1;
  const cylH = ball.cylinderHeight ?? spec.cylinderHeight ?? baseRadius * 2;

  const r = baseRadius * ball.scaleMultiplier;
  const h = cylH * ball.scaleMultiplier;

  if (shape === 'cylinder') {
    rig.shapePivot.scale.set(r, h, r);
  } else if (shape === 'disc') {
    rig.shapePivot.scale.set(r, h, r);
  } else if (shape === 'ellipsoid' || shape === 'egg') {
    rig.shapePivot.scale.set(r * 0.88, r * 0.88, r * prolateZ);
  } else {
    rig.shapePivot.scale.setScalar(r);
  }
  rig.shapePivot.rotation.set(ball.rotX, ball.rotY, ball.rotZ);

  if (rig.isCrystal) {
    rig.crystalCore.rotation.y = elapsedTime * 1.4;
    rig.crystalCore.rotation.x = elapsedTime * 0.8;
  }

  const mat = rig.mesh.material as THREE.MeshStandardMaterial;
  const isTimerBomb = rig.activeBallId === 'timer_bomb';
  const bombUrgent = isTimerBomb && (ball.bombCountdown ?? 15) <= 4.0;
  if (ball.hitFlashTimer > 0) {
    mat.emissive.set('#ffffff');
    mat.emissiveIntensity = 0.65;
  } else if (ball.isClashedFire || isFireItem) {
    mat.emissive.set('#ea580c');
    mat.emissiveIntensity = 0.45;
  } else if (ball.isBombArmed || bombUrgent) {
    const rate = isTimerBomb ? 24 : 18;
    mat.emissive.set(Math.sin(elapsedTime * rate) > 0 ? '#dc2626' : '#09090b');
    mat.emissiveIntensity = 0.58;
  } else if (ball.isJelly10x) {
    mat.emissive.set('#ec4899');
    mat.emissiveIntensity = 0.25;
  } else {
    mat.emissive.set('#000000');
    mat.emissiveIntensity = 0;
  }

  // Realistic Fire Flame Aura (ignited by clash, item, or Salto!)
  const showFire = ball.isClashedFire || isFireItem;
  rig.fireGroup.visible = showFire;
  if (showFire) {
    const pulse = 1 + Math.sin(elapsedTime * 20) * 0.08;
    rig.fireGroup.scale.set(r * pulse, r * (1.05 + Math.cos(elapsedTime * 24) * 0.12), r * pulse);
    rig.fireGroup.rotation.y += 0.14;
  }

  // Arah gerak bola (untuk ekor api & ekor bayangan putih)
  const bvx = ball.vx ?? 0;
  const bvy = ball.vy ?? 0;
  const bvz = ball.vz ?? 0;
  const speed3 = Math.hypot(bvx, bvy, bvz);
  const hasDir = speed3 > 0.5;
  const backX = hasDir ? -bvx / speed3 : 0;
  const backY = hasDir ? -bvy / speed3 : 0;
  const backZ = hasDir ? -bvz / speed3 : 0;

  // Api realistis: lidah api naik + ekor api memanjang ke belakang saat bola melaju
  const fl = rig.fireSprites;
  const moveK = Math.min(1, speed3 / 12);
  for (let i = 0; i < fl.length; i++) {
    const sp = fl[i];
    sp.visible = showFire;
    if (!showFire) continue;
    const t = i / (fl.length - 1);
    const flick = Math.sin(elapsedTime * 22 + i * 1.9) * 0.5 + Math.sin(elapsedTime * 37 + i * 3.1) * 0.5;
    let dx = backX * moveK;
    let dy = backY * moveK + 0.85;
    let dz = backZ * moveK;
    const dl = Math.hypot(dx, dy, dz) || 1;
    dx /= dl;
    dy /= dl;
    dz /= dl;
    const dist = r * (0.35 + t * (1.2 + moveK * 2.6));
    sp.position.set(
      dx * dist + flick * r * 0.12 * (1 - t),
      dy * dist + r * 0.1,
      dz * dist + Math.cos(elapsedTime * 19 + i) * r * 0.1 * (1 - t)
    );
    const size = r * (2.1 - t * 1.35) * (0.92 + flick * 0.1);
    sp.scale.set(size, size * 1.25, 1);
    const m = sp.material as THREE.SpriteMaterial;
    m.color.set(t < 0.25 ? '#fff4b8' : t < 0.6 ? '#ffa94d' : '#e5481a');
    m.opacity = Math.max(0, 0.85 * (1 - t * 0.85));
  }

  // Ekor bayangan: jejak posisi bola sebelumnya (mengikuti lintasan nyata), tipis dan memudar
  const hist = rig.trailHist;
  const lastH = hist[hist.length - 1];
  if (lastH && (elapsedTime < lastH.t - 0.001 || Math.hypot(ball.x - lastH.x, ball.y - lastH.y, ball.z - lastH.z) > 4)) {
    hist.length = 0; // lompatan waktu / teleport (kickoff, replay): jejak direset
  }
  if (hist.length === 0 || elapsedTime - hist[hist.length - 1].t > 0.004) {
    hist.push({ x: ball.x, y: ball.y, z: ball.z, t: elapsedTime });
  }
  while (hist.length > 2 && hist[0].t < elapsedTime - 0.7) hist.shift();

  const trail = rig.speedTrail;
  const trailK = Math.max(0, Math.min(1, (speed3 - 9) / 8));
  for (let i = 0; i < trail.length; i++) {
    const sp = trail[i];
    const t = (i + 1) / trail.length;
    const targetT = elapsedTime - (i + 1) * 0.032;
    let ok = false;
    if (trailK > 0.02 && hist.length >= 2 && hist[0].t <= targetT) {
      for (let k = hist.length - 1; k > 0; k--) {
        const h1 = hist[k];
        const h0 = hist[k - 1];
        if (h0.t <= targetT && targetT <= h1.t) {
          const f = h1.t > h0.t ? (targetT - h0.t) / (h1.t - h0.t) : 0;
          sp.position.set(
            h0.x + (h1.x - h0.x) * f - ball.x,
            h0.y + (h1.y - h0.y) * f - ball.y,
            h0.z + (h1.z - h0.z) * f - ball.z
          );
          ok = true;
          break;
        }
      }
    }
    sp.visible = ok;
    if (!ok) continue;
    const size = r * (1.25 - t * 0.85);
    sp.scale.set(size, size, 1);
    const tm = sp.material as THREE.SpriteMaterial;
    tm.blending = THREE.AdditiveBlending;
    tm.color.set(t < 0.4 ? '#ffffff' : '#cfe8ff');
    tm.opacity = 0.34 * trailK * (1 - t) * (1 - t * 0.4);
  }

  // Armed Bomb Fuse & 15s Timer Bomb Ring
  const showFuse = ball.isBombArmed || isTimerBomb;
  rig.bombGroup.visible = showFuse;
  if (showFuse) {
    rig.bombGroup.scale.setScalar(r);
    const spark = rig.bombGroup.children[2];
    if (spark) {
      spark.scale.setScalar(0.85 + Math.sin(elapsedTime * (bombUrgent ? 36 : 24)) * 0.45);
      spark.rotation.y += 0.25;
    }
  }
  rig.bombTimerRing.visible = isTimerBomb;
  if (isTimerBomb) {
    const leftRatio = Math.max(0, Math.min(1, (ball.bombCountdown ?? 15) / 15));
    const pulseRate = bombUrgent ? 22 : 6;
    const pScale = r * (1.02 + Math.sin(elapsedTime * pulseRate) * (bombUrgent ? 0.12 : 0.04));
    rig.bombTimerRing.scale.setScalar(pScale);
    (rig.bombTimerRing.material as THREE.MeshBasicMaterial).color.set(leftRatio < 0.28 ? '#ef4444' : '#facc15');
  }

  // Glossy Translucent Rubber Coat
  rig.rubberShell.visible = ball.isJelly10x;
  if (ball.isJelly10x) {
    const wobble = 1 + Math.sin(elapsedTime * 14) * 0.05;
    rig.rubberShell.scale.set(r * wobble, r / wobble, r * wobble);
  }

  // Swirling Wind Vortex
  rig.windGroup.visible = isWindItem;
  if (isWindItem) {
    rig.windGroup.scale.setScalar(r);
    rig.windGroup.rotation.y += 0.18;
  }

  const groundHalfY = shape === 'cylinder' || shape === 'disc' ? h * 0.5 : r;
  const heightAboveGround = Math.max(0, ball.y - groundHalfY);
  const shadowScale = r * (1.15 + heightAboveGround * 0.12);
  const shadowOpacity = Math.max(0.14, 0.62 - heightAboveGround * 0.1);
  rig.shadowMesh.position.set(ball.x, 0.02, ball.z);
  rig.shadowMesh.scale.setScalar(shadowScale);
  (rig.shadowMesh.material as THREE.MeshBasicMaterial).opacity = shadowOpacity;
}

// 4 Distinct Random Drop Arena Props (Wooden Chair, Wooden Box, Oil Drum, Water Gallon)
export interface PropRig {
  group: THREE.Group;
  bodyGroup: THREE.Group;
  durabilityPips: THREE.Mesh[];
  materials: THREE.MeshStandardMaterial[];
  textures: THREE.Texture[];
  shadowMesh: THREE.Mesh;
}

export function buildPropMesh(kind: PropKind, shadowTex: THREE.Texture): PropRig {
  const group = new THREE.Group();
  const bodyGroup = new THREE.Group();
  group.add(bodyGroup);
  const materials: THREE.MeshStandardMaterial[] = [];
  const textures: THREE.Texture[] = [];

  const regMat = (color: string, roughness = 0.55, metalness = 0.1, transparent = false, opacity = 1, map?: THREE.Texture) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness, metalness, transparent, opacity, map });
    materials.push(m);
    return m;
  };

  if (kind === 'wooden_chair') {
    const wood = regMat('#b45309', 0.72, 0.04);
    const darkWood = regMat('#78350f', 0.78, 0.04);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.08, 0.58), wood);
    seat.position.y = 0.06;
    seat.castShadow = true;
    const backL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.62, 0.08), darkWood);
    backL.position.set(-0.26, 0.37, -0.24);
    const backR = backL.clone();
    backR.position.x = 0.26;
    const backTop = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.16, 0.08), wood);
    backTop.position.set(0, 0.6, -0.24);
    backTop.castShadow = true;
    bodyGroup.add(seat, backL, backR, backTop);
    for (const lx of [-0.24, 0.24]) {
      for (const lz of [-0.22, 0.22]) {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.38, 0.08), darkWood);
        leg.position.set(lx, -0.15, lz);
        leg.castShadow = true;
        bodyGroup.add(leg);
      }
    }
  } else if (kind === 'wooden_box') {
    const crateTex = createWoodenCrateTexture(4);
    textures.push(crateTex);
    const crateMat = regMat('#ffffff', 0.78, 0.04, false, 1, crateTex);
    const trimMat = regMat('#5c3317', 0.82, 0.04);
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.74, 0.74), crateMat);
    box.castShadow = true;
    box.receiveShadow = true;
    bodyGroup.add(box);
    // Subtle dark timber corner bumpers around top and bottom edges without covering the X-brace face
    for (const cy of [-0.35, 0.35]) {
      for (const cx of [-0.36, 0.36]) {
        for (const cz of [-0.36, 0.36]) {
          const cap = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.08), trimMat);
          cap.position.set(cx, cy, cz);
          bodyGroup.add(cap);
        }
      }
    }
  } else if (kind === 'oil_drum') {
    const drumMat = regMat('#dc2626', 0.35, 0.45);
    const bandMat = regMat('#facc15', 0.4, 0.3);
    const rimMat = regMat('#1e293b', 0.3, 0.65);
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.86, 16), drumMat);
    cyl.castShadow = true;
    const stripe = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.24, 16), bandMat);
    const topRing = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.035, 6, 18), rimMat);
    topRing.rotation.x = Math.PI / 2;
    topRing.position.y = 0.42;
    const botRing = topRing.clone();
    botRing.position.y = -0.42;
    bodyGroup.add(cyl, stripe, topRing, botRing);
  } else if (kind === 'bomb') {
    const bombMat = regMat('#111827', 0.3, 0.55);
    const capMat = regMat('#64748b', 0.35, 0.7);
    const fuseMat = regMat('#a16207', 0.8, 0.05);
    const sparkMat = new THREE.MeshBasicMaterial({ color: '#fb923c' });
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.36, 18, 14), bombMat);
    ball.castShadow = true;
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.12, 10), capMat);
    cap.position.y = 0.38;
    const fuse = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.22, 6), fuseMat);
    fuse.position.set(0.04, 0.54, 0);
    fuse.rotation.z = -0.4;
    const spark = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 6), sparkMat);
    spark.position.set(0.12, 0.65, 0);
    const skull = new THREE.Mesh(new THREE.CircleGeometry(0.12, 12), new THREE.MeshBasicMaterial({ color: '#f8fafc' }));
    skull.position.set(0, 0.02, 0.355);
    bodyGroup.add(ball, cap, fuse, spark, skull);
    textures.push(sparkMat as unknown as THREE.Texture);
  } else if (kind === 'potion') {
    const glass = regMat('#a855f7', 0.12, 0.05, true, 0.82);
    const liquid = new THREE.MeshBasicMaterial({ color: '#e879f9', transparent: true, opacity: 0.9 });
    const corkMat = regMat('#92400e', 0.8, 0.02);
    const flask = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12), glass);
    flask.position.y = -0.05;
    flask.castShadow = true;
    const inner = new THREE.Mesh(new THREE.SphereGeometry(0.24, 14, 10), liquid);
    inner.position.y = -0.09;
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 0.28, 12), glass);
    neck.position.y = 0.3;
    const cork = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.085, 0.1, 10), corkMat);
    cork.position.y = 0.48;
    bodyGroup.add(flask, inner, neck, cork);
    textures.push(liquid as unknown as THREE.Texture);
  } else if (kind === 'ostrich_egg') {
    const eggMat = regMat('#fef3c7', 0.55, 0.02);
    const spotMat = regMat('#b45309', 0.7, 0.02);
    const egg = new THREE.Mesh(new THREE.SphereGeometry(0.38, 18, 14), eggMat);
    egg.scale.set(1, 1.28, 1);
    egg.castShadow = true;
    bodyGroup.add(egg);
    const spots: Array<[number, number, number, number]> = [
      [0.26, 0.12, 0.22, 0.07],
      [-0.22, 0.28, 0.24, 0.06],
      [0.05, -0.18, 0.34, 0.08],
      [-0.3, -0.05, 0.2, 0.06],
      [0.18, 0.4, 0.14, 0.05],
    ];
    for (const [sx, sy, sz, sr] of spots) {
      const sp = new THREE.Mesh(new THREE.SphereGeometry(sr, 8, 6), spotMat);
      sp.position.set(sx, sy, sz);
      sp.scale.set(1, 1, 0.5);
      bodyGroup.add(sp);
    }
  } else {
    // 'water_gallon': Translucent azure 5-gallon water jug
    const jugMat = regMat('#38bdf8', 0.16, 0.08, true, 0.78);
    const capMat = regMat('#f8fafc', 0.3, 0.1);
    const jugBody = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.64, 14), jugMat);
    jugBody.castShadow = true;
    const shoulder = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.32, 0.16, 14), jugMat);
    shoulder.position.y = 0.4;
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.1, 12), capMat);
    cap.position.y = 0.52;
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.28, 0.1), jugMat);
    handle.position.set(0.31, 0.12, 0);
    bodyGroup.add(jugBody, shoulder, cap, handle);
  }

  // 3 Floating Durability Pips (shows 3 uses remaining clearly)
  const durabilityPips: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) {
    const pip = new THREE.Mesh(
      new THREE.BoxGeometry(0.11, 0.11, 0.11),
      new THREE.MeshBasicMaterial({ color: '#4ade80' })
    );
    pip.position.set((i - 1) * 0.17, 0.74, 0);
    pip.userData.hidden = kind === 'bomb' || kind === 'potion' || kind === 'ostrich_egg';
    group.add(pip);
    durabilityPips.push(pip);
  }

  const shadowGeo = new THREE.CircleGeometry(0.48, 14);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMesh = new THREE.Mesh(
    shadowGeo,
    new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, opacity: 0.48, depthWrite: false })
  );
  shadowMesh.position.y = 0.02;
  group.add(shadowMesh);

  return { group, bodyGroup, durabilityPips, materials, textures, shadowMesh };
}

export function syncPropRig(
  rig: PropRig,
  prop: Pick<ArenaPropSim, 'x' | 'y' | 'z' | 'rotY' | 'usesRemaining' | 'flashTimer' | 'carriedByPlayerId'>,
  elapsedTime: number
) {
  rig.group.position.set(prop.x, prop.y, prop.z);
  rig.bodyGroup.rotation.y = prop.rotY;
  rig.bodyGroup.rotation.z = prop.carriedByPlayerId ? Math.sin(elapsedTime * 8) * 0.05 : 0;

  for (let i = 0; i < rig.durabilityPips.length; i++) {
    const pip = rig.durabilityPips[i];
    pip.visible = !pip.userData.hidden && i < prop.usesRemaining;
    if (pip.visible) {
      const m = pip.material as THREE.MeshBasicMaterial;
      m.color.set(prop.usesRemaining === 3 ? '#4ade80' : prop.usesRemaining === 2 ? '#facc15' : '#ef4444');
    }
  }

  for (const m of rig.materials) {
    if (prop.flashTimer > 0) {
      m.emissive.set('#ffffff');
      m.emissiveIntensity = 0.7;
    } else {
      m.emissive.set('#000000');
      m.emissiveIntensity = 0;
    }
  }

  const h = Math.max(0, prop.y - 0.36);
  rig.shadowMesh.position.y = -prop.y + 0.02;
  const s = Math.max(0.55, 1 - h * 0.08);
  rig.shadowMesh.scale.setScalar(s);
}



export interface BullRig {
  group: THREE.Group;
  body: THREE.Group;
  legs: THREE.Mesh[];
  materials: THREE.Material[];
  geometries: THREE.BufferGeometry[];
}

/** Banteng (menghadap +Z lokal): badan coklat, tanduk putih, mata merah, cincin hidung */
export function buildBullMesh(): BullRig {
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);
  const materials: THREE.Material[] = [];
  const geometries: THREE.BufferGeometry[] = [];
  const mk = (color: string, rough = 0.7, metal = 0.05) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    materials.push(m);
    return m;
  };
  const g = <T extends THREE.BufferGeometry>(geo: T): T => {
    geometries.push(geo);
    return geo;
  };
  const hide = mk('#7c3f1d');
  const dark = mk('#4a2410');
  const cream = mk('#f5f5f4', 0.4);
  const red = new THREE.MeshBasicMaterial({ color: '#ef4444' });
  materials.push(red);
  const metal = mk('#fbbf24', 0.3, 0.7);

  const torso = new THREE.Mesh(g(new THREE.BoxGeometry(1.0, 1.0, 1.7)), hide);
  torso.position.set(0, 1.05, 0);
  torso.castShadow = true;
  const hump = new THREE.Mesh(g(new THREE.SphereGeometry(0.55, 12, 8)), dark);
  hump.position.set(0, 1.62, 0.5);
  hump.scale.set(1, 0.8, 1);
  const head = new THREE.Mesh(g(new THREE.BoxGeometry(0.72, 0.7, 0.72)), hide);
  head.position.set(0, 1.05, 1.15);
  head.castShadow = true;
  const snout = new THREE.Mesh(g(new THREE.BoxGeometry(0.5, 0.4, 0.34)), dark);
  snout.position.set(0, 0.88, 1.58);
  const ring = new THREE.Mesh(g(new THREE.TorusGeometry(0.09, 0.02, 6, 12)), metal);
  ring.position.set(0, 0.8, 1.76);
  ring.rotation.x = Math.PI / 2;
  const hornGeo = g(new THREE.ConeGeometry(0.11, 0.6, 8));
  const hornL = new THREE.Mesh(hornGeo, cream);
  hornL.position.set(-0.46, 1.42, 1.1);
  hornL.rotation.z = Math.PI / 2 + 0.5;
  const hornR = new THREE.Mesh(hornGeo, cream);
  hornR.position.set(0.46, 1.42, 1.1);
  hornR.rotation.z = -(Math.PI / 2 + 0.5);
  const eyeGeo = g(new THREE.SphereGeometry(0.07, 8, 6));
  const eyeL = new THREE.Mesh(eyeGeo, red);
  eyeL.position.set(-0.22, 1.18, 1.5);
  const eyeR = new THREE.Mesh(eyeGeo, red);
  eyeR.position.set(0.22, 1.18, 1.5);
  const tail = new THREE.Mesh(g(new THREE.CylinderGeometry(0.04, 0.04, 0.7, 6)), dark);
  tail.position.set(0, 1.1, -1.0);
  tail.rotation.x = 0.6;
  body.add(torso, hump, head, snout, ring, hornL, hornR, eyeL, eyeR, tail);

  const legGeo = g(new THREE.BoxGeometry(0.28, 0.6, 0.28));
  const legs: THREE.Mesh[] = [];
  for (const [lx, lz] of [[-0.34, 0.6], [0.34, 0.6], [-0.34, -0.6], [0.34, -0.6]] as Array<[number, number]>) {
    const leg = new THREE.Mesh(legGeo, dark);
    leg.position.set(lx, 0.3, lz);
    leg.castShadow = true;
    body.add(leg);
    legs.push(leg);
  }
  group.scale.setScalar(1.1);
  return { group, body, legs, materials, geometries };
}

export function syncBullRig(rig: BullRig, b: { x: number; z: number; facing: number; vx: number; vz: number; stun: number }, t: number) {
  const speed = Math.hypot(b.vx, b.vz);
  rig.group.position.set(b.x, 0, b.z);
  rig.group.rotation.y = b.facing;
  const gait = Math.sin(t * 18) * Math.min(1, speed / 6);
  rig.body.position.y = Math.abs(gait) * 0.08;
  rig.body.rotation.z = b.stun > 0 ? Math.sin(t * 30) * 0.06 : gait * 0.04;
  rig.legs.forEach((leg, i) => {
    leg.rotation.x = (i % 2 === 0 ? 1 : -1) * gait * 0.7;
  });
}
