import { useCallback, useEffect, useRef, useState } from 'react';
import { CharacterCustomizationScreen } from './components/CharacterCustomizationScreen';
import { MatchHUD } from './components/MatchHUD';
import { MatchPreviewScreen } from './components/MatchPreviewScreen';
import { MatchSettingsScreen } from './components/MatchSettingsScreen';
import { MenuVirtualPad } from './components/MenuVirtualPad';
import { MultiplayerSplitCustomization } from './components/MultiplayerSplitCustomization';
import { OptionModal } from './components/OptionModal';
import { LanguageContext } from './game/i18n';
import { ScrollButtons } from './components/ScrollButtons';
import { PauseGameOverModal } from './components/PauseGameOverModal';
import { ReplayOverlay } from './components/ReplayOverlay';
import { SetupModal } from './components/SetupModal';
import { CutsceneKind, StoryDialogueCutscene } from './components/StoryDialogueCutscene';
import { StoryMapModal } from './components/StoryMapModal';
import { OpenWorldScreen } from './components/OpenWorldScreen';
import { ResultModal } from './components/AdventureMenus';
import { MainMenuDestination, TitleScreen } from './components/TitleScreen';
import { TrophyCollectionModal } from './components/TrophyCollectionModal';
import { gameAudio } from './game/audio';
import { PAD_KIND_LABEL, gamepadManager } from './game/gamepadManager';
import {
  AdventureResult,
  AdventureSave,
  clearAdventure,
  completeAdventureMatch,
  createAdventureMatchConfig,
  createNewAdventure,
  loadAdventure,
  persistAdventure,
} from './game/adventure';
import {
  ARENAS,
  BALLS,
  createDefaultMatchConfig,
  DEFAULT_CONTROL_MAPPING,
  DEFAULT_GAME_OPTIONS,
  DEFAULT_VIRTUAL_LAYOUT,
} from './game/catalog';
import { EngineCanvas, HudSnapshot, VirtualPadState } from './game/EngineCanvas';
import { ReplayBundle, ReplayCameraAngle, ReplayFrame } from './game/replay';
import {
  completeStoryMatch,
  createStoryMatchConfig,
  loadStoryProgress,
  saveStoryProgress,
  STORY_WORLDS,
  StoryCompletionOutcome,
  StoryProgressState,
} from './game/story';
import { ControlMapping, GameOptions, GameScreenState, MatchConfig, TeamId } from './game/types';

const STORAGE_CONTROLS_KEY = 'rubber_pitch_controls_v7';
const STORAGE_OPTIONS_KEY = 'rubber_pitch_options_v1';

function loadSavedControls(): ControlMapping {
  try {
    const raw = localStorage.getItem(STORAGE_CONTROLS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<ControlMapping>;
      return {
        p1: { ...DEFAULT_CONTROL_MAPPING.p1, ...(parsed.p1 ?? {}) },
        p2: { ...DEFAULT_CONTROL_MAPPING.p2, ...(parsed.p2 ?? {}) },
        p3: { ...DEFAULT_CONTROL_MAPPING.p3!, ...(parsed.p3 ?? {}) },
        p4: { ...DEFAULT_CONTROL_MAPPING.p4!, ...(parsed.p4 ?? {}) },
      };
    }
  } catch {
    // ignore storage errors
  }
  return DEFAULT_CONTROL_MAPPING;
}

function loadSavedOptions(): GameOptions {
  try {
    const raw = localStorage.getItem(STORAGE_OPTIONS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<GameOptions>;
      // Migrasi layout lama: 'shoulders' (L+R digabung) dipecah jadi shoulderL / shoulderR,
      // dan posisi 'system' lama (SELECT/START di bawah) dibuang karena START kini di pojok kanan atas.
      const savedLayout = (parsed.virtualLayout ?? {}) as Record<string, Partial<{ xOffset: number; yOffset: number; scale: number }> | undefined>;
      const isLegacy = !!savedLayout.shoulders && !savedLayout.shoulderL;
      const legacyShoulders = savedLayout.shoulders ?? {};
      return {
        ...DEFAULT_GAME_OPTIONS,
        ...parsed,
        buttonSkin: (() => {
          // Sekali saja: Icon Clear menjadi skin default untuk pengguna lama juga
          try {
            if (!localStorage.getItem('bolagila-skin-default-v10')) {
              localStorage.setItem('bolagila-skin-default-v10', '1');
              return 'icons_clear' as GameOptions['buttonSkin'];
            }
          } catch {
            // abaikan
          }
          return (['nintendo', 'transparent', 'icons', 'icons_clear'] as const).includes(parsed.buttonSkin as never)
            ? (parsed.buttonSkin as GameOptions['buttonSkin'])
            : DEFAULT_GAME_OPTIONS.buttonSkin;
        })(),
        virtualLayout: {
          dpad: { ...DEFAULT_VIRTUAL_LAYOUT.dpad, ...(savedLayout.dpad ?? {}) },
          system: { ...DEFAULT_VIRTUAL_LAYOUT.system, ...(isLegacy ? {} : (savedLayout.system ?? {})) },
          shoulderL: { ...DEFAULT_VIRTUAL_LAYOUT.shoulderL, ...(isLegacy ? legacyShoulders : (savedLayout.shoulderL ?? {})) },
          shoulderR: { ...DEFAULT_VIRTUAL_LAYOUT.shoulderR, ...(isLegacy ? legacyShoulders : (savedLayout.shoulderR ?? {})) },
          abxy: { ...DEFAULT_VIRTUAL_LAYOUT.abxy, ...(savedLayout.abxy ?? {}) },
        },
      };
    }
  } catch {
    // ignore storage errors
  }
  return DEFAULT_GAME_OPTIONS;
}

interface ActiveStoryCutsceneState {
  kind: CutsceneKind;
  worldIdx: number;
  matchIdx: number;
  winOutcome?: StoryCompletionOutcome | null;
}

export default function App() {
  const autostart =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('autostart') === '1';

  const [screenState, setScreenState] = useState<GameScreenState>(autostart ? 'playing' : 'title');
  const [config, setConfig] = useState<MatchConfig>(createDefaultMatchConfig);
  const [controls, setControls] = useState<ControlMapping>(loadSavedControls);
  const [options, setOptions] = useState<GameOptions>(loadSavedOptions);
  const [showOptionsModal, setShowOptionsModal] = useState(false);

  // Standalone Character Locker state (opened from Main Menu -> CHARACTER or Story Map -> Customize Hero)
  const [characterStandalone, setCharacterStandalone] = useState(false);
  const [returnToStoryMapAfterChar, setReturnToStoryMapAfterChar] = useState(false);

  // Story Mode: World Tour Challenge State
  const [storyProgress, setStoryProgress] = useState<StoryProgressState>(loadStoryProgress);
  const [showStoryMap, setShowStoryMap] = useState(false);
  const [showTrophies, setShowTrophies] = useState(false);
  const [returnToStoryMapAfterSetup, setReturnToStoryMapAfterSetup] = useState(false);
  const [travelFromWorldIdx, setTravelFromWorldIdx] = useState<number | null>(null);
  const [storyCutscene, setStoryCutscene] = useState<ActiveStoryCutsceneState | null>(null);

  // Story Mode Open World
  const [adventure, setAdventure] = useState<AdventureSave>(loadAdventure);
  const [showOpenWorld, setShowOpenWorld] = useState(false);
  const [adventureResult, setAdventureResult] = useState<AdventureResult | null>(null);
  const [worldKey, setWorldKey] = useState(0);
  const adventureRef = useRef(adventure);
  adventureRef.current = adventure;

  const handleAdventureChange = useCallback((next: AdventureSave) => {
    const prev = adventureRef.current;
    adventureRef.current = next;
    setAdventure(next);
    if (next.settings.autosave || prev.settings.autosave !== next.settings.autosave) persistAdventure(next);
  }, []);
  const handleAdventureManualSave = useCallback((next: AdventureSave) => {
    adventureRef.current = next;
    setAdventure(next);
    persistAdventure(next);
  }, []);

  const [matchNonce, setMatchNonce] = useState(1);
  const [muted, setMuted] = useState(false);
  const [isTouchDevice] = useState(() =>
    typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0)
  );
  const [lanRoomCode, setLanRoomCode] = useState<string | null>(null);
  const [lanRole, setLanRole] = useState<'host' | 'guest' | null>(null);

  const [replayBundle, setReplayBundle] = useState<ReplayBundle | null>(null);
  const [replayOpen, setReplayOpen] = useState(false);
  const [replayView, setReplayView] = useState<{
    frame: ReplayFrame | null;
    angle: ReplayCameraAngle;
    focusTeam: TeamId | null;
  }>({ frame: null, angle: 'broadcast', focusTeam: null });

  const [hud, setHud] = useState<HudSnapshot>({
    redScore: 0,
    blueScore: 0,
    timeRemaining: 300,
    currentHalf: 1,
    halfTimeBanner: false,
    goalBannerTeam: null,
    matchEnded: false,
    bombCountdown: null,
    p1CarryingProp: false,
    p1PunchCharge: 0,
    p1KickCharge: 0,
    isGoalReplay: false,
  });

  const skipGoalReplayRef = useRef<(() => void) | null>(null);

  const virtualPadRef = useRef<VirtualPadState>({
    moveX: 0,
    moveZ: 0,
    kick: false,
    kickRightSpin: false,
    grabProp: false,
    jump: false,
    headSpinLeft: false,
    dash: false,
  });

  useEffect(() => {
    document.body.dataset.state = screenState;
  }, [screenState]);

  useEffect(() => {
    gameAudio.applyOptions(options);
  }, [options]);

  const effectiveShowVirtualPad =
    options.virtualPadMode === 'on' ? true : options.virtualPadMode === 'off' ? false : isTouchDevice;

  const startMatch = useCallback(
    (customConfig?: MatchConfig) => {
      gameAudio.unlock();
      if (customConfig) setConfig(customConfig);
      setShowStoryMap(false);
      setShowOpenWorld(false);
      setStoryCutscene(null);
      setCharacterStandalone(false);
      setMatchNonce((n) => n + 1);
      setReplayOpen(false);
      setReplayBundle(null);
      setReplayView({ frame: null, angle: 'broadcast', focusTeam: null });
      setHud((prev) => ({
        ...prev,
        redScore: 0,
        blueScore: 0,
        timeRemaining:
          ((customConfig ?? config).halves ?? 2) === 2 && (customConfig ?? config).mode !== 'training'
            ? (customConfig ?? config).durationMinutes * 60 * 2
            : (customConfig ?? config).durationMinutes * 60,
        currentHalf: 1,
        halfTimeBanner: false,
        goalBannerTeam: null,
        matchEnded: false,
        bombCountdown: (customConfig ?? config).ballType === 'timer_bomb' ? 15 : null,
        p1CarryingProp: false,
        p1PunchCharge: 0,
        p1KickCharge: 0,
        isGoalReplay: false,
      }));
      setScreenState('playing');
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
    },
    [config]
  );

  const handleReplayFrameChange = useCallback(
    (frame: ReplayFrame | null, angle: ReplayCameraAngle, focusTeam: TeamId | null) => {
      setReplayView({ frame, angle, focusTeam });
    },
    []
  );

  const handleToggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      gameAudio.setMuted(next);
      return next;
    });
  }, []);

  // Saat game diminimalkan / tab disembunyikan: suara mati dan pertandingan otomatis dijeda
  useEffect(() => {
    const onVisibility = () => {
      const hidden = document.hidden;
      gameAudio.setBackgrounded(hidden);
      if (hidden) {
        setScreenState((cur) => (cur === 'playing' ? 'paused' : cur));
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', onVisibility);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', onVisibility);
    };
  }, []);

  // Deteksi controller otomatis (USB/Bluetooth) + notifikasi tersambung / terputus
  const [padToast, setPadToast] = useState('');
  useEffect(() => {
    gamepadManager.start();
    let t = 0;
    const off = gamepadManager.onEvent((e) => {
      if (e.type === 'swapped') return;
      const who = e.pad.slot ? `Player ${e.pad.slot}` : 'cadangan';
      const msg =
        e.type === 'connected'
          ? `🎮 ${PAD_KIND_LABEL[e.pad.kind]} tersambung → ${who} (Connected)`
          : `🎮 ${PAD_KIND_LABEL[e.pad.kind]} terputus (${e.pad.slot ? `Player ${e.pad.slot}` : 'cadangan'}) — otomatis tersambung kembali`;
      setPadToast(msg);
      window.clearTimeout(t);
      t = window.setTimeout(() => setPadToast(''), 3000);
    });
    return () => {
      off();
      window.clearTimeout(t);
    };
  }, []);

  // Tombol Start pada controller mana pun = Start / Menu (pause)
  useEffect(() => {
    const onStart = () => {
      if (showOptionsModal || showStoryMap || showTrophies || storyCutscene || showOpenWorld) return;
      if (screenState === 'playing' && !hud.isGoalReplay) setScreenState('paused');
    };
    window.addEventListener('wobble-gamepad-start', onStart);
    return () => window.removeEventListener('wobble-gamepad-start', onStart);
  }, [screenState, showOptionsModal, showStoryMap, showTrophies, storyCutscene, showOpenWorld, hud.isGoalReplay]);

  // Global in-match & modal hotkeys (Main Menu / Settings / Custom / Preview use useMenuController cleanly)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (showOptionsModal || showStoryMap || showTrophies || storyCutscene || showOpenWorld) return;

      if (screenState === 'gameover' && replayOpen && (e.code === 'Enter' || e.code === 'Escape' || e.code === 'KeyP')) {
        e.preventDefault();
        setReplayOpen(false);
        return;
      }
      if (screenState === 'playing' && hud.isGoalReplay && (e.code === 'Enter' || e.code === 'Escape' || e.code === 'KeyP')) {
        e.preventDefault();
        skipGoalReplayRef.current?.();
        return;
      }
      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (screenState === 'playing') {
          e.preventDefault();
          setScreenState('paused');
        } else if (screenState === 'paused') {
          e.preventDefault();
          setScreenState('playing');
        }
        return;
      }
      if (e.code === 'KeyM') {
        handleToggleMute();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [
    screenState,
    showOptionsModal,
    showStoryMap,
    showTrophies,
    storyCutscene,
    replayOpen,
    hud.isGoalReplay,
    handleToggleMute,
  ]);

  const handleSelectMainMenu = (dest: MainMenuDestination) => {
    gameAudio.unlock();
    if (dest === 'story') {
      setShowOpenWorld(true);
    } else if (dest === 'quick') {
      setCharacterStandalone(false);
      setConfig((prev) => ({
        ...prev,
        mode: 'quick',
        matchSubMode: 'quick',
        localPlayerCount: 1,
      }));
      setScreenState('match_settings');
    } else if (dest === 'local_multiplayer') {
      setCharacterStandalone(false);
      setConfig((prev) => ({
        ...prev,
        mode: 'coop',
        matchSubMode: 'local_multiplayer',
        localPlayerCount: Math.max(2, prev.localPlayerCount ?? 2) as 2 | 3 | 4,
      }));
      setScreenState('match_settings');
    } else if (dest === 'tournament') {
      setCharacterStandalone(false);
      setConfig((prev) => ({
        ...prev,
        mode: 'quick',
        matchSubMode: 'tournament',
        localPlayerCount: 1,
        redCount: 2,
        blueCount: 2,
        tournamentRound: 1,
        tournamentWins: 0,
      }));
      setScreenState('match_settings');
    } else if (dest === 'character') {
      setReturnToStoryMapAfterChar(false);
      setCharacterStandalone(true);
      setScreenState('character_custom');
    } else if (dest === 'settings') {
      setShowOptionsModal(true);
    }
  };

  const handleSelectStoryNode = (worldIdx: number, matchIdx: number) => {
    setStoryProgress((prev) => {
      const next = { ...prev, lastSelectedWorld: worldIdx, lastSelectedMatch: matchIdx };
      saveStoryProgress(next);
      return next;
    });
  };

  const handleChallengeStoryMatch = (worldIdx: number, matchIdx: number) => {
    gameAudio.unlock();
    handleSelectStoryNode(worldIdx, matchIdx);
    setShowStoryMap(false);
    setStoryCutscene({ kind: 'pre_match', worldIdx, matchIdx });
  };

  const handleMatchEnd = useCallback(
    (redScore: number, blueScore: number) => {
      setHud((prev) => ({ ...prev, redScore, blueScore, matchEnded: true }));
      const pScore = config.p1Team === 'red' ? redScore : blueScore;
      const oScore = config.p1Team === 'red' ? blueScore : redScore;

      if (config.adventure) {
        const { save: nextSave, result } = completeAdventureMatch(
          adventureRef.current,
          config.adventure.stadium,
          config.adventure.match,
          pScore,
          oScore
        );
        adventureRef.current = nextSave;
        setAdventure(nextSave);
        if (nextSave.settings.autosave) persistAdventure(nextSave);
        setAdventureResult(result);
        setScreenState('gameover');
        return;
      }

      if (config.mode === 'story') {
        const wIdx = config.storyWorldIndex ?? 0;
        const mIdx = config.storyMatchIndex ?? 0;

        if (pScore > oScore) {
          const outcome = completeStoryMatch(storyProgress, wIdx, mIdx);
          setStoryProgress(outcome.nextState);
          saveStoryProgress(outcome.nextState);
          if (outcome.unlockedNextWorld !== null) {
            setTravelFromWorldIdx(wIdx);
          } else {
            setTravelFromWorldIdx(null);
          }
          setScreenState('gameover');
          setStoryCutscene({
            kind: 'post_win',
            worldIdx: wIdx,
            matchIdx: mIdx,
            winOutcome: outcome,
          });
          return;
        } else {
          setTravelFromWorldIdx(null);
          setScreenState('gameover');
          setStoryCutscene({ kind: 'post_lose', worldIdx: wIdx, matchIdx: mIdx });
          return;
        }
      }

      setScreenState('gameover');
    },
    [config.adventure, config.mode, config.p1Team, config.storyMatchIndex, config.storyWorldIndex, storyProgress]
  );

  const handleNextStoryStage = () => {
    const wIdx = storyProgress.lastSelectedWorld;
    const mIdx = storyProgress.lastSelectedMatch;
    setStoryCutscene({ kind: 'pre_match', worldIdx: wIdx, matchIdx: mIdx });
  };

  const handleNextTournamentRound = () => {
    const nextRound = Math.min(3, (config.tournamentRound ?? 1) + 1);
    const nextArena = ARENAS[(nextRound * 3 + 1) % ARENAS.length].id;
    const nextBall = BALLS[(nextRound * 2) % BALLS.length].id;
    const nextCfg: MatchConfig = {
      ...config,
      tournamentRound: nextRound,
      tournamentWins: (config.tournamentWins ?? 0) + 1,
      aiDifficulty: nextRound === 3 ? 'hard' : 'normal',
      arena: nextArena,
      arenaRandom: false,
      ballType: nextBall,
    };
    startMatch(nextCfg);
  };

  const handleUpdateControls = (next: ControlMapping) => {
    setControls(next);
    try {
      localStorage.setItem(STORAGE_CONTROLS_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
  };

  const handleUpdateOptions = (next: GameOptions) => {
    setOptions(next);
    try {
      localStorage.setItem(STORAGE_OPTIONS_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
  };

  void muted;

  const cutsceneWorld = storyCutscene
    ? STORY_WORLDS[storyCutscene.worldIdx] ?? STORY_WORLDS[0]
    : null;
  const cutsceneMatch =
    cutsceneWorld && storyCutscene
      ? cutsceneWorld.matches[storyCutscene.matchIdx] ?? cutsceneWorld.matches[0]
      : null;

  const noOverlayOpen = !showOptionsModal && !showStoryMap && !showTrophies && !storyCutscene && !showOpenWorld;
  const isInMenuFlow =
    screenState === 'title' ||
    screenState === 'match_settings' ||
    screenState === 'character_custom' ||
    screenState === 'multiplayer_split' ||
    screenState === 'match_preview';

  return (
    <LanguageContext.Provider value={options.language ?? 'en'}>
    <main className="relative w-screen h-screen overflow-hidden bg-[#0b1922]">
      {padToast && (
        <div
          data-testid="controller-toast"
          className="fixed top-2 left-1/2 -translate-x-1/2 z-[90] px-3 py-1 rounded-xl bg-slate-950/85 border-2 border-emerald-300 text-[11px] font-extrabold text-white pointer-events-none"
        >
          {padToast}
        </div>
      )}
      {/* Isolated 3D WebGL Engine Canvas */}
      <EngineCanvas
        screenState={screenState}
        config={config}
        controls={controls}
        virtualPadRef={virtualPadRef}
        matchNonce={matchNonce}
        lanRoomCode={lanRoomCode}
        lanRole={lanRole}
        onHudUpdate={setHud}
        onMatchEnd={handleMatchEnd}
        onReplayAvailable={setReplayBundle}
        skipGoalReplayRef={skipGoalReplayRef}
        replayActive={replayOpen}
        replayFrame={replayView.frame}
        replayCameraAngle={replayView.angle}
        replayFocusTeam={replayView.focusTeam}
      />

      {screenState === 'title' && !showStoryMap && !storyCutscene && !showOpenWorld && (
        <TitleScreen
          active={screenState === 'title' && noOverlayOpen}
          storyProgress={storyProgress}
          onSelectMenu={handleSelectMainMenu}
          onOpenTrophies={() => setShowTrophies(true)}
        />
      )}

      {screenState === 'match_settings' && (
        <MatchSettingsScreen
          active={screenState === 'match_settings' && noOverlayOpen}
          config={config}
          lanRoomCode={lanRoomCode}
          lanRole={lanRole}
          onChangeConfig={setConfig}
          onSetLan={(code, role) => {
            setLanRoomCode(code);
            setLanRole(role);
          }}
          onBack={() => setScreenState('title')}
          onContinue={() =>
            setScreenState(
              (config.localPlayerCount ?? 1) >= 2 ? 'multiplayer_split' : 'character_custom'
            )
          }
        />
      )}

      {screenState === 'character_custom' && (
        <CharacterCustomizationScreen
          active={screenState === 'character_custom' && noOverlayOpen}
          standalone={characterStandalone}
          team={config.p1Team}
          custom={config.p1Custom}
          onChangeTeam={(t) => setConfig((prev) => ({ ...prev, p1Team: t }))}
          onChangeCustom={(c) => setConfig((prev) => ({ ...prev, p1Custom: c }))}
          onBack={() => {
            if (characterStandalone) {
              setCharacterStandalone(false);
              setScreenState('title');
              if (returnToStoryMapAfterChar) {
                setShowStoryMap(true);
                setReturnToStoryMapAfterChar(false);
              }
            } else {
              setScreenState('match_settings');
            }
          }}
          onReady={() => {
            if (characterStandalone) {
              setCharacterStandalone(false);
              setScreenState('title');
              if (returnToStoryMapAfterChar) {
                setShowStoryMap(true);
                setReturnToStoryMapAfterChar(false);
              }
            } else {
              setScreenState('match_preview');
            }
          }}
        />
      )}

      {screenState === 'multiplayer_split' && (
        <MultiplayerSplitCustomization
          active={screenState === 'multiplayer_split' && noOverlayOpen}
          config={config}
          controls={controls}
          onChangeConfig={setConfig}
          onBack={() => setScreenState('match_settings')}
          onContinue={() => setScreenState('match_preview')}
        />
      )}

      {screenState === 'match_preview' && (
        <MatchPreviewScreen
          active={screenState === 'match_preview' && noOverlayOpen}
          config={config}
          onBack={() =>
            setScreenState(
              (config.localPlayerCount ?? 1) >= 2 ? 'multiplayer_split' : 'character_custom'
            )
          }
          onStartMatch={() => startMatch()}
        />
      )}

      {screenState === 'setup' && (
        <SetupModal
          config={config}
          highestStoryStage={storyProgress.highestWorldUnlocked * 5}
          lanRoomCode={lanRoomCode}
          lanRole={lanRole}
          backLabel={returnToStoryMapAfterSetup ? 'Save & Return to Map' : 'Back'}
          onChangeConfig={setConfig}
          onSetLan={(code, role) => {
            setLanRoomCode(code);
            setLanRole(role);
          }}
          onOpenStoryMap={() => {
            setScreenState('title');
            setShowStoryMap(true);
          }}
          onStartMatch={() => {
            if (returnToStoryMapAfterSetup) {
              setScreenState('title');
              setShowStoryMap(true);
              setReturnToStoryMapAfterSetup(false);
            } else {
              startMatch();
            }
          }}
          onBack={() => {
            setScreenState('title');
            if (returnToStoryMapAfterSetup) {
              setShowStoryMap(true);
              setReturnToStoryMapAfterSetup(false);
            }
          }}
        />
      )}

      {/* Corner-anchored Virtual Menu Controller for Android / Touch */}
      {isInMenuFlow && noOverlayOpen && (
        <MenuVirtualPad
          visible={effectiveShowVirtualPad && screenState !== 'multiplayer_split'}
          showBumpers={screenState === 'character_custom'}
          startLabel={
            screenState === 'match_preview'
              ? 'PLAY'
              : screenState === 'character_custom'
                ? 'READY'
                : 'START'
          }
        />
      )}

      {screenState === 'playing' && (
        <MatchHUD
          hud={hud}
          gameMode={config.mode}
          showVirtualPad={effectiveShowVirtualPad}
          buttonSkin={options.buttonSkin}
          virtualLayout={options.virtualLayout}
          scoreHudPos={options.scoreHudPos ?? 'center'}
          scoreHudStyle={options.scoreHudStyle ?? 'random'}
          virtualPadRef={virtualPadRef}
          onToggleMute={handleToggleMute}
          onPause={() => setScreenState('paused')}
          onSkipGoalReplay={() => skipGoalReplayRef.current?.()}
        />
      )}

      {(screenState === 'paused' || screenState === 'gameover') &&
        !replayOpen &&
        !(screenState === 'gameover' && adventureResult && config.adventure) &&
        !storyCutscene &&
        !showStoryMap && (
          <PauseGameOverModal
            mode={screenState}
            gameMode={config.mode}
            matchSubMode={config.matchSubMode}
            tournamentRound={config.tournamentRound}
            p1Team={config.p1Team}
            redScore={hud.redScore}
            blueScore={hud.blueScore}
            hasNextStoryStage={config.mode === 'story'}
            hasReplay={Boolean(replayBundle && replayBundle.tailFrames.length > 0)}
            onResume={() => setScreenState('playing')}
            onRestart={() => startMatch()}
            onNextStoryStage={handleNextStoryStage}
            onNextTournamentRound={handleNextTournamentRound}
            onOpenStoryMap={() => {
              setReplayOpen(false);
              setScreenState('title');
              setShowStoryMap(true);
            }}
            onOpenReplay={() => setReplayOpen(true)}
            onOpenOptions={() => setShowOptionsModal(true)}
            onMainMenu={() => {
              setReplayOpen(false);
              setScreenState('title');
              if (config.adventure) setShowOpenWorld(true);
            }}
          />
        )}

      {screenState === 'gameover' && replayOpen && replayBundle && (
        <ReplayOverlay
          bundle={replayBundle}
          onFrameChange={handleReplayFrameChange}
          onExit={() => setReplayOpen(false)}
        />
      )}

      {showOpenWorld && screenState === 'title' && (
        <OpenWorldScreen
          key={worldKey}
          save={adventure}
          onSaveChange={handleAdventureChange}
          onManualSave={handleAdventureManualSave}
          onPlayMatch={(stadium, match, posSave) => {
            gameAudio.unlock();
            // Sinkronkan tampilan Hero dengan kostum yang dipilih di Character Locker
            const hc = config.p1Custom;
            const synced: AdventureSave = {
              ...posSave,
              heroCustom: { ...hc },
              roster: posSave.roster.map((a) =>
                a.id === 'hero' ? { ...a, animal: hc.animal, hat: hc.hat, mask: hc.mask, cape: hc.cape } : a
              ),
            };
            handleAdventureChange(synced);
            setAdventureResult(null);
            startMatch(createAdventureMatchConfig(synced, stadium, match, config));
          }}
          onReset={() => {
            clearAdventure();
            const fresh = createNewAdventure(config.p1Custom);
            adventureRef.current = fresh;
            setAdventure(fresh);
            persistAdventure(fresh);
            setWorldKey((k) => k + 1);
          }}
          onExit={() => setShowOpenWorld(false)}
        />
      )}

      {screenState === 'gameover' && adventureResult && config.adventure && !replayOpen && (
        <ResultModal
          result={adventureResult}
          onContinue={() => {
            setAdventureResult(null);
            setScreenState('title');
            setShowOpenWorld(true);
          }}
        />
      )}

      {showStoryMap && (
        <StoryMapModal
          progress={storyProgress}
          heroCustom={config.p1Custom}
          initialWorldIdx={storyProgress.lastSelectedWorld}
          initialMatchIdx={storyProgress.lastSelectedMatch}
          travelFromWorldIdx={travelFromWorldIdx}
          onSelectNode={handleSelectStoryNode}
          onChallengeMatch={handleChallengeStoryMatch}
          onOpenCharacterLocker={() => {
            setShowStoryMap(false);
            setReturnToStoryMapAfterChar(true);
            setCharacterStandalone(true);
            setScreenState('character_custom');
          }}
          onOpenTrophies={() => setShowTrophies(true)}
          onReplayEnding={() => {
            setShowStoryMap(false);
            setStoryCutscene({ kind: 'world10_ending', worldIdx: 9, matchIdx: 4 });
          }}
          onBack={() => {
            setShowStoryMap(false);
            setScreenState('title');
          }}
        />
      )}

      {storyCutscene && cutsceneWorld && cutsceneMatch && (
        <StoryDialogueCutscene
          key={`${storyCutscene.kind}-${storyCutscene.worldIdx}-${storyCutscene.matchIdx}`}
          kind={storyCutscene.kind}
          world={cutsceneWorld}
          match={cutsceneMatch}
          heroCustom={config.p1Custom}
          winOutcome={storyCutscene.winOutcome}
          onRematch={() => {
            const nextCfg = createStoryMatchConfig(
              storyCutscene.worldIdx,
              storyCutscene.matchIdx,
              config.p1Custom,
              config
            );
            startMatch(nextCfg);
          }}
          onFinish={() => {
            if (storyCutscene.kind === 'pre_match') {
              const nextCfg = createStoryMatchConfig(
                storyCutscene.worldIdx,
                storyCutscene.matchIdx,
                config.p1Custom,
                config
              );
              startMatch(nextCfg);
            } else if (
              storyCutscene.kind === 'post_win' &&
              storyCutscene.winOutcome?.completedStoryEnding
            ) {
              setStoryCutscene({
                kind: 'world10_ending',
                worldIdx: 9,
                matchIdx: 4,
                winOutcome: storyCutscene.winOutcome,
              });
            } else {
              setStoryCutscene(null);
              setScreenState('title');
              setShowStoryMap(true);
            }
          }}
        />
      )}

      {showTrophies && (
        <TrophyCollectionModal
          progress={storyProgress}
          onClose={() => setShowTrophies(false)}
        />
      )}

      {showOptionsModal && (
        <OptionModal
          options={options}
          controls={controls}
          onChangeOptions={handleUpdateOptions}
          onChangeControls={handleUpdateControls}
          onClose={() => setShowOptionsModal(false)}
        />
      )}
      <ScrollButtons hidden={screenState === 'playing' && !showOptionsModal} />
    </main>
    </LanguageContext.Provider>
  );
}
