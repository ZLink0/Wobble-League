import { useEffect, useState } from 'react';
import { PadInfo, SlotId, gamepadManager } from '../game/gamepadManager';

export interface SlotStatus {
  slot: SlotId;
  pad: PadInfo | null;
  reconnecting: boolean;
}

/** Status controller per player (diperbarui otomatis saat tersambung / terputus / ditukar) */
export function useGamepadStatus(): { slots: SlotStatus[]; spare: PadInfo[] } {
  const read = () => ({ slots: gamepadManager.getStatus(), spare: gamepadManager.getSpare() });
  const [state, setState] = useState(read);
  useEffect(() => {
    gamepadManager.start();
    const update = () => setState(read());
    update();
    return gamepadManager.subscribe(update);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return state;
}
