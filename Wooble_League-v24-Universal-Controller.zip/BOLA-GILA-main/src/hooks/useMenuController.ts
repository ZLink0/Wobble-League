import { gamepadManager } from '../game/gamepadManager';
import { useEffect, useRef } from 'react';

export type MenuNavAction =
  | 'up'
  | 'down'
  | 'left'
  | 'right'
  | 'confirm'
  | 'back'
  | 'start'
  | 'lb'
  | 'rb'
  | 'lt'
  | 'rt';

export interface MenuControllerHandlers {
  active?: boolean;
  onAction: (action: MenuNavAction) => void;
  onRotateStick?: (dx: number) => void;
}

export function dispatchMenuVirtualAction(action: MenuNavAction): void {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent('menu-vpad', { detail: { action } }));
}

export function useMenuController({
  active = true,
  onAction,
  onRotateStick,
}: MenuControllerHandlers): void {
  const actionRef = useRef(onAction);
  const rotateRef = useRef(onRotateStick);
  actionRef.current = onAction;
  rotateRef.current = onRotateStick;

  useEffect(() => {
    if (!active) return;

    const onKeyDown = (e: KeyboardEvent) => {
      if (document.body.dataset.capturingKey === '1') return;
      const target = e.target as HTMLElement | null;
      const isFormInput =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'SELECT' ||
        target?.tagName === 'TEXTAREA';
      if (isFormInput && e.code !== 'Escape') return;

      let act: MenuNavAction | null = null;
      if (e.code === 'ArrowUp' || e.code === 'KeyW') act = 'up';
      else if (e.code === 'ArrowDown' || e.code === 'KeyS') act = 'down';
      else if (e.code === 'ArrowLeft' || e.code === 'KeyA') act = 'left';
      else if (e.code === 'ArrowRight' || e.code === 'KeyD') act = 'right';
      else if (e.code === 'Enter' || e.code === 'Space') act = 'confirm';
      else if (e.code === 'Escape' || e.code === 'Backspace') act = 'back';
      else if (e.code === 'KeyQ' || e.code === 'BracketLeft') act = 'lb';
      else if (e.code === 'KeyE' || e.code === 'BracketRight') act = 'rb';
      else if (e.code === 'Minus') act = 'lt';
      else if (e.code === 'Equal') act = 'rt';

      if (act) {
        e.preventDefault();
        actionRef.current(act);
      }
    };

    const onVirtualPad = (e: Event) => {
      const detail = (e as CustomEvent<{ action: MenuNavAction }>).detail;
      if (detail?.action) {
        actionRef.current(detail.action);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('menu-vpad', onVirtualPad);

    let rafId = 0;
    let prevBtns: boolean[] = [];
    let lastDirAt = 0;
    let lastDirKey = '';

    const pollGamepad = () => {
      // Navigasi menu: controller dengan slot terendah (sudah dinormalkan ke posisi fisik Xbox)
      const gp = gamepadManager.getPrimaryStd();
      const now = performance.now();
      if (gp) {
        const edge = (idx: number) => !!gp.buttons[idx]?.pressed && !prevBtns[idx];
        if (edge(0)) actionRef.current('confirm');
        else if (edge(1)) actionRef.current('back');
        else if (edge(9)) actionRef.current('start');
        else if (edge(4)) actionRef.current('lb');
        else if (edge(5)) actionRef.current('rb');
        else if (edge(6)) actionRef.current('lt');
        else if (edge(7)) actionRef.current('rt');

        const axX = gp.axes[0] || 0;
        const axY = gp.axes[1] || 0;
        let dir: MenuNavAction | null = null;
        if (gp.buttons[12]?.pressed || axY < -0.55) dir = 'up';
        else if (gp.buttons[13]?.pressed || axY > 0.55) dir = 'down';
        else if (gp.buttons[14]?.pressed || axX < -0.55) dir = 'left';
        else if (gp.buttons[15]?.pressed || axX > 0.55) dir = 'right';

        if (dir) {
          if (dir !== lastDirKey || now - lastDirAt > 200) {
            actionRef.current(dir);
            lastDirKey = dir;
            lastDirAt = now;
          }
        } else {
          lastDirKey = '';
        }

        const rx = gp.axes[2] || 0;
        if (Math.abs(rx) > 0.18) {
          rotateRef.current?.(rx * 0.055);
        }

        prevBtns = gp.buttons.map((b) => !!b.pressed);
      } else {
        prevBtns = [];
      }
      rafId = requestAnimationFrame(pollGamepad);
    };
    rafId = requestAnimationFrame(pollGamepad);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('menu-vpad', onVirtualPad);
      cancelAnimationFrame(rafId);
    };
  }, [active]);
}
