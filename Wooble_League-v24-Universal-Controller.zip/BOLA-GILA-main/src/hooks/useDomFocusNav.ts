import { RefObject, useEffect, useRef } from 'react';
import { MenuNavAction, useMenuController } from './useMenuController';

const FOCUSABLE =
  'button:not([disabled]), [role="button"]:not([aria-disabled="true"]), a[href], input:not([disabled]), select:not([disabled]), [data-nav-item]';

/** Tumpukan menu aktif: hanya menu paling atas (modal terakhir yang muncul) yang merespons D-Pad */
const navStack: symbol[] = [];

interface DomFocusNavOptions {
  /** Elemen root menu/modal; hanya elemen fokus di dalamnya yang dinavigasi */
  rootRef: RefObject<HTMLElement | null>;
  active?: boolean;
  onBack?: () => void;
  onStart?: () => void;
  /** Dipanggil untuk LB/RB (mis. ganti tab) */
  onBumper?: (dir: -1 | 1) => void;
}

function isVisible(el: HTMLElement): boolean {
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  const st = window.getComputedStyle(el);
  return st.visibility !== 'hidden' && st.display !== 'none';
}

function getItems(root: HTMLElement): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(isVisible);
}

function markFocus(root: HTMLElement, el: HTMLElement | null) {
  root.querySelectorAll('[data-nav-focus="true"]').forEach((n) => n.removeAttribute('data-nav-focus'));
  if (el) {
    el.setAttribute('data-nav-focus', 'true');
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
  }
}

/** Geser slider (input range) tanpa sentuhan, kompatibel dengan React controlled input */
function stepRange(input: HTMLInputElement, dir: -1 | 1) {
  const step = Number(input.step) || 1;
  const min = input.min !== '' ? Number(input.min) : 0;
  const max = input.max !== '' ? Number(input.max) : 100;
  const next = Math.max(min, Math.min(max, Number(input.value) + dir * step));
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  setter?.call(input, String(next));
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

function scrollParentOf(el: HTMLElement | null, root: HTMLElement): HTMLElement | null {
  let cur: HTMLElement | null = el;
  while (cur && cur !== root.parentElement) {
    const oy = window.getComputedStyle(cur).overflowY;
    if ((oy === 'auto' || oy === 'scroll') && cur.scrollHeight > cur.clientHeight + 2) return cur;
    cur = cur.parentElement;
  }
  return null;
}

/**
 * Navigasi menu tanpa sentuhan (D-Pad virtual, keyboard, gamepad / kontrol eksternal):
 * panah memindahkan fokus secara spasial, confirm menekan tombol, kiri/kanan menggeser slider,
 * dan daftar otomatis ter-scroll mengikuti item yang difokuskan.
 */
export function useDomFocusNav({ rootRef, active = true, onBack, onStart, onBumper }: DomFocusNavOptions) {
  const cbRef = useRef({ onBack, onStart, onBumper });
  cbRef.current = { onBack, onStart, onBumper };
  const idRef = useRef<symbol>(Symbol('nav'));

  useEffect(() => {
    if (!active) return;
    const id = idRef.current;
    navStack.push(id);
    return () => {
      const i = navStack.indexOf(id);
      if (i >= 0) navStack.splice(i, 1);
    };
  }, [active]);

  // Fokus awal otomatis ke item pertama saat menu muncul
  useEffect(() => {
    if (!active) return;
    const t = window.setTimeout(() => {
      const root = rootRef.current;
      if (!root) return;
      const items = getItems(root);
      if (items.length && !root.contains(document.activeElement)) markFocus(root, items[0]);
    }, 60);
    return () => {
      window.clearTimeout(t);
      rootRef.current?.querySelectorAll('[data-nav-focus="true"]').forEach((n) => n.removeAttribute('data-nav-focus'));
    };
  }, [active, rootRef]);

  const move = (dir: 'up' | 'down' | 'left' | 'right') => {
    const root = rootRef.current;
    if (!root) return;
    const items = getItems(root);
    if (!items.length) return;
    const cur = (document.activeElement && root.contains(document.activeElement)
      ? (document.activeElement as HTMLElement)
      : null);
    if (!cur || !items.includes(cur)) {
      markFocus(root, items[0]);
      return;
    }

    // Slider: kiri/kanan mengubah nilai
    if (cur instanceof HTMLInputElement && cur.type === 'range' && (dir === 'left' || dir === 'right')) {
      stepRange(cur, dir === 'left' ? -1 : 1);
      return;
    }

    const cr = cur.getBoundingClientRect();
    const cx = cr.left + cr.width / 2;
    const cy = cr.top + cr.height / 2;
    let best: HTMLElement | null = null;
    let bestScore = Infinity;
    for (const el of items) {
      if (el === cur) continue;
      const r = el.getBoundingClientRect();
      const ex = r.left + r.width / 2;
      const ey = r.top + r.height / 2;
      const dx = ex - cx;
      const dy = ey - cy;
      let along = 0;
      let across = 0;
      if (dir === 'up') {
        along = -dy;
        across = Math.abs(dx);
      } else if (dir === 'down') {
        along = dy;
        across = Math.abs(dx);
      } else if (dir === 'left') {
        along = -dx;
        across = Math.abs(dy);
      } else {
        along = dx;
        across = Math.abs(dy);
      }
      if (along <= 4) continue;
      const score = along + across * 2.2;
      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }

    if (best) {
      markFocus(root, best);
    } else if (dir === 'up' || dir === 'down') {
      // Tidak ada item lagi: scroll panel agar konten tersembunyi terlihat
      const sp = scrollParentOf(cur, root);
      sp?.scrollBy({ top: dir === 'down' ? 140 : -140, behavior: 'smooth' });
    }
  };

  useMenuController({
    active,
    onAction: (action: MenuNavAction) => {
      if (navStack[navStack.length - 1] !== idRef.current) return;
      if (action === 'up' || action === 'down' || action === 'left' || action === 'right') {
        move(action);
      } else if (action === 'confirm') {
        const root = rootRef.current;
        const el = document.activeElement as HTMLElement | null;
        if (root && el && root.contains(el) && el !== root) {
          if (el instanceof HTMLInputElement && el.type === 'range') return;
          el.click();
        }
      } else if (action === 'back') {
        cbRef.current.onBack?.();
      } else if (action === 'start') {
        cbRef.current.onStart?.();
      } else if (action === 'lb') {
        cbRef.current.onBumper?.(-1);
      } else if (action === 'rb') {
        cbRef.current.onBumper?.(1);
      }
    },
  });
}
