/* =====================================================================
 *  GAMEPAD MANAGER — 1 controller = 1 Device ID = 1 mapping = 1 player
 *
 *  - Deteksi otomatis Xbox / PlayStation / Nintendo / Joy-Con / generic (USB & Bluetooth)
 *  - Setiap perangkat diidentifikasi lewat Gamepad Index + ID (tidak selalu index 0)
 *  - Penugasan otomatis berurutan: controller 1 -> P1, 2 -> P2, 3 -> P3, 4 -> P4
 *  - Tombol dinormalkan ke POSISI FISIK ala Xbox (bawah/kanan/kiri/atas), termasuk Nintendo & PlayStation
 *  - Analog dibaca per perangkat dengan radial deadzone (360°, diagonal tidak lebih cepat)
 *  - Reconnect otomatis: slot controller yang terputus dipertahankan, tidak mengubah controller lain
 * ===================================================================== */

export type SlotId = 1 | 2 | 3 | 4;
export type PadKind = 'xbox' | 'playstation' | 'nintendo' | 'joycon' | 'generic';

export const PAD_KIND_LABEL: Record<PadKind, string> = {
  xbox: 'Xbox',
  playstation: 'PlayStation',
  nintendo: 'Nintendo',
  joycon: 'Joy-Con',
  generic: 'Gamepad',
};

export interface PadInfo {
  index: number;
  id: string;
  name: string;
  kind: PadKind;
  mapping: string;
  key: string; // id + urutan (stabil selama controller yang sama dicolok ulang)
  slot: SlotId | null;
}

/** Pad yang sudah dinormalkan: indeks standar = posisi fisik Xbox */
export interface StdPad {
  buttons: Array<{ pressed: boolean; value: number }>; // 0 bawah,1 kanan,2 kiri,3 atas,4 LB,5 RB,6 LT,7 RT,8 back,9 start,12-15 dpad
  axes: number[]; // [lx, ly, rx, ry]
}

export interface SlotPadInput {
  moveX: number;
  moveZ: number;
  run: boolean;
  kickPressed: boolean;
  kickHeld: boolean;
  kickRightPressed: boolean;
  kickRightHeld: boolean;
  grabPressed: boolean;
  jumpPressed: boolean;
  headPressed: boolean;
  dashPressed: boolean;
  startPressed: boolean;
}

export type PadEvent =
  | { type: 'connected'; pad: PadInfo }
  | { type: 'disconnected'; pad: PadInfo }
  | { type: 'swapped' };

export const STICK_DEADZONE = 0.18;
const RESERVE_MS = 60_000;
const STORAGE_KEY = 'wobble_pad_assign_v2';
const MAP_STORAGE_KEY = 'wobble_pad_button_maps_v1';
export type PadAction = 'kick' | 'jump' | 'kick2' | 'grab' | 'head' | 'dash' | 'start';
export type PadButtonMap = Record<PadAction, number>;
const DEFAULT_PAD_MAP: PadButtonMap = { kick: 0, jump: 1, kick2: 2, grab: 3, head: 4, dash: 5, start: 9 };

/* ----------------------------- identifikasi jenis ----------------------------- */
function vendorOf(id: string): string {
  const a = /Vendor:\s*([0-9a-f]{4})/i.exec(id);
  if (a) return a[1].toLowerCase();
  const b = /^([0-9a-f]{4})-[0-9a-f]{4}/i.exec(id);
  return b ? b[1].toLowerCase() : '';
}

export function detectKind(id: string): PadKind {
  const v = vendorOf(id);
  const s = id.toLowerCase();
  if (/joy-?con/.test(s) && !/\(l\+r\)|l\/r|pair/.test(s)) return 'joycon';
  if (v === '057e' || /nintendo|switch|pro controller|joy-?con/.test(s)) return 'nintendo';
  if (v === '054c' || /playstation|dualshock|dualsense|sony|ps4|ps5|wireless controller/.test(s)) return 'playstation';
  if (v === '045e' || /xbox|x-box|xinput|microsoft/.test(s)) return 'xbox';
  return 'generic';
}

function friendlyName(id: string): string {
  const clean = id.replace(/\(.*?\)/g, '').replace(/Vendor:.*$/i, '').replace(/^[0-9a-f]{4}-[0-9a-f]{4}-/i, '').trim();
  return clean || id;
}

function isUsable(gp: Gamepad): boolean {
  const s = gp.id.toLowerCase();
  if (/accelerometer|motion sensor|gyro|touchpad|mouse|keyboard|consumer control|system control|headset/.test(s)) return false;
  // Beberapa gamepad Bluetooth Android (termasuk mode generic/X3) melaporkan
  // tombol lebih dulu dan axis kosong. Jangan buang perangkat hanya karena axis < 2.
  return gp.buttons.length >= 1 || gp.axes.length >= 1;
}

/* ----------------------------- layout tombol ----------------------------- */
interface Layout {
  bottom: number;
  right: number;
  left: number;
  top: number;
  lb: number;
  rb: number;
  lt: number;
  rt: number;
  back: number;
  start: number;
}
const STD_LAYOUT: Layout = { bottom: 0, right: 1, left: 2, top: 3, lb: 4, rb: 5, lt: 6, rt: 7, back: 8, start: 9 };
// DualShock/DualSense tanpa mapping standar: Square, Cross, Circle, Triangle
const PS_RAW_LAYOUT: Layout = { bottom: 1, right: 2, left: 0, top: 3, lb: 4, rb: 5, lt: 6, rt: 7, back: 8, start: 9 };
// Xbox 360/One tanpa mapping standar (trigger berupa axis)
const XBOX_RAW_LAYOUT: Layout = { bottom: 0, right: 1, left: 2, top: 3, lb: 4, rb: 5, lt: -1, rt: -1, back: 6, start: 7 };

function layoutFor(kind: PadKind, mapping: string, nButtons: number): Layout {
  if (mapping === 'standard') return STD_LAYOUT;
  if (kind === 'playstation') return PS_RAW_LAYOUT;
  if (kind === 'xbox' && nButtons <= 11) return XBOX_RAW_LAYOUT;
  return STD_LAYOUT; // Nintendo & generic: urutan posisi fisik B(bawah) A(kanan) Y(kiri) X(atas)
}

function decodeHat(v: number): { up: boolean; down: boolean; left: boolean; right: boolean } {
  const r = { up: false, down: false, left: false, right: false };
  if (!Number.isFinite(v) || v > 1.1) return r;
  const steps = [-1, -0.714, -0.428, -0.142, 0.142, 0.428, 0.714, 1];
  let best = 0;
  let bd = 9;
  steps.forEach((s, i) => {
    const d = Math.abs(s - v);
    if (d < bd) {
      bd = d;
      best = i;
    }
  });
  if (bd > 0.1) return r;
  // 0 up, 1 up-right, 2 right, 3 down-right, 4 down, 5 down-left, 6 left, 7 up-left
  r.up = best === 0 || best === 1 || best === 7;
  r.right = best === 1 || best === 2 || best === 3;
  r.down = best === 3 || best === 4 || best === 5;
  r.left = best === 5 || best === 6 || best === 7;
  return r;
}

export function standardize(gp: Gamepad, kind: PadKind): StdPad {
  const L = layoutFor(kind, gp.mapping, gp.buttons.length);
  const raw = (i: number) => (i >= 0 ? gp.buttons[i] : undefined);
  const pick = (i: number) => ({ pressed: !!raw(i)?.pressed, value: raw(i)?.value ?? (raw(i)?.pressed ? 1 : 0) });
  const b = Array.from({ length: 16 }, () => ({ pressed: false, value: 0 }));
  b[0] = pick(L.bottom);
  b[1] = pick(L.right);
  b[2] = pick(L.left);
  b[3] = pick(L.top);
  b[4] = pick(L.lb);
  b[5] = pick(L.rb);
  b[6] = pick(L.lt);
  b[7] = pick(L.rt);
  b[8] = pick(L.back);
  b[9] = pick(L.start);
  b[10] = pick(10);
  b[11] = pick(11);
  if (gp.mapping === 'standard') {
    b[12] = pick(12);
    b[13] = pick(13);
    b[14] = pick(14);
    b[15] = pick(15);
  } else if (gp.axes.length > 9) {
    const h = decodeHat(gp.axes[9]);
    b[12] = { pressed: h.up, value: h.up ? 1 : 0 };
    b[13] = { pressed: h.down, value: h.down ? 1 : 0 };
    b[14] = { pressed: h.left, value: h.left ? 1 : 0 };
    b[15] = { pressed: h.right, value: h.right ? 1 : 0 };
  }
  return {
    buttons: b,
    axes: [gp.axes[0] || 0, gp.axes[1] || 0, gp.axes[2] || 0, gp.axes[3] || 0],
  };
}

/** Radial deadzone: arah dipertahankan (360°), magnitudo maksimal 1 sehingga diagonal tidak lebih cepat */
export function applyRadialDeadzone(x: number, y: number, dz = STICK_DEADZONE): { x: number; y: number } {
  const mag = Math.hypot(x, y);
  if (mag <= dz) return { x: 0, y: 0 };
  const scaled = Math.min(1, (mag - dz) / (1 - dz));
  return { x: (x / mag) * scaled, y: (y / mag) * scaled };
}

/* ----------------------------- manager ----------------------------- */
interface Dev {
  info: PadInfo;
  dupCount: number;
  ignored: boolean;
}

class GamepadManager {
  private devices = new Map<number, Dev>();
  private slots: Record<SlotId, number | null> = { 1: null, 2: null, 3: null, 4: null };
  private reserved = new Map<string, { slot: SlotId; until: number }>();
  private prevByConsumer = new Map<string, boolean[]>();
  private listeners = new Set<() => void>();
  private eventListeners = new Set<(e: PadEvent) => void>();
  private lastScan = 0;
  private timer: number | null = null;
  private started = false;

  /* ------------ siklus hidup ------------ */
  start(): void {
    if (this.started || typeof window === 'undefined') return;
    this.started = true;
    window.addEventListener('gamepadconnected', () => this.scan(true));
    window.addEventListener('gamepaddisconnected', () => this.scan(true));
    // Android/embedded browsers sometimes expose a pad only after focus or a user input.
    window.addEventListener('focus', () => this.scan(true));
    window.addEventListener('pageshow', () => this.scan(true));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) this.scan(true); });
    this.timer = window.setInterval(() => {
      this.scan(true);
      this.pollStart();
    }, 120);
    this.scan(true);
  }

  subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }
  onEvent(cb: (e: PadEvent) => void): () => void {
    this.eventListeners.add(cb);
    return () => this.eventListeners.delete(cb);
  }
  private emit() {
    this.listeners.forEach((l) => l());
  }
  private emitEvent(e: PadEvent) {
    this.eventListeners.forEach((l) => l(e));
  }

  /* ------------ pemindaian perangkat ------------ */
  scan(force = false): void {
    const now = performance.now();
    if (!force && now - this.lastScan < 8) return;
    this.lastScan = now;
    let list: Array<Gamepad | null> = [];
    try {
      list = (typeof navigator !== 'undefined' && typeof navigator.getGamepads === 'function'
        ? Array.from(navigator.getGamepads())
        : []) as Array<Gamepad | null>;
    } catch {
      // WebViews that expose but block Gamepad API must not crash the game.
      list = [];
    }
    const seen = new Set<number>();
    let changed = false;
    const pads: Gamepad[] = [];
    for (const gp of list) {
      if (!gp || !gp.connected || !isUsable(gp)) continue;
      pads.push(gp);
    }
    this.detectDuplicates(pads);
    for (const gp of pads) {
      const known = this.devices.get(gp.index);
      if (known?.ignored) continue;
      seen.add(gp.index);
      if (!known || known.info.id !== gp.id) {
        this.addDevice(gp);
        changed = true;
      }
    }
    const present = new Set(pads.map((g) => g.index));
    for (const [idx, dev] of [...this.devices.entries()]) {
      if (dev.ignored) {
        if (!present.has(idx)) this.devices.delete(idx);
        continue;
      }
      if (!seen.has(idx)) {
        this.removeDevice(idx, dev);
        changed = true;
      }
    }
    // reservasi kedaluwarsa
    for (const [k, r] of [...this.reserved.entries()]) if (r.until < Date.now()) this.reserved.delete(k);
    if (changed) this.emit();
  }

  /** Dua entri dengan ID sama yang menampilkan input identik & timestamp sama = satu perangkat fisik yang terdaftar ganda */
  private detectDuplicates(pads: Gamepad[]): void {
    const sig = (g: Gamepad) =>
      g.axes.map((a) => a.toFixed(1)).join(',') + '|' + g.buttons.map((b) => (b.pressed ? 1 : 0)).join('');
    const active = (g: Gamepad) => g.buttons.some((b) => b.pressed) || g.axes.slice(0, 4).some((a) => Math.abs(a) > 0.4);
    for (let i = 0; i < pads.length; i++) {
      for (let j = i + 1; j < pads.length; j++) {
        const a = pads[i];
        const b = pads[j];
        if (a.id !== b.id) continue;
        const dev = this.devices.get(b.index);
        if (!dev) continue;
        if (active(a) && active(b) && sig(a) === sig(b) && a.timestamp === b.timestamp) {
          dev.dupCount++;
          if (dev.dupCount >= 10 && !dev.ignored) {
            dev.ignored = true;
            this.removeDevice(b.index, dev, true);
            this.emit();
          }
        } else dev.dupCount = 0;
      }
    }
  }

  private freeSlot(slot: SlotId): boolean {
    return this.slots[slot] === null;
  }
  private reservedByOther(slot: SlotId, key: string): boolean {
    for (const [k, r] of this.reserved) if (k !== key && r.slot === slot && r.until > Date.now()) return true;
    return false;
  }

  private addDevice(gp: Gamepad): void {
    const base = gp.id;
    let ordinal = 0;
    for (const d of this.devices.values()) if (d.info.id === base && d.info.index !== gp.index) ordinal++;
    const key = `${base}#${ordinal}`;
    const kind = detectKind(gp.id);
    const info: PadInfo = { index: gp.index, id: gp.id, name: friendlyName(gp.id), kind, mapping: gp.mapping, key, slot: null };
    const existing = this.devices.get(gp.index);
    if (existing?.info.slot) this.slots[existing.info.slot] = null;
    this.devices.set(gp.index, { info, dupCount: 0, ignored: false });

    const connectedCount = this.devices.size;
    let slot: SlotId | null = null;
    const res = this.reserved.get(key);
    if (res && this.freeSlot(res.slot)) slot = res.slot; // reconnect: slot yang sama
    if (!slot) {
      const saved = this.loadSaved()[key];
      if (saved && saved <= connectedCount && this.freeSlot(saved) && !this.reservedByOther(saved, key)) slot = saved;
    }
    // Joy-Con sengaja tidak pernah auto-assign; pemain harus memilih slot manual.
    if (!slot && kind !== 'joycon') {
      for (const s of [1, 2, 3, 4] as SlotId[]) {
        if (this.freeSlot(s) && !this.reservedByOther(s, key)) {
          slot = s;
          break;
        }
      }
    }
    this.reserved.delete(key);
    if (slot) {
      this.slots[slot] = gp.index;
      info.slot = slot;
      this.persist();
    }
    this.emitEvent({ type: 'connected', pad: { ...info } });
  }

  private removeDevice(idx: number, dev: Dev, silent = false): void {
    const slot = dev.info.slot;
    if (slot && this.slots[slot] === idx) {
      this.slots[slot] = null;
      if (!silent) this.reserved.set(dev.info.key, { slot, until: Date.now() + RESERVE_MS });
    }
    if (!dev.ignored || !silent) this.devices.delete(idx);
    for (const k of [...this.prevByConsumer.keys()]) if (k.startsWith(`${idx}:`)) this.prevByConsumer.delete(k);
    if (!silent) this.emitEvent({ type: 'disconnected', pad: { ...dev.info } });
  }

  private loadSaved(): Record<string, SlotId> {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    } catch {
      return {};
    }
  }
  private persist(): void {
    try {
      const m = this.loadSaved();
      for (const d of this.devices.values()) if (d.info.slot) m[d.info.key] = d.info.slot;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(m));
    } catch {
      // abaikan
    }
  }

  /* ------------ mapping universal per perangkat ------------ */
  getDevices(): PadInfo[] { this.scan(); return [...this.devices.values()].map(d => ({ ...d.info })); }
  getButtonMap(key: string): PadButtonMap {
    try { const all = JSON.parse(localStorage.getItem(MAP_STORAGE_KEY) || '{}'); return { ...DEFAULT_PAD_MAP, ...(all[key] || {}) }; }
    catch { return { ...DEFAULT_PAD_MAP }; }
  }
  setButtonMap(key: string, map: PadButtonMap): void {
    try { const all = JSON.parse(localStorage.getItem(MAP_STORAGE_KEY) || '{}'); all[key] = map; localStorage.setItem(MAP_STORAGE_KEY, JSON.stringify(all)); } catch { /* storage optional */ }
    this.emit();
  }
  assignSlot(index: number, slot: SlotId | null): void {
    const dev = this.devices.get(index); if (!dev) return;
    if (dev.info.slot && this.slots[dev.info.slot] === index) this.slots[dev.info.slot] = null;
    if (slot !== null) {
      const other = this.slots[slot];
      if (other !== null) { const od = this.devices.get(other); if (od) od.info.slot = null; }
      this.slots[slot] = index;
    }
    dev.info.slot = slot;
    this.persist(); this.emitEvent({ type: 'swapped' }); this.emit();
  }

  /* ------------ status & penugasan ------------ */
  getStatus(): Array<{ slot: SlotId; pad: PadInfo | null; reconnecting: boolean }> {
    this.scan();
    return ([1, 2, 3, 4] as SlotId[]).map((slot) => {
      const idx = this.slots[slot];
      const dev = idx !== null ? this.devices.get(idx) : undefined;
      let reconnecting = false;
      if (!dev) for (const r of this.reserved.values()) if (r.slot === slot && r.until > Date.now()) reconnecting = true;
      return { slot, pad: dev ? { ...dev.info } : null, reconnecting };
    });
  }
  getSpare(): PadInfo[] {
    return [...this.devices.values()].filter((d) => !d.info.slot).map((d) => ({ ...d.info }));
  }

  /** Tukar penugasan dua slot (mis. P1 <-> P2) */
  swapSlots(a: SlotId, b: SlotId): void {
    const ia = this.slots[a];
    const ib = this.slots[b];
    this.slots[a] = ib;
    this.slots[b] = ia;
    if (ia !== null) {
      const d = this.devices.get(ia);
      if (d) d.info.slot = b;
    }
    if (ib !== null) {
      const d = this.devices.get(ib);
      if (d) d.info.slot = a;
    }
    this.persist();
    this.emitEvent({ type: 'swapped' });
    this.emit();
  }

  /* ------------ pembacaan input ------------ */
  private deviceForSlot(slot: SlotId): { dev: Dev; gp: Gamepad } | null {
    const idx = this.slots[slot];
    if (idx === null) return null;
    const dev = this.devices.get(idx);
    if (!dev) return null;
    const gp = (navigator.getGamepads?.() ?? [])[idx];
    if (!gp || !gp.connected) return null;
    return { dev, gp };
  }

  /** Pad ternormalisasi untuk slot tertentu (menu) — null jika tidak ada controller di slot itu */
  getStd(slot: SlotId): StdPad | null {
    this.scan();
    const r = this.deviceForSlot(slot);
    return r ? standardize(r.gp, r.dev.info.kind) : null;
  }

  /** Controller dengan slot terendah (untuk navigasi menu) */
  getPrimaryStd(): StdPad | null {
    this.scan();
    for (const s of [1, 2, 3, 4] as SlotId[]) {
      const p = this.getStd(s);
      if (p) return p;
    }
    return null;
  }

  private edges(consumer: string, idx: number, std: StdPad): boolean[] {
    const key = `${idx}:${consumer}`;
    const prev = this.prevByConsumer.get(key) ?? [];
    const now = std.buttons.map((b) => b.pressed);
    this.prevByConsumer.set(key, now);
    return now.map((p, i) => p && !prev[i]);
  }

  /** Input permainan untuk satu player — hanya dari controller yang ditugaskan ke slot itu */
  readSlot(slot: SlotId, consumer = 'match'): SlotPadInput | null {
    this.scan();
    const r = this.deviceForSlot(slot);
    if (!r) return null;
    const std = standardize(r.gp, r.dev.info.kind);
    const map = this.getButtonMap(r.dev.info.key);
    const mapped = (action: PadAction) => ({ pressed: !!r.gp.buttons[map[action]]?.pressed, value: r.gp.buttons[map[action]]?.value ?? 0 });
    const e = this.edges(`${consumer}:${slot}`, r.dev.info.index, { buttons: Array.from({length:16}, (_,i) => ({pressed: !!r.gp.buttons[i]?.pressed, value: r.gp.buttons[i]?.value ?? 0})), axes: std.axes });
    let { x, y } = applyRadialDeadzone(std.axes[0], std.axes[1]);
    if (x === 0 && y === 0) {
      const dx = (std.buttons[15].pressed ? 1 : 0) - (std.buttons[14].pressed ? 1 : 0);
      const dy = (std.buttons[13].pressed ? 1 : 0) - (std.buttons[12].pressed ? 1 : 0);
      const m = Math.hypot(dx, dy);
      if (m > 0) {
        x = dx / m;
        y = dy / m;
      }
    }
    return {
      moveX: x,
      moveZ: y,
      run: Math.hypot(x, y) > 0.72,
      kickPressed: mapped('kick').pressed && e[map.kick],
      kickHeld: mapped('kick').pressed,
      jumpPressed: mapped('jump').pressed && e[map.jump],
      kickRightPressed: mapped('kick2').pressed && e[map.kick2],
      kickRightHeld: mapped('kick2').pressed,
      grabPressed: mapped('grab').pressed && e[map.grab],
      headPressed: mapped('head').pressed && e[map.head],
      dashPressed: mapped('dash').pressed && e[map.dash],
      startPressed: mapped('start').pressed && e[map.start],
    };
  }

  /** True jika salah satu controller yang ditugaskan baru menekan tombol standar tertentu */
  edgeAny(consumer: string, buttons: number[]): boolean {
    this.scan();
    let hit = false;
    for (const s of [1, 2, 3, 4] as SlotId[]) {
      const r = this.deviceForSlot(s);
      if (!r) continue;
      const std = standardize(r.gp, r.dev.info.kind);
      const e = this.edges(`${consumer}:any${s}`, r.dev.info.index, std);
      if (buttons.some((b) => e[b])) hit = true;
    }
    return hit;
  }

  /** Tombol Start pada controller mana pun = Start / Menu (pause) */
  private pollStart(): void {
    if (this.devices.size === 0) return;
    if (this.edgeAny('start-event', [9])) window.dispatchEvent(new CustomEvent('wobble-gamepad-start'));
  }
}

export const gamepadManager = new GamepadManager();
